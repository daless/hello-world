
# Cigna
# project id = 195	
#CIGNA PROCLAIM	DBSWP0626
# RACER00195


setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
#library(h2o)
#h2o.init()
#library(h2oEnsemble)




conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

conn2 = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACER00195;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)




# table listing in db
# table_listing <- as.data.frame(sqlTables(conn))
# write.table(table_listing, file = "table_listing_racer_research.csv",
#             row.names = FALSE, sep ="\t")
# 
# pars_fileds <- sqlColumns(
# conn, "dbo.PARS"  )
# 
# 
# write.table(table_listing, file = "PARS_fileds.csv",
#             row.names = FALSE, sep ="\t")


# from spreadsheet Data Science Proclaim Leakage Data & Data Science Data Pull Leakage sql code.sql


# need to confirm DATE_LOADED_RADAR is the filed to use for data fences and what edate span shoul be

claim_fileds <- sqlColumns(
  conn, "dbo.CLAIMS"  )
  
  
par1 <- sqlQuery(
  conn,
  " select * from dbo.PARS as p 
where p.project_Id = 195
and p.adjusted_feed_Id = 586
and p.bill_type != 0
and p.adjustment_code is not null
and p.AAL_TREND_OPPORTUNITY = 0
and p.OPS_MISSED_OPPORTUNITY = 0
and p.FULL_REFUND_FLAG = 0
and p.DATE_LOADED_RADAR >= '2018-03-01'
"
  ,max = 100)



# claim pull

# PATIENT_ID = 1000809643

junk1 <- sqlQuery(
  conn,"select  PATIENT_ID from dbo.PARS where  PATIENT_ID = 1000809643")


junk1 <- sqlQuery(
  conn2,"select  PATIENT_ID from dbo.CLAIM where  PATIENT_ID = 1000809643")

table_listing <- as.data.frame(sqlTables(conn2))
 claims_fileds <- sqlColumns(
 conn2, "dbo.CLAIM"  )


junk2 <-  (sqlQuery(conn2, "select c.* from dbo.CLAIM c 
                   where c.PATIENT_ID = (sqlQuery(conn,select PATIENT_ID from dbo.PARS where  PATIENT_ID = 1000809643))"))
 
 


par_claim1 <-  sqlQuery(
  conn,
  "select c.* from dbo.CLAIMS  c
  INNER JOIN dbo.PARS p
  ON  c.PATIENT_ID = p.PATIENT_ID
  WHERE p.project_Id = 195
  and p.adjusted_feed_Id = 586
  and p.bill_type != 0
  and p.adjustment_code is not null
  and p.AAL_TREND_OPPORTUNITY = 0
  and p.OPS_MISSED_OPPORTUNITY = 0
  and p.FULL_REFUND_FLAG = 0
  and p.DATE_LOADED_RADAR >= '2018-03-01'
  " ,max = 100)



par_claim1 <-  sqlQuery(
  conn,
  "select c.* from dbo.CLAIMS  c
  INNER JOIN dbo.PARS p
  ON  c.PATIENT_ID = p.PATIENT_ID
  WHERE c.CLAIM_NO = p.CLAIM_NO
  and p.project_Id = 195
  and p.adjusted_feed_Id = 586
  and p.bill_type != 0
  and p.adjustment_code is not null
  and p.AAL_TREND_OPPORTUNITY = 0
  and p.OPS_MISSED_OPPORTUNITY = 0
  and p.FULL_REFUND_FLAG = 0
  and p.DATE_LOADED_RADAR >= '2018-03-01'
  " ,max = 100)















par_claim1 <-  sqlQuery(
  conn,
  "select c.* from dbo.CLAIMS  c
INNER JOIN dbo.PARS  p
  on c.PATIENT_ID = p.PATIENT_ID
  on c.CLAIM_NO = p.CLAIM_NO
and p.project_Id = 195
and p.adjusted_feed_Id = 586
and p.bill_type != 0
and p.adjustment_code is not null
and p.AAL_TREND_OPPORTUNITY = 0
and p.OPS_MISSED_OPPORTUNITY = 0
and p.FULL_REFUND_FLAG = 0
and p.DATE_LOADED_RADAR >= '2018-03-01'
  " ,max = 100)






# exclusions from reson codes

par1$exclu <-( ifelse(grepl(
  "dependent", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE),1,
  ifelse(grepl(
    "medicare", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE), 1, 
    ifelse(grepl(
      "other insurance", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE), 1,
      ifelse(grepl(
        "medicare", par1$ADJSTMNT_RSN_CD2, ignore.case = TRUE), 1, 0)))))
  

# remove text exclusions
par1 <- sqldf("select * from par1 where exclu = 0" )
par1$exclu <- NULL


# exclude members with 10+ records in study period

member10 <- sqldf("select  PAT_MEMBER_NO as MEM,  count() as cnt  from par1 group by PAT_MEMBER_NO")

par1 <- sqldf("select p.* from par1 as p, member10 as m  where p.PAT_MEMBER_NO = m.MEM" )

rm(member10 )

#str(par1, list.len=ncol(par1))
