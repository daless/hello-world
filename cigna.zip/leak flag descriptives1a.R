
setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(kamila)
library(cluster)
library(arules)
library(h2o)
h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)





claim_flag1 <-
  sqlQuery(
    conn,
    "Select d.* ,  p.ADJUSTED_FEED_ID,
p.SURGERY_CPT_FLAG
from dbo.Cigna_PARS_Racer_Claim d, dbo.PARS p where
    d.CLAIM_ID = p.ORIG_CLAIM_ID
    and p.PROJECT_ID = 195
    and p.Is_Par_Claim = 1
    and d.AMT_PAID >= 250
    and d.BILL_TYPE >= 3
    and d.BILL_TYPE != 721
    AND p.post_optum_leakage_flag = 1
    AND p.CLAIM_TYPE_FLAG = 0
    AND p.FULL_REFUND_FLAG = 1
    AND p.POST_OPTUM_LEAKAGE_FLAG = 1
    " )



claim_flag1 <-
  sqlQuery(
    conn,
    "Select d.* ,  p.ADJUSTED_FEED_ID,
    p.SURGERY_CPT_FLAG,
    p.CT_Flag,
    p.Trauma_Burn_Flag,
    p.Cancer_Flag,
    p.SubAcute_Flag,
    p.NICU_Flag,
    p.BoarderBaby_Flag,
    p.Therapy_Flag,
    p.Ambulance_Flag
    from dbo.Cigna_PARS_Racer_Claim d, dbo.PARS p where
    d.CLAIM_ID = p.ORIG_CLAIM_ID
    and p.PROJECT_ID = 195
    and p.Is_Par_Claim = 1
    and d.AMT_PAID >= 250
    and d.BILL_TYPE >= 3
    and d.BILL_TYPE != 721
    AND p.post_optum_leakage_flag = 1
    AND p.CLAIM_TYPE_FLAG = 0
    AND p.FULL_REFUND_FLAG = 1
    AND p.POST_OPTUM_LEAKAGE_FLAG = 1
    " )
