
# Cigna
# project id = 195	
#CIGNA PROCLAIM	DBSWP0626
# RACER00195

# OSOD1  4/1/18 - 5/31/18
# OSOD2 2/1/18 - 3/31/18
# OSOD3 12/1/17 - 1/31/18

# study date 60 days is SOP fopr investigation 10/1/17 - 11/30/17

setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
#library(h2o)
#h2o.init()
#library(h2oEnsemble)




conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

conn2 = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACER00195;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)


#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#
#  KEEP FOR PRODUCTION
#
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# date fences for study and claims
# max_date <- sqlQuery(
#   conn,
#   " select max(DATE_LOADED_RADAR) as mx_date from dbo.PARS ")
# 
# max_date$mx_date60 <- date(as.character(max_date$mx_date)) - 60
# max_date$mx_date365 <-date(as.character(max_date$mx_date)) - 365
# 
# date_fence <- max_date$mx_date60 
# date_fence2 <- max_date$mx_date365









# table listing in db
# table_listing <- as.data.frame(sqlTables(conn))
# write.table(table_listing, file = "table_listing_racer_research.csv",
#             row.names = FALSE, sep ="\t")
# 
# pars_fileds <- sqlColumns(
# conn, "dbo.PARS"  )
# 
# 
# write.table(table_listing, file = "PARS_fileds.csv",
#             row.names = FALSE, sep ="\t")


# from spreadsheet Data Science Proclaim Leakage Data & Data Science Data Pull Leakage sql code.sql


# need to confirm DATE_LOADED_RADAR is the filed to use for data fences and what edate span shoul be

#claim_fileds <- sqlColumns(
#  conn, "dbo.CLAIMS"  )
  
  

# 
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# #
# #  KEEP FOR PRODUCTION
# #
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# 
# 
# pars_string <- paste(" select * from dbo.PARS as p 
#                      where p.project_Id = 195
#                      and p.adjusted_feed_Id = 586
#                      and p.bill_type != 0
#                      and p.adjustment_code is not null
#                      and p.AAL_TREND_OPPORTUNITY = 0
#                      and p.OPS_MISSED_OPPORTUNITY = 0
#                      and p.FULL_REFUND_FLAG = 0
#                      and p.DATE_LOADED_RADAR >='" ,date_fence , "'", sep = "")
# 
# 
# par1 <- sqlQuery(
#   conn,pars_string)
# 

# PARS 60 day study period



par1 <-sqlQuery(conn, " select * from dbo.PARS as p
                     where p.project_Id = 195
                     and p.adjusted_feed_Id = 586
                     and p.bill_type != 0
                     and p.adjustment_code is not null
                     and p.AAL_TREND_OPPORTUNITY = 0
                     and p.OPS_MISSED_OPPORTUNITY = 0
                     and p.FULL_REFUND_FLAG = 0
                     and p.DATE_LOADED_RADAR >= '2017-10-01' 
                 and p.DATE_LOADED_RADAR <= '2017-11-30'"
)

par1 <-sqlQuery(conn, " select * from dbo.PARS as p
                     where p.project_Id = 195
                and p.adjusted_feed_Id = 586
                and p.bill_type != 0
                and p.adjustment_code is not null
                and p.AAL_TREND_OPPORTUNITY = 0
                and p.OPS_MISSED_OPPORTUNITY = 0
                and p.FULL_REFUND_FLAG = 0
                and p.DATE_LOADED_RADAR >= '2017-10-01'
                "
)

par1 <- sqldf("select * from par1 where DATE_LOADED_RADAR <= '2017-11-30'")


# exclusions from reson codes

par1$exclu <-( ifelse(grepl(
  "dependent", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE),1,
  ifelse(grepl(
    "medicare", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE), 1, 
    ifelse(grepl(
      "other insurance", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE), 1,
      ifelse(grepl(
        "medicare", par1$ADJSTMNT_RSN_CD2, ignore.case = TRUE), 1, 0)))))
  

# remove text exclusions
par1 <- sqldf("select * from par1 where exclu = 0" )
par1$exclu <- NULL


# exclude members with 10+ records in study period

member10 <- sqldf("select  PAT_MEMBER_NO as MEM,  count() as cnt  from par1 group by PAT_MEMBER_NO")

par1 <- sqldf("select p.* from par1 as p, member10 as m  where p.PAT_MEMBER_NO = m.MEM" )

rm(member10 )

#str(par1, list.len=ncol(par1))

write.table(par1, file = "par1.csv",
            row.names = FALSE, sep ="\t")
#par1 <- read.csv("par1.csv", header=TRUE, sep="\t")

# distinct values to merge to claims

par2 <- sqldf("select DISTINCT CLAIM_NO, ORIG_CLAIM_ID as CLAIM_ID, PATIENT_ID from par1")





# 
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# #
# #  KEEP FOR PRODUCTION
# #
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# 
# 

# claims_string <- paste(
#   " select p.* from dbo.CLAIM p where
#   p.project_Id = 195
#   and p.bill_type != 0
#   and p.DATE_PAID  >='",
#   date_fence2 ,
#   "'",
#   sep = ""
# )
# 
# 
# 
# 
# claims1 <- sqlQuery(
#   conn2, claims_string) 




claims1 <- sqlQuery(
  conn2,
  " select p.* from dbo.CLAIM p where
  p.project_Id = 195
  and p.bill_type != 0
  and p.DATE_PAID  >= '2017-06-01' OR p.DATE_LOADED_RADAR <= '2017-11-30'")





junk<- sqldf(
  "select distinct p.* from claims1 p, par2 r
  where p.PATIENT_ID = r.PATIENT_ID
  order by p.PATIENT_ID" 
)


junk2 <- sqldf(" select distinct PATIENT_ID from junk")



str(junk, list.len=ncol(junk))


write.table(claims1, file = "claims1.csv",
            row.names = FALSE, sep ="\t")

#claims1 <- read.csv("claims1.csv", header=TRUE, sep="\t")