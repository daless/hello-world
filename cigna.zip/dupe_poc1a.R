
library(proxy)


# from leakage code
# members with 2+ claims

rangeStandardize <- function(x) {
  (x - min(x)) / diff(range(x))
}


member_multi <- sqldf("select PAT_MEMBER_NO, count(PAT_MEMBER_NO) as memcnt from claim1 group by PAT_MEMBER_NO having memcnt >= 2")

#LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL  OOOOOOO PPPPPPPPPPPPPPPPPPPPPPPPP
# build example to test code

cl_dup1 <- sqldf("select c.* from claim1 c, member_multi m where
                 c.PAT_MEMBER_NO = m.PAT_MEMBER_NO
                 AND m.PAT_MEMBER_NO = '001424377ESANDRA G'
                 ORDER BY DATE_OF_SERVICE_BEG")


# NORMALIZATION

# number_list <- c(names(Filter(is.numeric,cl_dup1)))
# number_match <- match(number_list, names(cl_dup1))
# number_match <- cl_dup1[,number_match]
# 
# number_names <- colnames(number_match)
# 
# cl_dup1b <- cl_dup1
# conVars <- cl_dup1[,number_names]
# conVars <- as.data.frame(lapply(conVars, rangeStandardize))
# 
# cl_dup1b[number_names] <- NULL
# cl_dup2 <- cbind(conVars,cl_dup1b )


cl_dup1$DATE_OF_SERVICE_BEG <- as.factor(as.character(cl_dup1$DATE_OF_SERVICE_BEG))
cl_dup1$DATE_OF_SERVICE_END  <-  as.factor(as.character(cl_dup1$DATE_OF_SERVICE_END))
cl_dup1$CLS_PROCESSING_DATE <-  as.factor(as.character(cl_dup1$CLS_PROCESSING_DATE))


cl_dup2 <- as.data.frame(as.matrix(simil(cl_dup1, by_rows = TRUE,   method = "simple matching")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),1)

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)


# examples below all work as alternatives to simple
# 
# (proxy::dist(cl_dup1, by_rows = TRUE, method = "Jaccard"))
# 
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "simple matching")
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Kulczynski1")
# 
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Kulczynski2")
# 
# # possible score
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Fager")
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Russel")
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Faith")
# 
# 
# 
# proxy::simil(cl_dup1, by_rows = TRUE, method = "Fager")
# proxy::simil(cl_dup1, by_rows = TRUE, method = "Faith")
# 
# 
# cl_dup2 <- as.data.frame(as.matrix(dist(cl_dup1, by_rows = TRUE, method = "Faith")))
# 





