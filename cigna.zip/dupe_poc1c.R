
library(proxy)
library(reshape2)
library(plyr)
library(dplyr)

# from leakage code
# members with 2+ claims

rangeStandardize <- function(x) {
  (x - min(x)) / diff(range(x))
}


member_multi <- sqldf("select PAT_MEMBER_NO, count(PAT_MEMBER_NO) as memcnt from claim1 group by PAT_MEMBER_NO having memcnt >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 10, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Jaccard', 'Kulczynski1', 'Kulczynski2', "Mountford", 'Fager', 'Russel', 
                   'simple_matching', 'Hamman', 'Faith')
colnames(scores) <- score_columns


# make empty df for formatting

icd_base <- data.frame(matrix(ncol = 11, nrow = 0))
b <- c('CLAIM_ID', 'DX1', 'DX2', 'DX3', 'DX4', 'DX5', 'DX6', 'DX7', 'DX8', 'DX9', 'DX10')
colnames(icd_base) <- b

proc_base <- data.frame(matrix(ncol = 11, nrow = 0))
p <- c('CLAIM_ID', 'PROC1', 'PROC2', 'PROC3', 'PROC4', 'PROC5', 'PROC6', 'PROC7', 'PROC8', 'PROC9', 'PROC10')
colnames(proc_base) <- p

doc_base <- data.frame(matrix(ncol = 6, nrow = 0))
d <- c('CLAIM_ID', 'PROV1', 'PROV2', 'PROV3', 'PROV4', 'PROV5')
colnames(doc_base) <- d

# dummy df dx codes
dummy_dx <- data.frame(matrix(ncol = 3, nrow = 10))
dumb <- c('CLAIM_ID', 'ICD9_CODE', 'icd_cntr')
colnames(dummy_dx) <- dumb
dummy_dx$CLAIM_ID <- -1
dummy_dx$ICD9_CODE <- 'FOO'
dummy_dx$icd_cntr <- 1:nrow(dummy_dx)

# dummy for proc codes
dummy_p <- data.frame(matrix(ncol = 3, nrow = 10))
dumbp <- c('CLAIM_ID', 'CPT', 'proc_cntr')
colnames(dummy_p) <- dumbp
dummy_p$CLAIM_ID <- -1
dummy_p$CPT <- 'FOO'
dummy_p$proc_cntr <- 1:nrow(dummy_p)

# dummy for providers
dummy_doc <- data.frame(matrix(ncol = 3, nrow = 5))
dumbd <- c('CLAIM_ID', 'PROVIDER_NO', 'prov_cntr')
colnames(dummy_doc) <- dumbd
dummy_doc$CLAIM_ID <- -1
dummy_doc$PROVIDER_NO <- 'FOO'
dummy_doc$prov_cntr <- 1:nrow(dummy_doc)



#LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL  OOOOOOO PPPPPPPPPPPPPPPPPPPPPPPPP
# build example to test code

cl_dup1 <- sqldf("select c.* from claim1 c, member_multi m where
                 c.PAT_MEMBER_NO = m.PAT_MEMBER_NO
                 AND m.PAT_MEMBER_NO = '001424377ESANDRA G'
                 ORDER BY DATE_OF_SERVICE_BEG")


# NORMALIZATION

# number_list <- c(names(Filter(is.numeric,cl_dup1)))
# number_match <- match(number_list, names(cl_dup1))
# number_match <- cl_dup1[,number_match]
# 
# number_names <- colnames(number_match)
# 
# cl_dup1b <- cl_dup1
# conVars <- cl_dup1[,number_names]
# conVars <- as.data.frame(lapply(conVars, rangeStandardize))
# 
# cl_dup1b[number_names] <- NULL
# cl_dup2 <- cbind(conVars,cl_dup1b )


cl_dup1$DATE_OF_SERVICE_BEG <- as.factor(as.character(cl_dup1$DATE_OF_SERVICE_BEG))
cl_dup1$DATE_OF_SERVICE_END  <-  as.factor(as.character(cl_dup1$DATE_OF_SERVICE_END))
cl_dup1$CLS_PROCESSING_DATE <-  as.factor(as.character(cl_dup1$CLS_PROCESSING_DATE))



# add dx codes

icd_dup1 <- sqldf("select i.CLAIM_ID, i.ICD9_CODE from icd1 i , cl_dup1 c
                  where i.CLAIM_ID = c.CLAIM_IDx
                  order by i.CLAIM_ID")

# add counter for dx code
icd_dup1 <- ddply(icd_dup1, .(CLAIM_ID), mutate, icd_cntr = seq_along(ICD9_CODE))
# add dummy rows to make max 10 dx codes
icd_dup1 <- rbind(icd_dup1,dummy_dx )

icd_dup1 <- dcast(icd_dup1,  CLAIM_ID ~icd_cntr, value.var = "ICD9_CODE")
j <- colnames(icd_dup1)
icd_dup1 <- icd_dup1  %>% rename_at(vars(j), ~ b)
# remove dummy
icd_dup1 <- sqldf("select * from icd_dup1 where CLAIM_ID != -1")
icd_dup1 <- icd_dup1 %>% replace(is.na(.),0)


# procedures
# only top 10 procedures in alpha order

proc_dup1 <- sqldf(
  "select p.CLAIM_ID, p.CPT FROM proc1b p, cl_dup1 c
  where p.CLAIM_ID = c.CLAIM_IDx
  and p.CPT != ''
  order by p.CLAIM_ID, p.CPT "
) 
# add counter for proc code
proc_dup1 <- ddply(proc_dup1, .(CLAIM_ID), mutate, proc_cntr = seq_along(CPT))

# TOP 10 PROC CODES
proc_dup1 <- sqldf("select * from proc_dup1 where proc_cntr <= 10")

# add dummy rows to make max 10 dx codes
proc_dup1 <- rbind(proc_dup1,dummy_p )

# transpose
proc_dup1 <- dcast(proc_dup1,  CLAIM_ID ~proc_cntr, value.var = "CPT")
pd <- colnames(proc_dup1)
proc_dup1 <- proc_dup1  %>% rename_at(vars(pd), ~ p)
# remove dummy
proc_dup1 <- sqldf("select * from proc_dup1 where CLAIM_ID != -1")
proc_dup1<- proc_dup1 %>% replace(is.na(.),0)


# providers



prov_dup1 <- sqldf(
  "select p.CLAIM_ID, p.PROVIDER_NO FROM prov_list p, cl_dup1 c
  where p.CLAIM_ID = c.CLAIM_IDx
  order by p.CLAIM_ID, p.PROVIDER_NO "
) 

# add counter for prov code
prov_dup1 <- ddply(prov_dup1, .(CLAIM_ID), mutate, prov_cntr = seq_along(PROVIDER_NO))

# TOP 5 PROv CODES
prov_dup1 <- sqldf("select * from prov_dup1 where prov_cntr <= 5")

# add dummy rows to make max 10 dx codes
prov_dup1 <- rbind(prov_dup1,dummy_doc )

# transpose
prov_dup1 <- dcast(prov_dup1,  CLAIM_ID ~prov_cntr, value.var = "PROVIDER_NO")
pv <- colnames(prov_dup1)
prov_dup1 <- prov_dup1  %>% rename_at(vars(pv), ~ d)
# remove dummy
prov_dup1 <- sqldf("select * from prov_dup1 where CLAIM_ID != -1")
prov_dup1<- prov_dup1 %>% replace(is.na(.),0)


# merge files

dupes <- sqldf("select * from cl_dup1 d, icd_dup1 i where d.CLAIM_IDx = i.CLAIM_ID")
dupes$CLAIM_ID <- NULL
dupes <- sqldf("select * from cl_dup1 d, proc_dup1  i where d.CLAIM_IDx = i.CLAIM_ID")
dupes$CLAIM_ID <- NULL
dupes <- sqldf("select * from cl_dup1 d,prov_dup1  i where d.CLAIM_IDx = i.CLAIM_ID ORDER BY DATE_OF_SERVICE_BEG")
dupes$CLAIM_IDx <- NULL

score_append <- sqldf("select distinct PAT_MEMBER_NO from dupes")

cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "simple matching")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),1)

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$simple_matching <- member_score

cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Jaccard")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),1)

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$Jaccard <- member_score


cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Kulczynski1")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <-0

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$Kulczynski1 <- member_score

cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Kulczynski2")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <-0

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$Kulczynski2 <- member_score

cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Mountford")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <-0

member_score <- sum(cl_dup2)
score_append$Mountford <- member_score

cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Fager")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <-0

member_score <- sum(cl_dup2)
score_append$Fager <- member_score

cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Russel")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <-0

member_score <- sum(cl_dup2)
score_append$Russel <- member_score


cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Hamman")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <-0

member_score <- sum(cl_dup2)
score_append$Hamman <- member_score

cl_dup2 <- as.data.frame(as.matrix(simil(dupes, by_rows = TRUE,   method = "Faith")))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.),1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <-0

member_score <- sum(cl_dup2)
score_append$Faith <- member_score

scores <- rbind(scores, score_append)





# examples below all work as alternatives to simple
# 
# (proxy::dist(cl_dup1, by_rows = TRUE, method = "Jaccard"))
# 
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "simple matching")
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Kulczynski1")
# 
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Kulczynski2")
# 
# # possible score
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Fager")
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Russel")
# 
# proxy::dist(cl_dup1, by_rows = TRUE, method = "Faith")
# 
# 
# 
# proxy::simil(cl_dup1, by_rows = TRUE, method = "Fager")
# proxy::simil(cl_dup1, by_rows = TRUE, method = "Faith")
# 
# 
# cl_dup2 <- as.data.frame(as.matrix(dist(cl_dup1, by_rows = TRUE, method = "Faith")))
# 
