


setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
#library(h2o)
#h2o.init()
#library(h2oEnsemble)




connx = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

table_listing <- as.data.frame(sqlTables(connx))

icd_fields <- sqlColumns(
conn, "DBDataAnalytics-DM.Cigna_PARS_Racer_ICD9"  )

