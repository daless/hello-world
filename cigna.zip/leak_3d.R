
setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(kamila)
library(cluster)
library(arules)
library(h2o)
h2o.init()
#library(h2oEnsemble)




conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

# 
#  pars_fileds <- sqlColumns( conn, "dbo.Cigna_PARS_Racer_ICD9"  )
#  pars_fields <- sqlColumns( conn, "dbo.PARS"  )
# 
#  
 
 par1 <- sqlQuery(
   conn,
   " select * from dbo.PARS as p
   where p.PROJECT_ID = 195
   and p.DATE_LOADED_RADAR >= '2018-05-20'
   and (p.OPTUMREFUND = '0' OR p.OPTUMREFUND = 'NONOPTUM')"
 )
 

deletes_pars <- c('PROJECT_NAME', 	'ORIGINAL_PAID_AMT', 	'ORIGINAL_BILLED_AMT', 	'ADJUSTED_PAID_AMT',
                  'ADJUSTED_BILLED_AMT', 	'DRG', 	'SRC_MBR_LAST_NM', 	'CLAIM_RESERACH_STATUS',
                  'MAX_ADJUST_DATE', 	'CLOSED_AND_LATER_ID', 	'COB_ONLY_CASE_HITS', 	'PCT_PAID',
                  'LOS', 	'PRINCIPAL_DIAG', 	'MATERNITY_FLAG', 	'FULL_REFUND_FLAG', 
                  'ADJUSTMENT_NOTES', 	'AAL_TREND_OPPORTUNITY', 	'RADAR_EXCLUDED', 
                  'DISCHARGE_STATUS', 	'MEDICAID_ID', 	'MEDICARE_ID', 	'LOAD_COMPLETE', 
                  'Part_A_Coverage_Status', 	'Part_A_Coverage_Status_Reason', 
                  'Part_A_Coverage_Status_Date_Updated', 	'Part_A_Coverage_Status_User_Updated', 
                  'Part_B_Coverage_Status', 	'Part_B_Coverage_Status_Reason', 
                  'Part_B_Coverage_Status_Date_Updated', 	'Part_B_Coverage_Status_User_Updated', 
                  'Commercial_Coverage_Status', 	'Commercial_Coverage_Status_Date_Updated', 
                  'Commercial_Coverage_Status_User_Updated', 	'Invalid_SSN', 	'Invalid_DOB', 
                  'Restricted_Group_Policy', 	'Date_Restricted', 	'Group_Name', 	'line_of_business', 
                  'product_line', 	'member_value', 	'Part_A_status_changes', 	
                  'Part_B_status_changes', 	'SF_1', 	'SF_3', 	'SF_6', 	'SF_7', 	'SF_9', 
                  'SF_10', 	'SF_12', 	'SF_13', 	'SF_14', 	'SF_15', 	'SF_16', 	'SF_17', 
                  'SF_18', 	'SF_19', 	'SF_20', 	'MEDICARE_CASE_HIT_APPLIED', 
                  'DATE_ANALYTIC_ID_APPLIED', 	'PART_A_EFF_DATE', 	'PART_B_EFF_DATE', 
                  'COMM_EFF_DATE', 	'CLOSED_BY_WASTE_SCRAPE', 	'CLOSED_BY_CLOSE_PROCESS', 
                  'COB_Refund', 	'Duplicate_Refund', 	'Optum_CreditBalance', 	'Tagged_Date', 
                  'ADJSTMNT_RSN_CD3', 	'ADJSTMNT_RSN_CD4', 	'IS_RESTRICED', 
                  'EXTERNAL_INTERNAL_VENDOR', 	'ADHOC_CASE')

par1[deletes_pars] <- NULL


deletes2_pars <- c('TAX_ID', 	'REL_TO_INS', 	'PROV_STATE', 	'PROV_NAME', 	'PROJECT_ID', 	
                   'PRE_CLAIM_NO', 	'PATIENT_ZIP', 	'PATIENT_STATE', 	'ORIGINAL_FEED_ID', 
                   'INVALID_DOB', 	'INS_GROUP_NO', 	'INITIAL_DATE_MEMBER_RECEIVED', 
                   'INITIAL_DATE_CLAIM_RECEIVED', 	'GROUP_1', 	'DATE_OF_BIRTH', 
                   'DATE_LOADED_RADAR', 	'DATE_LOADED_RACER_ORIG_FEED', 	
                   'DATE_LOADED_RACER_ADJ_FEED', 	'DATE_IDENTIFIED', 	'CURRENT_ANALYTIC_ID', 
                   'ADJ_CLAIM_ID','TAXONOMY_CODE'
)

par1[deletes2_pars] <- NULL




delete3_pars <- c('	PROVIDER_NO', 	'PROV_STATE', 
                  'PROJECT_ID', 	'PROD_CASE_HIT', 	'PROCEDURE_SERVICE_EXCLUSION', 	'PRE_CLAIM_NO', 
                  'PATIENT_ID', 	'PAT_MEMBER_NO', 	'ORIGINAL_FEED_ID', 
                  'ORIGINAL_DATE_PAID',  	'OPTUMREFUND', 
                  'OPS_MISSED_OPPORTUNITY', 	'NPI', 	'NOTE', 	'NOT_WORKABLE_BY_TAGGED_DATE', 
                  'NOT_LOADED_TO_RACER', 	'NON_CANDD_REFUND', 	'MEDICARE_DEDUCTIBLES', 
                  'IS_PARTB_CLAIM', 	'IS_PARTA_CLAIM', 	'IS_PAR_CLAIM', 	'INVALID_DOB', 
                  'INS_GROUP_NO', 	'INITIAL_DATE_MEMBER_RECEIVED', 	'INITIAL_DATE_CLAIM_RECEIVED',
                  'GROUP_1', 	'EXTERNALVENDOR', 	'EXTERNAL_CASE_HIT', 	'EXPLORATORY_ONLY_HIT', 
                  'END_DOS', 	'DATE_OF_BIRTH', 	'DATE_LOADED_RADAR', 	'DATE_LOADED_RACER_ORIG_FEED', 
                  'DATE_LOADED_RACER_ADJ_FEED', 	'DATE_IDENTIFIED', 	'CURRENT_ANALYTIC_ID', 
                  'COMM_CASE_HIT_APPLIED', 	'COB_CLAIM_INDICATOR', 	'COB_AMT_PAID', 
                  'CLAIM_TYPE_FLAG', 	'CLAIM_NO', 	'BELOW_OPTUM_DECISION_REFUND_THRE', 
                  'BELOW_CLIENT_REFUND_THRESHOLD', 	'BEG_DOS', 	'AGE_GROUP', 	
                  'AGE_AT_TIME_OF_CLAIM', 	'ADJUSTMENT_NOTES', 	'ADJUSTMENT_CODE', 
                  'ADJUSTED_FEED_ID', 	'ADJSTMNT_RSN_CD4', 	'ADJSTMNT_RSN_CD3', 
                  'ADJSTMNT_RSN_CD2', 	'ADJSTMNT_RSN_CD1', 	'ADJSTMNT_RSN_CD', 
                  'ADJ_DATE_PAID', 	'ADJ_CLAIM_ID')

par1[delete3_pars] <- NULL



# top 10 dx codes



icd1 <-
  sqlQuery(conn,
           "Select d.* from dbo.Cigna_PARS_Racer_ICD9 d, dbo.PARS p where
           d.CLAIM_ID = p.ORIG_CLAIM_ID 
           and d.ICD9_TYPE ='DIAG10'
           and p.PROJECT_ID = 195
and d.ORDER_IN_CLAIM <= 9
           AND p.DATE_LOADED_RADAR >= '2018-05-20'
           and (p.OPTUMREFUND = '0' OR p.OPTUMREFUND = 'NONOPTUM')")


icd1$ICD9_CODE <- gsub(".","",icd1$ICD9_CODE, fixed = TRUE)

CCS_lookup <- read.csv("ccs_dx_icd10cm_2018_1.csv", sep = ",",  quote = "\"", header = TRUE)
# rename columns
CCS_lookup$ICD9_CODE <- CCS_lookup$X.ICD.10.CM.CODE.
CCS_lookup$CCS_DX <- CCS_lookup$X.CCS.CATEGORY.
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))

icd2 <- sqldf("select i.*, c.CCS_DX from icd1 i,CCS_lookup c where i.ICD9_CODE = c.ICD9_CODE ")

icd2$ICD9_TYPE <- NULL
icd2$ADMITTING_CODE <- NULL
icd2$PRINCIPAL_CODE <- NULL
icd2$CLAIM_LINE_ID <- NULL
icd2$ORDER_IN_CLAIM <- NULL



icd3 <- sqldf("select * from icd2 order by CLAIM_ID ")


charlson_scores <- comorbidity(x=icd3, id = "CLAIM_ID",  code = "ICD9_CODE", score = "charlson_icd10")
elixhauser_scores <- comorbidity(x=icd3, id = "CLAIM_ID", code = "ICD9_CODE", score = "elixhauser_icd10")


charlson_scores <- sqldf("select CLAIM_ID, wscore as Charlson_score from charlson_scores")
elixhauser_scores <- sqldf("select CLAIM_ID, wscore as Elixhauser_score from elixhauser_scores")

# 
# write.table(charlson_scores, file = "charlson_scores.csv",
#             row.names = FALSE, sep ="\t")
# 
# write.table(elixhauser_scores, file = "elixhauser_scores.csv",
#             row.names = FALSE, sep ="\t")


icd3 <- sqldf("select i.*, c.Charlson_score from icd3 i, charlson_scores c
              where i.CLAIM_ID = c.CLAIM_ID ")

icd3 <- sqldf("select i.*, c.Elixhauser_score from icd3 i, elixhauser_scores c
              where i.CLAIM_ID = c.CLAIM_ID ")

icd3$ICD9_CODE <- NULL





claim1 <-
  sqlQuery(conn,
           "Select d.* from dbo.Cigna_PARS_Racer_Claim d, dbo.PARS p where
           d.CLAIM_ID = p.ORIG_CLAIM_ID 
           and p.PROJECT_ID = 195
           AND p.DATE_LOADED_RADAR >= '2018-05-20'
           and (p.OPTUMREFUND = '0' OR p.OPTUMREFUND = 'NONOPTUM')")



deletes_claims <- c( 	'CLS_TOT_COIN_AMT', 	'CLS_TOT_DEDUCTIBLE', 
                    'CLS_TOT_EXPERIENCE_AMT', 	'CLS_TOT_NET_CHNG_TO_COBR', 
                    'CLS_TOT_PENALTY_INTEREST', 	'CLS_TOT_PLAN_LIAB', 	'CLS_TOT_PREV_OOP', 
                    'SUB_MEMBER_NO', 	'PROVIDER_NO', 	'PRINCIPAL_DIAG', 	'PAT_DATE_OF_BIRTH', 
                    'paid_to_allowed', 	'INS_GROUP_NO', 	'CLS_WITHHOLD_IND', 	'CLS_VHS_IND',
                    'CLS_VERIFY_CODE', 	'CLS_UR_SSO_IND', 	'CLS_UR_PREADM_IND',
                    'CLS_UR_OUTPAT_IND', 	'CLS_UR_ADMIT_NUM', 	'CLS_TYPE_COVS', 	'CLS_TYPE_COB',
                    'CLS_TYPE_CERTIFICATION', 	'CLS_TRANS_TYP_CODE', 	'CLS_TOT_AVAIL_BENE_CRED',
                    'CLS_TOT_AMT_OTHER_CARRIER', 	'CLS_TEAM', 	'CLS_SUPPRESSED_WITHHOLD',
                    'CLS_SUPPRESSED_AMT', 	'CLS_STD_INDUSTRY_CODE', 	'CLS_SCHEDULE', 
                    'CLS_REGION_IND', 	'CLS_RECD_DATE', 	'CLS_QUALITY_CENTER_IND', 
                    'CLS_PVP_PROC_DT', 	'CLS_PROV_OBA_IND', 	'CLS_PRE_OPER', 	'CLS_PAY_OPER', 
                    'CLS_PAT_SEX', 	'CLS_PAT_RELATION', 	'CLS_PAT_MARITAL_STATUS', 
                    'CLS_PAT_HANDICAPPED_STATUS', 	'CLS_PAT_EMPLOYED_STATUS', 
                    'CLS_ORTHO_MSG_IND', 	'CLS_OPER', 	'CLS_OOB_FIX_IND')


deletes_claims2 <- c('CLS_OOB_FIX_DATE', 
                    'CLS_NEW_COB_IND', 	'CLS_MGD_CARE_PRODS', 	'CLS_MEDICARE_PAID_AMT', 
                    'CLS_MEDICAID_IND', 	'CLS_MED_RX_ADMIN_CODE', 	'CLS_MDCR_OR_INS', 
                    'CLS_LTD_POOL_GR_ACCT_NUM', 	'CLS_ISSUE_CHGCR_KEY_BYTE', 
                    'CLS_ICD_CD_NF_INDS', 	'CLS_HWC_PLAN_IND', 	'CLS_GR_ACCT_NUM', 
                    'CLS_FUNDING_ARRANGEMENT', 	'CLS_FSA_REQ_AMT', 	'CLS_FSA_CARRYOVER_AMT', 
                    'CLS_FIELD_OFFICE', 	'CLS_EXP_CODE_II', 	'CLS_ERROR_TYPE', 
                    'CLS_ERROR_TAG', 	'CLS_ERISA_EOB_MSG_IND', 	'CLS_EPO_ESCROW_AMT', 
                    'CLS_EPO_BENEFIT_IND', 	'CLS_EOB_PD_MSG_NUM', 	'CLS_EOB_IND', 	
                    'CLS_DRG_PDM_IND', 	'CLS_DRG_CODE', 	'CLS_DRAFT_STATUS_CODE', 
                    'CLS_DOC_SPLIT_IND', 	'CLS_DOC_NUM', 	'CLS_DLET_DOC_FIELD', 
                    'CLS_DISP_DATE', 	'CLS_DECEASED_ASSN_MBR', 	'CLS_DATE_TIME_STAMP',
                    'CLS_DATE_SICKNESS_BEGAN', 	'CLS_DATE_PREV_FINALIZED', 	'CLS_CURR_STATUS', 
                    'CLS_CODE_ERROR_CODE', 	'CLS_COB_CREDIT', 	'CLS_CLM_LEV_ACM_IND', 
                    'CLS_CLM_CAUSE_5', 	'CLS_CLM_CAUSE_4', 	'CLS_CLM_CAUSE_3', 	'CLS_CLM_CAUSE_2',
                    'CLS_CLM_CAUSE_1', 	'CLS_CLASS_NUM', 	'CLS_CLAIMCHECK_IND', 
                    'CLS_CLAIM_NO_II', 	'CLS_CHARGE_CREDIT_KEY', 	'CLS_CASE_MGT_REVIEW_NO', 
                    'CLS_CANCELLED_ACCT_IND', 	'CLS_AUTOCODER_IND', 	'CLS_AUTH_TEAM', 
                    'CLS_AUTH_OPER', 	'CLS_ACP_SOURCE_IND', 	'CLS_ACP_REFERENCE_NUM', 
                    'CLAIM_NO', 	 	'ALTERNATE_MEMBER_ID', 	'CLS_FSA_FLAG', 
                    'CLS_ORTHO_RECERT_MAIL_TO', 	'CLS_PAT_STUDENT_STATUS')



claim1[deletes_claims] <- NULL
claim1[deletes_claims2] <- NULL

claim1$AMT_PAID[is.na(claim1$AMT_PAID)] <- 0
claim1$AMT_ALLOWED[is.na(claim1$AMT_ALLOWED)] <- 0





claim1$AMT_PAID <- ifelse(is.nan(claim1$AMT_PAID), 0, claim1$AMT_PAID)
claim1$AMT_ALLOWED <- ifelse(is.nan(claim1$AMT_ALLOWED), 0, claim1$AMT_ALLOWED)


claim1$paid_to_allowed <- sqrt((claim1$AMT_PAID /claim1$AMT_ALLOWED + 1))
claim1$paid_to_allowed <- ifelse(is.nan(claim1$paid_to_allowed), 0, claim1$paid_to_allowed)  




#### BUILD study table

par2 <- sqldf("select p.*, i.* from par1 p, icd3 i where p.ORIG_CLAIM_ID = i.CLAIM_ID" )


claim1$CLAIM_IDx = claim1$claim_id
claim1$BILL_TYPE <- NULL

par3 <-
  sqldf(
    "select c.* , e.*
    from par2 c, claim1 e
    where c.CLAIM_ID = e.CLAIM_IDx
    and c.BILL_TYPE  != 0"
  )


par3 %>% replace(is.na(.), 0)


# factor conversions

facts <- c('AMBSURG_FLAG', 	'Ambulance_Flag', 	'ANESTHESIA_CPT_FLAG', 
           'Below_Client_Refund_Threshold', 	'Below_Optum_Decision_Refund_Threshold', 
            	'CCS_DX', 	'CLS_CALC_IND', 	'CLS_CASE_MGT_PLAN_IND', 
           'CLS_CAUSE_ACC_SICK', 	'CLS_CAUSE_VEHICLE', 	'CLS_SBU_IND', 
           'COB_Claim_Indicator', 	'CTSCAN_FLAG', 	'current_analytic_ID', 
           'DIALYSIS_FLAG', 	'DME_CPT_Flag', 	'DRUG_CPT_FLAG', 	'DRUG_FLAG',
           'EM_CPT_FLAG', 	'ER_FLAG', 	'Facility_Anesthesia_Flag', 	'HOSPICE_FLAG', 
           'IMPLANT_FLAG', 	'INTENSIVECARE_FLAG', 	'Is_Par_Claim', 
           'MEDICINE_CPT_FLAG', 	'MRI_FLAG', 	'Non_CandD_Refund', 
           'Not_Workable_By_Tagged_Date', 	'OBSERVATION_FLAG', 	'PATHLABS_CPT_FLAG', 
           'RADIOLOGY_CPT_FLAG', 	'SF_2', 	'SF_4', 	'SF_5', 	'SNF_Rehab_Flag', 
           'SURGERY_CPT_FLAG', 	'SURGERY_FLAG', 'CLS_PROVIDENT_COMPANY',
            'POS', 'BILL_TYPE')




par3[,facts] <- lapply(par3[,facts],as.factor)


delete_parts4 <- c( 	'claim_id', 	'CLAIM_IDx', 	'cob_amt_paid', 
                 'current_analytic_ID', 	'Date_Identified', 	'DATE_OF_SERVICE_BEG',
                 'DATE_OF_SERVICE_END', 	'Initial_Date_Claim_Received', 
                 'Initial_Date_Member_Received', 	'is_partA_claim', 	'is_partB_claim',
                 'medicare_deductibles', 	'ORIG_CLAIM_ID', 	'PAT_MEMBER_NO', 
                 'PATIENT_ACCT_NO', 	'PROVIDER_NO', 'AMT_PAID', 'AMT_BILLED', 'AMT_ALLOWED',
                 'CLS_BATCH_ADJUDICATE_IND', 'CLS_BULKED_AMT', 'CLS_BULKED_WITHHOLD',
                 'CLS_PEN_INTEREST_GR_ACCT_NUM','CLS_PROCESSING_DATE', 'CLS_TOT_ALLOW_EXP',
                 'CLS_TOT_AMT_CURR_PAID', 'CLS_WORK_COMP_CLM', 'POST_OPTUM_LEAKAGE_FLAG'
                 )


par3[delete_parts4] <- NULL



par3$YR1_SUM_AMT_PAID[is.na(par3$YR1_SUM_AMT_PAID)] <- 0
par3$YR3_SUM_AMT_PAID[is.na(par3$YR3_SUM_AMT_PAID)] <- 0

# 
# write.table(par3, file = "par3.csv",
#             row.names = FALSE, sep ="\t")

# clustering



# list of factor variables for RF feature reduction

# remove CCS run CCS below
fact_reduce <- par3
fact_reduce$CCS_DX <- NULL

fact_reduce$CLAIM_ID <- NULL
fact_reduce$SF_8 <- NULL
fact_reduce$SF_4 <- NULL
fact_reduce$SF_11 <- NULL
fact_reduce$SF_2 <- NULL

factor_list <- c(names(Filter(is.factor,fact_reduce)))
fact_match <- match(factor_list, names(fact_reduce))
fact_match <- fact_reduce[,fact_match]

# add dummy target
fact_model <- sqldf("select REFUND_AMT from par3")
fact_model <- cbind(fact_model, fact_match)



fact_model_h2o <- as.h2o(fact_model)
y <- "REFUND_AMT"
x <- setdiff(names(fact_model_h2o), y)

fact_list3 <- h2o.randomForest(x=x,
                              y = y,
                              training_frame = fact_model_h2o,
                              ntrees = 50,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)


fact_list3_var_import <- h2o.varimp(fact_list3)


# top 15 factors
fact_list3_var_import <-fact_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 15)


k1 <- cbind(fact_list3_var_import, dummy(fact_list3_var_import$variable , sep= ""))
colnames(k1) <- (gsub("fact_list3_var_import", "",  colnames(k1)))
k1$variable <- NULL
k1$relative_importance <- NULL
k1$scaled_importance <-NULL
k1$percentage <- NULL

factor_names <- colnames(k1)

# factor table
fact_match2 <- match(factor_names, names(fact_reduce))
fact_match2 <- fact_reduce[,fact_match2]


# get continous features
# drop dummy target variable from list from random froest
fact_reduce2 <- fact_reduce
fact_reduce2$REFUND_AMT <- NULL 

number_list <- c(names(Filter(is.numeric,fact_reduce2)))
number_match <- match(number_list, names(fact_reduce2))
number_match <- fact_reduce2[,number_match]

number_names <- colnames(number_match)




#### CCs feature reduction


CCS_Dummy_test <- sqldf("select CCS_DX from par3")


CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_DX , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test", "CCS_",  colnames(CCS_Dummy_test)))
# group by client id
#CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
#CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy3_test <- lapply(CCS_Dummy3_test, factor)
CCS_Dummy3_test <- as.data.frame(CCS_Dummy3_test)
CCS_Dummy3_test$CCS__0 <- NULL
CCS_Dummy3_test$CCS_DX <- NULL

CCS_list2 <- sqldf("select REFUND_AMT from par3")
CCS_list2 <- cbind(CCS_list2, CCS_Dummy3_test)


CCS_list2_h2o <- as.h2o(CCS_list2)
y <- "REFUND_AMT"
x <- setdiff(names(CCS_list2_h2o), y)

CCS_list3 <- h2o.randomForest(x=x,
                              y = y,
                              training_frame = CCS_list2_h2o,
                              ntrees = 50,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)


CCS_list3_var_import <- h2o.varimp(CCS_list3)


# top 15 comrobidites
CCS_list3_import <-CCS_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 15)
CCS_list3_import$CCS <- CCS_list3_import$variable


# get CCS comorbid list
j1 <- cbind(CCS_list3_import, dummy(CCS_list3_import$CCS , sep= "_"))
colnames(j1) <- (gsub("CCS_list3_import_", "",  colnames(j1)))
j1$CCS <- NULL
j1$variable <- NULL
j1$relative_importance  <- NULL
j1$scaled_importance  <- NULL
j1$percentage  <- NULL

neph_names <- colnames(j1)
# keep neph comordities

neph_match <- match(neph_names, names(CCS_list2))

neph_match <- CCS_list2[,neph_match]

par3$CCS_DX <- NULL



par4 <- cbind(fact_match2, neph_match)
par4 <- cbind(par4, number_match)
clid <- sqldf("select CLAIM_ID from par3")
par4 <- cbind(par4, clid)
par4 <- sqldf("select distinct * from par4")
id<- sqldf("select CLAIM_ID from par4")

par4$CLAIM_ID <- NULL

# 
# write.table(par4, file = "par4.csv",
#             row.names = FALSE, sep ="\t")
# 
# 
# par4 <- read.csv("par4.csv",  sep="\t", header = TRUE)
 


catVarsFac <- c(names(Filter(is.factor,par4)))
conInd <- number_names


#
# sum(is.na(par3$Age_at_time_of_claim))
# sum(is.na(par3$Charlson_score))
# sum(is.na(par3$Elixhauser_score))
# sum(is.na(par3$paid_to_allowed))
# sum(is.na(par3$REFUND_AMT))
# sum(is.na(par3$YR1_SUM_AMT_PAID))
# sum(is.na(par3$YR3_SUM_AMT_PAID))
# summary(par3$paid_to_allowed)
# summary(par3$Age_at_time_of_claim)

rangeStandardize <- function(x) {
  (x - min(x)) / diff(range(x))
}


L1Dist <- function(v1, v2) {
  sum(abs(v1 - v2))
}
matchingDist <- function(v1, v2) {
  sum(as.integer(v1) != as.integer(v2))
}


# pam function wrapper

pamix <- function(connData, catData, conWeight, nclust, ...) {
  conData <- as.data.frame(conVars)
  catData <- as.data.frame(catVarsFac)
  distmat <- daisy(x= cbind(conData, catData), metric = "gower",
                   weights = rep(c(conWeight, 1 - conWeight),
                                 times = c(ncol(conData), ncol(catData))))
  clustRes <- pam(x = distMat, k = nclust, diss = TRUE, ...)
  return(list(cluster = clustRes$clustering,
              conCenters = conData[clustRes$id.med, , drop = FALSE],
              catCenters = catData[clustRes$id.med, , drop = FALSE]))
}


set.seed(77)
conVars <- par4[,conInd]
#conVars <- data.frame(scale(conVars))
conVars <- as.data.frame(lapply(conVars, rangeStandardize))

catVarsFac[] <- lapply(catVarsFac, factor)
catVarsDum <- dummyCodeFactorDf(catVarsFac)




set.seed(77)

gmsResHw <- gmsClust(conVars,catVarsDum, nclust = 3 )
gmsResLloyd <- gmsClust(conVars,catVarsDum, nclust = 3 ,
                     algorithm = "Lloyd", searchDensity = 10)



factor_list3 <- c(names(Filter(is.factor,par4)))
fact_match3 <- match(factor_list3, names(par4))
catVarsFac <- par4[,fact_match3]

# kamRes <- kamila(conVars, catVarsFac, numClust = 4, numInit = 10,
#                 maxIter = 50)
kamRes2 <- kamila(conVars, catVarsFac, numClust = 2 : 10, numInit = 10,
                 calcNumClust = "ps", numPredStrCvRun = 10, predStrThresh = 0.5,  maxIter = 50)


kam_membership<- as.data.frame(kamRes2$finalMemb)
number_clusters <- as.data.frame(kamRes2$nClust$bestNClust)
cluster_strength <- as.data.frame(kamRes2$nClust$avgPredStr)

plotDatKam <- cbind(id,conVars, catVarsFac, Cluster = factor(kamRes2$finalMemb) )


# remove standardized continuous data and reload orignial data
# this makes rules easier to implament

plotDatKam <- plotDatKam[,!colnames(plotDatKam) %in% conInd]
conVars <- par4[,conInd]
plotDatKam <- cbind(plotDatKam ,conVars )



# C5 by cluster


C5a <- plotDatKam


C5a$target <- ifelse(C5a$Cluster == 1,1,0)
C5a$target <- as.factor(as.character(C5a$target))
C5b <- C5a
C5b$Cluster <- NULL


y <- c("target")
x <- colnames(C5b)

ruleC5 <- C5.0(target ~., data = C5b, rules = TRUE, winnow = TRUE)
#sink('treeC5_tree_boost.txt')
summary(ruleC5 )
#sink()




C5a$target <- ifelse(C5a$Cluster == 2,1,0)
C5a$target <- as.factor(as.character(C5a$target))
C5b <- C5a
C5b$Cluster <- NULL


y <- c("target")
x <- colnames(C5b)

ruleC5_boost <- C5.0(target ~., data = C5b, rules = TRUE, winnow = TRUE)
#sink('treeC5_tree_boost.txt')
summary(ruleC5_boost )


# apriori cpt codes

# https://datascienceplus.com/implementing-apriori-algorithm-in-r/







proc1 <-
  sqlQuery(
    conn,
    "Select d.* from dbo.Cigna_PARS_Racer_Claim_Line d, dbo.PARS p where
    d.CLAIM_ID = p.ORIG_CLAIM_ID
    and p.PROJECT_ID = 195
    AND p.DATE_LOADED_RADAR >= '2018-05-20'
    AND p.REFUND_AMT >0
    and (p.OPTUMREFUND = '0' OR p.OPTUMREFUND = 'NONOPTUM')"
  )


id_1 <- sqldf("select CLAIM_ID from plotDatKam where cluster = 1")

proc1b <- sqldf("select distinct  p.CLAIM_ID, p.CPT from proc1 p, id_1 i 
                where p.CLAIM_ID = i.CLAIM_ID
                order by p.CLAIM_ID")


proc1b  %>% replace(is.na(.), "")


proc1b <- sqldf("select distinct * from proc1b where CPT != '' order by CLAIM_ID")


HCPC_meta  <- read.csv("HCPC.csv", header=TRUE, sep="\t")

# HCPC BETOS
proc1c <- sqldf("select distinct p.*, h.BETOS from proc1b p, HCPC_meta h where p.CPT = h.HCPC 
                order by p.CLAIM_ID")



# find counts by betos












# remove library dplyr

if(sessionInfo()['basePkgs']=="dplyr" | sessionInfo()['otherPkgs']=="dplyr"){
  detach(package:dplyr, unload=TRUE)
}
library(plyr)

df_itemList <- ddply(proc1b, c("CLAIM_ID"),
                     function(proc1b)
                       paste(proc1b$CPT,
                             collapse = ","))


df_itemList$CLAIM_ID <- NULL
colnames(df_itemList) <- c("itemList")

write.table(df_itemList, file = "ItemList.csv", quote = FALSE,
            row.names = TRUE, sep ="\t")

txn <- read.transactions("ItemList.csv",  format="basket",sep="\t",cols=1)
summary(txn)
itemFrequencyPlot(txn,topN=20, type='absolute')


CPT_rules <- apriori(txn)

CPT_rules <- apriori(txn,parameter = list(sup = 0.1 ,conf = 0.4,  
                                          minlen = 2, maxlen=10, target="rules"))


# transaction clean up
txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)


df_itemList$itemList <- as.factor(df_itemList$itemList)


df_itemList2 <- as(df_itemList, "transactions")
summary(df_itemList2)
inspect(df_itemList2)

#df_itemList$itemList <- as.factor(df_itemList$itemList)

CPT_rules <- apriori(df_itemList,parameter = list(sup = 0.1, conf = 0.5))

CPT_rules <- apriori(txn,parameter = list(sup = 0.1, conf = 0.5))

CPT_rules <- apriori(df_itemList2,parameter = list(sup = 0.5, conf = 0.5,
                                                   minlen = 2, maxlen=10, target="frequent"))


inspect(CPT_rules)

CPT_rules <- as(CPT_rules, "data.frame")

