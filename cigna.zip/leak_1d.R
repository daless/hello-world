
# Cigna
# project id = 195	
#CIGNA PROCLAIM	DBSWP0626
# RACER00195

# OSOD1  4/1/18 - 5/31/18
# OSOD2 2/1/18 - 3/31/18
# OSOD3 12/1/17 - 1/31/18

# study date 60 days is SOP fopr investigation 10/1/17 - 11/30/17

setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
#library(h2o)
#h2o.init()
#library(h2oEnsemble)




conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

conn2 = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACER00195;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)


#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#
#  KEEP FOR PRODUCTION
#
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

# date fences for study and claims
# max_date <- sqlQuery(
#   conn,
#   " select max(DATE_LOADED_RADAR) as mx_date from dbo.PARS ")
# 
# max_date$mx_date60 <- date(as.character(max_date$mx_date)) - 60
# max_date$mx_date365 <-date(as.character(max_date$mx_date)) - 365
# 
# date_fence <- max_date$mx_date60 
# date_fence2 <- max_date$mx_date365









# table listing in db
 # table_listing <- as.data.frame(sqlTables(conn2))
 # write.table(table_listing, file = "table_listing_RACER00195.csv",
 #             row.names = FALSE, sep ="\t")
# 
# pars_fileds <- sqlColumns(
# conn, "dbo.PARS"  )
# 
# 
# write.table(table_listing, file = "PARS_fileds.csv",
#             row.names = FALSE, sep ="\t")


# from spreadsheet Data Science Proclaim Leakage Data & Data Science Data Pull Leakage sql code.sql


# need to confirm DATE_LOADED_RADAR is the filed to use for data fences and what edate span shoul be

#claim_fileds <- sqlColumns(
#  conn, "dbo.CLAIMS"  )
  
  

# 
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# #
# #  KEEP FOR PRODUCTION
# #
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# 
# 
# pars_string <- paste(" select * from dbo.PARS as p 
#                      where p.project_Id = 195
#                      and p.adjusted_feed_Id = 586
#                      and p.bill_type != 0
#                      and p.adjustment_code is not null
#                      and p.AAL_TREND_OPPORTUNITY = 0
#                      and p.OPS_MISSED_OPPORTUNITY = 0
#                      and p.FULL_REFUND_FLAG = 0
#                      and p.DATE_LOADED_RADAR >='" ,date_fence , "'", sep = "")
# 
# 
# par1 <- sqlQuery(
#   conn,pars_string)
# 

# PARS 60 day study period



par1 <-sqlQuery(conn, " select * from dbo.PARS as p
                     where p.project_Id = 195
                     and p.adjusted_feed_Id = 586
                     and p.bill_type != 0
                     and p.adjustment_code is not null
                     and p.AAL_TREND_OPPORTUNITY = 0
                     and p.OPS_MISSED_OPPORTUNITY = 0
                     and p.FULL_REFUND_FLAG = 0"
)

#par1$CLAIM_NO <- as.character(par1$CLAIM_NO)


# exclusions from reson codes

par1$exclu <-( ifelse(grepl(
  "dependent", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE),1,
  ifelse(grepl(
    "medicare", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE), 1, 
    ifelse(grepl(
      "other insurance", par1$ADJSTMNT_RSN_CD1, ignore.case = TRUE), 1,
      ifelse(grepl(
        "medicare", par1$ADJSTMNT_RSN_CD2, ignore.case = TRUE), 1, 0)))))
  

# remove text exclusions
par1 <- sqldf("select * from par1 where exclu = 0" )
par1$exclu <- NULL


# exclude members with 10+ records in study period

member10 <- sqldf("select  PAT_MEMBER_NO as MEM,  count() as cnt  from par1 group by PAT_MEMBER_NO")

par1 <- sqldf("select p.* from par1 as p, member10 as m  where p.PAT_MEMBER_NO = m.MEM" )

rm(member10 )

#str(par1, list.len=ncol(par1))

write.table(par1, file = "par1.csv",
            row.names = FALSE, sep ="\t")
#par1 <- read.csv("par1.csv", header=TRUE, sep="\t")

# distinct values to merge to claims

par2 <- sqldf("select DISTINCT CLAIM_NO, ORIG_CLAIM_ID as CLAIM_ID, PATIENT_ID from par1")





# 
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# #
# #  KEEP FOR PRODUCTION
# #
# #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
# 
# 

# claims_string <- paste(
#   " select p.* from dbo.CLAIM p where
#   p.project_Id = 195
#   and p.bill_type != 0
#   and p.DATE_PAID  >='",
#   date_fence2 ,
#   "'",
#   sep = ""
# )
# 
# 
# 
# 
# claims1 <- sqlQuery(
#   conn2, claims_string) 



claim_f <- sqlColumns(
 conn2, "dbo.FD_CIGNA_PROCLAIM_CLM"  )






claims1 <- sqlQuery(
  conn2,
  " select
  ALTERNATE_MEMBER_ID,
  AMT_ALLOWED,
  AMT_BILLED,
  AMT_PAID,
  BILL_TYPE,
  CLAIM_NO,
  CLS_ACP_REFERENCE_NUM,
  CLS_ACP_SOURCE_IND,
  CLS_AUTH_OPER,
  CLS_AUTH_TEAM,
  CLS_AUTOCODER_IND,
  CLS_BATCH_ADJUDICATE_IND,
  CLS_BULKED_AMT,
  CLS_BULKED_WITHHOLD,
  CLS_CALC_IND,
  CLS_CALC_TYPE,
  CLS_CANCELLED_ACCT_IND,
  CLS_CASE_MGT_PLAN_IND,
  CLS_CASE_MGT_REVIEW_NO,
  CLS_CAUSE_ACC_SICK,
  CLS_CAUSE_EMERG,
  CLS_CAUSE_VEHICLE,
  CLS_CHARGE_CREDIT_KEY,
  CLS_CLAIM_FORM_TYPE,
  CLS_CLAIM_NO_II,
  CLS_CLAIMCHECK_IND,
  CLS_CLASS_NUM,
  CLS_CLM_CAUSE_1,
  CLS_CLM_CAUSE_2,
  CLS_CLM_CAUSE_3,
  CLS_CLM_CAUSE_4,
  CLS_CLM_CAUSE_5,
  CLS_CLM_LEV_ACM_IND,
  CLS_COB_CREDIT,
  CLS_CODE_ERROR_CODE,
  CLS_CURR_STATUS,
  CLS_DATE_PREV_FINALIZED,
  CLS_DATE_SICKNESS_BEGAN,
  CLS_DATE_TIME_STAMP,
  CLS_DECEASED_ASSN_MBR,
  CLS_DISP_DATE,
  CLS_DLET_DOC_FIELD,
  CLS_DOC_NUM,
  CLS_DOC_SPLIT_IND,
  CLS_DRAFT_STATUS_CODE,
  CLS_DRG_CODE,
  CLS_DRG_PDM_IND,
  CLS_EOB_IND,
  CLS_EOB_PD_MSG_NUM,
  CLS_EPO_BENEFIT_IND,
  CLS_EPO_ESCROW_AMT,
  CLS_ERISA_EOB_MSG_IND,
  CLS_ERROR_TAG,
  CLS_ERROR_TYPE,
  CLS_EXP_CODE_II,
  CLS_FIELD_OFFICE,
  CLS_FSA_CARRYOVER_AMT,
  CLS_FSA_FLAG,
  CLS_FSA_REQ_AMT,
  CLS_FUNDING_ARRANGEMENT,
  CLS_GR_ACCT_NUM,
  CLS_HWC_PLAN_IND,
  CLS_ICD_CD_NF_INDS,
  CLS_ISSUE_CHGCR_KEY_BYTE,
  CLS_LTD_POOL_GR_ACCT_NUM,
  CLS_MDCR_OR_INS,
  CLS_MED_RX_ADMIN_CODE,
  CLS_MEDICAID_IND,
  CLS_MEDICARE_PAID_AMT,
  CLS_MGD_CARE_PRODS,
  CLS_NEW_COB_IND,
  CLS_OOB_FIX_DATE,
  CLS_OOB_FIX_IND,
  CLS_OPER,
  CLS_ORTHO_MSG_IND,
  CLS_ORTHO_RECERT_MAIL_TO,
  CLS_PAT_EMPLOYED_STATUS,
  CLS_PAT_HANDICAPPED_STATUS,
  CLS_PAT_MARITAL_STATUS,
  CLS_PAT_RELATION,
  CLS_PAT_SEX,
  CLS_PAT_STUDENT_STATUS,
  CLS_PAY_OPER,
  CLS_PEN_INTEREST_GR_ACCT_NUM,
  CLS_PRE_OPER,
  CLS_PROCESSING_DATE,
  CLS_PROV_OBA_IND,
  CLS_PROVIDENT_COMPANY,
  CLS_PRV_NETWORK_STATUS_IND,
  CLS_PVP_PROC_DT,
  CLS_QUALITY_CENTER_IND,
  CLS_RECD_DATE,
  CLS_REGION_IND,
  CLS_SBU_IND,
  CLS_SCHEDULE,
  CLS_STD_INDUSTRY_CODE,
  CLS_SUPPRESSED_AMT,
  CLS_SUPPRESSED_WITHHOLD,
  CLS_TEAM,
  CLS_TOT_ALLOW_EXP,
  CLS_TOT_AMT_CURR_PAID,
  CLS_TOT_AMT_OTHER_CARRIER,
  CLS_TOT_AVAIL_BENE_CRED,
  CLS_TOT_COIN_AMT,
  CLS_TOT_DEDUCTIBLE,
  CLS_TOT_EXPERIENCE_AMT,
  CLS_TOT_NET_CHNG_TO_COBR,
  CLS_TOT_PENALTY_INTEREST,
  CLS_TOT_PLAN_LIAB,
  CLS_TOT_PREV_OOP,
  CLS_TRANS_TYP_CODE,
  CLS_TYPE_CERTIFICATION,
  CLS_TYPE_COB,
  CLS_TYPE_COVS,
  CLS_UR_ADMIT_NUM,
  CLS_UR_OUTPAT_IND,
  CLS_UR_PREADM_IND,
  CLS_UR_SSO_IND,
  CLS_VERIFY_CODE,
  CLS_VHS_IND,
  CLS_WITHHOLD_IND,
  CLS_WORK_COMP_CLM,
  DATE_OF_SERVICE_BEG,
  DATE_OF_SERVICE_END,
  INS_GROUP_NO,
  PAT_DATE_OF_BIRTH,
  PAT_MEMBER_NO,
  PATIENT_ACCT_NO,
  PRINCIPAL_DIAG,
  PROVIDER_NO,
  SUB_MEMBER_NO
  from dbo.FD_CIGNA_PROCLAIM_CLM p where
  p.DATE_PAID  >= '2018-03-01'
  and p.DATE_PAID  <= '2018-05-31'
  and p.FEED_ID >= 534
  and p.FEED_ID <= 582"
)








claim_sample <- sqlQuery(
  conn2,
  " select p.* from dbo.FD_CIGNA_PROCLAIM_CLM  p ", max=100
)

write.table(claim_sample, file = "claim_sample.csv",
            row.names = FALSE, sep ="\t")



junk<- sqldf(
  "select distinct p.* from claims1 p, par2 r
  where p.CLAIM_NO = r.CLAIM_NO
  order by p.PATIENT_ID" 
)


junk2 <- sqldf(" select distinct PATIENT_ID from junk")



str(junk, list.len=ncol(junk))


write.table(claims1, file = "claims1.csv",
            row.names = FALSE, sep ="\t")

#claims1 <- read.csv("claims1.csv", header=TRUE, sep="\t")



#######################################################


# exploratory to get code for temp files

# dx codes

icd9_fields <- sqlColumns(conn2, "dbo.ICD9"  )

icd9_test <- sqlQuery(
  conn2,
  " select * from dbo.ICD9 where 	CLAIM_ID = 1570256829")


CLAIM_LINE_fields <- sqlColumns(conn2, "dbo.CLAIM_LINE"  )

claim_line_test <-  sqlQuery(
  conn2,
  " select * from dbo.CLAIM_LINE where 	CLAIM_ID = 1570256829")




prov_fields <- sqlColumns(conn2, "dbo.PROVIDER"  )
ProviderAttributefields <- sqlColumns(conn2, "dbo.ProviderAttribute"  )


