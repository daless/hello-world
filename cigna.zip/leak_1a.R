
# Cigna
# project id = 195	
#CIGNA PROCLAIM	DBSWP0626
# RACER00195


setwd("~/cigna")


#works
#conn = odbcDriverConnect(
#  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACER00195;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
#)


# table listing in db
table_listing <- as.data.frame(sqlTables(conn))


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

write.table(table_listing, file = "table_listing_racer_research.csv",
            row.names = FALSE, sep ="\t")

pars_fileds <- sqlColumns(
conn, "dbo.PARS"  )


write.table(table_listing, file = "PARS_fileds.csv",
            row.names = FALSE, sep ="\t")
