


setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
#library(h2o)
#h2o.init()
#library(h2oEnsemble)



# 
# connx = odbcDriverConnect(
#   'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
# )
# 
# table_listing <- as.data.frame(sqlTables(connx))
# 
# icd_fields <- sqlColumns(
# conn, "DBDataAnalytics-DM.Cigna_PARS_Racer_ICD9"  )


# comorbidities
icd2 <- read.csv("icd2.csv", header=TRUE, sep="\t")
icd3 <- sqldf("select CLAIM_ID, ICD9_CODE from icd2 where ORDER_IN_CLAIM <= 9 order by CLAIM_ID ")


charlson_scores <- comorbidity(x=icd3, id = "CLAIM_ID",  code = "ICD9_CODE", score = "charlson_icd10")
elixhauser_scores <- comorbidity(x=icd3, id = "CLAIM_ID", code = "ICD9_CODE", score = "elixhauser_icd10")


charlson_scores <- sqldf("select CLAIM_ID, wscore as Charlson_score from charlson_scores")
elixhauser_scores <- sqldf("select CLAIM_ID, wscore as Elixhauser_score from elixhauser_scores")


write.table(charlson_scores, file = "charlson_scores.csv",
            row.names = FALSE, sep ="\t")

write.table(elixhauser_scores, file = "elixhauser_scores.csv",
            row.names = FALSE, sep ="\t")





claim1 <- read.csv("claim2.csv", header = TRUE, sep = "\t")
proc2 <- read.csv("proc2.csv", header = TRUE, sep = "\t")
par1_clean <- read.csv("par1_clean.csv", header = TRUE, sep = "\t")
icd2_inpt_pivot <-
  read.csv("icd2_inpt_pivot.csv", header = TRUE, sep = "\t")



claim1_inpt <- sqldf("select * from par1_clean where bill_type >0")
claim1_inpt <-
  sqldf(
    "select c.* , e.Charlson_score, e.CLAIM_ID from claim1_inpt c, charlson_scores e
    where c.orig_claim_id = e.CLAIM_ID"
  )
claim1_inpt <-
  sqldf(
    "select c.* , e.Elixhauser_score from claim1_inpt c, elixhauser_scores e
    where c.CLAIM_ID = e.CLAIM_ID"
  )

claim1_inpt <-
  sqldf(
    "select c.* , e.CCS_0, e.CCS_1,e.CCS_2,e.CCS_3,e.CCS_4,e.CCS_5,e.CCS_6,
    e.CCS_7,e.CCS_8, e.CCS_9
    from claim1_inpt c, icd2_inpt_pivot e
    where c.CLAIM_ID = e.CLAIM_ID"
  )




claim1_inpt$Days_of_service <- difftime(claim1_inpt$end_dos ,
                                        claim1_inpt$beg_dos,
                                        units = c("days"))
claim1_inpt$Days_of_service <- claim1_inpt$Days_of_service + 1


claim1_inpt$X <- NULL
claim1_inpt$unnamed..0 <- NULL
claim1_inpt$taxonomy_code <- NULL
claim1_inpt$tax_id <- NULL
claim1_inpt$rel_to_ins <- NULL
claim1_inpt$provider_no <- NULL
claim1_inpt$prov_state <- NULL
claim1_inpt$project_id <- NULL
claim1_inpt$prod_case_hit <- NULL
claim1_inpt$procedure_service_exclusion <- NULL
claim1_inpt$pre_claim_no <- NULL
claim1_inpt$patient_state <- NULL
claim1_inpt$patient_id <- NULL
claim1_inpt$pat_member_no <- NULL
claim1_inpt$original_feed_id <- NULL
claim1_inpt$original_date_paid <- NULL
claim1_inpt$orig_claim_id <- NULL
claim1_inpt$optumrefund <- NULL
claim1_inpt$ops_missed_opportunity <- NULL
claim1_inpt$npi <- NULL
claim1_inpt$note <- NULL
claim1_inpt$not_workable_by_tagged_date <- NULL
claim1_inpt$not_loaded_to_racer <- NULL
claim1_inpt$non_candd_refund <- NULL
claim1_inpt$medicare_deductibles <- NULL
claim1_inpt$is_partb_claim <- NULL
claim1_inpt$is_parta_claim <- NULL
claim1_inpt$is_par_claim <- NULL
claim1_inpt$invalid_dob <- NULL
claim1_inpt$ins_group_no <- NULL
claim1_inpt$initial_date_member_received <- NULL
claim1_inpt$initial_date_claim_received <- NULL
claim1_inpt$group_1 <- NULL
claim1_inpt$externalvendor <- NULL
claim1_inpt$external_case_hit <- NULL
claim1_inpt$exploratory_only_hit <- NULL
claim1_inpt$end_dos <- NULL
claim1_inpt$date_of_birth <- NULL
claim1_inpt$date_loaded_radar <- NULL
claim1_inpt$date_loaded_racer_orig_feed <- NULL
claim1_inpt$date_loaded_racer_adj_feed <- NULL
claim1_inpt$date_identified <- NULL
claim1_inpt$current_analytic_id <- NULL
claim1_inpt$comm_case_hit_applied <- NULL
claim1_inpt$cob_claim_indicator <- NULL
claim1_inpt$cob_amt_paid <- NULL
claim1_inpt$claim_type_flag <- NULL
claim1_inpt$claim_no <- NULL
claim1_inpt$below_optum_decision_refund_thre <- NULL
claim1_inpt$below_client_refund_threshold <- NULL
claim1_inpt$beg_dos <- NULL
claim1_inpt$age_group <- NULL
claim1_inpt$age_at_time_of_claim <- NULL
claim1_inpt$adjustment_notes <- NULL
#claim1_inpt$adjustment_code <- NULL
claim1_inpt$adjusted_feed_id <- NULL
claim1_inpt$adjstmnt_rsn_cd4 <- NULL
claim1_inpt$adjstmnt_rsn_cd3 <- NULL
claim1_inpt$adjstmnt_rsn_cd2 <- NULL
claim1_inpt$adjstmnt_rsn_cd1 <- NULL
claim1_inpt$adjstmnt_rsn_cd <- NULL
claim1_inpt$adj_date_paid <- NULL
claim1_inpt$adj_claim_id <- NULL

str(claim1, list.len = ncol(claim1))

str(claim1, list.len=ncol(claim1))

claim1$X <- NULL
claim1$Unnamed..0 <- NULL
claim1$PATIENT_ACCT_NO <- NULL
claim1$PAT_MEMBER_NO <- NULL
claim1$DATE_OF_SERVICE_END <- NULL
claim1$DATE_OF_SERVICE_BEG <- NULL
claim1$CLS_WORK_COMP_CLM <- NULL
claim1$CLS_TOT_PREV_OOP <- NULL
claim1$CLS_TOT_PLAN_LIAB <- NULL
claim1$CLS_TOT_PENALTY_INTEREST <- NULL
claim1$CLS_TOT_NET_CHNG_TO_COBR <- NULL
claim1$CLS_TOT_EXPERIENCE_AMT <- NULL
claim1$CLS_TOT_DEDUCTIBLE <- NULL
claim1$CLS_TOT_COIN_AMT <- NULL
claim1$CLS_TOT_AMT_CURR_PAID <- NULL
claim1$CLS_TOT_ALLOW_EXP <- NULL
claim1$CLS_SBU_IND <- NULL
claim1$CLS_PRV_NETWORK_STATUS_IND <- NULL
claim1$CLS_PROVIDENT_COMPANY <- NULL
claim1$CLS_PROCESSING_DATE <- NULL
claim1$CLS_PEN_INTEREST_GR_ACCT_NUM <- NULL
claim1$CLS_BULKED_WITHHOLD <- NULL
claim1$CLS_BULKED_AMT <- NULL
claim1$CLAIM_NO <- NULL
claim1$BILL_TYPE <- NULL
claim1$AMT_PAID <- NULL
claim1$AMT_BILLED <- NULL
claim1$AMT_ALLOWED <- NULL

claim1$CLAIM_IDx = claim1$claim_id + 0


claim2_inpt <-
  sqldf(
    "select c.* , e.*
    from claim1_inpt c, claim1 e
    where c.CLAIM_ID = e.CLAIM_IDx", method = "name_class"
  )



# replace missings with none

claim2_inpt[claim2_inpt == ""] <- "None"



claim2_inpt$CLAIM_IDx  <- NULL
claim2_inpt$CLAIM_ID  <- NULL
claim2_inpt$claim_id <- NULL
claim2_inpt$prov_name <- NULL
claim2_inpt$patient_zip  <- NULL



#write.table(claim2_inpt, file = "claim2_inpt.csv",
 #           row.names = FALSE, sep ="\t")

# convert to factors

nominal <- c("ambsurg_flag", 	"ambulance_flag", 	"anesthesia_cpt_flag", 	
             "below_optum_decision_refund_threshold", 	"bill_type", 	"CCS_0",
             "CCS_1", 	"CCS_2", 	"CCS_3", 	"CCS_4", 	"CCS_5", 	"CCS_6", 	"CCS_7", 
             "CCS_8", 	"CCS_9", 	"CLS_BATCH_ADJUDICATE_IND", 	"CLS_CALC_IND",
             "CLS_CALC_TYPE", 	"CLS_CASE_MGT_PLAN_IND", 	"CLS_CAUSE_ACC_SICK",
             "CLS_CAUSE_EMERG", 	"CLS_CAUSE_VEHICLE", 	"CLS_CLAIM_FORM_TYPE", 
             "ctscan_flag", 	"dialysis_flag", 	"dme_cpt_flag", 	"drug_cpt_flag", 
             "drug_flag", 	"em_cpt_flag", 	"er_flag", 	"facility_anesthesia_flag", 
             "hospice_flag", 	"implant_flag", 	"intensivecare_flag", 
             "medicine_cpt_flag", 	"mri_flag", 	"observation_flag", 
             "pathlabs_cpt_flag", 	"patient_gender", 	"pos", 
             "post_optum_leakage_flag", 	"product", 	"radiology_cpt_flag", 
              	"snf_rehab_flag", "sf_2",  "sf_11", "sf_5",
             "surgery_cpt_flag", 	"surgery_flag", "adjustment_code") 

claim2_inpt[nominal] <- lapply(claim2_inpt[nominal], factor)

#sf_8 sf_4

str(claim2_inpt, list.len=ncol(claim2_inpt))


BILL_TYPE <- sqldf("select bill_type, count(bill_type) as count from claim2_inpt group by bill_type")

#claim2_inpt$yr3_sum_amt_paid <- as.numeric(as.character(claim2_inpt$yr3_sum_amt_paid))

# change continuous data to deciles

claim2_inpt$paid_to_allowed_bin <- ntile(claim2_inpt$paid_to_allowed, 10)
claim2_inpt$Days_of_service_bin <- ntile(claim2_inpt$Days_of_service, 10)
claim2_inpt$Elixhauser_score_bin <- ntile(claim2_inpt$Elixhauser_score, 10)
claim2_inpt$Charlson_score_bin <- ntile(claim2_inpt$Charlson_score, 10)
claim2_inpt$yr3_sum_amt_paid_bin <- ntile(claim2_inpt$yr3_sum_amt_paid, 10)
claim2_inpt$yr1_sum_amt_paid_bin <- ntile(claim2_inpt$yr1_sum_amt_paid, 10)
claim2_inpt$refund_amt_bin <- ntile(claim2_inpt$refund_amt, 10)



claim2_inpt$yr1_sum_amt_paid <- NULL
claim2_inpt$yr3_sum_amt_paid <- NULL
claim2_inpt$Charlson_score <- NULL
claim2_inpt$Elixhauser_score <-  NULL
claim2_inpt$Days_of_service <- NULL
claim2_inpt$paid_to_allowed <- NULL
claim2_inpt$refund_amt <-NULL

# put back in if can combine factor levels and rollup
claim2_inpt$sf_8 <- NULL
claim2_inpt$sf_4 <- NULL








nominal2 <- c("yr1_sum_amt_paid_bin", "yr3_sum_amt_paid_bin", "Charlson_score_bin", "Elixhauser_score_bin",
              "Days_of_service_bin", "paid_to_allowed_bin" , "refund_amt_bin" )


claim2_inpt[nominal2] <- lapply(claim2_inpt[nominal2], factor)

claim3_inpt <- claim2_inpt

claim3_inpt <- as.factor(claim3_inpt)

claim3_inpt <- data.matrix(claim3_inpt)

cluster_results <- kmodes(claim3_inpt, 5, iter.max = 10, weighted = FALSE)
cluster_results <- kmodes(claim3_inpt,1)



