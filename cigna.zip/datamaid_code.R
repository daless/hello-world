

setwd("~/cigna")
library(dataMaid)



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)

claim1 <- read.csv("claim1.csv", header=TRUE, sep="\t")
proc2 <- read.csv("proc2.csv", header=TRUE, sep="\t")
par1_clean <- read.csv("par1_clean.csv", header=TRUE, sep="\t")
icd2 <- read.csv("icd2.csv", header=TRUE, sep="\t")

str(par1_clean, list.len=ncol(par1_clean))

makeCodebook(claim1, vol="1",  
             replace = TRUE, render = TRUE,openResult = TRUE,
             reportTitle = "claim1 - Codebook")


makeCodebook(proc2, vol="1",  
             replace = TRUE, render = TRUE,openResult = TRUE,
             reportTitle = "proc2 - Codebook")

makeCodebook(icd2, vol="1",  
             replace = TRUE, render = TRUE,openResult = TRUE,
             reportTitle = "icd2 - Codebook")


makeCodebook(par1_clean, vol="1",  
             replace = TRUE, render = TRUE,openResult = TRUE,
             reportTitle = "par1_clean - Codebook")


