


setwd("~/cigna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(lubridate)



conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0626.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

# find maximum feed id

feed_id_range <- sqlQuery(
  conn,
  " select max(ADJUSTED_FEED_ID) as max_feed_id from dbo.PARS as p
  where p.PROJECT_ID = 195
  and p.post_optum_leakage_flag = 1"
)


# range of feed ids - use 3 for hx data most recent feed use to score


feed_id_range$low_feed = feed_id_range$max_feed_id - 4
feed_id_range$high_feed = feed_id_range$max_feed_id - 1



# use pars table to get the feed ids
#dbo.Cigna_PARS_Racer_ICD9 has the dx codes
# project id 195 is cigna

icd1 <-
  sqlQuery(conn,
           "Select d.*, p.ADJUSTED_FEED_ID from dbo.Cigna_PARS_Racer_ICD9 d, dbo.PARS p where
           d.CLAIM_ID = p.ORIG_CLAIM_ID 
           and d.ICD9_TYPE ='DIAG10'
           and p.PROJECT_ID = 195")


# limit to study feeds
icd1 <- sqldf("select p.* from icd1 p , feed_id_range f
              where p.ADJUSTED_FEED_ID >= f.low_feed
              and p.ADJUSTED_FEED_ID <= f.max_feed_id")

# remove decimals
icd1$ICD9_CODE <- gsub(".","",icd1$ICD9_CODE, fixed = TRUE)


icd3 <- sqldf("select * from icd1 order by CLAIM_ID ")

# compute elixhouser score
elixhauser_scores <- comorbidity(x=icd3, id = "CLAIM_ID", code = "ICD9_CODE", score = "elixhauser_icd10")


icd3 <- sqldf("select i.*, c.Elixhauser_score from icd3 i, elixhauser_scores c
              where i.CLAIM_ID = c.CLAIM_ID ")



# claims
claim1 <-
  sqlQuery(
    conn,
    "Select d.* ,  p.ADJUSTED_FEED_ID from dbo.Cigna_PARS_Racer_Claim d, dbo.PARS p where
    d.CLAIM_ID = p.ORIG_CLAIM_ID
    and p.PROJECT_ID = 195
    and len(d.BILL_TYPE) >= 3" )





claim1$BILL_TYPE <- as.character(claim1$BILL_TYPE)
claim1$b_type_flag <- substr(claim1$BILL_TYPE , start = 2, stop = 2)


# outpatient bill type c.bill_type NOT like ''_1_'' -- MIDDILE CHARACTER OF BILL TYPE CANNOT BE A 1
claim1 <- sqldf("select * from claim1 where b_type_flag != '1'")
claim1$b_type_flag <- NULL


# for study period

claim1 <-sqldf("select distinct p.* from claim1 p , feed_id_range f
               where p.ADJUSTED_FEED_ID >= f.low_feed
               and p.ADJUSTED_FEED_ID <= f.max_feed_id
               order by p.claim_Id")

str(claim1, list.len=ncol(claim1))





proc1 <-
  sqlQuery(
    conn,
    "Select d.* from dbo.Cigna_PARS_Racer_Claim_Line d, dbo.PARS p where
   d.CLAIM_ID = p.ORIG_CLAIM_ID
    and p.PROJECT_ID = 195
    and d.AMT_PAID >= 0
    order by d.CLAIM_ID"
  )



proc1<-sqldf("select distinct p.* from proc1 p , feed_id_range f
               where p.FEED_ID >= f.low_feed
               and p.FEED_ID <= f.max_feed_id
               order by p.CLAIM_ID")



