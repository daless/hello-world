
library(reshape2)
library(igraph)

CCS_spin1 <- sqldf("select CLAIM_ID, ORDER_IN_CLAIM, CCS_Category
                   from DX_CCS")


CCS_spin2 <- reshape(CCS_spin1, idvar = "CLAIM_ID", timevar = "ORDER_IN_CLAIM",direction = "wide" )
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.0'] <- 'CCS_1'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.2'] <- 'CCS_2'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.3'] <- 'CCS_3'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.4'] <- 'CCS_4'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.5'] <- 'CCS_5'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.6'] <- 'CCS_6'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.7'] <- 'CCS_7'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.8'] <- 'CCS_8'
colnames(CCS_spin2) [colnames(CCS_spin2) == 'CCS_Category.9'] <- 'CCS_9'
CCS_spin2[,11] <- NULL


CCS_spin3_matrix <- as.matrix(CCS_spin2)
network1 <- graph_from_incidence_matrix(CCS_spin3_matrix, directed = TRUE,
                                        multiple =TRUE, mode = "all")

edges <- do.call(rbind, Map(cbind, CCS_spin2[,1], apply(CCS_spin2[,-1], 1, na.omit)))
gg <- simplify(graph.edgelist(edges, directed = T))
get.adjacency(gg)


plot(gg, vertex.label.cex =.6, vertex.label.color = "black")

plot(network1, vertex.label.cex =.6, vertex.label.color = "black")


plot(gg, layout = layout.fruchterman.reingold(gg),
    edge.arrow.size = .2)


##########################

library(arules)
library(arulesViz)
library(visNetwork)
library(plyr)
library(igraph)


ap1 <- sqldf("select CLAIM_ID,  CCS_Category as CCS_DX
                   from DX_CCS")

ap1$CLAIM_ID <- as.factor(as.character((ap1$CLAIM_ID)))
ap1$CCS_DX <- as.factor(as.character((ap1$CCS_DX)))


ap2 <- ddply(ap1, c("CLAIM_ID"),
             function(ap1)paste(ap1$CCS_DX,
                                collapse = ','))

names(ap2)[2] <- "CCS"

ap3 <- ap2
ap3$CLAIM_ID <- NULL

write.csv(ap2, file = "ccs_transactions.csv")

txn <- read.transactions(file="ccs_transactions.csv", rm.duplicates = TRUE,
                         format="single", sep=",", cols=c("CLAIM_ID","CCS"))




# remove quotes
txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)

basket_rules <- apriori(txn,parameter = list(sup = 0.0001, 
                                             conf=0.0001, target="rules"))

# remove redundent rules
basket_rules <- basket_rules[!is.redundant(basket_rules)]
plot(basket_rules)
CCS_Basket <- DATAFRAME(basket_rules, separate = TRUE)

# have to have at least 3 rules
if (NROW(CCS_Basket) >=3 ){
  
  # see if LHS all empty
  # if so add 0 to LHS
  CCS_Basket <-  CCS_Basket[!sapply( CCS_Basket, function(k) all(k =="{}"))]
  
  if(NCOL(CCS_Basket) ==6){
    # remove brackets
    CCS_Basket$LHS <- gsub("[{}]","", CCS_Basket$LHS)
    CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
  }
  
  if(NCOL(CCS_Basket) ==5){
    CCS_Basket$LHS <- '0'
    CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
    #CCS_Basket <- sqldf("select LHS,RHS,support,confidence,lift,count from CCS_Basket")
  }
  
  
  # SNA
  # nodes rule id adges are rules
  
  adj1 <- sqldf("select LHS , RHS , count as weight from CCS_Basket")
  
  # add row ids for nodes
  adj1$id <- 1:nrow(adj1)
  
  
  adj1$weight <- as.integer(adj1$weight)
  adj2 <-adj1
  adj2$id <- NULL
  
  
  # 

  transferGraph <- graph_from_data_frame(adj2, directed = TRUE)
  transferGraph_und <- graph_from_data_frame(adj2, directed = FALSE)
  
  c1 <- cluster_edge_betweenness(transferGraph_und)
  length(c1)
  sizes(c1)
  
  
  plot(c1,transferGraph_und)
  
  co <- cluster_optimal(transferGraph_und)
  plot(co,transferGraph_und)
  
  # look at other layouts in igraph
  plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
                                                           weights=E(transferGraph)$weight),
       edge.arrow.size = .2)
  
  
  ig <- plot(basket_rules, method="graph")
  ig_df <- get.data.frame(ig,what = "both")
  

  visNetwork(
    nodes = data.frame(
      id = ig_df$vertices$name
      ,value = ig_df$vertices$lift  # try lift & confidence
      ,title = ifelse(ig_df$vertices$label == "", ig_df$vertices$name, ig_df$vertices$label)
      ,ig_df$vertices
    )
    , edges = ig_df$edges
  ) %>%
    visNodes(size = 10) %>%
    visLegend() %>%
    visEdges(smooth = FALSE) %>%
    visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
    visInteraction(navigationButtons = TRUE) %>%
    visEdges( arrows = 'from') %>%
    visPhysics(
      solver = "barnesHut",
      maxVelocity = 35,
      forceAtlas2Based = list(gravitationalConstant = -6000)

    )

  
  
  # betweenness
  # ig_between <-  as.data.frame(betweenness(transferGraph))
  # names(ig_between)[2] <- "betweenness"
  
  # edge betweeness
  
  
  ig_between <-  as.data.frame(edge.betweenness(transferGraph, weights=E(transferGraph)$weight))
  names(ig_between)[1] <- "edge_betweenness"
  ig_between <- rownames_to_column(ig_between, var="id")
  
  # other metrics are at the NODE level
  
  # coreness
  ig_coreness <-  as.data.frame(coreness(transferGraph, mode="all"))
  names(ig_coreness)[1] <- "coreness"
  ig_coreness <-  rownames_to_column(ig_coreness, var="id")
  
  
  
  # strength --- numbr of edges that go from one node to another
  # lower number less connected
  ig_strength <-  as.data.frame(strength(transferGraph, weights=E(transferGraph)$weight))
  names(ig_strength)[1] <- "strength"
  ig_strength <-  rownames_to_column(ig_strength, var="id")
  
  # closeness number of steps to access other nodes - higher values less
  # centrality
  
  ig_closeness <- as.data.frame(closeness(transferGraph, normalized = TRUE, weights=E(transferGraph)$weight))
  names(ig_closeness)[1] <- "closeness"
  ig_closeness <-  rownames_to_column(ig_closeness, var="id")
  
  
  # authority score -- high authority when is linked
  #by other nodes with link other nodes
  
  ig_authority <- as.data.frame(authority_score(transferGraph,scale=TRUE,
                                                weights=E(transferGraph)$weight)$vector)
  names(ig_authority)[1] <- "authority_score"
  ig_authority <-  rownames_to_column(ig_authority, var="id")
  ig_authority <- sqldf("select * from ig_authority where id != ''")
  
  
  
  hist(degree(transferGraph))
  
  cl <- clusters(transferGraph)
  plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
                                                           weights=E(transferGraph)$weight),
       vertex.color = cl$membership+1L, edge.arrow.size = 1)
  
  
  
  # remove rwonames after redundants deleted
  rownames(CCS_Basket) <- c()
  
  dissi <- dissimilarity(basket_rules, method = "Jaccard", which = "associations")
  
  dissi_m <- melt(as.matrix(dissi))
  p <- t(apply(dissi_m[,c(1,2)],1,FUN=sort))
  rmv1 <- which(p[,1] == p[,2])
  
  p <- paste(p[,1],p[,2], sep = "|")
  rmv2 <- which(duplicated(p))
  
  dissi_m <- as.data.frame(dissi_m[-c(rmv1,rmv2),])
  
  # filter to get all with score of 1
  # VAR is the index 
  dissi_m1 <- sqldf("select Var1 as rule_i, count(Var1) as rule_cnt from  dissi_m
                        where value = 1
                        group by Var1")
  
  dissi_m2 <- sqldf("select Var2 as rule_i, count(Var2) as rule_cnt from  dissi_m
                        where value = 1
                        group by Var2")
  
  distance_rule_cnt <- rbind(dissi_m1, dissi_m2)
  
  distance_rule_cnt <- sqldf("select rule_i, sum(rule_cnt) as tot_rules
                                 from distance_rule_cnt
                                 group by rule_i
                                 order by tot_rules desc ")
  
  
  CCS_Basket<- data.frame(rule_index = row.names(CCS_Basket), CCS_Basket)
  #CCS_Basket$tot_rules <- ifelse(is.na(CCS_Basket$tot_rules), 0, CCS_Basket$tot_rules)
  CCS_Basket <- sqldf("select c.*, d.* from CCS_Basket c LEFT JOIN  distance_rule_cnt d
                          ON c.rule_index = d.rule_i
                          order by tot_rules desc")
  
  
  # ADD SNA metrics to market basket data
  
  
  CCS_Basket <- sqldf("select c.*, d.edge_betweenness from CCS_Basket c,  
                          ig_between d,
                          adj1 a
                          where d.id = a.id
                          AND a.LHS = c.LHS
                          AND a.RHS = c.RHS")
  
  CCS_Basket <- sqldf("select c.*, d.authority_score from  CCS_Basket c  
                          LEFT JOIN ig_authority d
                          ON c.LHS = d.id")
  
  
  CCS_Basket <- sqldf("select c.*, d.closeness from  CCS_Basket c  
                          LEFT JOIN ig_closeness d
                          ON c.LHS = d.id")
  
  
  CCS_Basket <- sqldf("select c.*, d.strength from  CCS_Basket c  
                          LEFT JOIN ig_strength d
                          ON c.LHS = d.id")
  
  CCS_Basket <- sqldf("select c.*, d.coreness from  CCS_Basket c  
                          LEFT JOIN ig_coreness d
                          ON c.LHS = d.id")
}