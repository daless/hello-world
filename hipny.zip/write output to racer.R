

# code to write output files of last 10 feeds 

setwd("~/hipny")

library(RODBC)
library(sqldf)





#conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')





#conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;database=racerresearch;UID=COBUnixToSQL;PWD=Q438IerK@u9D')

outfiles <- readRDS(file="hipny184.Rda")
#str(outfiles)
outfiles$CLAIM_FEED_ID <- 184
claims_to_investigate_claims<-sqldf("select CLAIM_CLAIM_ID,CLAIM_FEED_ID, AMT_PAID as CLAIM_AMT_PAID,p0 ,p1 
                                    from outfiles group by CLAIM_CLAIM_ID,CLAIM_CLAIM_NO,CLAIM_FEED_ID,CLAIM_AMT_PAID,p0,p1")


sqlSave(conn1,claims_to_investigate_claims,tablename="dbo.hipny_COPDM_Feed184",rownames=FALSE)






# write.csv(claims_to_investigate, file = "claims_to_investigate_hipny186.csv")
# saveRDS(claims_to_investigate, file="hipny185.Rda")
# 
# 
# 
# 
# high_bucs <- sqldf("select * from claims_to_investigate where AMT_PAID > 50000 and p1 <= 0.03 order by AMT_PAID desc ")
# write.csv(high_bucs, file = "high_bucs_hipny185.csv")
# saveRDS(claims_to_investigate, file="high_hipny185.Rda")