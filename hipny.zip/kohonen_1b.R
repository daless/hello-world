

# sOMBREREO testing


library(SOMbrero)
library(kohonen)
library(dplyr)
library(NbClust)
library(cluster)
library(factoextra)
library(tidyverse)
set.seed(77)




base_table8 <- readRDS(file="base_table8.Rda")


junk <- as.matrix(base_table8 )
base_table8 <- as.data.frame(junk)


base_table8$Days_of_service <- as.numeric(as.character(base_table8$Days_of_service))
base_table8$ratio_billed_to_paid <- as.numeric(as.character(base_table8$ratio_billed_to_paid))
base_table8$PATIENT_AGE_NORM <- as.numeric(as.character(base_table8$PATIENT_AGE_NORM))
base_table8$Charlson_score <- as.numeric(as.character(base_table8$Charlson_score))
base_table8$wscore_ahrq  <- as.numeric(as.character(base_table8$wscore_ahrq))

# collapse insurace group
base_table8$INS_GROUP_ID <- fct_lump(base_table8$INS_GROUP_ID, n=10)

base_table88 <- base_table8

# remove factors with 1 level

base_table8 <- base_table8[, sapply(base_table8, nlevels) !=1]
base_table8 <- data.frame(r_index = row.names(base_table8), base_table8)
id<- sqldf("select r_index from base_table8")
the_target  <- sqldf("select target from base_table8")

base_table8$target <- NULL
base_table8$r_index <- NULL

base_table9 <- base_table8



# make factors numeric
kohonen1 <- base_table9

# change factors to numeric
# 
kohonen1<-kohonen1 %>%
  mutate_if(is.factor, ~as.numeric(as.character(.)))

kohonen1$INS_GROUP_ID <- NULL

#str(kohonen1,list.len = ncol(kohonen1))


# 
# som1 <- trainSOM(x.data = kohonen1, dimension = c(5,5), nb.save = 10, maxit = 500, scaling = "none")
# table(som1$clustering)
# summary(som1)
# 
# plot(som1, what = "energy")
# 
# plot(som1, what = "obs", type = "hitmap")
# 
# par(mfrow = c(1,2))
# plot(som1, what = 'prototypes', type = "color", var = 1, main = "prototypes - x1")
# plot(som1, what = 'prototypes', type = "color", var = 22, main = "prototypes - x2")
# 
# 
# # means
# plot(som1, what = 'obs', type = "color", var = 1, main = "obs mean values - x1")
# plot(som1, what = 'obs', type = "color", var = 22, main = "obs mean values - x2")
# ###############################################################################



som2 <- trainSOM(x.data = kohonen1, dimension = c(15,15), nb.save = 10, maxit = 200,
                 scaling = "none")

plot(som2, what = "obs", type = "hitmap")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=5)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)

# add cluster back to base data
som_clusters <- as.data.frame(out_grid)
som_clusters <- sqldf("select sc from som_clusters" )

som_clusters <- data.frame(id = row.names(som_clusters), som_clusters)

som_clusters_2 <- sqldf("select c.*, s.* from som_clusters c, som_dist s
                        where c.sc = s.r_index")
som_clusters_2_id <- sqldf("select id, sc from som_clusters_2")

som_clusters_2$id <- NULL
som_clusters_2$sc  <- NULL
som_clusters_2$r_index  <- NULL
colnames(som_clusters_2)[colSums(is.na(som_clusters_2)) > 0]

out_distm <- as.matrix(out_dist)
str(som_clusters_2,list.len = ncol(som_clusters_2))


# optimal number of clusters
asw <- numeric(20)

for (k in 2:20)
  asw[k] <- pam(out_distm, k) $ silinfo $ avg.width
k.best <- which.max(asw)
print(k.best)



p2m <- pam(out_distm, 2, diss = TRUE,   medoids =  c(1,16))
table(p2m$cluster)

PAM_cluster <- as.data.frame(p2m$cluster)
PAM_cluster$cluster <- PAM_cluster[,1]
PAM_cluster <- data.frame(PAM_id = row.names(PAM_cluster), PAM_cluster)
PAM_cluster2 <- sqldf("select p.PAM_id, s.id, p.cluster as PAM_cluster
                      from som_clusters_2_id s, PAM_cluster p
                      where p.PAM_id = s.sc") 

#str(PAM_cluster2,list.len = ncol(PAM_cluster2))

#out_dist2 <- cbind(out_dist, cluster = p2m$cluster)

base_table8 <- data.frame(r_index = row.names(base_table8), base_table8)
base_table10 <- sqldf("select b.*, p.PAM_cluster
                      from base_table8 b,PAM_cluster2 p
                      where b.r_index = p.id")

base_table10$r_index <- NULL
base_table10$PAM_cluster <- as.factor(base_table10$PAM_cluster)

str(base_table10,list.len = ncol(base_table10))



idx <- sample(seq(1,2), size = nrow(base_table10), replace = TRUE, prob = c(0.7, 0.3))
train <- base_table10[idx == 1,]
test <- base_table10[idx == 2,]


train_auto_ml <- train
test_auto_ml <- test


train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "PAM_cluster"
x <- setdiff(names(train), y)

# GBM

# if models do not take long to run add reproducible = TRUE,

response <- "PAM_cluster"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)


SOM_list <- h2o.randomForest(x=x,
                              y = y,
                              training_frame = train,
                              ntrees = 50,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)


SOM_list_var_import <- h2o.varimp(SOM_list)


# top quartile features

SOM_list_var_import <-SOM_list_var_import[SOM_list_var_import$relative_importance >
                                            quantile(SOM_list_var_import$relative_importance , 0.75), ]


SOM_list_var_import$feature <- SOM_list_var_import$variable
SOM_Top25<-as.data.frame(SOM_list_var_import$feature)

names(SOM_Top25)
SOM_short<-as.character(SOM_list_var_import$feature)
SOM_match<- match(SOM_short, names(base_table10))
SOM_match <- base_table10[,SOM_match]


base_table11 <- cbind(SOM_match, the_target)


#HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH

str(base_table11,list.len = ncol(base_table11))






idx <- sample(seq(1,2), size = nrow(base_table11), replace = TRUE, prob = c(0.7, 0.3))
train <- base_table11[idx == 1,]
test <- base_table11[idx == 2,]


train_auto_ml <- train
test_auto_ml <- test


train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "target"
x <- setdiff(names(train), y)

# GBM

# if models do not take long to run add reproducible = TRUE,

response <- "target"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)

# base gbm
gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10, categorical_encoding = "AUTO")
pred_gbm <- h2o.performance(gbm, newdata = test)
pred_gbm



gbm_2a <- h2o.gbm(x= predictors, y=response, training_frame = train, validation_frame = test, nfolds = 10, 
                  categorical_encoding = "AUTO")

summary(gbm_2a)





# with balance classes with HIPNY

# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 10
)

summary(gbm2)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
head(as.data.frame(h2o.varimp(gbm2)),n=10)



h2o.confusionMatrix(gbm2,valid=TRUE)






# GBM GRID
# gbm using hper parameter search
hyper_params = list(max_depth = seq(1,29,2))

grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = list(strategy = "Cartesian"),
  algorithm = "gbm",
  grid_id = "depth_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 200,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  stopping_rounds =5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10
)
grid
# sort grid models be creasing AUC
sortedGrid <- h2o.getGrid("depth_grid", sort_by="auc", decreasing = TRUE)
sortedGrid

# find the range of max_depth for the top 5 models
topDepths = sortedGrid@summary_table$max_depth[1:5]
minDepth = min(as.numeric(topDepths))
maxDepth = max(as.numeric(topDepths))
minDepth
maxDepth

# HIPNY includes balance classes = TRUE for low signal

hyper_params = list(
  max_depth = seq(minDepth, maxDepth, 1),
  sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate_per_tree = seq(0.2, 1, 0.01),
  col_sample_rate_change_per_level = seq(0.9, 1.1, 0.01),
  min_rows = 2^seq(0, log2(nrow(train)) - 1, 1),
  nbins = 2^seq(4, 10, 1),
  nbins_cats = 2^seq(4, 12, 1),
  min_split_improvement = c(0, 1e-8, 1e-6, 1e-4),
  balance_classes = c(TRUE, FALSE),
  histogram_type = c("UniformAdaptive", "QuantilesGlobal", "RoundRobin")
  
)

search_criteria = list(
  
  strategy = "RandomDiscrete",
  max_runtime_secs = 36000,
  max_models = 100,
  seed = 77,
  stopping_rounds = 5,
  stopping_metric = "AUC",
  stopping_tolerance = 1e-3
)

# if try different parametrs - change grid_id each time
grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = search_criteria,
  algorithm = "gbm",
  grid_id = "final_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  max_runtime_secs = 360,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10,
  seed = 77
)

##### from h2o tutorials in rclas h20 folder
# sort grid models by AUC
sortedGrid <- h2o.getGrid("final_grid", sort_by = "auc", decreasing = TRUE)
print(sortedGrid)

summary(grid)



# find the range of max_depth for the top 5 models
topDepths = sortedGrid@summary_table$max_depth[1:5]
minDepth = min(as.numeric(topDepths))
maxDepth = max(as.numeric(topDepths))
minDepth
maxDepth







# HIPNY includes balance classes = TRUE for low signal

hyper_params = list(
  max_depth = seq(minDepth, maxDepth, 1),
  sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate_per_tree = seq(0.2, 1, 0.01),
  col_sample_rate_change_per_level = seq(0.9, 1.1, 0.01),
  min_rows = 2^seq(0, log2(nrow(train)) - 1, 1),
  nbins = 2^seq(4, 10, 1),
  nbins_cats = 2^seq(4, 12, 1),
  min_split_improvement = c(0, 1e-8, 1e-6, 1e-4),
  balance_classes = c(TRUE, FALSE),
  histogram_type = c("UniformAdaptive", "QuantilesGlobal", "RoundRobin")
  
)

search_criteria = list(
  
  strategy = "RandomDiscrete",
  max_runtime_secs = 36000,
  max_models = 100,
  seed = 77,
  stopping_rounds = 5,
  stopping_metric = "AUC",
  stopping_tolerance = 1e-3
)

# if try different parametrs - change grid_id each time
grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = search_criteria,
  algorithm = "gbm",
  grid_id = "final_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  max_runtime_secs = 360,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10,
  seed = 77
)

##### from h2o tutorials in rclas h20 folder
# sort grid models by AUC
sortedGrid <- h2o.getGrid("final_grid", sort_by = "auc", decreasing = TRUE)
print(sortedGrid)

summary(grid)

best_GBM_grid_model <- h2o.getModel(sortedGrid@model_ids[[1]])
h2o.auc(best_GBM_grid_model, valid = TRUE)


#RRRRRRRRRRRRRRRRRRR

# generic RF


nfolds = 10

rf <- h2o.randomForest(x=x,
                       y = y,
                       training_frame = train,
                       ntrees = 500,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       seed = 77)


summary(rf)
pred_rf@model$validation_metrics
pred_rf


pred_rf <- h2o.performance(rf, newdata = test,  valid = TRUE)

summary(pred_rf)







rf_2 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         ntrees = 500,
                         nfolds = nfolds,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)

pred_rf_2 <- h2o.performance(rf_2, newdata = test,  valid = TRUE)
pred_rf_2




rf_3 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         validation_frame = test,
                         ntrees = 500,
                         nfolds = nfolds,
                         nbins = 50,
                         balance_classes = TRUE,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         categorical_encoding = "AUTO",
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)

# pred_rf_3 <- h2o.performance(rf_3, newdata = test,  valid = TRUE)
# pred_rf_3

summary(rf_3)






# xgboost

nfolds <- 10
xgboost <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 200,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost)







##########
# h2o ensemble

# stacked ensemble model
# random forest and GBM



# max and min rows based upon above max and min depth
# experiment with fold_assignment "AUTO", "Random", "Modulo", "Stratified"

nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 200,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 200,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)

solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id))


h2o.saveModel(ensemble, path = "ensemble", force =TRUE)

#"/home/dless1/BCBSMN/ensemble/ensemble_binomial"



perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_solo_dl))

ensemble_auc_test <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
pred_ensemble




###########################################

# same as above except balanced


##########
# h2o ensemble

# stacked ensemble model
# random forest and GBM



# max and min rows based upon above max and min depth
# experiment with fold_assignment "AUTO", "Random", "Modulo", "Stratified"

nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 200,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  balance_classes = TRUE,
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 200,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            balance_classes = TRUE,
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             balance_classes = TRUE,
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             balance_classes = TRUE,
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)

solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            balance_classes = TRUE,
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id))


h2o.saveModel(ensemble, path = "ensemble", force =TRUE)

#"/home/dless1/BCBSMN/ensemble/ensemble_binomial"



perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_solo_dl))

ensemble_auc_test_blanced <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test_blanced))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test_blanced))

pred_ensemble_blanced <- h2o.predict(ensemble, newdata = test)
pred_ensemble_balanced
















gbm_grid_ensemble <- h2o.grid(
  algorithm = "gbm",
  grid_id = "gbm_grid_binomial",
  x = x,
  y = y,
  training_frame = train,
  ntrees = 500,
  seed = 77,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  hyper_params = hyper_params,
  search_criteria = search_criteria)



ensemble2 <- h2o.stackedEnsemble(
  x = x,
  y = y,
  training_frame = train,
  model_id = "ensemble_gbm_grid_binomial",
  base_models = gbm_grid_ensemble@model_ids
)

h2o.saveModel(ensemble2, path = "fit2", force =TRUE)
#"/home/dless1/BCBSMN/fit2/ensemble_gbm_grid_binomial"

perf_grid_ensemble <- h2o.performance(ensemble2, newdata = test)

# compare to base learner performance on test setwd
getauc <- function(mm) h2o.auc(h2o.performance(h2o.getModel(mm), newdata = test))
base_leaner_aucs2 <- sapply(gbm_grid_ensemble@model_ids, getauc)
baselearner_best_auc_test2 <- max(base_leaner_aucs2)
ensemble_auc_test2 <- h2o.auc(perf_grid_ensemble )
print(sprintf("Best Base-learner Test AUC GRID:  %s", baselearner_best_auc_test2))
print(sprintf("Ensemble Test AUC GRID:  %s", ensemble_auc_test2))
perf_grid_ensemble










