

setwd("~/hipny")

library(RODBC)
library(sqldf)
library(dplyr)
library(tidyr)
library(tidyverse)
library(comorbidity)
library(dummies)
library(randomForest)
library(caret)
library(ggplot2)

library(RODBC)
conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')




#table listing in db
#table_listing <- as.data.frame(sqlTables(conn))
#write.csv(table_listing,file="racer_scehma.csv")
table_listing <- as.data.frame(sqlTables(conn))

 
claim_status <- sqlColumns(
  conn, "Racer00319.DBO.CLAIM"  )

claim_status <- sqlQuery(conn,"select * from  racer00319.dbo.claim_Status", max =10)

origin <- sqlQuery(conn,"select * from DMFEED00319.DBO.FD_HIPNY_QPNY_PCLM.MBR_Origin", max =100) 
origin <- sqlQuery(conn,"select * from dmfeed00319.dbo.fd_hipny_pclm.mbr_origin", max =100) 
origin <- sqlQuery(conn,"select * from dmfeed00319.dbo.fd_hipny_qpny_pclm", max =100)


# member
junk_iclm <- sqlQuery(conn, "select * from dmfeed00319.dbo.fd_hipny_qpny_pclm", max =10)
str(junk_iclm,list.len = ncol(junk_iclm))

junk_iclm <- sqlQuery(conn, "select * from Racer00319.DBO.CLAIM", max =10)
str(junk_iclm,list.len = ncol(junk_iclm))


# claim line
junk_clin <- sqlQuery(conn, "select * from DMFEED00319.DBO.FD_HIPNY_QPNY_PCLIN", max =10)

# claim
junk_clm <- sqlQuery(conn, "select * from DMFEED00319.DBO.FD_HIPNY_QPNY_ICLM", max =10)


# claim lines
junk_iclin<- sqlQuery(conn, "select * from DMFEED00319.DBO.FD_HIPNY_QPNY_ICLIN", max =10)

junk_claim<- sqlQuery(conn, "select * from Racer00319.DBO.CLAIM", max =10)
str(junk_claim,list.len = ncol(junk_claim))

junk_pars<- sqlQuery(conn, "select * from  racerresearch.dbo.PARS", max =10)
str(junk_pars,list.len = ncol(junk_pars))


junk_pclm<- sqlQuery(conn, "select * from  dmfeed00319.dbo.fd_hipny_qpny_pclm", max =10)
str(junk_pclm,list.len = ncol(junk_pclm))
junk_pclm$Z <- as.character(junk_pclm$CLAIM_NO)


#h2o.init(port=54333)
#h2o.shutdown(prompt  = FALSE)
#h2o.init(port=54333)




data0 = sqlQuery(
  conn,
  "SELECT DISTINCT c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,SUBSTRING(c.CLAIM_NO, 1, 12) AS CLAIM_CLAIM_NO                                                                          
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID 
,c.PROJECT_ID
,c.INS_GROUP_ID
,c.GROUP_SIZE
,c.PROVIDER_ID
,c.PATIENT_ID 
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
,cs.REASON_CODE as CLAIM_STATUS_REASON_CODE                                                                      
,cs.STATUS_CODE as CLAIM_STATUS_STATUS_CODE                                                                      
,cs.PROJECT_ID as CLAIM_STATUS_PROJECT_ID
,cs.CASE_ID as CLAIM_STATUS_CASE_ID
,cs.AMT_OF_REFUND as CLAIM_STATUS_AMT_OF_REFUND
,cs.CURRENT_STATUS as CLAM_STATUS_CURRENT_STATUS
,cs.HDS_LOB_ID as CLAIM_STATUS_HDS_LOB_ID
,cs.ERROR_CODE as CLAIM_STATUS_ERROR_CODE
,cs.DATE_UPDATED as CLAIM_STATUS_DATE_UPDATED
,cs.COMMENTS as CLAIM_STATUS_COMMENTS
from Racer00319.DBO.CLAIM c
INNER JOIN RACER00319.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
INNER JOIN RACER00319.DBO.CLAIM_STATUS cs                                                                        
on c.claim_id = cs.claim_id
inner join RACER00319.DBO.CASE_DATA cd                                                                          
on cd.case_id = cs.case_id
inner join RACER00319.DBO.STATUS_CODE sc                                                                         
on sc.status_code = cs.status_code
inner join DMFEED00319.DBO.FD_HIPNY_QPNY_ICLM dc
on dc.claim_no = c.claim_no
  WHERE c.AMT_PAID > 150
  and c.PROJECT_ID = 319
  and c.CLAIM_ID IS NOT NULL
 and c.FEED_ID = 193
and dc.DATE_PAID >= DATEADD(year,-1,GETDATE())
and DATEDIFF(D,  dc.DATE_OF_SERVICE_BEG, GETDATE()) < 180"
  )

 
#, max =100


data0$CLAIM_CLAIM_NO <- as.character(data0$CLAIM_CLAIM_NO)

# join clims to get only people not from CT and get member id

# 
# 

NON_CT_members <- sqlQuery(conn, "select DISTINCT m.PAT_MEMBER_NO , m.claim_id,
SUBSTRING(m.claim_no,1,12) as claim_no_12, m.MBR_Origin, m.FEED_ID, m.PROJECT_ID
from dmfeed00319.dbo.fd_hipny_qpny_pclm  m
                           where MBR_Origin NOT IN('CC')
                           and m.PROJECT_ID = 319 ")

NON_CT_members$claim_no_12 <- trimws(as.character(NON_CT_members$claim_no_12))

data0$CLAIM_CLAIM_NO <- trimws(as.character(data0$CLAIM_CLAIM_NO))



junk <- sqldf("select distinct d.* from data0  d,  NON_CT_members n
              where d.CLAIM_CLAIM_NO = n.claim_no_12")

junk <- sqldf("select distinct d.* from data0 d where d.CLAIM_CLAIM_NO ='20A520352000'")








# 
# NON_CT_members$claim_no <- trimws(as.character(NON_CT_members$claim_no))
# 
# NON_CT_members$claim_no_13 <-  trimws(substr(NON_CT_members$claim_no,1,13))
# NON_CT_members$claim_no_13b <-  trimws(substr(NON_CT_members$claim_no_13,1,13))
# 
# junk <- sqldf("select distinct d.*, m.PAT_MEMBER_NO from data0 d, NON_CT_members m
#               where d.claim_num_nosuffix = m.claim_no
#              ")
# junk <- sqldf("select  m.* from dmfeed00319.dbo.fd_hipny_qpny_pclm m
#               where m.claim_no = '2017307714919'
#              ")

timely <- sqlQuery(
  conn, "select  * from RacerResearch.[DBDataAnalytics-DM].EmblemLookBackPeriods where project_id = 319")




# , max =10000 and d.CLAIM_CLAIM_ID = m.claim_id


DX_claim  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer00319.DBO.CLAIM CLM
  INNER JOIN Racer00319.DBO.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  where CLM.PROJECT_ID = 319
  AND  DX.ORDER_IN_CLAIM <= 9
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

cl_id <- sqldf("select distinct CLAIM_CLAIM_ID from data0 ")

DX_claim <- sqldf("select x.* from DX_claim x, cl_id c
                  where x.CLAIM_ID = c.CLAIM_CLAIM_ID")


#################################################

#BBBBBBBBBBBBBBBBBBBBBBBBBBBB


# BETOS

HCPC_meta  <- read.csv("HCPC.csv", header=TRUE, sep="\t")
HCPC_meta$HCPC <- as.character(HCPC_meta$HCPC)

# HCPC BETOS >> change parent table

proc1c <- sqldf("select distinct p.CLAIM_CLAIM_NO, p.CLAIM_CLAIM_ID, p.CLAIM_LINE_CPT , 
p.CLAIM_LINE_CPT_MODIFIER , h.BETOS from 
data0 p LEFT JOIN HCPC_meta h ON
p.CLAIM_LINE_CPT  = h.HCPC 
and p.CLAIM_LINE_CPT != 'NA'
                order by p.CLAIM_CLAIM_NO")

# delete na rows
proc1c <- proc1c[!is.na(proc1c$CLAIM_LINE_CPT),]

proc1d <- sqldf("select CLAIM_CLAIM_NO, Count(CLAIM_CLAIM_ID) as CPT_CNT 
                from proc1c group by CLAIM_CLAIM_ID")

proc1d$CLAIM_IDx <- proc1d$CLAIM_CLAIM_NO
proc1d$CLAIM_CLAIM_NO <- NULL

proc1e <- sqldf("select CLAIM_CLAIM_NO, Count(CLAIM_CLAIM_ID) as Modifier_CNT from proc1c 
where CLAIM_LINE_CPT_MODIFIER != 'NA'
group by CLAIM_CLAIM_ID")
proc1e$CLAIM_IDx <- proc1e$CLAIM_CLAIM_ID
proc1e$CLAIM_CLAIM_ID <- NULL

proc_betos1 <- sqldf("select distinct CLAIM_CLAIM_ID, BETOS from proc1c 
where BETOS != ''")



proc_betos2 <- cbind(proc_betos1, dummy(proc_betos1$BETOS , sep= "_"))
# replace with BETOS
colnames(proc_betos2) <- (gsub("proc_betos1", "BETOS",  colnames(proc_betos2)))

proc_betos2 <- proc_betos2 %>% group_by(CLAIM_CLAIM_ID) %>% summarise_if(is.numeric, sum)

#temporaty id to character
proc_betos2$CLAIM_CLAIM_ID <- as.character(proc_betos2$CLAIM_CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
proc_betos2 <- proc_betos2 %>% mutate_if(is.numeric,
                                         function(x) case_when(
                                           x >= 1 ~ 1,
                                           x == 0 ~ 0
                                         )
)


#proc_betos2$BETOS <- NULL
#proc_betos2$BETOS_ <- NULL
proc_betos2$CLAIM_IDx <- as.character(proc_betos2$CLAIM_CLAIM_ID)
proc_betos2$CLAIM_CLAIM_ID <- NULL


proc_betos2 <- proc_betos2 %>% mutate_if(is.numeric, funs(factor(.)))

#proc_betos2$CLAIM_IDx <- as.numeric(proc_betos2$CLAIM_IDx)

proc_betos2 <- sqldf("select distinct * from proc_betos2 order by CLAIM_IDx ")
#proc_betos2$CLAIM_IDx <- proc_betos2$CLAIM_CLAIM_NO

DX_claim <- sqldf("select distinct * from DX_claim p LEFT JOIN proc_betos2 b
                  ON p.CLAIM_ID = b.CLAIM_IDx")

DX_claim$CLAIM_IDx <- DX_claim$CLAIM_ID

DX_claim <- mutate_at(DX_claim, vars(starts_with("BETOS_")),
                  list(~if_else(is.na(.),"0",.)))


DX_claim <- DX_claim %>%
  mutate_at(vars(starts_with("BETOS_")),as.factor)

#, max =10000

claims_OP<-sqldf("select * from data0 where CLAIM_STATUS_STATUS_CODE in (50,14,2) and CLAM_STATUS_CURRENT_STATUS=1")

claims_OP$OVP=1
claims_NOP<-sqldf("select * from data0 where (CLAIM_STATUS_STATUS_CODE in (20) and CLAIM_STATUS_REASON_CODE in (13,14,16,17,19,22,24,27,31,39,71) and CLAM_STATUS_CURRENT_STATUS=1) or (CLAIM_STATUS_STATUS_CODE in (40,1) and CLAM_STATUS_CURRENT_STATUS=1) ")
claims_NOP$OVP=0
claims<-rbind(claims_OP,claims_NOP)
Unique_claimids <- sqldf("select distinct CLAIM_CLAIM_ID from  claims")
DX_claimids  <- sqldf("SELECT DISTINCT d.*,m.* from DX_claim d INNER JOIN Unique_claimids as m 
                  ON d.CLAIM_ID =m.CLAIM_CLAIM_ID")
DX_claimids$ICD9_CODE<-as.character(DX_claimids$ICD9_CODE)
DX_claimids$ICD10_CODE<-DX_claimids$ICD9_CODE
DX_claimids$ICD9_CODE<-gsub(".","",DX_claimids$ICD9_CODE,fixed=TRUE)
DX_claimids_Diag <- sqldf("select distinct * from DX_claimids where ICD9_TYPE='DIAG'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")
elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

claims$Days_of_service <- difftime(claims$CLAIM_DATE_OF_SERVICE_END , 
                                   claims$CLAIM_DATE_OF_SERVICE_BEG,
                                   units = c("days")) 

# remove positive skew of LOS
claims$Days_of_service <- round(sqrt(as.integer(claims$Days_of_service + 1)))
# remove decimals from princiapl dx code


#str(claims,list.len = ncol(claims))






claims$CLAIM_PRINCIPAL_DIAG <- as.character(claims$CLAIM_PRINCIPAL_DIAG)
claims$CLAIM_PRINCIPAL_DIAG <- gsub(".","",claims$CLAIM_PRINCIPAL_DIAG, fixed = TRUE)


# place of service
claims$PLACE_OF_SERVICE<- ifelse(is.na(claims$CLAIM_PLACE_OF_SERVICE), 0, 
                                 claims$CLAIM_PLACE_OF_SERVICE)
claims$PLACE_OF_SERVICE<- as.factor(claims$PLACE_OF_SERVICE)

##### CCS groupings##########



CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
#names(CCS)[2]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)
# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category
 from DX_claimids d left join CCS c on d.ICD9_CODE = c.ICD10_Code
                        order by d.CLAIM_ID")
DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), 0, DX_CCS$CCS_Category)

DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
### One hot encoding of CCS variables #####

CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
## Making a wide table
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))

##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID, CLAIM_PLACE_OF_SERVICE from claims")
names(POS)[2]<-"POS"
POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor) 
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
##### configuring Claim Line CPT###


CPT <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID,  CLAIM_LINE_CPT as CPT from claims")


CPT <- cbind(CPT, dummy(CPT$CPT , sep= "_"))


# group by client id
CPT1 <- CPT %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor) 
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character((CPT2$CLAIM_ID)))
CPT2$CPT <- NULL


####### provider daata is bogus so no privider city :: Configuring Provider city#########


########Deriving new features#######3


claims$CLAIM_LINE_AMT_BILLED[is.na(claims$CLAIM_LINE_AMT_BILLED)] <-0
claims$CLAIM_AMT_ALLOWED[is.na(claims$claims$CLAIM_AMT_ALLOWED)] <-0
claims$claims$CLAIM_LINE_AMT_PAID[is.na(claims$claims$CLAIM_LINE_AMT_PAID)] <-0


claims$ratio_billed_to_paid<-(claims$CLAIM_LINE_AMT_BILLED + 1 )/(claims$CLAIM_LINE_AMT_PAID +1 )
claims$ratio_allowed_to_paid<-(claims$CLAIM_AMT_ALLOWED +1 ) /(claims$CLAIM_AMT_PAID +1)
claims$PATIENT_AGE_NORM <- scale(claims$CLAIM_PATIENT_AGE)
claims$PATIENT_AGE_NORM<-as.numeric(claims$PATIENT_AGE_NORM)
prop.table(table(claims$OVP))



# get PARS primary dx code
# original code hard coded dx codes, this dynamically generates CCS

pars_CCS1 <- sqlQuery(conn,"select  PRINCIPAL_DIAG, count(PRINCIPAL_DIAG) as dx_cnt
from  racerresearch.dbo.PARS
where PROJECT_ID = 319
and post_OPTUM_LEAKAGE_FLAG='1' 
AND left(externalvendor,5) <> 'OPTUM'
                      group by PRINCIPAL_DIAG
                      order by dx_cnt desc")

pars_CCS1$PRINCIPAL_DIAG<-gsub(".","",pars_CCS1$PRINCIPAL_DIAG,fixed=TRUE)

pars_CCS2 <- sqldf("select DISTINCT d.*,  c.CCS_Category as PARS_CCS, count(CCS_Category) as cnt_ccs
 from pars_CCS1 d , CCS c 
 where  d.PRINCIPAL_DIAG = c.ICD10_Code
 group by CCS_Category
                        order by cnt_ccs desc")

pars_CCS_top_10_percent <- pars_CCS2 %>% filter(cnt_ccs >= quantile(cnt_ccs, 0.9))


DX_leakage <- sqldf("select DISTINCT d.*,  c.PARS_CCS as ICD10_CODE_Leakage from 
DX_CCS d left join pars_CCS_top_10_percent c
on d.CCS_Category = c.PARS_CCS
                   order by d.CLAIM_ID ")


##setting up Leakage codes to be 1 
DX_leakage$ICD10_CODE_Leakage[is.na(DX_leakage$ICD10_CODE_Leakage)]<-0
DX_leakage$ICD10_CODE_Leakage<-ifelse(DX_leakage$ICD10_CODE_Leakage==0,0,1)
DX_leakage$ICD10_CODE_Leakage <- as.numeric(DX_leakage$ICD10_CODE_Leakage)
Leakage_test <- sqldf("select DISTINCT CLAIM_ID, ICD10_CODE_Leakage from DX_leakage")

# group by client id
Leakage_test2 <- Leakage_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)


# temporarialy make claim id text
Leakage_test2$CLAIM_ID <- as.character(Leakage_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Leakage_test3 <- Leakage_test2 %>% mutate_if(is.numeric,
                                             function(x) case_when(
                                               x >= 1 ~ 1,
                                               x == 0 ~ 0
                                             )
)
Leakage_test3 <- lapply(Leakage_test3, factor) 
Leakage_test3 <- as.data.frame(Leakage_test3)
Leakage_test3$CLAIM_ID <- as.numeric(as.character(Leakage_test3$CLAIM_ID))

table(Leakage_test$ICD10_CODE_Leakage)
prop.table(table(Leakage_test$ICD10_CODE_Leakage))



###################################
#Merging with cormorbidities

claims<-claims[order(claims$CLAIM_CLAIM_ID),]
#Merging with cormorbidities
claims_charlson <- sqldf("SELECT DISTINCT b.*, c.wscore as Charlson_score from DX_claimids b left join charlson_scores c
                   on b.CLAIM_ID = c.CLAIM_ID")

#charlson_scores$CLAIM_ID <- as.numeric(charlson_scores$CLAIM_ID )
claims_charlson$CLAIM_ID <- as.numeric(claims_charlson$CLAIM_ID )


claims_charlson <- claims%>%left_join(claims_charlson,by=c("CLAIM_CLAIM_ID" = "CLAIM_ID"))
claims_charlson$Charlson_score <-  ifelse(is.na(claims_charlson$Charlson_score),1,claims_charlson$Charlson_score)



##base_table2$Elixhauser_score <-  ifelse(is.na(base_table2$Elixhauser_score),1,base_table2$Elixhauser_score)

elixhauser_scores$CLAIM_ID<-as.numeric(elixhauser_scores$CLAIM_ID)

elixhauser_scores2 <- sqldf("select CLAIM_ID, wscore_ahrq from elixhauser_scores")




claims_charlson_elix <- claims_charlson%>% 
  left_join(elixhauser_scores2, by =c("CLAIM_CLAIM_ID"= "CLAIM_ID"))

claims_charlson_elix$wscore_ahrq <-  ifelse(is.na(claims_charlson_elix$wscore_ahrq),1,claims_charlson_elix$wscore_ahrq)
### Merging with CCS
# CCS dx


#claims_charlson_ccs <- sqldf("SELECT DISTINCT b.*, c.* from claims_charlson b inner join CCS_Dummy_test3 c
#                                on b.CLAIM_ID = c.CLAIM_IDx")
claims_charlson_elix_ccs <- claims_charlson_elix%>%inner_join(CCS_Dummy_test3,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))


##### Merging with POS
claims_charlson_elix_ccs_pos <- claims_charlson_elix_ccs%>%left_join(POS2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))



##### Merging with CPT

claims_charlson_elix_ccs_pos_cpt <- claims_charlson_elix_ccs_pos%>%left_join(CPT2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))
#Merging with leakage
claims_charlson_elix_ccs_pos_cpt_leakage <- claims_charlson_elix_ccs_pos_cpt%>%left_join(Leakage_test3,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))



################ Creating the target variable ############
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<-
  claims_charlson_elix_ccs_pos_cpt_leakage




claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage <- 
  as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$ICD10_CODE_Leakage)

claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage <-
  as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage)


# replace NA with 0
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage[is.na(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage )] <- 0

##base_table6$ICD9_CODE_neph <- NULL
table(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage)

prop.table(table(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage))



#claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE_NORM <- scale(claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE)
#claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE<-NULL




#################################### Feature reduction of CCS variables#####

































