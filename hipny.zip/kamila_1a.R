setwd("~/hipny")

library(caret)
library(klaR)
library(kamila)
library(cluster)



base_table8 <- readRDS(file="base_table8.Rda")


junk <- as.matrix(base_table8 )
base_table8 <- as.data.frame(junk)


base_table8$Days_of_service <- as.numeric(as.character(base_table8$Days_of_service))
base_table8$ratio_billed_to_paid <- as.numeric(as.character(base_table8$ratio_billed_to_paid))
base_table8$PATIENT_AGE_NORM <- as.numeric(as.character(base_table8$PATIENT_AGE_NORM))
base_table8$Charlson_score <- as.numeric(as.character(base_table8$Charlson_score))
base_table8$wscore_ahrq  <- as.numeric(as.character(base_table8$wscore_ahrq))

# remove factors with 1 level

base_table8 <- base_table8[, sapply(base_table8, nlevels) !=1]
base_table8 <- data.frame(r_index = row.names(base_table8), base_table8)
id<- sqldf("select r_index from base_table8")
the_target  <- sqldf("select target from base_table8")

base_table8$target <- NULL
base_table8$r_index <- NULL

base_table9 <- base_table8


number_list <- c(names(Filter(is.numeric,base_table9)))
number_match <- match(number_list, names(base_table9))
conVars <- base_table9[,number_match]

factor_list3 <- c(names(Filter(is.factor,base_table9)))
fact_match3 <- match(factor_list3, names(base_table9))
catVarsFac <- base_table9[,fact_match3]






kamRes <- kamila(conVars, catVarsFac,  numClust = 3, numInit = 10)
kam_membership<- as.data.frame(kamRes$finalMemb)


plotDatKam <- cbind(id,conVars, catVarsFac, Cluster = factor(kamRes$finalMemb) )
# 
# kamRes2 <- kamila(conVars, catVarsFac, numClust = 2 : 4, numInit = 10,
#                   calcNumClust = "ps", numPredStrCvRun = 10, predStrThresh = 0.5,  maxIter = 50)
# 
# 
# kam_membership<- as.data.frame(kamRes2$finalMemb)
# number_clusters <- as.data.frame(kamRes2$nClust$bestNClust)
# N_clusters = kamRes2$nClust$bestNClust
# cluster_strength <- as.data.frame(kamRes2$nClust$avgPredStr)
# 
# plotDatKam <- cbind(id,conVars, catVarsFac, Cluster = factor(kamRes2$finalMemb) )















