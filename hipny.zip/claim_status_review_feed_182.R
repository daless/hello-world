



setwd("~/hipny")
library(comorbidity)
library(RODBC)
library(sqldf)
library(tidyr)

library(tidyverse)




conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')


status_rev1 <- 
  sqlQuery(
    conn, " select * from RACER00319.DBO.CLAIM_STATUS
    where CLAIM_ID = 1336149290")


status_rev2 <- 
  sqlQuery(
    conn, " select * from RACER00319.DBO.CLAIM_STATUS
    where CLAIM_ID = 1336214958")


status_rev3 <- 
  sqlQuery(
    conn, " select * from RACER00319.DBO.CLAIM_STATUS
    where CLAIM_ID = 1336087063")



status_rev3_claims <- 
  sqldf(" select * from claims
    where CLAIM_CLAIM_ID = 1336087063")

status_rev3_claims2 <- 
  sqldf(" select * from junk
    where CLAIM_CLAIM_ID = 1336087063")
status_rev3_claims28 <- 
  sqldf(" select * from base_table8
    where CLAIM_CLAIM_ID = 1336214958")



# code to change
base_table8 <- base_table8 %>%
  group_by(CLAIM_CLAIM_ID) %>%
  arrange_all(desc)




