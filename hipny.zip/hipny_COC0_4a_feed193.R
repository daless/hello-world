
setwd("~/hipny")
library(comorbidity)
#library(tidyr)
library(RODBC)
library(sqldf)
library(tidyverse)




conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')


#library(h2o)
#h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)
#h2o.init(port=54333)


# hold outs are FEEDs 191, 192,193
# business rule is claims form run date to paid date of 620 days 
# 820 allows for 200 days of run out on initial pull
# then filters 620 days for greatest paid date in data pull



# FEED 193 |||||||||||||||||||||||||

data0 = sqlQuery(
  conn,
  "SELECT DISTINCT c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,SUBSTRING(c.CLAIM_NO, 1, 12) AS CLAIM_CLAIM_NO                                                                          
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID 
,c.PROJECT_ID
,c.INS_GROUP_ID
,c.GROUP_SIZE
,c.PROVIDER_ID
,c.PATIENT_ID 
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
,cs.REASON_CODE as CLAIM_STATUS_REASON_CODE                                                                      
,cs.STATUS_CODE as CLAIM_STATUS_STATUS_CODE                                                                      
,cs.PROJECT_ID as CLAIM_STATUS_PROJECT_ID
,cs.CASE_ID as CLAIM_STATUS_CASE_ID
,cs.AMT_OF_REFUND as CLAIM_STATUS_AMT_OF_REFUND
,cs.CURRENT_STATUS as CLAM_STATUS_CURRENT_STATUS
,cs.HDS_LOB_ID as CLAIM_STATUS_HDS_LOB_ID
,cs.ERROR_CODE as CLAIM_STATUS_ERROR_CODE
,cs.DATE_UPDATED as CLAIM_STATUS_DATE_UPDATED
,cs.COMMENTS as CLAIM_STATUS_COMMENTS
,o.lookbackMonths
from Racer00319.DBO.CLAIM c
INNER JOIN RACER00319.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
INNER JOIN RACER00319.DBO.CLAIM_STATUS cs                                                                        
on c.claim_id = cs.claim_id
inner join RACER00319.DBO.CASE_DATA cd                                                                          
on cd.case_id = cs.case_id
inner join RACER00319.DBO.STATUS_CODE sc                                                                         
on sc.status_code = cs.status_code
inner join DMFEED00319.DBO.FD_HIPNY_QPNY_ICLM dc
on dc.claim_no = c.claim_no
inner join Racer00319.DBO.PROVIDER p
on p.PROVIDER_ID = c.PROVIDER_ID
left join RacerResearch.[DBDataAnalytics-DM].EmblemLookBackPeriods o
on o.provider_no =p.PROVIDER_NO
inner join RACER00319.DBO.MEMBER mem
on c.PATIENT_ID = mem.MEMBER_ID
  WHERE c.AMT_PAID > 150
  and c.PROJECT_ID = 319
  and c.CLAIM_ID IS NOT NULL
 and c.FEED_ID = 193
 and mem.STATE != 'CT'
and DATEDIFF(D,  c.DATE_PAID, GETDATE()) < 725"
    )

#saveRDS(data0, file="data0a.Rda")

#data0aa <- readRDS(file="data0a.Rda")
#data0 <- data0aa 
# , max =1000

# apply date fences from RacerResearch.[DBDataAnalytics-DM].EmblemLookBackPeriods or use 620 day fence as defualt
# rules from business

#() find max paid date as upper date fence for the last feed

data0$beg_date <-as.Date(max(data0$CLAIM_DATE_PAID, na.rm = TRUE))

# lookback expressed in months convert to days


data0$beg_date2<- ifelse(is.na(data0$lookbackMonths), 620, (data0$lookbackMonths * 30))

  
data0$beg_date3 <- data0$beg_date - data0$beg_date2

data0$CLAIM_DATE_PAID <- as.Date(data0$CLAIM_DATE_PAID)

data0$prov_lookback_flag <- ifelse(data0$CLAIM_DATE_PAID >=data0$beg_date3 ,1, 0)

data0bb <- sqldf("select * from data0 where prov_lookback_flag = 1 ")



rm(data0)
data0 <- data0bb

data0$beg_date <- NULL
data0$beg_date2 <- NULL
data0$beg_date3 <- NULL
data0$prov_lookback_flag <- NULL

rm(data0bb)

#saveRDS(data0, file="data0aa.Rda")

#data0 <- readRDS(file="data0aa.Rda")


DX_claim  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer00319.DBO.CLAIM CLM
  INNER JOIN Racer00319.DBO.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  where CLM.PROJECT_ID = 319
  AND  DX.ORDER_IN_CLAIM <= 9
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

cl_id <- sqldf("select distinct CLAIM_CLAIM_ID from data0 ")


library(dplyr)

library(tidyverse)

DX_claim <- inner_join(DX_claim, cl_id, by = c("CLAIM_ID" = "CLAIM_CLAIM_ID") )





DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")


elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")

#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

library(dummies)
library(randomForest)
library(caret)
library(ggplot2)
library(dataMaid)
library(C50)
library(lubridate)
library(tidyverse)
library(psych)
library(plyr)

#################################################

#BBBBBBBBBBBBBBBBBBBBBBBBBBBB


# BETOS

HCPC_meta  <- read.csv("HCPC.csv", header=TRUE, sep="\t")
HCPC_meta$HCPC <- as.character(HCPC_meta$HCPC)

# HCPC BETOS >> change parent table

proc1c <- sqldf("select distinct p.CLAIM_CLAIM_NO, p.CLAIM_CLAIM_ID, p.CLAIM_LINE_CPT , 
p.CLAIM_LINE_CPT_MODIFIER , h.BETOS from 
data0 p LEFT JOIN HCPC_meta h ON
p.CLAIM_LINE_CPT  = h.HCPC 
and p.CLAIM_LINE_CPT != 'NA'
                order by p.CLAIM_CLAIM_NO")

# delete na rows
proc1c <- proc1c[!is.na(proc1c$CLAIM_LINE_CPT),]

proc1d <- sqldf("select CLAIM_CLAIM_NO, Count(CLAIM_CLAIM_ID) as CPT_CNT 
                from proc1c group by CLAIM_CLAIM_ID")

proc1d$CLAIM_IDx <- proc1d$CLAIM_CLAIM_NO
proc1d$CLAIM_CLAIM_NO <- NULL

proc1e <- sqldf("select CLAIM_CLAIM_NO, Count(CLAIM_CLAIM_ID) as Modifier_CNT from proc1c 
where CLAIM_LINE_CPT_MODIFIER != 'NA'
group by CLAIM_CLAIM_ID")
proc1e$CLAIM_IDx <- proc1e$CLAIM_CLAIM_ID
proc1e$CLAIM_CLAIM_ID <- NULL

proc_betos1 <- sqldf("select distinct CLAIM_CLAIM_ID, BETOS from proc1c 
where BETOS != ''")



proc_betos2 <- cbind(proc_betos1, dummy(proc_betos1$BETOS , sep= "_"))
# replace with BETOS
colnames(proc_betos2) <- (gsub("proc_betos1", "BETOS",  colnames(proc_betos2)))

proc_betos2 <- proc_betos2 %>% group_by(CLAIM_CLAIM_ID) %>% summarise_if(is.numeric, sum)

#temporaty id to character
proc_betos2$CLAIM_CLAIM_ID <- as.character(proc_betos2$CLAIM_CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
proc_betos2 <- proc_betos2 %>% mutate_if(is.numeric,
                                         function(x) case_when(
                                           x >= 1 ~ 1,
                                           x == 0 ~ 0
                                         )
)


#proc_betos2$BETOS <- NULL
#proc_betos2$BETOS_ <- NULL
proc_betos2$CLAIM_IDx <- as.character(proc_betos2$CLAIM_CLAIM_ID)
proc_betos2$CLAIM_CLAIM_ID <- NULL


proc_betos2 <- proc_betos2 %>% mutate_if(is.numeric, funs(factor(.)))

#proc_betos2$CLAIM_IDx <- as.numeric(proc_betos2$CLAIM_IDx)

proc_betos2 <- sqldf("select distinct * from proc_betos2 order by CLAIM_IDx ")
#proc_betos2$CLAIM_IDx <- proc_betos2$CLAIM_CLAIM_NO


proc_betos2$CLAIM_IDx <- as.integer(proc_betos2$CLAIM_IDx)

#saveRDS(proc_betos2, file="proc_betos2.Rda")
#proc_betos2 <- readRDS(file="proc_betos2.Rda")

DX_claim <- left_join(DX_claim, proc_betos2, by = c("CLAIM_ID" = "CLAIM_IDx") )



DX_claim <- mutate_at(DX_claim, vars(starts_with("BETOS_")),
                      ~replace(., is.na(.), 0))

# 
# DX_claim <- DX_claim %>%
#   mutate_at(vars(starts_with("BETOS_")),as.factor)
# DX_claim$CLAIM_IDx <- NULL

#saveRDS(DX_claim, file="DX_claim.Rda")
#saveRDS(proc_betos2, file="proc_betos2.Rda")


#####
# AHRQ comorbidities
 library(icd)

AHRQ_1 <- icd_comorbid_ahrq(DX_claim, visit_name = 'CLAIM_ID', icd_name = 'ICD9_CODE', return_df = TRUE,
                                    return_binary = FALSE)

AHRQ_1$CLAIM_ID <- as.character(AHRQ_1$CLAIM_ID)
cols <- sapply(AHRQ_1, is.logical)

AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.numeric)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.character)
AHRQ_1$CLAIM_ID <- as.integer(AHRQ_1$CLAIM_ID)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.factor)
colnames(AHRQ_1) <- paste("AHRQ", colnames(AHRQ_1), sep = "_")
AHRQ_1$CLAIM_IDx <- AHRQ_1$AHRQ_CLAIM_ID
AHRQ_1$AHRQ_CLAIM_ID <- NULL


DX_claim <- inner_join(DX_claim, AHRQ_1, by = c("CLAIM_ID" = "CLAIM_IDx") )


DX_claim$CLAIM_IDx <- NULL

#saveRDS(DX_claim, file="DX_claim.Rda")
#saveRDS(DX_claimids, file="DX_claimids.Rda")
#saveRDS(AHRQ_1, file="AHRQ_1.Rda")

#DX_claim <- readRDS(file="DX_claim.Rda")
#DX_claimids <- readRDS(file="DX_claimids.Rda")


############################################################################

# TARGET



claims_OP <- data0 %>% filter(CLAIM_STATUS_STATUS_CODE %in% c(50,14,2)
                              &  CLAM_STATUS_CURRENT_STATUS == 1 )
claims_OP$OVP=1

claims_NOP <- data0 %>% filter(
  (CLAIM_STATUS_STATUS_CODE == 20
   & CLAIM_STATUS_REASON_CODE %in%  c(13,14,16,17,19,22,24,27,31,39,71)
   & CLAM_STATUS_CURRENT_STATUS == 1) | (CLAIM_STATUS_STATUS_CODE %in%  c(40,1)
                                         & CLAM_STATUS_CURRENT_STATUS == 1)
)

claims_NOP$OVP=0
claims<-rbind(claims_OP,claims_NOP)



Unique_claimids <- distinct(claims, CLAIM_CLAIM_ID)

DX_claimids <-  inner_join(DX_claim, Unique_claimids, by = c("CLAIM_ID" = "CLAIM_CLAIM_ID") )


DX_claimids$ICD9_CODE<-as.character(DX_claimids$ICD9_CODE)
DX_claimids$ICD10_CODE<-DX_claimids$ICD9_CODE
DX_claimids$ICD9_CODE<-gsub(".","",DX_claimids$ICD9_CODE,fixed=TRUE)

#saveRDS(DX_claimids, file="DX_claimids.Rda")
#DX_claimids <- readRDS(file="DX_claimids.Rda")



#table(unique_OVP$OVP)
#prop.table(table(unique_OVP$OVP))



DX_claimids_Diag <- distinct(DX_claimids %>%
                               filter(ICD9_TYPE =='DIAG'))


claims$Days_of_service <- difftime(claims$CLAIM_DATE_OF_SERVICE_END , 
                                   claims$CLAIM_DATE_OF_SERVICE_BEG,
                                   units = c("days")) 

# remove positive skew of LOS
claims$Days_of_service <- round(sqrt(as.integer(claims$Days_of_service + 1)))
# remove decimals from princiapl dx code


#str(claims,list.len = ncol(claims))






claims$CLAIM_PRINCIPAL_DIAG <- as.character(claims$CLAIM_PRINCIPAL_DIAG)
claims$CLAIM_PRINCIPAL_DIAG <- gsub(".","",claims$CLAIM_PRINCIPAL_DIAG, fixed = TRUE)


# place of service
claims$PLACE_OF_SERVICE<- ifelse(is.na(claims$CLAIM_PLACE_OF_SERVICE), 0, 
                                 claims$CLAIM_PLACE_OF_SERVICE)
claims$PLACE_OF_SERVICE<- as.factor(claims$PLACE_OF_SERVICE)





##### CCS groupings##########


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)
# build CCS dx table

DX_CCS <- distinct(DX_claimids %>%
                     left_join(select(CCS, CCS_Category,ICD10_Code), 
                               by = c("ICD9_CODE" = "ICD10_Code")))



DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), 0, DX_CCS$CCS_Category)

DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
### One hot encoding of CCS variables #####

CCS_Dummy_test <- DX_CCS %>%
  select(CLAIM_ID, CCS_Category) %>%
  arrange(CLAIM_ID)


## Making a wide table
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))

#saveRDS(CCS_Dummy_test3, file="CCS_Dummy_test3.Rda")
#CCS_Dummy_test3 <- readRDS(file="CCS_Dummy_test3.Rda")

##### Configuring Place of service
str(claims,list.len = ncol(claims))
##### Configuring Place of service

POS <- distinct (claims %>%
                   select(CLAIM_CLAIM_ID, CLAIM_PLACE_OF_SERVICE))
POS$CLAIM_ID <- POS$CLAIM_CLAIM_ID
POS$CLAIM_CLAIM_ID <- NULL

POS <- sqldf("select CLAIM_ID,CLAIM_PLACE_OF_SERVICE from POS" )

names(POS)[2]<-"POS"
POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor) 
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
##### configuring Claim Line CPT###


CPT <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID,  CLAIM_LINE_CPT as CPT from claims")


CPT <- cbind(CPT, dummy(CPT$CPT , sep= "_"))


# group by client id
CPT1 <- CPT %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor) 
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character((CPT2$CLAIM_ID)))
CPT2$CPT <- NULL


####### provider daata is bogus so no privider city :: Configuring Provider city#########


########Deriving new features#######3
#for HIPNY claims$CLAIM_AMT_ALLOWED is missing
claims$CLAIM_AMT_ALLOWED <- NULL

claims$CLAIM_LINE_AMT_BILLED[is.na(claims$CLAIM_LINE_AMT_BILLED)] <-0
#claims$CLAIM_AMT_ALLOWED[is.na(claims$claims$CLAIM_AMT_ALLOWED)] <-0
claims$CLAIM_LINE_AMT_PAID[is.na(claims$CLAIM_LINE_AMT_PAID)] <-0


claims$ratio_billed_to_paid<-(claims$CLAIM_LINE_AMT_BILLED + 1 )/(claims$CLAIM_LINE_AMT_PAID +1 )
#claims$ratio_allowed_to_paid<-(claims$CLAIM_AMT_ALLOWED +1 ) /(claims$CLAIM_AMT_PAID +1)
claims$PATIENT_AGE_NORM <- scale(claims$CLAIM_PATIENT_AGE)
claims$PATIENT_AGE_NORM<-as.numeric(claims$PATIENT_AGE_NORM)
prop.table(table(claims$OVP))



# get PARS primary dx code
# original code hard coded dx codes, this dynamically generates CCS

icd10codes_leakage <- sqlQuery(conn,"select  PRINCIPAL_DIAG, count(PRINCIPAL_DIAG) as dx_cnt
from  racerresearch.dbo.PARS
where PROJECT_ID = 319
and post_OPTUM_LEAKAGE_FLAG='1' 
AND left(externalvendor,5) <> 'OPTUM'
                      group by PRINCIPAL_DIAG
                      order by dx_cnt desc")


#write.csv(icd10codes_leakage, file = "icd10codes_leakage.csv")

icd10codes_leakage$PRINCIPAL_DIAG<-gsub(".","",icd10codes_leakage$PRINCIPAL_DIAG,fixed=TRUE)
#icd10codes_leakage$ICD10_CODE<-as.character(icd10codes_leakage$ICD10_CODE)
#icd10codes_leakage$icd10_leakage<-gsub(".","",icd10codes_leakage$ICD10_CODE,fixed=TRUE)


# initally was top 10 percentile then changed to 80% to increase amount of signal
# new plan so not much PARs data


pars_primary_dx_top_10_percent <-  icd10codes_leakage[icd10codes_leakage$dx_cnt > quantile(icd10codes_leakage$dx_cnt, 0.8), ]


DX_leakage <- sqldf("select DISTINCT d.*,  c.PRINCIPAL_DIAG as ICD10_CODE_Leakage from 
DX_claimids d left join pars_primary_dx_top_10_percent c on d.ICD9_CODE = c.PRINCIPAL_DIAG
                   order by d.CLAIM_ID ")


##setting up Leakage codes to be 1 
DX_leakage$ICD10_CODE_Leakage[is.na(DX_leakage$ICD10_CODE_Leakage)]<-0
DX_leakage$ICD10_CODE_Leakage<-ifelse(DX_leakage$ICD10_CODE_Leakage==0,0,1)
DX_leakage$ICD10_CODE_Leakage <- as.numeric(DX_leakage$ICD10_CODE_Leakage)
Leakage_test <- sqldf("select DISTINCT CLAIM_ID, ICD10_CODE_Leakage from DX_leakage")

# group by client id
Leakage_test2 <- Leakage_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)


# temporarialy make claim id text
Leakage_test2$CLAIM_ID <- as.character(Leakage_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Leakage_test3 <- Leakage_test2 %>% mutate_if(is.numeric,
                                             function(x) case_when(
                                               x >= 1 ~ 1,
                                               x == 0 ~ 0
                                             )
)
Leakage_test3 <- lapply(Leakage_test3, factor) 
Leakage_test3 <- as.data.frame(Leakage_test3)
Leakage_test3$CLAIM_ID <- as.numeric(as.character(Leakage_test3$CLAIM_ID))

table(Leakage_test$ICD10_CODE_Leakage)
prop.table(table(Leakage_test$ICD10_CODE_Leakage))

#saveRDS(claims, file="claims.Rda")
#claims <- readRDS(file="claims.Rda")

#saveRDS(Leakage_test3, file="Leakage_test3.Rda")
#Leakage_test3 <- readRDS(file="Leakage_test3.Rda")


###################################
#Merging with cormorbidities

claims<-claims[order(claims$CLAIM_CLAIM_ID),]
#Merging with cormorbidities

claims<-claims[order(claims$CLAIM_CLAIM_ID),]
#Merging with cormorbidities

charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)

claims_charlson <- claims %>%
  left_join(select(charlson_scores,CLAIM_ID, wscore), 
            by = c("CLAIM_CLAIM_ID" = "CLAIM_ID")) 

claims_charlson$Charlson_score <- claims_charlson$wscore
claims_charlson$wscore <- NULL

#charlson_scores$CLAIM_ID <- as.numeric(charlson_scores$CLAIM_ID )
##claims_charlson$CLAIM_ID <- as.numeric(claims_charlson$CLAIM_ID )


##claims_charlson <- claims%>%left_join(claims_charlson,by=c("CLAIM_CLAIM_ID" = "CLAIM_ID"))
##claims_charlson$CLAIM_ID <- NULL

claims_charlson$Charlson_score <-  ifelse(is.na(claims_charlson$Charlson_score),1,claims_charlson$Charlson_score)



##base_table2$Elixhauser_score <-  ifelse(is.na(base_table2$Elixhauser_score),1,base_table2$Elixhauser_score)

elixhauser_scores$CLAIM_ID<-as.numeric(elixhauser_scores$CLAIM_ID)



elixhauser_scores2 <- elixhauser_scores %>%
  select(CLAIM_ID, wscore_ahrq) %>%
  arrange(CLAIM_ID)




claims_charlson_elix <- claims_charlson%>% 
  left_join(elixhauser_scores2, by =c("CLAIM_CLAIM_ID"= "CLAIM_ID"))
claims_charlson_elix$CLAIM_ID <- NULL

claims_charlson_elix$wscore_ahrq <-  ifelse(is.na(claims_charlson_elix$wscore_ahrq),
                                            1,claims_charlson_elix$wscore_ahrq)


### Merging with CCS
# CCS dx


#claims_charlson_ccs <- sqldf("SELECT DISTINCT b.*, c.* from claims_charlson b inner join CCS_Dummy_test3 c
#                                on b.CLAIM_ID = c.CLAIM_IDx")

claims_charlson_elix_ccs <- claims_charlson_elix%>%inner_join(CCS_Dummy_test3,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))
claims_charlson_elix_ccs$CLAIM_ID <- NULL





##### Merging with POS
claims_charlson_elix_ccs_pos <- claims_charlson_elix_ccs%>%left_join(POS2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))
claims_charlson_elix_ccs_pos$CLAIM_ID <- NULL


##### Merging with CPT

claims_charlson_elix_ccs_pos_cpt <- claims_charlson_elix_ccs_pos%>%left_join(CPT2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))
claims_charlson_elix_ccs_pos_cpt$CLAIM_ID <- NULL


#Merging with leakage
claims_charlson_elix_ccs_pos_cpt_leakage <- claims_charlson_elix_ccs_pos_cpt %>% 
  left_join(Leakage_test3,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))

claims_charlson_elix_ccs_pos_cpt_leakage$CLAIM_ID <- NULL
claims_charlson_elix_ccs_pos_cpt_leakage$ICD10_CODE_Leakage <- ifelse(is.na(claims_charlson_elix_ccs_pos_cpt_leakage$ICD10_CODE_Leakage ), 
                                                                      0, claims_charlson_elix_ccs_pos_cpt_leakage$ICD10_CODE_Leakage )


################ Creating the target variable ############
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<-
  claims_charlson_elix_ccs_pos_cpt_leakage



# replace NA with 0


claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$ICD10_CODE_Leakage <- 
  as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$ICD10_CODE_Leakage)

claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage <-
  as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$ICD10_CODE_Leakage)

claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage[is.na(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage )] <- 2

claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$ICD10_CODE_Leakage[is.na(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$ICD10_CODE_Leakage )] <- 2


##base_table6$ICD9_CODE_neph <- NULL
table(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage)

prop.table(table(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage))



#claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE_NORM <- scale(claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE)
#claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE<-NULL

# remove features with NA

claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_LINE_CPT_MODIFIER <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_DATE_ADMITTED <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$GROUP_SIZE <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_ERROR_CODE <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_LINE_AMT_ALLOWED <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_DATE_DISCHARGED  <- NULL
#claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_LINE_CPT  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_REASON_CODE  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_COMMENTS  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_REASON_CODE  <- NULL 
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_DATE_ENTERED  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CPT_NA <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CCS_0 <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$PROVIDER_ID<- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$PATIENT_ID <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_LINE_LINE_NO <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_LINE_DATE_PAID <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_STATUS_CODE <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_PROJECT_ID  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_CASE_ID  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_AMT_OF_REFUND  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAM_STATUS_CURRENT_STATUS   <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_HDS_LOB_ID  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_DATE_UPDATED <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_DATE_RECEIVED  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_HDS_LOB_ID  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_FEED_ID   <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$PROJECT_ID   <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_DATE_PAID   <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$POS   <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_DATE_OF_SERVICE_BEG  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_DATE_OF_SERVICE_END  <- NULL

claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_PROVIDER_ID  <- NULL
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_PRINCIPAL_DIAG  <- NULL


# replace NA with 0
#claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_AMT_OF_REFUND[is.na(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_STATUS_AMT_OF_REFUND )] <- 0
#claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_AMT_BILLED[is.na(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_AMT_BILLED )] <- 0
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$INS_GROUP_ID <- as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$INS_GROUP_ID)
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_LINE_REVENUE_CODE <-as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$CLAIM_LINE_REVENUE_CODE)
  
# ADD BETOS
#saveRDS(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix, file="claims_charlson_ccs_pos_cpt_leakage_city_prov_elix.Rda")

#claims_charlson_ccs_pos_cpt_leakage_city_prov_elix <-
# claim_100 <- readRDS(file="claims_charlson_ccs_pos_cpt_leakage_city_prov_elix.Rda")



claims_700 <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix

claims_701 <- distinct(left_join(claims_700, proc_betos2, by = c("CLAIM_CLAIM_ID" = "CLAIM_IDx")))



claims_702 <- mutate_at(claims_701, vars(starts_with("BETOS_")),
                      ~replace(., is.na(.), 0))



claims_702 <- claims_702  %>%
  mutate_at(vars(starts_with("BETOS_")),as.factor)
claims_702$CLAIM_IDx <- NULL

  
#str(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,list.len = ncol(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix))

#claims_charlson_ccs_pos_cpt_leakage_city_prov_elix

claims_702$CLAIM_AMT_BILLED <- NULL
claims_702$lookbackMonths  <- NULL
claims_702$CLAIM_PLACE_OF_SERVICE   <- NULL

colnames(claims_702)[colSums(is.na(claims_702)) > 0]

#saveRDS(claims_702, file="claims_702.Rda")
#claims_702 <- readRDS(file="claims_702.Rda")
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix <- claims_702
# 
# makeDataReport(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix, vol="1", render = TRUE, 
#                replace = TRUE, openResult = TRUE, codebook = TRUE,
#                reportTitle = "Base Data - Report")
# 
# makeCodebook(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix, vol="1",  
#              replace = TRUE, render = TRUE,openResult = TRUE,
#              reportTitle = "Base Data - Codebook")




#################################### Feature reduction of CCS variables#####

# 
CCS_list <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix %>% dplyr:: select (starts_with("CCS_"))
t_var<-select(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,target_leakage)
##t_var <- sqldf("select target_leakage from claims_charlson_ccs_pos_cpt_leakage_city_prov_elix")
CCS_list2 <- cbind(t_var,CCS_list)
# #h2o.init()
# 
# CCS_list2_h2o <- as.h2o(CCS_list2)
# y_ccs <- "target_leakage"
# x_ccs <- setdiff(names(CCS_list2_h2o), y_ccs)
# 
# CCS_list3 <- h2o.randomForest(x=x_ccs,
#                               y = y_ccs,
#                               training_frame = CCS_list2_h2o,
#                               ntrees = 50,
#                               nfolds = 10,
#                               sample_rate = 0.85,
#                               fold_assignment = "Modulo",
#                               stopping_tolerance = 1e-2,
#                               stopping_rounds = 2,
#                               seed = 77)
# 
# 
# CCS_list3_var_import <- h2o.varimp(CCS_list3)
# 
# 
# # top 25 comrobidites
# CCS_list3_import <-CCS_list3_var_import %>%
#   filter(rank(desc(relative_importance)) <= 25)
# CCS_list3_import$CCS <- CCS_list3_import$variable
# CCS_Top25<-as.data.frame(CCS_list3_import$CCS)
# write.csv(CCS_Top25,file="CCS_Top25_hipny.csv")
# 

#################################### Feature reduction of CCS variables#####

####Keeping the same CCS variables as the historic data#####
CCS_names_leakage<-read.csv("CCS_Top25_hipny.csv")
names(CCS_names_leakage)
CCS_leakage<-as.character(CCS_names_leakage$CCS_list3_import.CCS)
leakage_match<- match(CCS_leakage, names(CCS_list2))
leakage_match <- CCS_list2[,leakage_match]


# remove CCS from base data
##claims_charlson_ccs_pos_ckd_elix<-claims_member_leakage_dx_ckd_charlson_ccs_pos
no_ccs <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix[,!grepl("^CCS",names(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix ))]
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<- cbind(no_ccs, leakage_match)


#str(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,list.len = ncol(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix))

#################################### Feature reduction of CPT variables#####
# 
CPT_list <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix %>% dplyr:: select (starts_with("CPT_"))
cpt_var<-select(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,target_leakage)
##t_var <- sqldf("select target_leakage from claims_charlson_CPT_pos_cpt_leakage_city_prov_elix")
CPT_list2 <- cbind(cpt_var,CPT_list)
# #h2o.init()
# CPT_list2_h2o <- as.h2o(CPT_list2)
# y_CPT <- "target_leakage"
# x_CPT <- setdiff(names(CPT_list2_h2o), y_CPT)
# 
# CPT_list3 <- h2o.randomForest(x=x_CPT,
#                               y = y_CPT,
#                               training_frame = CPT_list2_h2o,
#                               ntrees = 50,
#                               nfolds = 10,
#                               sample_rate = 0.85,
#                               fold_assignment = "Modulo",
#                               stopping_tolerance = 1e-2,
#                               stopping_rounds = 2,
#                               seed = 77)
# 
# 
# CPT_list3_var_import <- h2o.varimp(CPT_list3)
# 
# 
# # top 15 comrobidites
# CPT_list3_import <-CPT_list3_var_import %>%
#   filter(rank(desc(relative_importance)) <= 10)
# CPT_list3_import$CPT <- CPT_list3_import$variable
# CPT_Top10<-as.data.frame(CPT_list3_import$CPT)
# write.csv(CPT_Top10,file="CPT_Top10_hipny.csv")


#################################### Feature reduction of CPT variables#####

####Keeping the same CPT variables as the historic data#####
CPT_names_leakage<-read.csv("CPT_Top10_hipny.csv")

# creates a table structructure using 10 10 CPT since CPT may not exist in a single feed

CPT_10 <- tidyr::spread(CPT_names_leakage,CPT_list3_import.CPT,X)
CPT_10 <-CPT_10[-1,]
CPT_10 <- CPT_10 %>% 
  mutate_if(is.integer, as.character)
CPT_10 <- CPT_10 %>% 
  mutate_if(is.character, as.factor)

CPT_10b <- bind_rows(CPT_10,CPT_list )[,intersect(names(CPT_10), names(CPT_list))]
CPT_10c <- join(CPT_10, CPT_10b,
                type = "full")

# recode factors NA to 0 for all columns
re_levels <- 
  function(col) {
    if (is.factor(col))  levels(col) <- c(levels(col), "0")
    col
  }

CPT_10c <- sapply(CPT_10c,re_levels)
CPT_10c[is.na(CPT_10c)] <- 0
CPT_10c <- as.data.frame(CPT_10c)



# remove CPT from base data
##claims_charlson_CPT_pos_ckd_elix<-claims_member_leakage_dx_ckd_charlson_CPT_pos
no_CPT <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix[,!grepl("^CPT",names(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix ))]
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<- cbind(no_CPT, CPT_10c)


######################
base_table6<-claims_charlson_ccs_pos_cpt_leakage_city_prov_elix
#base_table6$NORM_LINE_AMT_PAID<-scale(base_table6$CLAIM_LINE_AMT_PAID)
#base_table6$NORM_LINE_AMT_BILLED<-scale(base_table6$CLAIM_LINE_AMT_BILLED)



# construct analysis table

#str(base_table6,list.len = ncol(base_table6))

#saveRDS(base_table6, file="base_table6.Rda")
#base_table6 <- readRDS(file="base_table6.Rda")


base_table6$POS_NA <- NULL
#AHRQ_1 <- readRDS(file="AHRQ_1.Rda")


base_table6b <- inner_join(base_table6, AHRQ_1, by = c("CLAIM_CLAIM_ID"  = "CLAIM_IDx") )



base_table7<-base_table6b%>%select (CLAIM_CLAIM_ID,
                                   Days_of_service,ratio_billed_to_paid,PATIENT_AGE_NORM,INS_GROUP_ID,CLAIM_PATIENT_GENDER,
                                   Charlson_score, wscore_ahrq,starts_with("CCS_"),starts_with("POS_"),starts_with("BETOS_"),
                                   starts_with("AHRQ_"),starts_with("CPT_"),OVP)


#str(base_table7,list.len = ncol(base_table7))
colnames(base_table7)[colSums(is.na(base_table7)) > 0]



# get list of factors
# to do aggregation need to convert factors to numeric
factor_list <- c(names(Filter(is.factor,base_table7)))
numeric_list <- c(names(Filter(is.numeric,base_table7)))

base_table8 <- base_table7

# change factors to numeric
# 
base_table8<- base_table8 %>%
  mutate_if(is.factor, ~as.numeric(as.character(.)))

# aggregate with group by find max values

base_table8  <- base_table8 %>%
  group_by(CLAIM_CLAIM_ID,OVP) %>%
  summarise_all((funs(max)))


# change old factors back to factors
base_table8[factor_list] <- lapply(base_table8[factor_list], factor)
#base_table8[numeric_list] <- lapply(base_table8[numeric_list], numeric)


# collapse insurace group
base_table8$INS_GROUP_ID <- fct_lump(base_table8$INS_GROUP_ID, n=10)

base_table8$CLAIM_CLAIM_ID<-NULL
base_table8$OVP<-as.factor(base_table8$OVP)
#base_table8$ratio_billed_to_paid <-  ifelse(base_table8$ratio_billed_to_paid==Inf,1,base_table8$ratio_billed_to_paid)


#str(base_table8,list.len = ncol(base_table8))

# remove factors wih single level

base_table8 <- base_table8[, sapply(base_table8, nlevels) !=1]


base_table8$target <- base_table8$OVP
base_table8$OVP <- NULL
base_table8$POS_83 <- NULL
base_table8$CLAIM_PATIENT_GENDER <- NULL


#base_table8$INS_GROUP_ID <- NULL


#str(base_table8,list.len = ncol(base_table8))

colnames(base_table8)[colSums(is.na(base_table8)) > 0]
#saveRDS(base_table8, file="base_table8_193.Rda")
#base_table8 <- readRDS(file="base_table8_193.Rda")


# collapse insurace group
#base_table8$INS_GROUP_ID <- fct_lump(base_table8$INS_GROUP_ID, n=10)

# remove constants
#base_table8 <- base_table8[, sapply(base_table8, nlevels) !=1]

# 
# dscriptives_base_table8 <- describeBy(base_table8, group = base_table8$target)
# 
# 
# 
# 
# makeDataReport(base_table8, vol="1", render = TRUE, 
#                replace = TRUE, openResult = TRUE, codebook = TRUE,
#                reportTitle = "Training Data - Report")
# 
# makeCodebook(base_table8, vol="1",  
#              replace = TRUE, render = TRUE,openResult = TRUE,
#              reportTitle = "Training Data - Codebook")







idx <- sample(seq(1,2), size = nrow(base_table8), replace = TRUE, prob = c(0.7, 0.3))
train <- base_table8[idx == 1,]
test <- base_table8[idx == 2,]


table(base_table8$target)
prop.table(table(base_table8$target))


table(train$target)
prop.table(table(train$target))


train_auto_ml <- train
test_auto_ml <- test

# 
# 
# logistic_play <- sqldf("select target, ratio_billed_to_paid, PATIENT_AGE_NORM,wscore_ahrq,
#                        Charlson_score,Days_of_service from base_table8")
# 
# Lidx <- sample(seq(1,2), size = nrow(logistic_play), replace = TRUE, prob = c(0.7, 0.3))
# Ltrain <- logistic_play[Lidx == 1,]
# Ltest <- logistic_play[Lidx == 2,]
# 
# logistic_reg <- glm(target ~ ., data = Ltrain, family = binomial)
# summary(logistic_reg)
# 
# logistic_reg <- glm(target ~ wscore_ahrq +
#                     Charlson_score , data = Ltrain, family = binomial)
# # 
# # summary(logistic_reg)
# 
# logistic_reg_pred <- predict(logistic_reg, newdata=Ltest, type = "response")
# confusionMatrix(data = as.numeric(logistic_reg_pred) > 0.5, reference = Ltest$target)
# 
# logistic_reg_pred <- as.data.frame(logistic_reg_pred)
# 
# 



# C5 rule
ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
#sink('treeC5_tree_boost.txt')
summary(ruleC5_boost )
sink()

predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
table(predict_rulec5_boost,test_auto_ml$target )
summary(predict_rulec5_boost)





################################################################################

# H2o Models

# how to get h2o help
#args(h2o.deeplearning)
#help(h2o.deeplearning)
#example(h2odeeplearning)



train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "target"
x <- setdiff(names(train), y)




# GBM

# if models do not take long to run add reproducible = TRUE,

response <- "target"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)

#train <- as.h2o(train_auto_ml)
gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10)
h2o.varimp(gbm)


summary(gbm)
# as dataframe - if works put st end of all models
head(as.data.frame(h2o.varimp(gbm)),n=20)
#h2o.varimp_plot(gbm)
# AUC if works add to all models
#h2o.auc(gbm,valid=TRUE)


gbm@model$validation_metrics
h2o.confusionMatrix(gbm,valid=TRUE)
h2o.hit_ratio_table(gbm,valid = T)[1,2]

pred_gbm <- h2o.performance(gbm, newdata = test)
pred_gbm
#plot(pred_gbm)
#plot(pred_gbm, type = "roc")
#plot(pred_gbm, type = "cutoffs")

h2o.saveModel(gbm, path = "gbm", force =TRUE)
#"/home/dless1/BCBSMN/gbm/GBM_model_R_1543339224218_215"



gbm_2a <- h2o.gbm(x= predictors, y=response, training_frame = train, validation_frame = test, nfolds = 10)

summary(gbm_2a)

head(as.data.frame(h2o.varimp(gbm_2a)),n=10)
h2o.saveModel(gbm_2a, path = "gbm", force =TRUE)
#"/home/dless1/BCBSMN/gbm/GBM_model_R_1543339224218_975"




# with balance classes with HIPNY

# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 10
)

summary(gbm2)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
head(as.data.frame(h2o.varimp(gbm2)),n=10)



h2o.confusionMatrix(gbm2,valid=TRUE)






# GBM GRID
# gbm using hper parameter search
hyper_params = list(max_depth = seq(1,29,2))

grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = list(strategy = "Cartesian"),
  algorithm = "gbm",
  grid_id = "depth_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 200,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  stopping_rounds =5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10
)
grid
# sort grid models be creasing AUC
sortedGrid <- h2o.getGrid("depth_grid", sort_by="auc", decreasing = TRUE)
sortedGrid

# find the range of max_depth for the top 5 models
topDepths = sortedGrid@summary_table$max_depth[1:5]
minDepth = min(as.numeric(topDepths))
maxDepth = max(as.numeric(topDepths))
minDepth
maxDepth

# HIPNY includes balance classes = TRUE for low signal

hyper_params = list(
  max_depth = seq(minDepth, maxDepth, 1),
  sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate_per_tree = seq(0.2, 1, 0.01),
  col_sample_rate_change_per_level = seq(0.9, 1.1, 0.01),
  min_rows = 2^seq(0, log2(nrow(train)) - 1, 1),
  nbins = 2^seq(4, 10, 1),
  nbins_cats = 2^seq(4, 12, 1),
  min_split_improvement = c(0, 1e-8, 1e-6, 1e-4),
  balance_classes = c(TRUE, FALSE),
  histogram_type = c("UniformAdaptive", "QuantilesGlobal", "RoundRobin")
  
)

search_criteria = list(
  
  strategy = "RandomDiscrete",
  max_runtime_secs = 36000,
  max_models = 100,
  seed = 77,
  stopping_rounds = 5,
  stopping_metric = "AUC",
  stopping_tolerance = 1e-3
)

# if try different parametrs - change grid_id each time
grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = search_criteria,
  algorithm = "gbm",
  grid_id = "final_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  max_runtime_secs = 360,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10,
  seed = 77
)

##### from h2o tutorials in rclas h20 folder
# sort grid models by AUC
sortedGrid <- h2o.getGrid("final_grid", sort_by = "auc", decreasing = TRUE)
print(sortedGrid)

summary(grid)

##########################################################################


##########################################################################


# Random Forest

nfolds = 10

rf <- h2o.randomForest(x=x,
                       y = y,
                       training_frame = train,
                       ntrees = 500,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       seed = 77)


summary(rf)
h2o.saveModel(rf, path = "rf", force =TRUE)
#"/home/dless1/BCBSMN/rf/DRF_model_R_1543339224218_3317"

head(as.data.frame(h2o.varimp(rf)),n=10)

pred_rf <- h2o.performance(rf, newdata = test,  valid = TRUE)

summary(pred_rf)
pred_rf@model$validation_metrics
pred_rf
plot(pred_rf)

head(as.data.frame(h2o.varimp(pred_rf)),n=10)




rf_2 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         ntrees = 500,
                         nfolds = nfolds,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)
summary(rf_2)
h2o.saveModel(rf_2, path = "rf_2", force =TRUE)

#"/home/dless1/BCBSMN/rf_2/DRF_model_R_1543339224218_3891"



pred_rf_2 <- h2o.performance(rf_2, newdata = test,  valid = TRUE)
pred_rf_2
h2o.varimp(rf_2)

rf_3 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         validation_frame = test,
                         ntrees = 500,
                         nfolds = nfolds,
                         nbins = 50,
                         balance_classes = TRUE,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)

# pred_rf_3 <- h2o.performance(rf_3, newdata = test,  valid = TRUE)
# pred_rf_3

summary(rf_3)

head(as.data.frame(h2o.varimp(rf_3)),n=10)

h2o.saveModel(rf_3, path = "rf_3", force =TRUE)
#"/home/dless1/BCBSMN/rf_3/DRF_model_R_1543339224218_4225"

#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

# xgboost

nfolds <- 10
xgboost <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 200,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost)

head(as.data.frame(h2o.varimp(xgboost)),n=10)
#h2o.varimp_plot(xgboost)

h2o.saveModel(xgboost, path = "xgboost", force =TRUE)
#"/home/dless1/hipny/xgboost/XGBoost_model_R_1597235054235_1"

h2o.performance(xgboost)







nfolds=10
xgboost_notest <- h2o.xgboost(x=x,
                              y = y,
                              training_frame = train,
                              ntrees = 200,
                              nfolds = nfolds,
                              fold_assignment = "Modulo",
                              keep_cross_validation_predictions = TRUE,
                              max_depth = 3,
                              min_rows = 2,
                              learn_rate =0.2,
                              seed = 77)


summary(xgboost_notest)

h2o.saveModel(xgboost_notest, path = "xgboost_notest", force =TRUE)

#"/home/dless1/BCBSMN/xgboost_notest/XGBoost_model_R_1543339224218_4944"


#pred_XGBOOST2 <- h2o.performance(xgboost_notest, newdata = test,  valid = TRUE)

pred_XGBOOST <-h2o.predict(xgboost_notest,test)

ped_df <- as.data.frame(pred_XGBOOST)

#cl_ids <- sqldf("select member_ID, CLAIM_ID,FEED_ID, target from base_table6  ")


#claim_probabilities <- cbind(cl_ids,ped_df )

claims_to_investigate <- sqldf("select * from claim_probabilities where predict = 1 and p1 >= 0.975 order by p1 desc")



##########
# h2o ensemble

# stacked ensemble model
# random forest and GBM



# max and min rows based upon above max and min depth
# experiment with fold_assignment "AUTO", "Random", "Modulo", "Stratified"

nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 200,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 200,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)

solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id))


h2o.saveModel(ensemble, path = "ensemble", force =TRUE)

#"/home/dless1/BCBSMN/ensemble/ensemble_binomial"



perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_solo_dl))

ensemble_auc_test <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
pred_ensemble





gbm_grid_ensemble <- h2o.grid(
  algorithm = "gbm",
  grid_id = "gbm_grid_binomial",
  x = x,
  y = y,
  training_frame = train,
  ntrees = 500,
  seed = 77,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  hyper_params = hyper_params,
  search_criteria = search_criteria)



ensemble2 <- h2o.stackedEnsemble(
  x = x,
  y = y,
  training_frame = train,
  model_id = "ensemble_gbm_grid_binomial",
  base_models = gbm_grid_ensemble@model_ids
)

h2o.saveModel(ensemble2, path = "fit2", force =TRUE)
#"/home/dless1/BCBSMN/fit2/ensemble_gbm_grid_binomial"

perf_grid_ensemble <- h2o.performance(ensemble2, newdata = test)

# compare to base learner performance on test setwd
getauc <- function(mm) h2o.auc(h2o.performance(h2o.getModel(mm), newdata = test))
base_leaner_aucs2 <- sapply(gbm_grid_ensemble@model_ids, getauc)
baselearner_best_auc_test2 <- max(base_leaner_aucs2)
ensemble_auc_test2 <- h2o.auc(perf_grid_ensemble )
print(sprintf("Best Base-learner Test AUC GRID:  %s", baselearner_best_auc_test2))
print(sprintf("Ensemble Test AUC GRID:  %s", ensemble_auc_test2))
perf_grid_ensemble





family <- "binomial"

# default learners
learner <- c("h2o.glm.wrapper","h2o.randomForest.wrapper", "h2o.gbm.wrapper", "h2o.deeplearning.wrapper")

# from docs 

metalearner <- "h2o.glm.wrapper"




# start with 10 fold cross validation

fit <- h2o.ensemble(x = x,
                    y = y,
                    training_frame = train,
                    family = family,
                    learner = learner,
                    metalearner = metalearner,
                    cvControl = list(V=10))


# performance
perf_E1 <- h2o.ensemble_performance(fit, newdata = test)
perf_E1


print(perf_E1, metric = "MSE")
print(perf_E1, metric = "AUC")

h2o.saveModel(fit, path = "fit2", force =TRUE)


##########

# deep learning


model_nn <- h2o.deeplearning(x = features,
                             training_frame = train,
                             autoencoder = TRUE,
                             reproducible = TRUE,
                             ignore_const_cols = FALSE,
                             seed = 77,
                             hidden = c(10, 2, 10),
                             epochs = 100,
                             activation = "Tanh")

model_nn



model_nn_dim_2 <- h2o.deeplearning(x = features,
                                   y=response,
                                   training_frame = train,
                                   validation_frame = test,
                                   reproducible = TRUE,
                                   ignore_const_cols = FALSE,
                                   seed = 77,
                                   hidden = c(10, 2, 10),
                                   epochs = 100,
                                   activation = "Tanh")

model_nn_dim_2 
summary(model_nn_dim_2)


























