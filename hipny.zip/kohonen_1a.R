

# sOMBREREO testing


library(SOMbrero)
library(kohonen)
library(dplyr)
library(NbClust)
library(cluster)
library(factoextra)
set.seed(77)




base_table8 <- readRDS(file="base_table8.Rda")


junk <- as.matrix(base_table8 )
base_table8 <- as.data.frame(junk)


base_table8$Days_of_service <- as.numeric(as.character(base_table8$Days_of_service))
base_table8$ratio_billed_to_paid <- as.numeric(as.character(base_table8$ratio_billed_to_paid))
base_table8$PATIENT_AGE_NORM <- as.numeric(as.character(base_table8$PATIENT_AGE_NORM))
base_table8$Charlson_score <- as.numeric(as.character(base_table8$Charlson_score))
base_table8$wscore_ahrq  <- as.numeric(as.character(base_table8$wscore_ahrq))

base_table88 <- base_table8

# remove factors with 1 level

base_table8 <- base_table8[, sapply(base_table8, nlevels) !=1]
base_table8 <- data.frame(r_index = row.names(base_table8), base_table8)
id<- sqldf("select r_index from base_table8")
the_target  <- sqldf("select target from base_table8")

base_table8$target <- NULL
base_table8$r_index <- NULL

base_table9 <- base_table8



# make factors numeric
kohonen1 <- base_table9

# change factors to numeric
# 
kohonen1<-kohonen1 %>%
  mutate_if(is.factor, ~as.numeric(as.character(.)))

# 
# som1 <- trainSOM(x.data = kohonen1, dimension = c(5,5), nb.save = 10, maxit = 500, scaling = "none")
# table(som1$clustering)
# summary(som1)
# 
# plot(som1, what = "energy")
# 
# plot(som1, what = "obs", type = "hitmap")
# 
# par(mfrow = c(1,2))
# plot(som1, what = 'prototypes', type = "color", var = 1, main = "prototypes - x1")
# plot(som1, what = 'prototypes', type = "color", var = 22, main = "prototypes - x2")
# 
# 
# # means
# plot(som1, what = 'obs', type = "color", var = 1, main = "obs mean values - x1")
# plot(som1, what = 'obs', type = "color", var = 22, main = "obs mean values - x2")
# ###############################################################################



som2 <- trainSOM(x.data = kohonen1, dimension = c(10,10), nb.save = 10, maxit = 200,
                 scaling = "none")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=5)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)

# add cluster back to base data
som_clusters <- as.data.frame(out_grid)
som_clusters <- sqldf("select sc from som_clusters" )

som_clusters <- data.frame(id = row.names(som_clusters), som_clusters)

som_clusters_2 <- sqldf("select c.*, s.* from som_clusters c, som_dist s
                        where c.sc = s.r_index")
som_clusters_2_id <- sqldf("select id, sc from som_clusters_2")

som_clusters_2$id <- NULL
som_clusters_2$sc  <- NULL
som_clusters_2$r_index  <- NULL
colnames(som_clusters_2)[colSums(is.na(som_clusters_2)) > 0]

out_distm <- as.matrix(out_dist)
str(som_clusters_2,list.len = ncol(som_clusters_2))


# optimal number of clusters
asw <- numeric(20)

for (k in 2:20)
  asw[k] <- pam(out_distm, k) $ silinfo $ avg.width
k.best <- which.max(asw)
print(k.best)



p2m <- pam(out_distm, 2, diss = TRUE,   medoids =  c(1,16))
table(p2m$cluster)

PAM_cluster <- as.data.frame(p2m$cluster)
PAM_cluster$cluster <- PAM_cluster[,2]
PAM_cluster <- data.frame(PAM_id = row.names(PAM_cluster), PAM_cluster)
PAM_cluster2 <- sqldf("select p.PAM_id, s.id, p.cluster as PAM_cluster
                      from som_clusters_2_id s, PAM_cluster p
                      where p.PAM_id = s.sc") 

str(PAM_cluster2,list.len = ncol(PAM_cluster2))

#out_dist2 <- cbind(out_dist, cluster = p2m$cluster)

base_table8 <- data.frame(r_index = row.names(base_table8), base_table8)
base_table10 <- sqldf("select b.*, p.PAM_cluster
                      from base_table8 b,PAM_cluster2 p
                      where b.r_index = p.id")

base_table10$r_index <- NULL
base_table10$PAM_cluster <- as.factor(base_table10$PAM_cluster)

str(base_table10,list.len = ncol(base_table10))



idx <- sample(seq(1,2), size = nrow(base_table10), replace = TRUE, prob = c(0.7, 0.3))
train <- base_table10[idx == 1,]
test <- base_table10[idx == 2,]


train_auto_ml <- train
test_auto_ml <- test


train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "PAM_cluster"
x <- setdiff(names(train), y)

# GBM

# if models do not take long to run add reproducible = TRUE,

response <- "PAM_cluster"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)


SOM_list <- h2o.randomForest(x=x,
                              y = y,
                              training_frame = train,
                              ntrees = 50,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)


SOM_list_var_import <- h2o.varimp(SOM_list)


# top 25 comrobidites

SOM_list_var_import <-SOM_list_var_import[SOM_list_var_import$relative_importance >
                                            quantile(SOM_list_var_import$relative_importance , 0.75), ]


SOM_list_var_import$feature <- SOM_list_var_import$variable
SOM_Top25<-as.data.frame(SOM_list_var_import$feature)

names(SOM_Top25)
SOM_short<-as.character(SOM_list_var_import$feature)
SOM_match<- match(SOM_short, names(base_table10))
SOM_match <- base_table10[,SOM_match]


base_table11 <- cbind(SOM_match, the_target)




idx <- sample(seq(1,2), size = nrow(base_table11), replace = TRUE, prob = c(0.7, 0.3))
train <- base_table11[idx == 1,]
test <- base_table11[idx == 2,]


train_auto_ml <- train
test_auto_ml <- test


train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "target"
x <- setdiff(names(train), y)

# GBM

# if models do not take long to run add reproducible = TRUE,

response <- "PAM_cluster"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)



# 
# mds.tau <- function(H)
# {
#   n <- nrow(H)
#   P <- diag(n) - 1/n
#   return(-0.5 * P %*% H %*% P)
# }
# B<-mds.tau(out_distm)
# eig <- eigen(B, symmetric = TRUE)
# v <- eig$values[1:2]
# #convert negative values to 0.
# v[v < 0] <- 0
# transformed_matrix <- eig$vectors[, 1:2] %*% diag(sqrt(v))
# 
# transformed_matrix <- as.data.frame(transformed_matrix)



# 
# nb <- NbClust(transformed_matrix, diss = NULL, distance = "euclidean",
#               min.nc = 2, max.nc = 6, method = "kmeans",
#               index = "all", alphaBeale = 0.1)
# 
# hist(nb$Best.nc[1,], breaks = max(na.omit(nb$Best.nc[1,])))
# 
# 
# km <- kmeans(data_2_cluster2, centers = 5, nstart = 25)
# fviz_cluster (km, data =data_2_cluster2 , pointsize = 0.5, labelsize = 2, main = "Clusters of Paid Amount and Number Claims Normalized")
# 
# # extract cluster assignment vector from the kmeans model
# clust_km <- km$cluster
# centers <- as.data.frame(km$centers)
# # add cluster to dataframe
# jcode_descriptives3 <- mutate(jcode_descriptives2, cluster = clust_km)
# 






str(som_clusters_2,list.len = ncol(som_clusters_2))





# 
# 
# factor_list3 <- c(names(Filter(is.factor,base_table88)))
# fact_match3 <- match(factor_list3, names(base_table88))
# catVarsFac <- base_table88[,fact_match3]
# 
# cluster_assignment <- som2$codes
# catVarsFac$cluster <- cluster_assignment 
# 
# # chi squares for SOM code
# chis <- t(round(cbind(apply(catVarsFac, 2, function(x) {
#   ch <- chisq.test(catVarsFac$cluster, x)
#   c(unname(ch$statistic), ch$parameter, ch$p.value )})), 3))
# 
# 
# chis <- fact_match3 %>%
#   summarise_all(funs(chisq.test(.,catVarsFac$cluster)$p.value))
# str(catVarsFac,list.len = ncol(catVarsFac))
# 
# 
# chis <- base_table88 %>%
#   summarise_all(funs(chisq.test(.,base_table88$cluster)$p.value), -one_of("cluster"))
# 
# 
# chis <- data.frame(lapply(catVarsFac[,-1], function(x) chisq.test(table(x,catVarsFac$cluster), simulate.p.value = TRUE)$p.value))
# 




# does anova for cluster membership - significance is put into relavant clusters
summary(som2)

plot(som2, what = "prototypes", type = "lines", print.title = TRUE)

plot(som2, what = "obs", type = "barplot", show.names  = TRUE)


plot(som2, what = "obs", type = "radar", show.names = TRUE)

rownames(kohonen1)

plot(som2, what = "obs", type = "names",  show.names = TRUE)

plot(som2, what = "prototypes", type = "3d",  variable = 2, show.names = TRUE)

# distance between protptypes

plot(som2, what = "prototypes", type = "poly.dist",   show.names = TRUE)


plot(som2, what = "prototypes", type = "umatrix",   show.names = TRUE)


plot(som2, what = "prototypes", type = "smooth.dist")

plot(som2, what = "prototypes", type = "mds")


#################### kohonen



#kohonen1 <- base_table8

# change factors to numeric
# 
#kohonen1<-kohonen1 %>%
#  mutate_if(is.factor, ~as.numeric(as.character(.)))


kohonen1_matrix <- as.matrix(kohonen1)

som_grid <- somgrid(xdim = 6, ydim = 6 , topo = "hexagonal")

som_model <- som(kohonen1_matrix,
                grid = som_grid,
                rlen=500,
                alpha=c(0.05,0.01),
                keep.data = TRUE)

plot(som_model, type="change")

plot(som_model, type = "count", main="Node Counts")

# weight vecor
plot(som_model, type = "codes")

# heatmap

plot(som_model, type = "property", property = 
       getCodes(som_model)[,4], main=colnames(getCodes(som_model))[4],
     palette.name = rainbow)


# clustering codes
somcodes <- som_model$codes
wss <- (nrow(somcodes)-1 )* sum(apply(somcodes,2,var))
for (i in 2:15) {
    wss[i] <- sum(kmeans(somcodes, centers = i)$withinss)
        }
plot(wss)

som_cluster <- cutree(hclust(dist(som_model$codes)), 6)


som3 <- som(kohonen1_matrix, grid = somgrid(6,6,"rectangular"))


############################################################################################


# for number of cells in grid   abs( 3 * (sqrt(number of features)))

# hierarcial cluster example
library(rlang)
library(tidyverse)
library(magrittr)
library(RColorBrewer)
library(kohonen)

som_data1 <-  base_table9


numerics = summarise_all(som_data1, is.numeric) %>%
  as.logical

factors <- names(som_data1) %>%
  .[numerics]


numerics <- names(som_data1) %>%
  .[numerics]

data_list = list()
distances = vector()


for (fac in factors){
  data_list[[fac]] <- kohonen::classvec2classmat(som_data1[[fac]])
  distances <- c(distances, 'tanimoto')
}

data_list[['numerics']] <- scale(som_data1[,numerics])
distances <- c(distances, 'euclidean')

str(data_list)

map_dimension = abs( 3 * (sqrt(105)))
recalculate_map = T
n_iterations = 1000
recalculate_no_clusters = T

som_grid = kohonen::somgrid(xdim = map_dimension
                            , ydim = map_dimension
                            , topo = "hexagonal")

if(recalculate_map == F & file.exists('som.Rdata') == T){
  load('som.Rdata')
} else {
         m <- kohonen::supersom(data_list
                                , grid = som_grid
                                , rlen = n_iterations
                                , alpha = 0.05
                                , whatmap = c(factors, 'numerics')
                                , dist.fcts = distances)
         save(m, file = 'som.Rdata')
}
plot(m,type=changes)




plot(m,type="counts")

plot(m,type = "dist.neighbours")

plot(m,type = "codes")

plot(m,type="quality")











