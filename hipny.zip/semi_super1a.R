
setwd("~/hipny")

library(ssc)



base_table8 <- readRDS(file="base_table8.Rda")


junk <- as.matrix(base_table8 )
base_table8 <- as.data.frame(junk)
base_table8 <- base_table8 %>% mutate(id = row_number())


base_table8  <- data.frame(r_index = row.names(base_table8 ), base_table8 )
str(base_table8,list.len = ncol(base_table8))

cls <- which(colnames(base_table8) == "target")

# indipendents
x <- base_table8[, -cls] 
# dependent >> classes
y <- base_table8[, cls]

set.seed(77)

# use 50% of instances for training
#tra.idx <- sample(x = length(y) , size = ceiling(length(y) * 0.5))


idx <- sample(seq(1,2), size = nrow(base_table8), replace = TRUE, prob = c(0.5, 0.5))
tra.idx <- base_table8[idx == 1,]
tst.idx <- base_table8[idx == 2,]
tra.idx$idx <- NULL
tst.idx$idx <- NULL


# training instnces
xtrain <- tra.idx[,-1] 
ytrain <- tra.idx[,ncol(tra.idx)] #  classes of training instances



# use 70% of train instances as unlabeled set
idx <- sample(seq(1,2), size = nrow(tra.idx), replace = TRUE, prob = c(0.7, 0.3))
tra.na.idx <- tra.idx[idx == 1,]
tra.na.idx$idx <- NULL


# remove classes on unlabeled instances
tra.na.idx$target<- NA

# use the other 50% of instances for inductive test
#tst.idx <- setdiff(1:length(y), tra.idx)

# test instances
xitest <- tst.idx[,-1] 
yitest <- tst.idx[,ncol(tst.idx)]

# use the unlabeled examples for transductive test
tra_na_idx <- tra.na.idx
tra_idx <- tra.na.idx

xttest <- sqldf("select n.* from tra_na_idx n, tra_idx i where 
                n.r_index = i.r_index")

xttest$target <- NULL
xttest$.r_index <- NULL

yttest <- sqldf("select n.target from tra_na_idx n, tra_idx i where 
                n.r_index = i.r_index")


# computing distance and kernal matricies
xtrain$r_index <- NULL

dtrain <- as.matrix(proxy::dist(xtrain, method = "euclidean", by_rows = TRUE))















