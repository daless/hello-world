
setwd("~/hipny")

library(ssc)
library(sqldf)
library(tidyr)


library(caret)
library(ggplot2)

library(C50)
library(lubridate)

library(dplyr)

library(tidyverse)



base_table8 <- readRDS(file="base_table8.Rda")
# collapse insurace group
base_table8$INS_GROUP_ID <- fct_lump(base_table8$INS_GROUP_ID, n=10)

# remove constants
base_table8 <- base_table8[, sapply(base_table8, nlevels) !=1]


junk <- as.matrix(base_table8 )
base_table8 <- as.data.frame(junk)


base_table8$Days_of_service <- as.numeric(as.character(base_table8$Days_of_service))
base_table8$ratio_billed_to_paid <- as.numeric(as.character(base_table8$ratio_billed_to_paid))
base_table8$PATIENT_AGE_NORM <- as.numeric(as.character(base_table8$PATIENT_AGE_NORM))
base_table8$Charlson_score <- as.numeric(as.character(base_table8$Charlson_score))
base_table8$wscore_ahrq  <- as.numeric(as.character(base_table8$wscore_ahrq))


base_table8  <- data.frame(r_index = row.names(base_table8 ), base_table8 )
str(base_table8,list.len = ncol(base_table8))

# force factors to be numeric
base_table8<-base_table8 %>%
  mutate_if(is.factor, ~as.numeric(as.character(.)))




cls <- which(colnames(base_table8) == "target")

# indipendents
x <- base_table8[, -cls] 
# dependent >> classes
y <- base_table8[, cls]

set.seed(77)

# use 50% of instances for training
#tra.idx <- sample(x = length(y) , size = ceiling(length(y) * 0.5))


idx <- sample(seq(1,2), size = nrow(base_table8), replace = TRUE, prob = c(0.5, 0.5))
tra.idx <- base_table8[idx == 1,]
tst.idx <- base_table8[idx == 2,]
tra.idx$idx <- NULL
tst.idx$idx <- NULL


# training instnces
xtrain <- tra.idx[,-1] 
ytrain <- tra.idx[,ncol(tra.idx)] #  classes of training instances



# use 70% of train instances as unlabeled set
idx <- sample(seq(1,2), size = nrow(tra.idx), replace = TRUE, prob = c(0.7, 0.3))
tra.na.idx <- tra.idx[idx == 1,]
tra.na.idx$idx <- NULL


# remove classes on unlabeled instances
tra.na.idx$target<- NA

# use the other 50% of instances for inductive test
#tst.idx <- setdiff(1:length(y), tra.idx)

# test instances
xitest <- tst.idx[,-1] 
yitest <- tst.idx[,ncol(tst.idx)]

# use the unlabeled examples for transductive test
tra_na_idx <- tra.na.idx
tra_idx <- tra.na.idx

xttest <- sqldf("select n.* from tra_na_idx n, tra_idx i where 
                n.r_index = i.r_index")

xttest$target <- NULL
xttest$.r_index <- NULL

yttest <- sqldf("select n.target from tra_na_idx n, tra_idx i where 
                n.r_index = i.r_index")


# computing distance and kernal matricies
xtrain$r_index <- NULL

dtrain <- as.matrix(proxy::dist(xtrain, method = "euclidean", by_rows = TRUE))
ditest <- as.matrix(proxy::dist(xitest, y = xtrain, method = "euclidean",
                                by_rows = TRUE))














