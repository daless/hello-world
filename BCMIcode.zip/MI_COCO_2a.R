
#  scp auditpoint2.csv dless1@apsrd9425:/home/dless1/BCBSMI
#  scp NOV_DEC_2021.rpt dless1@apsrd9425:/home/dless1/BCBSMI

# txt files were deleted for space wqill need to copy from desktop

setwd("~/BCBSMI")


library(comorbidity)
library(stringr)
library(sqldf)
library(data.table)
library(dataMaid)

#files restore
# claims <- readRDS( file="claims.Rda")
# claims <- readRDS( file="claims.Rda")
# claims <- readRDS( file="claims.Rda")
# FIPS2 <- readRDS( file="FIPS2.Rda")
# DX_claim <- readRDS( file="DX_claim.Rda")
# charlson_scores <- readRDS( file="charlson_scores.Rda")
# elixhauser_scores <- readRDS( file="elixhauser_scores.Rda")
# CCS_Dummy_test3 <- readRDS( file="CCS_Dummy_test3.Rda")
# POS2 <- readRDS( file="POS2.Rda")
# CPT2 <- readRDS( file="CPT2.Rda")
# PROV_TYPE2 <- readRDS( file="PROV_TYPE2.Rda")
# AHRQ_1 <- readRDS(file="AHRQ_1.Rda")
# base1 <- readRDS(file="base1.Rda")
# base2 <- readRDS(file="base2.Rda")





# auditpoint1<-read.csv("Explorer_Pivot_Full_Data_data.csv", header=TRUE)
# #str(auditpoint1,list.len = ncol(auditpoint1))
# 
# 
# # rename columns
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.ID')] <- 'Claim_ID'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Age.from.Last.Status.Date')] <- 'SATUS_AGE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Age.from.Paid.Date')] <- 'PD_AGE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Age.from.Pre.Validation.Date')] <- 'PV_AGE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Audit.Name')] <- 'AUDIT_NAME'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Audit.Type')] <- 'AUDIT_TYPE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Audit')] <- 'Audit'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Case.Assigned.To.Team')] <- 'TEAM'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Case.Assigned.To.User')] <- 'USER'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Case.Hold.Flag')] <- 'HOLD'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Case.Run.Date')] <- 'CASE_RUN_DATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Case.Status.Date')] <- 'CASE_STATUS_DATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Case.Workflow')] <- 'WORKFLOW'
# colnames(auditpoint1)[which(names(auditpoint1) == 'CLAIM.CASE.REPORT.Group.ID')] <- 'GROUP_ID'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Financial.Error.Type')] <- 'EROOR_TYPE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Form.Type')] <- 'FORM_TYPE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Funding.Code')] <- 'FUNDING'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Group.Type')] <- 'GROUP_TYPE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.ITS.Flag')] <- 'ITS_FLAG'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.LOB.Rollup')] <- 'LOB_ROLLUP'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.LOB')] <- 'LOB'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.MBU.Rollup')] <- 'MBU'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Member.Contract.State')] <- 'STATE_CONTRACT'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Member.State')] <- 'STATE_MEMBER'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Paid.Date')] <- 'PD_DATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Par.Flag')] <- 'PAR'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Primacy.Reason')] <- 'PRIMACY_REASON'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Prior.Status.Date')] <- 'PRIOR_DATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Prior.Status')] <- 'PRIOR_STATUS'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Product.Type')] <- 'PRODUCT_TYPE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Risk.Class')] <- 'RISK_CLASS'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Service.Date')] <- 'SERV_DATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Status.Date')] <- 'STAT_DATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Status.Reason.AP')] <- 'STAT_REASON'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Status.Reason')] <- 'STATUS_REASON'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Status.Team')] <- 'STATUS_TEAM'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Status')] <- 'CLAIM_STATUS'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Submitting.Provider.State')] <- 'PROV_STATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Validation.Rejection.Date')] <- 'REG_DATE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Work.Status')] <- 'WORK_STATUS'
# colnames(auditpoint1)[which(names(auditpoint1) == 'ï..Explorer...Row.Selection')] <- 'REJECT'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Inventory...Selected.Age.Measure')] <- 'INV_AGE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Paid...30.Flag')] <- 'PD_30_FLAG'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Pre.Validated.Flag')] <- 'VAL_FLAG'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Root.Cause.Flag')] <- 'CAUSE_FLAG'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Risk.Class.Group')] <- 'RISK_GRP'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Root.Cause')] <- 'ROOT_CAUSE'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim.Provider.ID')] <- 'PROV_ID'
# 
# 
# 
# fnames <- c('AUDIT_NAME', 'AUDIT_TYPE', 'Audit', 'CAUSE_FLAG', 'CLAIM_STATUS',
#             'EROOR_TYPE', 'FORM_TYPE', 'FUNDING', 'GROUP_ID', 'GROUP_TYPE', 'HOLD',
#             'INV_AGE', 'ITS_FLAG', 'LOB_ROLLUP', 'LOB', 'MBU', 'PAR', 'PD_30_FLAG',
#             'PD_AGE', 'PRIMACY_REASON', 'PRIOR_STATUS', 'PRODUCT_TYPE', 'PROV_STATE',
#             'PV_AGE', 'REJECT', 'RISK_CLASS', 'RISK_GRP', 'ROOT_CAUSE', 'SATUS_AGE',
#             'STAT_REASON', 'STATE_CONTRACT', 'STATE_MEMBER', 'STATUS_REASON', 'STATUS_TEAM',
#             'TEAM', 'USER', 'VAL_FLAG', 'WORK_STATUS', 'WORKFLOW' )
# 
# auditpoint1[fnames] <- lapply(auditpoint1[fnames], as.factor)
# auditpoint1[is.na(auditpoint1)] <-0
# 
# charnames <- c('CASE_RUN_DATE', 'CASE_STATUS_DATE', 'PD_DATE', 'PRIOR_DATE',
#                'PROV_ID', 'REG_DATE', 'SERV_DATE', 'STAT_DATE' )
# auditpoint1[charnames] <- lapply(auditpoint1[charnames], as.character)
# 
# 
# 
# # remove from DF based upon datamiad
# # AUDIT_TYPE,AUDIT_NAME,EROOR_TYPE, FUNDING,GROUP_TYPE,HOLD, LOB_ROLLUP, MBU,PAR,
# # PRIOR_STATUS,PRODUCT_TYPE,PROV_STATE,REJECT,RISK_CLASS,RISK_GRP,ROOT_CAUSE, STATE_CONTRACT,
# #STATUS_TEAM, TEAM, USER,WORK_STATUS, WORKFLOW,PD_DATE,
# 
# auditpoint2 <- sqldf("select Claim_ID,  Audit, 
#                      CASE_RUN_DATE, CASE_STATUS_DATE, CAUSE_FLAG, CLAIM_STATUS,
#                      FORM_TYPE, GROUP_ID,  
#                     INV_AGE, ITS_FLAG, LOB,  PD_30_FLAG,
#                     PD_AGE,  PRIOR_DATE, 
#                       PV_AGE, REG_DATE, 
#                       SATUS_AGE, SERV_DATE,
#                     STAT_DATE, STAT_REASON, 
#                     STATUS_REASON,  VAL_FLAG 
#                     from auditpoint1
#                      where CLAIM_STATUS != 'Pre Validated'
#                      and LOB != 'MCARE'
#                     group by Claim_ID,STAT_DATE
#                      order by Claim_ID,STAT_DATE desc")
# 
# auditpoint2$fixid1 <- gsub('.{4}$', '', auditpoint2$Claim_ID)
# # grab planid
# auditpoint2$plan_id <- sub(".*-","", auditpoint2$Claim_ID)
# auditpoint2$fixid1 <- str_pad(auditpoint2$fixid1,15,"left","0")
# 
# # andy OVP logic
# # auditpoint = auditpoint %>% mutate(CLAIM_ID = Claim.ID) %>% 
# # mutate(OVP=ifelse(Claim.Status %in% c('ADJUSTED','VALIDATED'),1,ifelse(Claim.Status=='REJECTED',0,NA)))
# 
# #So Overpayment if Claim.Status is either ADJUSTED or VALIDATED and Non-overpayment if Claim.Status is REJECTED
# 
# # OVP target
# auditpoint2$OVP <- ifelse(auditpoint2$CLAIM_STATUS == 'ADJUSTED',1,
#                           ifelse(auditpoint2$CLAIM_STATUS == 'VALIDATED',1,
#                                  ifelse(auditpoint2$CLAIM_STATUS=='REJECTED',0,0)))
# 
# saveRDS(auditpoint2, file="auditpoint2.Rda")
# 
# 
# auditpoint1<- fread("Explorer_Pivot_Full_Data_data.csv", select =c("Claim ID", "Claim Status", "Claim LOB"))
# # #rename
# names(auditpoint1)[1] <- 'Claim_ID'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim LOB')] <- 'LOB'
# colnames(auditpoint1)[which(names(auditpoint1) == 'Claim Status')] <- 'CLAIM_STATUS'
# 
# 
# # remove planid
# auditpoint1$fixid1 <- gsub('.{4}$', '', auditpoint1$Claim_ID)
# # grab planid
# auditpoint1$plan_id <- sub(".*-","", auditpoint1$Claim_ID)
# 
# 
# 
# 
# auditpoint1$fixid1 <- str_pad(auditpoint1$fixid1,15,"left","0")
# idlist <- sqldf("select distinct fixid1 as claim_id, plan_id from auditpoint1  where CLAIM_STATUS != 'Pre Validated'
#                      and LOB != 'MCARE'")
# write.csv(idlist, file = "dale_idlist.csv")
# 


# # make datmaid codebook
# Instructions to open:  do file open rmd file; use Knit to render as an HTML doc
# makeDataReport(auditpoint2, vol="1", render = FALSE,
#                replace = TRUE, openResult = FALSE, codebook = TRUE,
#                reportTitle = "Auditpoint Data - Report")



# read SQL tables
auditpoint2 <- read.csv("auditpoint2.csv", header=TRUE, sep="\t")
names(auditpoint2)[1] <- 'CLAIM_ID_AP'
auditpoint2$CLAIM_ID <- as.character(auditpoint2$fixid1)
auditpoint2$CLAIM_ID <- str_pad(auditpoint2$CLAIM_ID,15,"left","0")

claims_line_180 <- read.csv("NOV_DEC_2021.rpt", header=TRUE, sep="\t")


# removes junk at end of csv
claims_line_180 <- claims_line_180[-nrow(claims_line_180),]
claims_line_180 <- claims_line_180[-nrow(claims_line_180),]




colnames(claims_line_180)[which(names(claims_line_180) == "PROC_CODE")] <- "CPT"

claims_line_180$CPT <- as.character(claims_line_180$CPT)


colnames(claims_line_180)[which(names(claims_line_180) == "ICN_NUM")] <- "CLAIM_ID"
claims_line_180$CLAIM_ID <- as.character(claims_line_180$CLAIM_ID )


colnames(claims_line_180)[which(names(claims_line_180) == "allowed_units")] <- "UNITS_ALLOWED"
colnames(claims_line_180)[which(names(claims_line_180) == "paid")] <- "AMT_PAID"
colnames(claims_line_180)[which(names(claims_line_180) == "SERV_PLACE_CODE")] <- "POS"
colnames(claims_line_180)[which(names(claims_line_180) == "PROV_ZIP_CODE")] <- "ZIP_CODE"

claims_line_180$ZIP_CODE <- as.character(claims_line_180$ZIP_CODE)
claims_line_180$ZIP_CODE <- substr(claims_line_180$ZIP_CODE, start = 1, stop = 5)

# make groupid to join to auditpoint2
claims_line_180$GROUP_ID <- str_c(claims_line_180$GRP_BASE1_NUM, '',claims_line_180$GRP_BASE2_NUM)
claims_line_180$GROUP_ID <- str_pad(claims_line_180$GROUP_ID,9,"left","0")


claims_line_180 <- sqldf("select distinct c.* from claims_line_180 c, auditpoint2 a
where c.CLAIM_ID = a.CLAIM_ID
and a.GROUP_ID = c.GROUP_ID")

dx_long <- sqldf("SELECT CLAIM_ID, PMY_CODE, SEC_CODE, TER_CODE, FOURTH_CODE,
                 FIFTH_CODE
                 from claims_line_180")


library(reshape2)

DX_claim <- reshape2::melt(dx_long, id.vars = "CLAIM_ID")

DX_claimids_Diag <- sqldf("select DISTINCT CLAIM_ID, value as ICD9_CODE from DX_claim where TRIM(value) !=''
                          order by CLAIM_ID ")


detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)


charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")
elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")


library(icd)

AHRQ_1 <- icd_comorbid_ahrq(DX_claimids_Diag, visit_name = 'CLAIM_ID', icd_name = 'ICD9_CODE', return_df = TRUE,
                            return_binary = FALSE)

AHRQ_1$CLAIM_ID <- as.character(AHRQ_1$CLAIM_ID)
cols <- sapply(AHRQ_1, is.logical)

AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.numeric)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.character)
AHRQ_1$CLAIM_ID <- as.integer(AHRQ_1$CLAIM_ID)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.factor)
colnames(AHRQ_1) <- paste("AHRQ", colnames(AHRQ_1), sep = "_")
AHRQ_1$CLAIM_IDx <- AHRQ_1$AHRQ_CLAIM_ID
AHRQ_1$AHRQ_CLAIM_ID <- NULL


saveRDS(DX_claim, file="DX_claim.Rda")
saveRDS(charlson_scores, file="charlson_scores.Rda")
saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
saveRDS(AHRQ_1, file="AHRQ_1.Rda")


# CCS

library(dplyr)
library(dummies)
####CCS categories


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)



# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category, c.multi_desc 
from DX_claimids_Diag d left join CCS c on d.ICD9_CODE = c.ICD10_Code
order by d.CLAIM_ID")

#DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), '0', DX_CCS$CCS_Category)
DX_CCS$multi_desc  <- ifelse(is.na(DX_CCS$multi_desc ), 'missing', DX_CCS$multi_desc )

#DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
DX_CCS$multi_desc <-as.factor(DX_CCS$multi_desc)

### One hot encoding of CCS variables #####

#CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from DX_CCS order by CLAIM_ID")




## Making a wide table
#CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc, sep= "_"))

#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))


saveRDS(CCS_Dummy_test3, file="CCS_Dummy_test3.Rda")



##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_ID, POS from claims_line_180")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor)
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
saveRDS(POS2, file="POS2.Rda")




BETOS<-read.csv("betos20.txt", header=TRUE, sep="\t")


CPT <- sqldf("select DISTINCT CLAIM_ID ,CPT from claims_line_180
             where CPT != ''")


opvid <- sqldf("select  fixid1, OVP,STAT_DATE from auditpoint2
group by fixid1,STAT_DATE
                     order by fixid1,STAT_DATE desc")


prop.table(table(opvid$OVP))


CPT <- sqldf("select a.OVP, a.STAT_DATE, c.* from CPT c, opvid a
             where a.fixid1 = CLAIM_ID")


# CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c LEFT JOIN BETOS b
#              ON c.CPT = b.HCPCS")

# OVP can have multiple states, take the most recent date as status

CPT_OVP <- sqldf("select  claim_ID, OVP from CPT
                 group by CLAIM_ID
                     order by CLAIM_ID,STAT_DATE desc")


# for orphan betos, use CPT

# # BETOS CODE
# 
# CPT$BETOS_20 <-  ifelse(is.na(CPT$BETOS_20),CPT$CPT,CPT$BETOS_20)
# 
# CPT_b <- sqldf("select distinct CLAIM_ID, BETOS_20 from CPT")
# 
# CPT_b$BETOS_20 <- as.factor(CPT_b$BETOS_20)
# 
# CPT_b <- cbind(CPT_b, dummy(CPT_b$BETOS_20, sep= "_"))
# 
# #replace with betos
# 
# #replace with betos
# colnames(CPT_b)<-gsub("CPT_b","BETOS_20",colnames(CPT_b))
# 
# CPT_b$BETOS_20 <- NULL
# 
# 
# 
# # temp make id character
# CPT$CLAIM_ID <- as.character(CPT$CLAIM_ID)




# NON BETOS CODE
# BETOS CODE


CPT_b <- sqldf("select distinct CLAIM_ID, CPT from CPT")

CPT_b$CPT <- as.factor(CPT_b$CPT)

CPT_b <- cbind(CPT_b, dummy(CPT_b$CPT, sep= "_"))

#replace with betos

#replace with betos
colnames(CPT_b)<-gsub("CPT_b","CPT",colnames(CPT_b))

CPT_b$CPT <- NULL



# temp make id character
CPT$CLAIM_ID <- as.character(CPT$CLAIM_ID)




# new loop by to split CPT into columns split 10 ways
###############################################################


pid <- as.data.frame(CPT_b[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'



CPT_b$CLAIM_ID <- NULL

cpt_test2 <- split.default(CPT_b, gl(ncol(CPT_b)/10, 10))

number_data_frames <- as.integer(length(cpt_test2))




hcpc1 <- cpt_test2[[1]]
hcpc1 <- cbind(pid,hcpc1)
CPT1 <- hcpc1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  hcpc <- cpt_test2[[i]]
  hcpc <- cbind(pid,hcpc)
  
  hcpc3 <- hcpc %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(hcpc3)[1] <- 'CLAIM_IDx'
  
  CPT1<- cbind( CPT1,  hcpc3)
  CPT1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}


rm(cpt_test2)






# group by client id
#CPT1 <- CPT_b %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor)
CPT2 <- as.data.frame(CPT2)

CPT2 <- cbind(CPT_OVP$OVP,CPT2)
# #rename

names(CPT2)[1] <- 'OVP'

CPT2$OVP <- as.factor(as.character(CPT2$OVP))
CPT2$CLAIM_ID <- NULL

saveRDS(CPT2, file="CPT2.Rda")


library(randomForest)
library(psych)

set.seed(77)



rf_CPT1 <- randomForest(OVP~. ,data=CPT2, ntree=100)

rf_CPT1_importance <- as.data.frame(importance(rf_CPT1))

rf_CPT1_importance <- data.frame(CPT = row.names(rf_CPT1_importance), rf_CPT1_importance)

rf_CPT1_importance_tile <- mutate(rf_CPT1_importance, 
                                  tiles = ntile(rf_CPT1_importance$MeanDecreaseGini, 50))

rf_CPT1_importance <- sqldf("select * from rf_CPT1_importance_tile where tiles >= 40")








# CPT2 <- cbind(CPT_OVP$ICD10_CODE_Leakage,CPT2)
# # #rename
# names(CPT2)[1] <- 'ICD10_CODE_Leakage'
# 
# saveRDS(CPT2, file="CPT2_prod.Rda")
# 
# CPT2$ICD10_CODE_Leakage <- as.factor(as.character(CPT2$ICD10_CODE_Leakage))
# #CPT2$CLAIM_ID <- NULL
# rm(CPT1)
# rm(CPT_b)

####### Configuring Provider city#########


# FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
# USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")
# 
# 
# claims_line_180$ZIP <-  ifelse(is.na(claims_line_180$ZIP),'missing',claims_line_180$ZIP)
# 
# # V1 use zip not FIPS
# 
# claims_invoiced2 <- claims_line_180
# 
# claims_invoiced2 <- data.frame(r_index = row.names(claims_invoiced2), claims_invoiced2)
# 
# claims_invoiced2 <- sqldf("select v.*, f.COUNTY from   claims_invoiced2 v left join FIPS f
#                           ON v.ZIP = f.zip group by v.r_index
#                           " )
# 
# claims_invoiced2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from claims_invoiced2 v left join USDA f
#                           ON  v.COUNTY = f.FIPS  group by v.r_index")
# 
# claims_invoiced2$COUNTY <-  ifelse(is.na(claims_invoiced2$COUNTY),'missing',claims_invoiced2$COUNTY)
# claims_invoiced2$USDA_urban_rural <- ifelse(is.na(claims_invoiced2$USDA_urban_rural),0,claims_invoiced2$USDA_urban_rural)
# 
# 
# 
# # use FIPS instead
# FIPS <- sqldf("select DISTINCT claim_id as CLAIM_ID,  COUNTY from claims_invoiced2")
# 
# FIPS <- cbind(FIPS, dummy(FIPS$COUNTY , sep= "_"))
# 
# FIPS$FIPS_missing <- NULL
# 
# 
# 
# # new group by methodology
# pid <- as.data.frame(FIPS[,1])
# 
# #rename
# 
# names(pid)[1] <- 'CLAIM_ID'
# 
# 
# 
# FIPS$CLAIM_ID <- NULL
# 
# fips_test2 <- split.default(FIPS, gl(ncol(FIPS)/10, 10))
# 
# number_data_frames <- as.integer(length(fips_test2))
# 
# ###############################################################
# 
# county1 <- fips_test2[[1]]
# county1 <- cbind(pid,county1)
# FIPS1 <- county1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
# 
# 
# 
# #while (i <= number_data_frames)
# 
# i <- 2
# while (i <= number_data_frames)
# {
#   county <- fips_test2[[i]]
#   county <- cbind(pid,county)
#   
#   county3 <- county %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
#   names(county3)[1] <- 'CLAIM_IDx'
#   
#   FIPS1 <- cbind( FIPS1,  county3)
#   FIPS1$CLAIM_IDx <- NULL
#   
#   
#   i <- i+1
#   
# }
# 
# rm(fips_test2)
# # temp make id character
# FIPS1$CLAIM_ID <- as.character(FIPS1$CLAIM_ID)
# 
# # recode if > 0 then 1 else 0 instead of summing dummies
# FIPS2 <- FIPS1 %>% mutate_if(is.numeric,
#                              function(x) case_when(
#                                x >= 1 ~ 1,
#                                x == 0 ~ 0
#                              )
# )
# 
# FIPS2 <- lapply(FIPS2, factor)
# FIPS2<- as.data.frame(FIPS2)
# FIPS2$CLAIM_ID <- as.character((FIPS2$CLAIM_ID))
# FIPS2$COUNTY <- NULL
# #saveRDS(FIPS2, file="FIPS2_prod.Rda")

#ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ


# ZIP

ZIPS <- sqldf("select claim_id as CLAIM_ID,  ZIP_CODE from claims_line_180 group by claim_id,ZIP_CODE")

ZIPS <- cbind(ZIPS, dummy(ZIPS$ZIP_CODE , sep= "_"))

ZIPS$ZIP_missing <- NULL



# new group by methodology
pid <- as.data.frame(ZIPS[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'



ZIPS$CLAIM_ID <- NULL

fips_test2 <- split.default(ZIPS, gl(ncol(ZIPS)/10, 10))

number_data_frames <- as.integer(length(fips_test2))




county1 <- fips_test2[[1]]
#county1 <- cbind(pid,county1)
FIPS1 <- county1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  county <- fips_test2[[i]]
  county <- cbind(pid,county)
  
  county3 <- county %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(county3)[1] <- 'CLAIM_IDx'
  
  FIPS1 <- cbind( FIPS1,  county3)
  FIPS1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}

rm(fips_test2)
# temp make id character
FIPS1$CLAIM_ID <- as.character(FIPS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
FIPS2 <- FIPS1 %>% mutate_if(is.numeric,
                             function(x) case_when(
                               x >= 1 ~ 1,
                               x == 0 ~ 0
                             )
)

FIPS2 <- lapply(FIPS2, factor)
FIPS2<- as.data.frame(FIPS2)
FIPS2$CLAIM_ID <- as.character((FIPS2$CLAIM_ID))
FIPS2$COUNTY <- NULL

saveRDS(FIPS2, file="FIPS2.Rda")







#HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH

# HCPCS code is seperate
Hp1 <- sqldf("select DISTINCT CLAIM_ID, HCPCS_CODE from claims_line_180")
Hp1$HCPCS_CODE <- as.character(Hp1$HCPCS_CODE)
Hp1$HCPCS_CODE_recode <-  ifelse((Hp1$HCPCS_CODE == ""), 'missing', Hp1$HCPCS_CODE)
Hp1$HCPCS_CODE_recode <-  ifelse((Hp1$HCPCS_CODE == "UNK"), 'missing', Hp1$HCPCS_CODE)
Hp1 <- cbind(Hp1, dummy(Hp1$HCPCS_CODE_recode , sep= "_"))


# group by client id
Hp2 <- Hp1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
Hp2$CLAIM_ID <- as.character(Hp2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Hp3 <- Hp2 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

Hp3 <- lapply(Hp3, factor)
Hp3 <- as.data.frame(Hp3)
Hp3$CLAIM_ID <- as.character(Hp3$CLAIM_ID)
Hp3$Hp1_missing <- NULL
Hp3$Hp1_  <- NULL

saveRDS(Hp3, file="Hp3.Rda")

###### Configuring Provider Type#######
PROV_TYPE <- sqldf("select DISTINCT CLAIM_ID,  PROV_SPEC_2_CODE as PROV_TYPE from claims_line_180")

PROV_TYPE <- cbind(PROV_TYPE, dummy(PROV_TYPE$PROV_TYPE , sep= "_"))

PROV_TYPE$CLAIM_ID <- as.character(PROV_TYPE$CLAIM_ID)
# group by client id
PROV_TYPE1 <- PROV_TYPE %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
PROV_TYPE1$CLAIM_ID <- as.character(PROV_TYPE1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_TYPE2 <- PROV_TYPE1 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_TYPE2 <- lapply(PROV_TYPE2, factor)
PROV_TYPE2 <- as.data.frame(PROV_TYPE2)
PROV_TYPE2$CLAIM_ID <- as.character(PROV_TYPE2$CLAIM_ID)
PROV_TYPE2$PROV_TYPE <- NULL

saveRDS(PROV_TYPE2, file="PROV_TYPE2.Rda")



# SUM UP TO CLAIM LEVEL FOR FINANCIALS

finance1 <- sqldf("select CLAIM_ID , SUM(PRORT_AMT) as claim_amt_paid, SUM(PROV_CHRG_AMT) as claim_amt_billed,
                  SUM(ALLOW_CHRG_AMT) as claim_amt_allowed
                  from claims_line_180
                  group by CLAIM_ID")


finance1$ratio_billed_to_paid <- finance1$claim_amt_billed / finance1$claim_amt_paid
finance1$ratio_allowed_to_paid <- finance1$claim_amt_allowed / finance1$claim_amt_paid

library(BBmisc)
library(forcats)

finance1$ratio_billed_to_paid <-normalize(finance1$ratio_billed_to_paid , method="range", range=c(0,1))
finance1$ratio_allowed_to_paid <-normalize(finance1$ratio_allowed_to_paid , method="range", range=c(0,1))

claims_line_180$DOB <-as.POSIXct(claims_line_180$PAT_DOB_DATE, origin="1970-01-01")
claims_line_180$admit_date <-as.POSIXct(claims_line_180$FST_SERV_DATE, origin="1970-01-01")
claims_line_180$member_age <-(difftime(claims_line_180$admit_date ,claims_line_180$DOB, units = "days"  ))/365

claims_line_180$member_age <- as.integer(claims_line_180$member_age)

member_demographics <- sqldf("select distinct CLAIM_ID , member_age,PAT_DOB_DATE , PATIENT_NAME ,
                             REL_CODE_NUM, PGM_CLASS_CODE,
                             GRP_BASE1_NUM, GRP_BASE2_NUM, GRP_SECTION_CODE,
                             GRP_1_NAME, GRP_LOB_CD
                             from claims_line_180 order by CLAIM_ID")


member_demographics$REL_CODE_NUM <- as.factor(member_demographics$REL_CODE_NUM )
member_demographics$member_age_NORM <- normalize(member_demographics$member_age, method="range", range=c(0,1))

####  creating new features



claims_line_180$discharge_date <-as.POSIXct(claims_line_180$LST_SERV_DATE, origin="1970-01-01")

claims_line_180$Days_of_service <- difftime(claims_line_180$discharge_date ,
                                            claims_line_180$admit_date,
                                            units = c("days"))




claims_line_180$Days_of_service <- as.numeric(claims_line_180$Days_of_service)
LOS <- sqldf("select CLAIM_ID ,max(Days_of_service) as length_of_stay from claims_line_180
             group by CLAIM_ID"
             )
member_demographics <- sqldf("select distinct m.*, L.length_of_stay as Days_of_service 
from member_demographics m, LOS L
where m.CLAIM_ID = L.CLAIM_ID")


member_demographics$Days_of_service <-  normalize(member_demographics$Days_of_service, method="range", range=c(0,1))

# group ids change within the claim
member_demographics$GRP_BASE1_NUM <- NULL
member_demographics$GRP_BASE2_NUM <- NULL

member_demographics <- sqldf("select  * from member_demographics")


saveRDS(member_demographics, file="member_demographics.Rda")
saveRDS(claims_line_180, file="claims_line_180.Rda")


junk <- sqldf("select count(CLAIM_ID) as cnt from member_demographics group by CLAIM_ID
              order by cnt desc")


base1 <- sqldf("select distinct m.*, o.OVP
               from member_demographics m,opvid o
               where m.CLAIM_ID = o.fixid1")

base1 <- sqldf("select distinct m.*, o.ratio_billed_to_paid, 
o.ratio_allowed_to_paid
               from base1 m,finance1 o
               where m.CLAIM_ID = o.CLAIM_ID")

attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL

elixhauser_scores$CLAIM_IDx <- elixhauser_scores$CLAIM_ID

elixhauser_scores$index <- NULL
elixhauser_scores$windex_ahrq <- NULL
elixhauser_scores$windex_vw  <- NULL
elixhauser_scores$CLAIM_ID <- NULL




base1 <-sqldf("select distinct b.*, c.wscore as Charlson_score from  base1 b
             left join charlson_scores c
             on b.CLAIM_ID = c.CLAIM_ID", method = "name_class")




base1$Charlson_score <-  ifelse(is.na(base1$Charlson_score),1,base1$Charlson_score)


base1 <-sqldf("select distinct b.*, c.score as elix_score from  base1 b
             left join elixhauser_scores c
             on b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")

base1$elix_score <-  ifelse(is.na(base1$elix_score),0,base1$elix_score)
base1$CLAIM_IDx <- NULL

base1 <-sqldf("select distinct b.*, c.* from  base1 b
             left join AHRQ_1 c
             on b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")

base1$CLAIM_IDx <- NULL


base1 <- mutate_at(base1, vars(starts_with("AHRQ_")),
                   ~replace(., is.na(.), 0))


base1$elix_score <-  ifelse(is.na(base1$elix_score),0,base1$elix_score)
base1$CLAIM_IDx <- NULL

base1$GRP_1_NAME <- str_trim(base1$GRP_1_NAME)


insur <- sqldf("select distinct CLAIM_ID as CLAIM_IDx, GRP_1_NAME as INS_GROUP_ID from base1")

insur$INS_GROUP_ID <- as.factor(insur$INS_GROUP_ID)
insur$INS_GROUP_ID <- fct_lump(insur$INS_GROUP_ID, n=10)


base1 <-sqldf("select distinct b.*, c.INS_GROUP_ID from  base1 b, insur c
             where  b.claim_id = c.CLAIM_IDx", method = "name_class")



### Merging with CCS
# CCS dx
CCS_Dummy_test3$CLAIM_IDx <- CCS_Dummy_test3$CLAIM_ID

CCS_Dummy_test3$CLAIM_ID <- NULL

base1<- sqldf("SELECT DISTINCT b.*, c.* from base1 b left join CCS_Dummy_test3 c
                               on b.CLAIM_ID = c.CLAIM_IDx")




base1 <- mutate_at(base1, vars(starts_with("CCS_")),
                   ~replace(., is.na(.), 0))

base1$CLAIM_IDx <- NULL





POS2$CLAIM_IDx <- POS2$CLAIM_ID
POS2$CLAIM_ID <- NULL

rf_pos1 <- sqldf("select b.CLAIM_ID, b.OVP, p.* from base1 b, POS2 p
                 where b.CLAIM_ID = p.CLAIM_IDx")

rf_pos1$claim_id <- NULL
rf_pos1$CLAIM_IDx <- NULL
rf_pos1$POS_NA <- NULL


rf_pos1$OVP <- as.factor(rf_pos1$OVP)

rf_pos1 <- randomForest(OVP~. ,data=rf_pos1, ntree=500)

rf_pos1_importance <- as.data.frame(importance(rf_pos1))

rf_pos1_importance <- data.frame(POS = row.names(rf_pos1_importance), rf_pos1_importance)

rf_pos1_importance_tile <- mutate(rf_pos1_importance, 
                                  tiles = ntile(rf_pos1_importance$MeanDecreaseGini, 4))
# use all POS
rf_pos1_importance <- sqldf("select * from rf_pos1_importance_tile where tiles <= 4")




POS_match <- POS2[, names(POS2) %in% rf_pos1_importance$POS]
base1 <- cbind(base1, POS_match)


base1 <- mutate_at(base1, vars(starts_with("POS_")),
                   ~replace(., is.na(.), 0))



CPT2_match <- CPT2[, names(CPT2) %in% rf_CPT1_importance$CPT]

CPT2_match <- cbind(CPT1$CLAIM_ID, CPT2_match)
names(CPT2_match)[1] <- 'CLAIM_IDx'

base1<- sqldf("select b.*, c.* from base1 b left join CPT2_match c
               on b.CLAIM_ID = c.CLAIM_IDx")

base1 <- mutate_at(base1, vars(starts_with("BETOS_")),
                   ~replace(., is.na(.), 0))

base1$CLAIM_IDx <- NULL


##################################################  FIPS

FIPS2$CLAIM_IDx <- FIPS2$CLAIM_ID
FIPS2$CLAIM_ID <- NULL

rf_FIPS <- sqldf("select b.CLAIM_ID, b.OVP, p.* from base1 b, FIPS2 p
                 where b.CLAIM_ID = p.CLAIM_IDx")

rf_FIPS$claim_id <- NULL
rf_FIPS$CLAIM_IDx <- NULL
rf_FIPS$CPT2_NA <- NULL


set.seed(77)

rf_FIPS$OVP <- as.factor(rf_FIPS$OVP)

rf_FIPS <- randomForest(OVP~. ,data=rf_FIPS, ntree=500)

rf_FIPS_importance <- as.data.frame(importance(rf_FIPS))

rf_FIPS_importance <- data.frame(FIPS = row.names(rf_FIPS_importance), rf_FIPS_importance)


rf_FIPS_importance_tile <- mutate(rf_FIPS_importance, 
                                  tiles = ntile(rf_FIPS_importance$MeanDecreaseGini, 4))

rf_FIPS_importance <- sqldf("select * from rf_FIPS_importance_tile where tiles = 4")


# rf_FIPS_importance <-rf_FIPS_importance %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 20)

#saveRDS(rf_FIPS_importance, file="rf_FIPS_importance.Rda")


FIPS_match <- FIPS2[, names(FIPS2) %in% rf_FIPS_importance$FIPS]
base1 <- cbind(base1, FIPS_match)


base1 <- mutate_at(base1, vars(starts_with("FIPS_")),
                   ~replace(., is.na(.), 0))





##############################################################################################

# provider type targeted feature reduction
PROV_TYPE2$CLAIM_IDx <- PROV_TYPE2$CLAIM_ID
PROV_TYPE2$CLAIM_ID <- NULL

rf_PROV_TYPE <- sqldf("select b.CLAIM_ID, b.OVP, p.* from base1 b, PROV_TYPE2 p
                 where b.CLAIM_ID = p.CLAIM_IDx")

rf_PROV_TYPE$claim_id <- NULL
rf_PROV_TYPE$CLAIM_IDx <- NULL
rf_PROV_TYPE$CPT2_NA <- NULL


set.seed(77)

rf_PROV_TYPE$OVP <- as.factor(rf_PROV_TYPE$OVP)

rf_PROV_TYPE <- randomForest(OVP~. ,data=rf_PROV_TYPE, ntree=500)

rf_PROV_TYPE_importance <- as.data.frame(importance(rf_PROV_TYPE))

rf_PROV_TYPE_importance <- data.frame(PROV_TYPE = row.names(rf_PROV_TYPE_importance), rf_PROV_TYPE_importance)


rf_PROV_TYPE_importance_tile <- mutate(rf_PROV_TYPE_importance, 
                                       tiles = ntile(rf_PROV_TYPE_importance$MeanDecreaseGini, 4))

rf_PROV_TYPE_importance <- sqldf("select * from rf_PROV_TYPE_importance_tile where tiles = 4")



# rf_PROV_TYPE_importance <-rf_PROV_TYPE_importance %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 20)

#saveRDS(rf_PROV_TYPE_importance, file="rf_PROV_TYPE_importance.Rda")

PROV_TYPE_match <- PROV_TYPE2[, names(PROV_TYPE2) %in% rf_PROV_TYPE_importance$PROV_TYPE]
base1 <- cbind(base1, PROV_TYPE_match)


base1 <- mutate_at(base1, vars(starts_with("PROV_TYPE_")),
                   ~replace(., is.na(.), 0))


base1_auditpoint <- sqldf("select CLAIM_ID as CLAIM_IDx, Audit, GROUP_ID as auditpoint_group_ID , ITS_FLAG,
LOB as auditpoint_LOB
from auditpoint2
                          group by  CLAIM_ID")


# add audit point

base1 <- sqldf("select b.*, a.* from 
               base1 b, base1_auditpoint a
               where b.CLAIM_ID = a.CLAIM_IDx")







