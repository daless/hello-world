


setwd("~/BCBSMI")
library(comorbidity)
#library(RODBC)
library(sqldf)
library(psych)



claims_test <- read.csv("test.txt", header=TRUE, sep="\t")

# removes junk at end of csv
claims_test <- claims_test[-nrow(claims_test),]
claims_test <- claims_test[-nrow(claims_test),]


#rename
colnames(claims_test)[which(names(claims_test) == "Procedure_Code")] <- "CPT"
#names(claims_test)[56] <- 'CPT'

# remove hwmophilia
claims_test <- sqldf("select * from claims_test where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")

colnames(claims_test)[which(names(claims_test) == "Claim_ID")] <- "CLAIM_ID"
claims_test$CLAIM_ID <- as.character(claims_test$CLAIM_ID )


dx_long <- sqldf("SELECT CLAIM_ID, Diagnosis_Code_Principal, Diagnosis_Code_2_UB, Diagnosis_Code_3_UB, Diagnosis_Code_4_UB
from claims_test")

#library(reshape2)

DX_claim <- reshape2::melt(dx_long, id.vars = "CLAIM_ID")

DX_claimids_Diag <- sqldf("select CLAIM_ID, value as ICD9_CODE from DX_claim where TRIM(value) !=''")




charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")
elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

# remove more junk from CSV
charlson_scores<- charlson_scores[-1,]
elixhauser_scores <- elixhauser_scores[-1,] 



charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
elixhauser_scores$CLAIM_IDx <- as.numeric(elixhauser_scores$CLAIM_ID)

elixhauser_scores$index <- NULL
elixhauser_scores$windex_ahrq <- NULL
elixhauser_scores$windex_vw  <- NULL
elixhauser_scores$CLAIM_ID <- NULL



# CCS



CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)

CCS_lookup <- CCS
CCS_lookup$multi_code <- CCS_lookup$CCS_Category
CCS_lookup$multi_code <- paste("CCS__",CCS_lookup$multi_code )


ccs_cols <- sqldf("select distinct multi_code, multi_desc from CCS_lookup")



# DX_claim  <- sqldf("select  d.* from DX_claim d
#                    where  d.ICD9_TYPE='DIAG10'")

icd2 <- sqldf("select distinct i.*, c.multi_desc from DX_claimids_Diag  i,CCS_lookup c where
              i.ICD9_CODE = c.ICD10_CODE ")


library(dplyr)
library(dummies)

CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from icd2")



CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test_", "",  colnames(CCS_Dummy_test)))
# group by client id
CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy3_test <- CCS_Dummy3_test %>% mutate_if(is.numeric, funs(factor(.)))
CCS_Dummy3_test$CLAIM_ID <- as.numeric(CCS_Dummy3_test$CLAIM_ID)
CCS_Dummy3_test$multi_desc <- NULL
CCS_Dummy3_test <- sqldf("select * from CCS_Dummy3_test order by CLAIM_ID")
CCS_Dummy3_test$CLAIM_IDx <-CCS_Dummy3_test$CLAIM_ID
CCS_Dummy3_test$CLAIM_ID <- NULL

# wide format
icd_C4_2 <- CCS_Dummy3_test 



