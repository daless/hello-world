
#scp baseline_3yrs.txt dless1@apsrd9425:/home/dless1/BCBSMI

setwd("~/BCBSMI")
library(comorbidity)
#library(RODBC)
library(sqldf)
library(psych)

# library(plyr)
# library(dplyr)
# library(icd)
# 
# library(dummies)
# library(data.table)
# library(ggplot2)
# library(dataMaid)
library(lubridate)
# library(NbClust)
# library(cluster)
library(tidyr)
# library(factoextra)
# library(proxy)
# library(tibble)
# library(network)
# # descriptive stats
# library(Hmisc)

# 
# library(arules)
# library(arulesViz)
# library(visNetwork)
# library(igraph)


#library(h2o)
#h2o.init()
########h2o.init(port=54322)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)




claims_line_180 <- read.csv("baseline_3yrs.txt", header=TRUE, sep="\t")



# removes junk at end of csv
claims_line_180 <- claims_line_180[-nrow(claims_line_180),]
claims_line_180 <- claims_line_180[-nrow(claims_line_180),]

colnames(claims_line_180)[which(names(claims_line_180) == "PROC_CODE")] <- "CPT"
colnames(claims_line_180)[which(names(claims_line_180) == "ICN_NUM")] <- "CLAIM_ID"
claims_line_180$CLAIM_ID <- as.character(claims_line_180$CLAIM_ID )


colnames(claims_line_180)[which(names(claims_line_180) == "allowed_units")] <- "UNITS_ALLOWED"
colnames(claims_line_180)[which(names(claims_line_180) == "paid")] <- "AMT_PAID"


# 1 yr hx data to set baselines


# remove human FACTOR

claims_line_180 <- sqldf("select * from claims_line_180 where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")

# 
# 
# jcode_cnt <- sqldf("select CPT,  CLAIM_ID, count(CLAIM_ID) as jcnt, sum(AMT_PAID) as paid,
#                    sum(UNITS_ALLOWED) as allowed_units
#                    from claims_line_180
#                    group by CPT, CLAIM_ID
#                    order by CPT")


claims_line_180$CPT <- as.character(claims_line_180$CPT)



jcode_cnt2 <- claims_line_180
jcode_cnt2$CLAIM_ID <- NULL

# jcode claim line descriptives

jcode_descriptives <- as.data.frame(describeBy(jcode_cnt2,
                                               group = list(jcode_cnt2$CPT), 
                                               mat=TRUE))

jcode_descriptives_pd <- sqldf("select * from jcode_descriptives where vars = 3
                            order by mean desc")

jcode_descriptives_vol <- sqldf("select * from jcode_descriptives where vars = 2
                            order by n desc")

jcode_descriptives_units <- sqldf("select * from jcode_descriptives where vars = 4
                            order by n desc")

jcode_descriptives2 <- sqldf("select v.group1 as CPT, v.n as num_admins, 
                             v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units,
                             v.median as median_num_admins, p.median as median_pd, u.median as median_units,
                             v.min as min_num_admins, v.max as max_num_admins, 
                             p.min as min_pd, p.max as max_pd,
                             u.min as min_units, u.max as max_units
                             from jcode_descriptives_pd p, jcode_descriptives_vol v, jcode_descriptives_units u
                             where v.group1 = p.group1
                             and p.group1 = u.group1
                             order by mean_pd desc")





# time between administrations

# Added 1 to days so could convert NAs to 0

# 
# library(dplyr)
# library(data.table)
# 
# jcode_time <- claims_line_180 %>%
#   arrange( CLAIM_ID, CPT,DATE_OF_SERVICE_BEG) %>%
#   group_by(CLAIM_ID, CPT) %>%
#   dplyr:::mutate(diff = DATE_OF_SERVICE_BEG - lag(DATE_OF_SERVICE_BEG,1))
# 
# # rx add 1 to all days so 0 is NA and those on same day coded as a 1
# jcode_time$days_between_admins = jcode_time$diff/ddays(1)
# jcode_time$days_between_admins <- ifelse(is.na(jcode_time$days_between_admins),
#                                          0, jcode_time$days_between_admins + 1)
# 
# 
# jcode_time <- sqldf("select * from jcode_time",method = "name_class")
# jcode_time$diff <- NULL
# 
# 
# 
# 
# 
# jcode_time2 <- sqldf("select CPT,  days_between_admins
#                    from jcode_time
#                   ")
# 
# jcode_time_descriptives <- as.data.frame(describeBy(jcode_time2,
#                                                     group = list(jcode_time2$CPT),
#                                                     mat=TRUE))
# 
# jcode_descriptives_time <- sqldf("select * from jcode_time_descriptives where vars = 2 order by n desc")



# jcode_descriptives2 <- sqldf("select v.group1 as CPT, v.n as num_admins,
#                              v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units, t.mean as mean_days,
#                              v.median as median_num_admins, p.median as median_pd, u.median as median_units, t.median as median_days,
#                              v.min as min_num_admins, v.max as max_num_admins,t.max as max_days,
#                              p.min as min_pd, p.max as max_pd,
#                              u.min as min_units, u.max as max_units
#                              from jcode_descriptives_pd p, jcode_descriptives_vol v,
#                              jcode_descriptives_units u, jcode_descriptives_time t
#                              where v.group1 = p.group1
#                              and v.group1 = u.group1
#                              and v.group1 = t.group1
#                              order by mean_pd desc")
# 

#jcode_descriptives2$total_paid <- jcode_descriptives2$num_admins * jcode_descriptives2$mean_pd

# calcualte deciles
library(dplyr)


jcode_descriptives2 <- mutate(jcode_descriptives2, 
                              total_paid_rank = ntile(jcode_descriptives2$median_pd, 10))


jcode_descriptives2 <- mutate(jcode_descriptives2, 
                              total_admins_rank = ntile(jcode_descriptives2$median_num_admins, 10))





saveRDS(jcode_descriptives2, file="jcode_descriptives2.Rda")

#   setwd("~/BCBSMI")
#   jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")
#   scp dless1@apsrd9425:/home/dless1/BCBSMI/jcode_descriptives2.Rda ~/Desktop

#CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

# cluster mappings
detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)
detach("package:dplyr", unload = TRUE)

library(ggplot2)
library(NbClust)
library(cluster)
library(factoextra)
library(sqldf)

# clustering rather than deciles

data_2_cluster <- sqldf("select median_num_admins, median_pd from jcode_descriptives2 ")

#scale and make data a matric=x for clusters

data_2_cluster2 <- scale(data_2_cluster)

# force to max of 5

nb <- NbClust(data_2_cluster2, diss = NULL, distance = "euclidean",
              min.nc = 2, max.nc = 5, method = "kmeans",
              index = "all", alphaBeale = 0.1)

hist(nb$Best.nc[1,], breaks = max(na.omit(nb$Best.nc[1,])))


km <- kmeans(data_2_cluster2, centers = 5, nstart = 25)
fviz_cluster (km, data =data_2_cluster2 , pointsize = 0.5, labelsize = 2, main = "Clusters of Paid Amount and Number Claims Normalized")

# extract cluster assignment vector from the kmeans model
clust_km <- km$cluster
table(som2$clustering)
centers <- as.data.frame(km$centers)
# add cluster to dataframe
jcode_descriptives3_initial <- mutate(jcode_descriptives2, cluster = clust_km)

#  J3399 mean $208,3337.000	chemo  cluster 5
# J2560  cluster 4 high dollar low admins
# J3398 low $ high admins


detach("package:psych", unload = TRUE)
detach("package:dplyr", unload = TRUE)

library(SOMbrero)
library(kohonen)
library(sqldf)



data_2_cluster <- sqldf("select median_num_admins, median_pd
                        from jcode_descriptives2 ")

#scale and make data a matric=x for clusters

data_2_cluster2 <- scale(data_2_cluster)
distance0_scale <- scale(data_2_cluster2)
som2 <- trainSOM(x.data = distance0_scale, dimension = c(5,4), nb.save = 10, maxit = 500,
                 scaling = "none")

# don't plot SOM locks up
table(som2$clustering)


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=9)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)

# save SOM output
# descriptives by cluster
 saveRDS(som_dist, file="som_dist.Rda")
# cluster membership
 saveRDS(som_diste, file="som_diste.Rda")
#som_diste <- readRDS(file="som_diste.Rda")



targ <- cbind(jcode_descriptives2,som_diste)

# #rename
names(targ)[17] <- 'SOM_CLUSTER'

#table(targ$SOM_CLUSTER)
#targ$case_1224_hit <- as.factor(as.character(targ$case_1224_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))


micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
library(dummies)
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
#micro_cluster$SOM_CLUSTER <- NULL

#summary(distance0)
library(psych)
SOM_descriptives <- as.data.frame(describeBy(targ,
                                             group = list(targ$SOM_CLUSTER), 
                                             mat=TRUE))


SOM_descriptives_pd <- sqldf("select * from SOM_descriptives where vars = 4
                            order by mean desc")

SOM_descriptives_vol <- sqldf("select * from SOM_descriptives where vars = 6
                            order by n desc")

SOM_descriptives_units <- sqldf("select * from SOM_descriptives where vars = 5
                            order by n desc")


SOM_descriptives2 <- sqldf("select v.group1 as micro_cluster, v.n as num_admins, 
                             v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units,
                             v.median as median_num_admins, p.median as median_pd, u.median as median_units, 
                             v.min as min_num_admins, v.max as max_num_admins, 
                             p.min as min_pd, p.max as max_pd,
                             u.min as min_units, u.max as max_units
                             from SOM_descriptives_pd p, SOM_descriptives_vol v, SOM_descriptives_units u
                             where v.group1 = p.group1
                             and v.group1 = u.group1
                             order by mean_pd desc")

saveRDS(targ, file="targ.Rda")
#targ <- readRDS(file="targ.Rda")

saveRDS(SOM_descriptives2, file="SOM_descriptives2.Rda")
#SOM_descriptives2 <- readRDS(file="SOM_descriptives2.Rda")
#jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")

# SOM_descriptives2 has the mappings of cluster to J code





