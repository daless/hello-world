
# txt files were deleted for space wqill need to copy from desktop

# V1C on based upon view
# scp test4_from_view.txt dless1@apsrd9425:/home/dless1/BCBSMI
#scp baseline.txt dless1@apsrd9425:/home/dless1/BCBSMI


setwd("~/BCBSMI")
library(comorbidity)
#library(RODBC)
library(sqldf)
library(psych)



claims_test <- read.csv("test4_from_view.txt", header=TRUE, sep="\t")

# removes junk at end of csv
claims_test <- claims_test[-nrow(claims_test),]
claims_test <- claims_test[-nrow(claims_test),]

# healthfirst benchmark data
jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")
som_diste <- readRDS(file="som_diste.Rda")
SOM_descriptives2 <- readRDS(file="SOM_descriptives2.Rda")
cluster1 <- as.vector(SOM_descriptives2[2,1])


#rename
colnames(claims_test)[which(names(claims_test) == "PROC_CODE")] <- "CPT"
colnames(claims_test)[which(names(claims_test) == "FST_SERV_DATE")] <- "DATE_OF_SERVICE_BEG"

#names(claims_test)[56] <- 'CPT'

# remove hwmophilia
claims_test <- sqldf("select * from claims_test where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")

colnames(claims_test)[which(names(claims_test) == "ICN_NUM")] <- "CLAIM_ID"
claims_test$CLAIM_ID <- as.character(claims_test$CLAIM_ID )


dx_long <- sqldf("SELECT CLAIM_ID, PMY_CODE, SEC_CODE, TER_CODE, FOURTH_CODE,
FIFTH_CODE
from claims_test")

library(reshape2)

DX_claim <- reshape2::melt(dx_long, id.vars = "CLAIM_ID")

DX_claimids_Diag <- sqldf("select CLAIM_ID, value as ICD9_CODE from DX_claim where TRIM(value) !=''")


detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")
elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

# remove more junk from CSV
# charlson_scores<- charlson_scores[-1,]
# elixhauser_scores <- elixhauser_scores[-1,] 



#charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
elixhauser_scores$CLAIM_IDx <- elixhauser_scores$CLAIM_ID

elixhauser_scores$index <- NULL
elixhauser_scores$windex_ahrq <- NULL
elixhauser_scores$windex_vw  <- NULL
elixhauser_scores$CLAIM_ID <- NULL



# CCS



CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)

CCS_lookup <- CCS
CCS_lookup$multi_code <- CCS_lookup$CCS_Category
CCS_lookup$multi_code <- paste("CCS__",CCS_lookup$multi_code )


ccs_cols <- sqldf("select distinct multi_code, multi_desc from CCS_lookup")



# DX_claim  <- sqldf("select  d.* from DX_claim d
#                    where  d.ICD9_TYPE='DIAG10'")

icd2 <- sqldf("select distinct i.*, c.multi_desc from DX_claimids_Diag  i,CCS_lookup c where
              i.ICD9_CODE = c.ICD10_CODE ")


library(dplyr)
library(dummies)

CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from icd2")



CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test_", "",  colnames(CCS_Dummy_test)))
# group by client id
CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy3_test <- CCS_Dummy3_test %>% mutate_if(is.numeric, funs(factor(.)))
#CCS_Dummy3_test$CLAIM_ID <- as.numeric(CCS_Dummy3_test$CLAIM_ID)
CCS_Dummy3_test$multi_desc <- NULL
CCS_Dummy3_test <- sqldf("select * from CCS_Dummy3_test order by CLAIM_ID")
CCS_Dummy3_test$CLAIM_IDx <-CCS_Dummy3_test$CLAIM_ID
CCS_Dummy3_test$CLAIM_ID <- NULL

# wide format
icd_C4_2 <- CCS_Dummy3_test 


# do not have time between administrations in the sandbox data


library(data.table)
library(psych)

# everything is 0
# jcode_time <- claims_test  %>%
#   arrange( CLAIM_ID, CPT,DATE_OF_SERVICE_BEG) %>%
#   group_by(CLAIM_ID, CPT) %>%
#   dplyr:::mutate(diff = DATE_OF_SERVICE_BEG - lag(DATE_OF_SERVICE_BEG,1))
# 
# jcode_time <- sqldf("select * from jcode_time",method = "name_class")
# # rx add 1 to all days so 0 is NA and those on same day coded as a 1
# jcode_time$days_between_admins = jcode_time$diff + 0
# 
# #jcode_time$days_between_admins = jcode_time$diff/ddays(1)
# jcode_time$days_between_admins <- ifelse(is.na(jcode_time$days_between_admins),
#                                          0, jcode_time$days_between_admins + 1)
# 
# 
# jcode_time <- sqldf("select * from jcode_time",method = "name_class")
# jcode_time$diff <- NULL
# 
# 
# 
# 
# 
# jcode_time2 <- sqldf("select CPT,  days_between_admins
#                    from jcode_time
#                   ")












claims_420a <- claims_test

colnames(claims_420a)[which(names(claims_420a) == "SERV_PLACE_CODE")] <- "PLACE_OF_SERVICE"
colnames(claims_420a)[which(names(claims_420a) == "BLNG_TYPE_CODE")] <- "BILL_TYPE"
colnames(claims_420a)[which(names(claims_420a) == "PROC_MOD_1_CODE")] <- "CPT_MODIFIER"
colnames(claims_420a)[which(names(claims_420a) == "SERVICE_TYPE_CODE")] <- "REVENUE_CODE"
colnames(claims_420a)[which(names(claims_420a) == "PROV_SPEC_2_CODE")] <- "specialty"
colnames(claims_420a)[which(names(claims_420a) == "PYMT_DATE")] <- "DATE_PAID"


claims_420a <- sqldf("select distinct b.*, c.wscore as charls_score from charlson_scores c,
               claims_420a b where 
               b.CLAIM_ID = c.CLAIM_ID", method = "name_class")




claims_420a<- sqldf("select distinct b.*, c.* from elixhauser_scores c,
               claims_420a b where 
               b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")



# load CCS stripe first 3 characters of CCS for rollups for apriori

targ <- cbind(jcode_descriptives2,som_diste)
names(targ)[17] <- 'SOM_CLUSTER'

claims_420b_string <- paste0("select  CPT from targ
                             where SOM_CLUSTER  = '",cluster1,"'")

claims_420b <- sqldf(claims_420b_string)

cluster4_j_claims2 <- sqldf("select c.* from claims_420a c, claims_420b b
                       where c.CPT = b.CPT")

cluster4_j_claims2$CLAIM_IDx <- NULL

cluster4_j_claims2$CPT <- as.factor(cluster4_j_claims2$CPT)
cluster4_j_claims2$CPT_MODIFIER <- as.factor(cluster4_j_claims2$CPT_MODIFIER)
cluster4_j_claims2$REVENUE_CODE <- as.factor(as.character(cluster4_j_claims2$REVENUE_CODE))
cluster4_j_claims2$specialty <- as.factor(cluster4_j_claims2$specialty)




# change bill type code NA to 0
claims_420a$BILL_TYPE <- ifelse(is.na(claims_420a$BILL_TYPE), 0, claims_420a$BILL_TYPE)


# place of service
claims_420a$PLACE_OF_SERVICE<- ifelse(is.na(claims_420a$PLACE_OF_SERVICE), 0, 
                                      claims_420a$PLACE_OF_SERVICE)


claims_420a$CPT_MODIFIER <- ifelse(is.na(claims_420a$CPT_MODIFIER), 0, claims_420a$CPT_MODIFIER)

claims_420a$REVENUE_CODE <- ifelse(is.na(claims_420a$REVENUE_CODE), 0, claims_420a$REVENUE_CODE)



# from healthfirst


# rename
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "PATN_ACT_NUM")] <- "PATIENT_ID"
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "SERV_UNIT_QTY")] <- "UNITS_ALLOWED"
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "PRORT_AMT")] <- "AMT_PAID"
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "GRP_LOB_CD")] <- "LOB"

cluster4_j_claims2$PATIENT_ID <- as.character(cluster4_j_claims2$PATIENT_ID)
cluster4_j_claims2$CLAIM_ID <- as.character(cluster4_j_claims2$CLAIM_ID)

cluster4_j_claims2 <- sqldf("select DISTINCT PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                      PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB, 
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                      ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                      pud, aids, lymph, metacanc, solidtum, 
                      rheumd, coag, obes, wloss, fed, 
                      blane, dane, alcohol, drug, psycho, 
                      depre,score, wscore_ahrq,wscore_vw,specialty
                            from cluster4_j_claims2")



outlier <- data.frame(matrix(ncol = 47, nrow = 0))
outlier_columns <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                     'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                     'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                     'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                     'pud','aids','lymph','metacanc','solidtum',
                     'rheumd','coag','obes','wloss','fed',
                     'blane','dane','alcohol','drug','psycho',
                     'depre','SOM_CLUSTER', 'Reconstruction.MSE',
                     'score', 'wscore_ahrq','wscore_vw','specialty')

outlier_temp <- data.frame(matrix(ncol = 47, nrow = 0))
colnames(outlier) <- outlier_columns
colnames(outlier_temp) <- outlier_columns

# dummy table structure to pull from base data 
# data pull
dummy_col_names <-  c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                      'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                      'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                      'pud','aids','lymph','metacanc','solidtum',
                      'rheumd','coag','obes','wloss','fed',
                      'blane','dane','alcohol','drug','psycho',
                      'depre', 'SOM_CLUSTER',
                      'score', 'wscore_ahrq','wscore_vw','specialty')

ccsnames <- c('chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
              'ond','cpd','diabunc','diabc','hypothy','rf','ld',
              'pud','aids','lymph','metacanc','solidtum',
              'rheumd','coag','obes','wloss','fed',
              'blane','dane','alcohol','drug','psycho',
              'depre')


fnames <- c( 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
             'PLACE_OF_SERVICE', 'CPT', 'LOB', 'SOM_CLUSTER','specialty')

# remove 'PATIENT_ID', 'CLAIM_ID', keep as character
intnames <- c( 'UNITS_ALLOWED','AMT_PAID')

numnames <- c('AMT_PAID','score', 'wscore_ahrq','wscore_vw')


dummy_pull <- data.frame(matrix(ncol = 46, nrow = 1))
colnames(dummy_pull) <- dummy_col_names

cluster4_j_claims2[ccsnames] <- lapply(cluster4_j_claims2[ccsnames], as.factor)
dummy_pull[ccsnames] <- lapply(dummy_pull[ccsnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[fnames] <- lapply(dummy_pull[fnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[intnames] <- lapply(dummy_pull[intnames], as.integer)
dummy_pull[numnames] <- lapply(dummy_pull[numnames], as.numeric)



outlier_temp[ccsnames] <- lapply(outlier_temp[ccsnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[fnames] <- lapply(outlier_temp[fnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[intnames] <- lapply(outlier_temp[intnames], as.integer)
outlier_temp[numnames] <- lapply(outlier_temp[numnames], as.numeric)
outlier_temp$PATIENT_ID <- as.character(outlier_temp$PATIENT_ID)
outlier_temp$CLAIM_ID <- as.character(outlier_temp$CLAIM_ID)


dummy_pull[setdiff(names(cluster4_j_claims2), names(dummy_pull))] <- NA
cluster4_j_claims2[setdiff(names(dummy_pull), names(cluster4_j_claims2))] <- NA

cluster4_j_claims2 <- rbind( dummy_pull,cluster4_j_claims2)
cluster4_j_claims2 <- sqldf("select  * from cluster4_j_claims2 where CPT != '0'")


jid <- sqldf("select distinct CPT from cluster4_j_claims2")

for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  j_string <- paste0("select PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                        PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB, 
                        chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                        ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                        pud, aids, lymph, metacanc, solidtum, 
                        rheumd, coag, obes, wloss, fed, 
                        blane, dane, alcohol, drug, psycho, 
                        depre,score, wscore_ahrq, wscore_vw,specialty
                        from cluster4_j_claims2
                     where CPT = '",jid_loop,"'")
  
  an0 <- sqldf(j_string)
  # remnove columns that all NA from dummy
  an0[sapply(an0, function(x) all(is.na(x)))] <- NULL
  
  an1 <- an0
  an1$PATIENT_ID <- NULL
  an1$AMT_PAID <- NULL
  an1$CLAIM_ID <- NULL
  
  
  # remove columns with all constant
  an1 <- an1[sapply(an1, function(x) length(unique(na.omit(x)))) >1]
  # only run anomoly if have 3+ columns non constant
  if(NCOL(an1) >= 3) {
    
    
    learnname <- colnames(an1) 
    
    an1_h2o <- as.h2o(an1)
    
    an1_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = an1_h2o, autoencoder = TRUE, 
                                   hidden = c(100,20,100), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                   categorical_encoding = "AUTO",seed = 77,
                                   standardize= TRUE,
                                   reproducible = TRUE)
    
    
    
    
    an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
    an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)
    
    
    outlier <- cbind(an0, an1_h2o_dl2)
    
    outlier <- data.frame(r_index = row.names(outlier), outlier)
    outlier$SOM_CLUSTER <- as.factor(cluster1)
    #outlier_temp<- bind_rows(outlier, outlier_temp)
    outlier_temp<- bind_rows(outlier, outlier_temp)
    
    
  }
  
}

###############################################
# claim line outlier Mahalnobis

outlier_temp$MSE <- outlier_temp$Reconstruction.MSE


# from CMS
jcode_max_units <- read.csv("CMS_Jcode_max_units.txt", header=TRUE, sep="\t")
UHG_units <- read.csv("UHG_NDC_Units.txt", header=TRUE, sep="\t")

Combined_units <- sqldf("select j.*, u.Units from jcode_max_units j
                        left join UHG_units u
                        on j.Code = u.CPT")


# add CMS max
outlier_temp <- sqldf("select  f.*, c.Max_Units from outlier_temp f INNER JOIN jcode_max_units c
                  ON f.CPT = c.Code")

# add median from baseline


outlier_temp <- sqldf("select  f.*, c.median_units as BaseLine_Median_Units from outlier_temp f INNER JOIN jcode_descriptives2 c
                  ON f.CPT = c.CPT")


outlier_temp$baseline_units_ratio <- outlier_temp$UNITS_ALLOWED / outlier_temp$BaseLine_Median_Units
outlier_temp$baseline_units_delta <- outlier_temp$UNITS_ALLOWED - outlier_temp$BaseLine_Median_Units


# drugs discontiued or not covered by CMS are 0 add 0.01 so can do ratio
outlier_temp$CMS_units_ratio <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED / outlier_temp$Max_Units,
                                       0)
outlier_temp$CMS_units_delta <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED - outlier_temp$Max_Units,
                                       0)



distance1 <- sqldf("select AMT_PAID,MSE,CMS_units_ratio, 
                     score, wscore_ahrq, wscore_vw from  outlier_temp")

distance1 <- scale(distance1)


# Mahalanobis from psych package
distance2 <- as.data.frame(outlier(distance1, plot = FALSE, bad = 5, xlab,ylab))
names(distance2)[1] <- "Mahalanobis"
outlier_temp2 <- cbind(outlier_temp,distance2)


# add add paid date filter on last paid 
outlier_temp2 <- sqldf ("select distinct o.* , c.DATE_PAID from outlier_temp2 o,claims_420a c
                 where  o.CLAIM_ID = c.CLAIM_ID")


outlier_temp2 <- mutate(outlier_temp2, 
                        Mahalanobis_rank = ntile(outlier_temp2$Mahalanobis, 10))
outlier_temp2$Reconstruction.MSE <- NULL

# make sure J0180 J9306 are in list per Amy


# 
# outlier_temp2$Units_Anomaly <- ifelse(outlier_temp2$Mahalanobis_rank >= 8 ,1,
#                                       ifelse(outlier_temp2$CPT == 'J0180',1,
#                                              ifelse(outlier_temp2$CPT == 'J9306',1,
#                                                     ifelse(outlier_temp2$CPT == 'J1745',1,
#                                                            ifelse(outlier_temp2$CPT == 'J2505' ,1,
#                                                                   ifelse(outlier_temp2$CPT == 'J9271',1,
#                                                                          ifelse(outlier_temp2$CPT == 'J9352' ,1,  
#                                                                                 ifelse(outlier_temp2$CPT == 'J9310',1, 0))))))))
# 
# 
# 
# 

outlier_temp2$Units_Anomaly <- ifelse(outlier_temp2$Mahalanobis_rank >= 8 ,1,0)





#saveRDS(outlier_temp2, file="outlier_temp2_claim_line.Rda")
#outlier_temp2_claim_line <- readRDS(file="outlier_temp2_claim_line.Rda")
outlier_temp2_claim_line <- outlier_temp2

# these are units above CMS or above median of sample
outlier_temp3_unit_hits_high <- sqldf("select * from outlier_temp2 where Units_Anomaly = 1
                                   order by Mahalanobis_rank DESC")
# flag for above and below benchmarks
outlier_temp3_unit_hits_high$above_benchmarks <-1
# these are below CMS and baseline but scorredd high mahalobious and anomoly

outlier_temp3_unit_hits_low <- sqldf("select * from outlier_temp2 where Units_Anomaly = 0
  
                                   order by Mahalanobis_rank DESC")

outlier_temp3_unit_hits_low$above_benchmarks <-0
outlier_temp3 <- rbind(outlier_temp3_unit_hits_high,outlier_temp3_unit_hits_low )



outlier_temp3_unit_hits_high$r_index <- NULL
Cluster4_claim_line_summary_df <- sqldf("select distinct * from  outlier_temp3_unit_hits_high
                                     order by Mahalanobis desc")

Cluster4_claim_line_summary_df[is.na(Cluster4_claim_line_summary_df)] <- 0

#saveRDS(Cluster4_claim_line_summary_df, file="Cluster4_claim_line_summary_df.Rda")
#Cluster4_claim_line_summary_dfz <- readRDS(file="Cluster4_claim_line_summary_df.Rda")



outlier_temp3_case_mix_hits <- sqldf("select * from outlier_temp2 where Units_Anomaly = 0
                                    
                                   order by Mahalanobis_rank DESC")

#OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


# CLAIMS



claim_line_output1 <- Cluster4_claim_line_summary_df 

names(claim_line_output1)[names(claim_line_output1) == "carit"] <- 'arrythmias' 
names(claim_line_output1)[names(claim_line_output1) == 'valv'] <- 'valvular_dz'
names(claim_line_output1)[names(claim_line_output1) == 'pcd'] <- 'pulmonary_circulation_dis'
names(claim_line_output1)[names(claim_line_output1) == 'pvd'] <- 'pvd'
names(claim_line_output1)[names(claim_line_output1) == 'hypunc'] <- 'hypertension_uncomplicated'
names(claim_line_output1)[names(claim_line_output1) == 'hypc'] <- 'hypertension_complicated'
names(claim_line_output1)[names(claim_line_output1) == 'para'] <- 'paralysis'
names(claim_line_output1)[names(claim_line_output1) == 'ond'] <- 'other_neuro'
names(claim_line_output1)[names(claim_line_output1) == 'cpd'] <- 'chronic_pulmonary_dis'
names(claim_line_output1)[names(claim_line_output1) == 'diabunc'] <- 'diabetes_uncomplicated'
names(claim_line_output1)[names(claim_line_output1) == 'diabc'] <- 'diabetes_complicated'
names(claim_line_output1)[names(claim_line_output1) == 'hypothy'] <- 'hypothyroidism'
names(claim_line_output1)[names(claim_line_output1) == 'rf'] <- 'renal_failure'
names(claim_line_output1)[names(claim_line_output1) == 'ld'] <- 'liver_dis'
names(claim_line_output1)[names(claim_line_output1) == 'pud'] <- 'peptic_ulcer'
names(claim_line_output1)[names(claim_line_output1) == 'aids'] <- 'HIV'
names(claim_line_output1)[names(claim_line_output1) == 'lymph'] <- 'lymphoma'
names(claim_line_output1)[names(claim_line_output1) == 'metacanc'] <- 'metastatic_cancer'
names(claim_line_output1)[names(claim_line_output1) == 'solidtum'] <- 'solid_tumour'
names(claim_line_output1)[names(claim_line_output1) == 'rheumd'] <- 'rheumatoid_arthritis'
names(claim_line_output1)[names(claim_line_output1) == 'coag'] <- 'coagulopathy'
names(claim_line_output1)[names(claim_line_output1) == 'obes'] <- 'obesity'
names(claim_line_output1)[names(claim_line_output1) == 'wloss'] <- 'weight_loss'
names(claim_line_output1)[names(claim_line_output1) == 'fed'] <- 'fluid_electorlyte'
names(claim_line_output1)[names(claim_line_output1) == 'blane'] <- 'blood_loss_anaemia'
names(claim_line_output1)[names(claim_line_output1) == 'dane'] <- 'deficiency_anaemia'
names(claim_line_output1)[names(claim_line_output1) == 'alcohol'] <- 'alcohol_abuse'
names(claim_line_output1)[names(claim_line_output1) == 'drug'] <- 'drug_abuse'
names(claim_line_output1)[names(claim_line_output1) == 'psycho'] <- 'psychoses'
names(claim_line_output1)[names(claim_line_output1) == 'depre'] <- 'depression'
#names(claim_line_output1)[names(claim_line_output1) == 'days_between_admins'] <- 'days_between_admins'
names(claim_line_output1)[names(claim_line_output1) == 'score'] <- 'Charlson_score'
names(claim_line_output1)[names(claim_line_output1) == 'wscore_ahrq'] <- 'AHRQ_score'
names(claim_line_output1)[names(claim_line_output1) == 'wscore_vw'] <- 'Elix_score'
names(claim_line_output1)[names(claim_line_output1) == 'SOM_CLUSTER'] <- 'cluster_id'

# TC only links to missings
# add TC
# NDC_TC_HCPC$HCPCS <- str_trim(as.character(NDC_TC_HCPC$HCPCS))
# claim_line_output1$CPT <- str_trim(claim_line_output1$CPT)
# junk <- sqldf("select c.*, t.Therapeutic_Class from claim_line_output1 c,
#               NDC_TC_HCPC t
#               where c.CPT = t.HCPCS")

outputid <- sqldf("select distinct CLAIM_ID as CLAIM_ID_x,  DATE_OF_SERVICE_BEG,
                  LST_SERV_DATE as DATE_OF_SERVICE_END from claims_420a")

top3_dx <-  sqldf("select distinct CLAIM_ID as CLAIM_ID_x, PMY_CODE, SEC_CODE,TER_CODE from claims_420a")
top3_dx1 <- sqldf("select CLAIM_ID_x, PMY_CODE as ICD9_CODE from top3_dx")
top3_dx2 <- sqldf("select CLAIM_ID_x, SEC_CODE as ICD9_CODE from top3_dx")
top3_dx3 <- sqldf("select  CLAIM_ID_x, TER_CODE as ICD9_CODE from top3_dx")


claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX1 from claim_line_output1 c left join top3_dx1 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")

claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX2 from claim_line_output1 c left join top3_dx2 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")

claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX3 from claim_line_output1 c left join top3_dx3 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")


output_cluster1_line <- sqldf("select distinct
  Mahalanobis as Score, Mahalanobis_rank as Score_Rank,a.CLAIM_ID,
                                PATIENT_ID, DATE_PAID, c.DATE_OF_SERVICE_BEG, c.DATE_OF_SERVICE_END,
                                CPT, UNITS_ALLOWED,AMT_PAID, 
                                Max_Units as CMS_MUE, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,
                                PLACE_OF_SERVICE,
                                LOB, DX1, DX2, DX3, Charlson_score, AHRQ_score,
                                Elix_score, specialty, chf, arrythmias, valvular_dz, 
                                pulmonary_circulation_dis, pvd, hypertension_uncomplicated,
                                hypertension_complicated, paralysis, other_neuro, 
                                chronic_pulmonary_dis, diabetes_uncomplicated,
                                diabetes_complicated, hypothyroidism, renal_failure, 
                                liver_dis,peptic_ulcer, HIV, lymphoma, metastatic_cancer,
                                solid_tumour, rheumatoid_arthritis, coagulopathy, 
                                obesity, weight_loss, fluid_electorlyte,blood_loss_anaemia,
                                deficiency_anaemia, alcohol_abuse, drug_abuse,psychoses,
                                depression
                                from claim_line_output1 a ,outputid c
                                where a.CLAIM_ID = c.CLAIM_ID_x
                              order by Mahalanobis desc")

output_cluster1_line$DATE_PAID <-as.POSIXct(output_cluster1_line$DATE_PAID, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_BEG <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_BEG, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_END <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_END, origin="1970-01-01")
output_cluster1_line$Service_Days <- difftime(output_cluster1_line$DATE_OF_SERVICE_END , output_cluster1_line$DATE_OF_SERVICE_BEG, units = "days"  )


library(BBmisc)


output_cluster1_line$Score_Normalized <- normalize(output_cluster1_line$Score, method="range", range=c(0,1))



output_cluster1_line <- sqldf("select distinct
 Score_Normalized,  Score_Rank,CLAIM_ID,
                                PATIENT_ID, DATE_PAID, DATE_OF_SERVICE_BEG, DATE_OF_SERVICE_END,Service_Days,
                                CPT, UNITS_ALLOWED,AMT_PAID, 
                                CMS_MUE, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,
                                PLACE_OF_SERVICE,
                                LOB, DX1, DX2, DX3,Charlson_score, AHRQ_score,
                                Elix_score, specialty, chf, arrythmias, valvular_dz, 
                                pulmonary_circulation_dis, pvd, hypertension_uncomplicated,
                                hypertension_complicated, paralysis, other_neuro, 
                                chronic_pulmonary_dis, diabetes_uncomplicated,
                                diabetes_complicated, hypothyroidism, renal_failure, 
                                liver_dis,peptic_ulcer, HIV, lymphoma, metastatic_cancer,
                                solid_tumour, rheumatoid_arthritis, coagulopathy, 
                                obesity, weight_loss, fluid_electorlyte,blood_loss_anaemia,
                                deficiency_anaemia, alcohol_abuse, drug_abuse,psychoses,
                                depression
                                from output_cluster1_line
                              order by Score desc", method = "name_class")

output_cluster1_line$DATE_PAID <-as.POSIXct(output_cluster1_line$DATE_PAID, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_BEG <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_BEG, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_END <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_END, origin="1970-01-01")


#write.table(output_cluster1_line, file = "output_cluster1_claim_6_22.csv",
#            row.names = FALSE, sep ="\t")
# write.table(output_cluster1_line, file = "output_cluster1_claim_9_29.csv",
#             row.names = FALSE, sep ="\t")

write.table(output_cluster1_line, file = "output_cluster7_claim_10_13.csv",
            row.names = FALSE, sep ="\t")

# scp dless1@apsrd9425:/home/dless1/BCBSMI/output_cluster7_claim_10_13.csv ~/Desktop

#output_cluster1_line_6_22  <- read.csv("output_cluster1_claim_6_22.csv", header=TRUE, sep="\t")


conn99 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;database=racerresearch;
                         UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')



sqlSave(conn99,output_cluster1_line,tablename="dbo.output_cluster1_line_9_7",rownames=FALSE)









