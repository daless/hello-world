
# txt files were deleted for space wqill need to copy from desktop

setwd("~/BCBSMI")
library(comorbidity)
#library(RODBC)
library(sqldf)



claims_line_180 <- read.csv("test4_from_view.txt", header=TRUE, sep="\t")

# removes junk at end of csv
claims_line_180 <- claims_line_180[-nrow(claims_line_180),]
claims_line_180 <- claims_line_180[-nrow(claims_line_180),]




colnames(claims_line_180)[which(names(claims_line_180) == "PROC_CODE")] <- "CPT"

claims_line_180$CPT <- as.character(claims_line_180$CPT)


colnames(claims_line_180)[which(names(claims_line_180) == "ICN_NUM")] <- "CLAIM_ID"
claims_line_180$CLAIM_ID <- as.character(claims_line_180$CLAIM_ID )


colnames(claims_line_180)[which(names(claims_line_180) == "allowed_units")] <- "UNITS_ALLOWED"
colnames(claims_line_180)[which(names(claims_line_180) == "paid")] <- "AMT_PAID"
colnames(claims_line_180)[which(names(claims_line_180) == "SERV_PLACE_CODE")] <- "POS"
colnames(claims_line_180)[which(names(claims_line_180) == "PROV_ZIP_CODE")] <- "ZIP_CODE"

claims_line_180$ZIP_CODE <- as.character(claims_line_180$ZIP_CODE)
claims_line_180$ZIP_CODE <- substr(claims_line_180$ZIP_CODE, start = 1, stop = 5)


dx_long <- sqldf("SELECT CLAIM_ID, PMY_CODE, SEC_CODE, TER_CODE, FOURTH_CODE,
FIFTH_CODE
from claims_line_180")

library(reshape2)

DX_claim <- reshape2::melt(dx_long, id.vars = "CLAIM_ID")

DX_claimids_Diag <- sqldf("select CLAIM_ID, value as ICD9_CODE from DX_claim where TRIM(value) !=''")


detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")
elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

# remove more junk from CSV
# charlson_scores<- charlson_scores[-1,]
# elixhauser_scores <- elixhauser_scores[-1,] 



#charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
elixhauser_scores$CLAIM_IDx <- elixhauser_scores$CLAIM_ID

elixhauser_scores$index <- NULL
elixhauser_scores$windex_ahrq <- NULL
elixhauser_scores$windex_vw  <- NULL
elixhauser_scores$CLAIM_ID <- NULL

saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
saveRDS(charlson_scores, file="charlson_scores.Rda")

# AHRQ comorbidities
library(icd)

AHRQ_1 <- icd_comorbid_ahrq(DX_claimids_Diag, visit_name = 'CLAIM_ID', icd_name = 'ICD9_CODE', return_df = TRUE,
                            return_binary = FALSE)

AHRQ_1$CLAIM_ID <- as.character(AHRQ_1$CLAIM_ID)
cols <- sapply(AHRQ_1, is.logical)

AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.numeric)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.character)
AHRQ_1$CLAIM_ID <- as.integer(AHRQ_1$CLAIM_ID)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.factor)
colnames(AHRQ_1) <- paste("AHRQ", colnames(AHRQ_1), sep = "_")
AHRQ_1$CLAIM_IDx <- AHRQ_1$AHRQ_CLAIM_ID
AHRQ_1$AHRQ_CLAIM_ID <- NULL

saveRDS(AHRQ_1, file="AHRQ_1.Rda")




# CCS

library(dplyr)
library(dummies)

CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)

colnames(DX_claim)[which(names(DX_claim) == "value")] <- "ICD9_CODE"

# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category, c.multi_desc 
from DX_claim d left join CCS c on d.ICD9_CODE = c.ICD10_Code
order by d.CLAIM_ID")



#DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), '0', DX_CCS$CCS_Category)
DX_CCS$multi_desc  <- ifelse(is.na(DX_CCS$multi_desc ), 'missing', DX_CCS$multi_desc )

#DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
DX_CCS$multi_desc <-as.factor(DX_CCS$multi_desc)

### One hot encoding of CCS variables #####

#CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from DX_CCS order by CLAIM_ID")




## Making a wide table
#CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc, sep= "_"))

#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))


saveRDS(CCS_Dummy_test3, file="CCS_Dummy_test3.Rda")



##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_ID, POS from claims_line_180")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor)
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
saveRDS(POS2, file="POS2.Rda")




BETOS<-read.csv("betos20.txt", header=TRUE, sep="\t")


CPT <- sqldf("select DISTINCT CLAIM_ID ,CPT from claims_line_180
             where CPT != ''")



# NEED TARGET VARIABLE HERE 


CPT <- sqldf("select b.*, p.ICD10_CODE_Leakage
from CPT b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")


CPT$ICD10_CODE_Leakage <- ifelse(is.na(CPT$ICD10_CODE_Leakage), 0,
                                 CPT$ICD10_CODE_Leakage)




CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c LEFT JOIN BETOS b
             ON c.CPT = b.HCPCS")

CPT_OVP <- sqldf("select distinct claim_ID, ICD10_CODE_Leakage from CPT")
# for orphan betos, use CPT

CPT$BETOS_20 <-  ifelse(is.na(CPT$BETOS_20),CPT$CPT,CPT$BETOS_20)

CPT_b <- sqldf("select distinct CLAIM_ID, BETOS_20 from CPT")








CPT_b$BETOS_20 <- as.factor(CPT_b$BETOS_20)

CPT_b <- cbind(CPT_b, dummy(CPT_b$BETOS_20, sep= "_"))

#replace with betos

#replace with betos
colnames(CPT_b)<-gsub("CPT_b","BETOS_20",colnames(CPT_b))

CPT_b$BETOS_20 <- NULL



# temp make id character
CPT$CLAIM_ID <- as.character(CPT$CLAIM_ID)


# new loop by to split CPT into columns split 10 ways
###############################################################


pid <- as.data.frame(CPT_b[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'



CPT_b$CLAIM_ID <- NULL

cpt_test2 <- split.default(CPT_b, gl(ncol(CPT_b)/10, 10))

number_data_frames <- as.integer(length(cpt_test2))




hcpc1 <- cpt_test2[[1]]
hcpc1 <- cbind(pid,hcpc1)
CPT1 <- hcpc1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  hcpc <- cpt_test2[[i]]
  hcpc <- cbind(pid,hcpc)
  
  hcpc3 <- hcpc %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(hcpc3)[1] <- 'CLAIM_IDx'
  
  CPT1<- cbind( CPT1,  hcpc3)
  CPT1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}


rm(cpt_test2)






# group by client id
#CPT1 <- CPT_b %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor)
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character(CPT2$CLAIM_ID))





CPT2 <- cbind(CPT_OVP$ICD10_CODE_Leakage,CPT2)
# #rename
names(CPT2)[1] <- 'ICD10_CODE_Leakage'

saveRDS(CPT2, file="CPT2_prod.Rda")

CPT2$ICD10_CODE_Leakage <- as.factor(as.character(CPT2$ICD10_CODE_Leakage))
#CPT2$CLAIM_ID <- NULL
rm(CPT1)
rm(CPT_b)

####### Configuring Provider city#########


FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


claims_line_180$ZIP <-  ifelse(is.na(claims_line_180$ZIP),'missing',claims_line_180$ZIP)



claims_invoiced2 <- claims_line_180

claims_invoiced2 <- data.frame(r_index = row.names(claims_invoiced2), claims_invoiced2)

claims_invoiced2 <- sqldf("select v.*, f.COUNTY from   claims_invoiced2 v left join FIPS f
                 ON v.ZIP = f.zip group by v.r_index
                          " )

claims_invoiced2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from claims_invoiced2 v left join USDA f
ON  v.COUNTY = f.FIPS  group by v.r_index")

claims_invoiced2$COUNTY <-  ifelse(is.na(claims_invoiced2$COUNTY),'missing',claims_invoiced2$COUNTY)
claims_invoiced2$USDA_urban_rural <- ifelse(is.na(claims_invoiced2$USDA_urban_rural),0,claims_invoiced2$USDA_urban_rural)



# use FIPS instead
FIPS <- sqldf("select DISTINCT claim_id as CLAIM_ID,  COUNTY from claims_invoiced2")

FIPS <- cbind(FIPS, dummy(FIPS$COUNTY , sep= "_"))

FIPS$FIPS_missing <- NULL



# new group by methodology
pid <- as.data.frame(FIPS[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'



FIPS$CLAIM_ID <- NULL

fips_test2 <- split.default(FIPS, gl(ncol(FIPS)/10, 10))

number_data_frames <- as.integer(length(fips_test2))

###############################################################

county1 <- fips_test2[[1]]
county1 <- cbind(pid,county1)
FIPS1 <- county1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  county <- fips_test2[[i]]
  county <- cbind(pid,county)
  
  county3 <- county %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(county3)[1] <- 'CLAIM_IDx'
  
  FIPS1 <- cbind( FIPS1,  county3)
  FIPS1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}

rm(fips_test2)
# temp make id character
FIPS1$CLAIM_ID <- as.character(FIPS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
FIPS2 <- FIPS1 %>% mutate_if(is.numeric,
                             function(x) case_when(
                               x >= 1 ~ 1,
                               x == 0 ~ 0
                             )
)

FIPS2 <- lapply(FIPS2, factor)
FIPS2<- as.data.frame(FIPS2)
FIPS2$CLAIM_ID <- as.numeric(as.character((FIPS2$CLAIM_ID)))
FIPS2$COUNTY <- NULL
saveRDS(FIPS2, file="FIPS2_prod.Rda")






###### Configuring Provider Type#######
PROV_TYPE <- sqldf("select DISTINCT CLAIM_ID,  PROV_SPEC_2_CODE as PROV_TYPE from claims_line_180")

PROV_TYPE <- cbind(PROV_TYPE, dummy(PROV_TYPE$PROV_TYPE , sep= "_"))

PROV_TYPE$CLAIM_ID <- as.character(PROV_TYPE$CLAIM_ID)
# group by client id
PROV_TYPE1 <- PROV_TYPE %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
PROV_TYPE1$CLAIM_ID <- as.character(PROV_TYPE1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_TYPE2 <- PROV_TYPE1 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_TYPE2 <- lapply(PROV_TYPE2, factor)
PROV_TYPE2 <- as.data.frame(PROV_TYPE2)
PROV_TYPE2$CLAIM_ID <- as.numeric(as.character((PROV_TYPE2$CLAIM_ID)))
PROV_TYPE2$PROV_TYPE <- NULL

saveRDS(PROV_TYPE2, file="PROV_TYPE2.Rda")



####  creating new features

# use scale / normalize library here
library(BBmisc)

claims_invoiced$ratio_billed_to_paid<-claims_invoiced$claim_amt_billed /claims_invoiced$claim_amt_paid
claims_invoiced$ratio_billed_to_paid <- normalize(claims_invoiced$ratio_billed_to_paid, method="range", range=c(0,1))


#claims_invoiced$ratio_billed_to_paid<-claims_invoiced$claim_line_amt_billed /claims_invoiced$claim_line_amt_paid

# allowed all missing

#claims_invoiced$ratio_allowed_to_paid<-claims_invoiced$claim_amt_allowed/claims_invoiced$claim_amt_paid
#claims_invoiced$PATIENT_AGE_NORM <- scale(claims_invoiced$claim_patient_age)
claims_invoiced$PATIENT_AGE_NORM <- normalize(claims_invoiced$claim_patient_age, method="range", range=c(0,1))

#claims_invoiced$PATIENT_AGE_NORM <- as.numeric(claims_invoiced$PATIENT_AGE_NORM)

claims_invoiced$Days_of_service <- difftime(claims_invoiced$claim_date_of_service_end ,
                                            claims_invoiced$claim_date_of_service_beg,
                                            units = c("days"))

claims_invoiced$Days_of_service <- as.numeric(claims_invoiced$Days_of_service)

claims_invoiced$Days_of_service <-  normalize(claims_invoiced$Days_of_service, method="range", range=c(0,1))

makeDataReport(claims_invoiced, vol="1", render = FALSE,
               replace = TRUE, openResult = FALSE, codebook = TRUE,
               reportTitle = "claims_invoiced - Report")







