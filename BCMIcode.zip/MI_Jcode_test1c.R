
# V1C on based upon view
#scp test3_from_view.txt dless1@apsrd9425:/home/dless1/BCBSMI
#scp baseline.txt dless1@apsrd9425:/home/dless1/BCBSMI


setwd("~/BCBSMI")
library(comorbidity)
#library(RODBC)
library(sqldf)
library(psych)



claims_test <- read.csv("test3_from_view.txt", header=TRUE, sep="\t")

# removes junk at end of csv
claims_test <- claims_test[-nrow(claims_test),]
claims_test <- claims_test[-nrow(claims_test),]

# healthfirst benchmark data
jcode_descriptives2 <- readRDS(file="jcode_descriptives2_HF.Rda")
som_diste <- readRDS(file="som_diste_HF.Rda")
SOM_descriptives2 <- readRDS(file="SOM_descriptives2_HF.Rda")
cluster1 <- as.vector(SOM_descriptives2[6,1])


#rename
colnames(claims_test)[which(names(claims_test) == "PROC_CODE")] <- "CPT"
colnames(claims_test)[which(names(claims_test) == "FST_SERV_DATE")] <- "DATE_OF_SERVICE_BEG"

#names(claims_test)[56] <- 'CPT'

# remove hwmophilia
claims_test <- sqldf("select * from claims_test where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")

colnames(claims_test)[which(names(claims_test) == "ICN_NUM")] <- "CLAIM_ID"
claims_test$CLAIM_ID <- as.character(claims_test$CLAIM_ID )


dx_long <- sqldf("SELECT CLAIM_ID, PMY_CODE, SEC_CODE, TER_CODE, FOURTH_CODE,
FIFTH_CODE
from claims_test")

#library(reshape2)

DX_claim <- reshape2::melt(dx_long, id.vars = "CLAIM_ID")

DX_claimids_Diag <- sqldf("select CLAIM_ID, value as ICD9_CODE from DX_claim where TRIM(value) !=''")


detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")
elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

# remove more junk from CSV
# charlson_scores<- charlson_scores[-1,]
# elixhauser_scores <- elixhauser_scores[-1,] 



#charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
elixhauser_scores$CLAIM_IDx <- elixhauser_scores$CLAIM_ID

elixhauser_scores$index <- NULL
elixhauser_scores$windex_ahrq <- NULL
elixhauser_scores$windex_vw  <- NULL
elixhauser_scores$CLAIM_ID <- NULL



# CCS



CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)

CCS_lookup <- CCS
CCS_lookup$multi_code <- CCS_lookup$CCS_Category
CCS_lookup$multi_code <- paste("CCS__",CCS_lookup$multi_code )


ccs_cols <- sqldf("select distinct multi_code, multi_desc from CCS_lookup")



# DX_claim  <- sqldf("select  d.* from DX_claim d
#                    where  d.ICD9_TYPE='DIAG10'")

icd2 <- sqldf("select distinct i.*, c.multi_desc from DX_claimids_Diag  i,CCS_lookup c where
              i.ICD9_CODE = c.ICD10_CODE ")


library(dplyr)
library(dummies)

CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from icd2")



CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test_", "",  colnames(CCS_Dummy_test)))
# group by client id
CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy3_test <- CCS_Dummy3_test %>% mutate_if(is.numeric, funs(factor(.)))
#CCS_Dummy3_test$CLAIM_ID <- as.numeric(CCS_Dummy3_test$CLAIM_ID)
CCS_Dummy3_test$multi_desc <- NULL
CCS_Dummy3_test <- sqldf("select * from CCS_Dummy3_test order by CLAIM_ID")
CCS_Dummy3_test$CLAIM_IDx <-CCS_Dummy3_test$CLAIM_ID
CCS_Dummy3_test$CLAIM_ID <- NULL

# wide format
icd_C4_2 <- CCS_Dummy3_test 


# do not have time between administrations in the sandbox data


library(data.table)
library(psych)

# everything is 0
# jcode_time <- claims_test  %>%
#   arrange( CLAIM_ID, CPT,DATE_OF_SERVICE_BEG) %>%
#   group_by(CLAIM_ID, CPT) %>%
#   dplyr:::mutate(diff = DATE_OF_SERVICE_BEG - lag(DATE_OF_SERVICE_BEG,1))
# 
# jcode_time <- sqldf("select * from jcode_time",method = "name_class")
# # rx add 1 to all days so 0 is NA and those on same day coded as a 1
# jcode_time$days_between_admins = jcode_time$diff + 0
# 
# #jcode_time$days_between_admins = jcode_time$diff/ddays(1)
# jcode_time$days_between_admins <- ifelse(is.na(jcode_time$days_between_admins),
#                                          0, jcode_time$days_between_admins + 1)
# 
# 
# jcode_time <- sqldf("select * from jcode_time",method = "name_class")
# jcode_time$diff <- NULL
# 
# 
# 
# 
# 
# jcode_time2 <- sqldf("select CPT,  days_between_admins
#                    from jcode_time
#                   ")












claims_420a <- claims_test

colnames(claims_420a)[which(names(claims_420a) == "SERV_PLACE_CODE")] <- "PLACE_OF_SERVICE"
colnames(claims_420a)[which(names(claims_420a) == "BLNG_TYPE_CODE")] <- "BILL_TYPE"
colnames(claims_420a)[which(names(claims_420a) == "PROC_MOD_1_CODE")] <- "CPT_MODIFIER"
colnames(claims_420a)[which(names(claims_420a) == "SERVICE_TYPE_CODE")] <- "REVENUE_CODE"
colnames(claims_420a)[which(names(claims_420a) == "PROV_SPEC_2_CODE")] <- "specialty"



claims_420a <- sqldf("select distinct b.*, c.wscore as charls_score from charlson_scores c,
               claims_420a b where 
               b.CLAIM_ID = c.CLAIM_ID", method = "name_class")




claims_420a<- sqldf("select distinct b.*, c.* from elixhauser_scores c,
               claims_420a b where 
               b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")



# load CCS stripe first 3 characters of CCS for rollups for apriori

targ <- cbind(jcode_descriptives2,som_diste)
names(targ)[20] <- 'SOM_CLUSTER'

claims_420b_string <- paste0("select  CPT from targ
                             where SOM_CLUSTER  = '",cluster1,"'")

claims_420b <- sqldf(claims_420b_string)

cluster4_j_claims2 <- sqldf("select c.* from claims_420a c, claims_420b b
                       where c.CPT = b.CPT")

cluster4_j_claims2$CLAIM_IDx <- NULL

cluster4_j_claims2$CPT <- as.factor(cluster4_j_claims2$CPT)
cluster4_j_claims2$CPT_MODIFIER <- as.factor(cluster4_j_claims2$CPT_MODIFIER)
cluster4_j_claims2$REVENUE_CODE <- as.factor(as.character(cluster4_j_claims2$REVENUE_CODE))
cluster4_j_claims2$specialty <- as.factor(cluster4_j_claims2$specialty)




# change bill type code NA to 0
claims_420a$BILL_TYPE <- ifelse(is.na(claims_420a$BILL_TYPE), 0, claims_420a$BILL_TYPE)


# place of service
claims_420a$PLACE_OF_SERVICE<- ifelse(is.na(claims_420a$PLACE_OF_SERVICE), 0, 
                                      claims_420a$PLACE_OF_SERVICE)


claims_420a$CPT_MODIFIER <- ifelse(is.na(claims_420a$CPT_MODIFIER), 0, claims_420a$CPT_MODIFIER)

claims_420a$REVENUE_CODE <- ifelse(is.na(claims_420a$REVENUE_CODE), 0, claims_420a$REVENUE_CODE)



# from healthfirst


# rename
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "PATN_ACT_NUM")] <- "PATIENT_ID"
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "SERV_UNIT_QTY")] <- "UNITS_ALLOWED"
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "PRORT_AMT")] <- "AMT_PAID"
colnames(cluster4_j_claims2)[which(names(cluster4_j_claims2) == "GRP_LOB_CD")] <- "LOB"



cluster4_j_claims2 <- sqldf("select DISTINCT PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                      PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB, 
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                      ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                      pud, aids, lymph, metacanc, solidtum, 
                      rheumd, coag, obes, wloss, fed, 
                      blane, dane, alcohol, drug, psycho, 
                      depre,score, wscore_ahrq,wscore_vw,specialty
                            from cluster4_j_claims2")



outlier <- data.frame(matrix(ncol = 47, nrow = 0))
outlier_columns <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                     'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                     'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                     'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                     'pud','aids','lymph','metacanc','solidtum',
                     'rheumd','coag','obes','wloss','fed',
                     'blane','dane','alcohol','drug','psycho',
                     'depre','SOM_CLUSTER', 'Reconstruction.MSE',
                     'score', 'wscore_ahrq','wscore_vw','specialty')

outlier_temp <- data.frame(matrix(ncol = 47, nrow = 0))
colnames(outlier) <- outlier_columns
colnames(outlier_temp) <- outlier_columns

# dummy table structure to pull from base data 
# data pull
dummy_col_names <-  c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                      'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                      'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                      'pud','aids','lymph','metacanc','solidtum',
                      'rheumd','coag','obes','wloss','fed',
                      'blane','dane','alcohol','drug','psycho',
                      'depre', 'SOM_CLUSTER',
                      'score', 'wscore_ahrq','wscore_vw','specialty')

ccsnames <- c('chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
              'ond','cpd','diabunc','diabc','hypothy','rf','ld',
              'pud','aids','lymph','metacanc','solidtum',
              'rheumd','coag','obes','wloss','fed',
              'blane','dane','alcohol','drug','psycho',
              'depre')


fnames <- c( 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
             'PLACE_OF_SERVICE', 'CPT', 'LOB', 'SOM_CLUSTER','specialty')

intnames <- c('PATIENT_ID', 'CLAIM_ID',
              'UNITS_ALLOWED','AMT_PAID')

numnames <- c('AMT_PAID','score', 'wscore_ahrq','wscore_vw')


dummy_pull <- data.frame(matrix(ncol = 46, nrow = 1))
colnames(dummy_pull) <- dummy_col_names

cluster4_j_claims2[ccsnames] <- lapply(cluster4_j_claims2[ccsnames], as.factor)
dummy_pull[ccsnames] <- lapply(dummy_pull[ccsnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[fnames] <- lapply(dummy_pull[fnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[intnames] <- lapply(dummy_pull[intnames], as.integer)
dummy_pull[numnames] <- lapply(dummy_pull[numnames], as.numeric)



outlier_temp[ccsnames] <- lapply(outlier_temp[ccsnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[fnames] <- lapply(outlier_temp[fnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[intnames] <- lapply(outlier_temp[intnames], as.integer)
outlier_temp[numnames] <- lapply(outlier_temp[numnames], as.numeric)




dummy_pull[setdiff(names(cluster4_j_claims2), names(dummy_pull))] <- NA
cluster4_j_claims2[setdiff(names(dummy_pull), names(cluster4_j_claims2))] <- NA


cluster4_j_claims2 <- rbind( dummy_pull,cluster4_j_claims2)
cluster4_j_claims2 <- sqldf("select  * from cluster4_j_claims2 where CPT != '0'")


jid <- sqldf("select distinct CPT from cluster4_j_claims2")








