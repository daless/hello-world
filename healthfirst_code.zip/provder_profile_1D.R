# FL L code provider code


prov_comm <- sqlQuery(
  conn_comm,
  " select
  CLM.PROVIDER_ID,
  count(CLM.PROVIDER_ID) as CNT,
  L.ICD9_CODE,
  count(L.ICD9_CODE) as ICD9_CODE_CNT,
  sum(CLM.AMT_PAID) as TOT_PAID
   FROM dbo.ICD9 L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND  L.ORDER_IN_CLAIM <= 5
  group by CLM.PROVIDER_ID, L.ICD9_CODE
  ")

prov_comm$ICD9_CODE<-as.character(prov_comm$ICD9_CODE)
prov_comm$ICD10_CODE<- prov_comm$ICD9_CODE
prov_comm$ICD9_CODE<- gsub(".","",prov_comm$ICD9_CODE,fixed=TRUE)

# this is after CCS code has been parsed
#CCS$multi_desc <- substr(CCS$CCS_Category,1,3)


CCSROLLUP <- read.csv("CCSROLLUP.txt", header = TRUE, sep="\t")



prov_comm2 <- sqldf("select i.*, c.multi_desc from  DX_claim i,CCS c where
              i.ICD9_CODE = c.ICD10_CODE ")
prov_comm2 <- sqldf("select c.*, i.CCS_roll_up from  CCSROLLUP i,prov_comm2 c where
              i.multi_desc = c.multi_desc ")






prov_comm3 <- sqldf("select PROVIDER_ID, count(PROVIDER_ID) as prov_cnt,
                    CCS_roll_up as multi_desc,
                    count(CCS_roll_up) as tot_dx
                    from prov_comm2
                    group by PROVIDER_ID,
                    CCS_roll_up
                    order by PROVIDER_ID, tot_dx desc
                    ")


prov_comm_top3 <- data.table(prov_comm3, key="PROVIDER_ID")
prov_comm_top3 <-prov_comm_top3[, head(.SD, 3), by=PROVIDER_ID]
prov_comm_top3 <- sqldf("select PROVIDER_ID,  multi_desc,tot_dx from prov_comm_top3 order by PROVIDER_ID, tot_dx desc")

prov_comm_top3$num <- ave(prov_comm_top3$multi_desc, prov_comm_top3$PROVIDER_ID, FUN = seq_along)

special1 <- sqldf("select PROVIDER_ID, multi_desc as spec1 from prov_comm_top3 where num = 1")
special2 <- sqldf("select PROVIDER_ID, multi_desc as spec2  from prov_comm_top3  where num = 2")
special3 <- sqldf("select PROVIDER_ID, multi_desc as spec3  from prov_comm_top3 where num = 3")

special1 <- sqldf("select s.* , x.spec2 from special1 s left join special2 x
                  on s.PROVIDER_ID = x.PROVIDER_ID")
special1 <- sqldf("select s.* , x.spec3 from special1 s left join special3 x
                  on s.PROVIDER_ID = x.PROVIDER_ID")

special1$spec2<- ifelse(is.na(special1$spec2), '', 
                        special1$spec2)
special1$spec3<- ifelse(is.na(special1$spec3), '', 
                        special1$spec3)
special1$specialty <- do.call(paste, c(special1[c("spec1", "spec2", "spec3")],sep="_" ))

saveRDS(special1, file="special1.Rda")






prov_comm <- sqlQuery(
  conn_comm,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer00319.DBO.CLAIM CLM
  INNER JOIN Racer00319.DBO.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  where CLM.PROJECT_ID = 319
  AND  DX.ORDER_IN_CLAIM <= 5
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)






















cluster4_j_claims2 <- sqldf ("select CLAIM_ID, PATIENT_ID,  BILL_TYPE,CPT_MODIFIER,REVENUE_CODE,
                             PLACE_OF_SERVICE, CPT, UNITS_BILLED, AMT_PAID, PROVIDER_ID, PATIENT_AGE
                             from cluster4_j_claims
                             order by CPT")


cluster4_j_claims2 <- prov_base1

#prov_base1$CLAIM_ID <- NULL
prov_base1$PATIENT_ID  <- NULL
prov_base1$BILL_TYPE <- NULL
prov_base1$CPT_MODIFIER <- NULL
prov_base1$PLACE_OF_SERVICE <- NULL
#prov_base1$CPT <- NULL
prov_base1$AMT_PAID <- NULL
prov_base1$PROVIDER_ID <- as.character(prov_base1$PROVIDER_ID)



#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
# anomaly temp files

outlier_b_an <- data.frame(matrix(ncol = 4, nrow = 0))
annames <- c('PROVIDER_ID', 'CLAIM_ID',  'iForest_score', 'CPT' )
colnames(outlier_b_an) <- annames


outlier_b_an$PROVIDER_ID <- as.character(outlier_b_an$PROVIDER_ID)
outlier_b_an$CLAIM_ID <- as.numeric(as.character(outlier_b_an$CLAIM_ID))
outlier_b_an$iForest_score <-  as.numeric(as.character(outlier_b_an$iForest_score))
outlier_b_an$CPT <-  as.factor(as.character(outlier_b_an$CPT))


jid <- sqldf("select distinct c.CPT from cluster4_j_claims2 c")
jid <- jid[201:399,1, drop = FALSE]


#junk <- jid
#jid <- sqldf("select distinct c.CPT from cluster4_j_claims2 c where c.CPT = '29540' ")

library(isofor)

for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  
  j_string <-
    paste0("select * from prov_base1 where CPT = '", jid_loop, "'")
  
  an0 <- sqldf(j_string)
  an0 <- an0[sapply(an0, function(x)
    length(unique(na.omit(x)))) > 1]
  
  if (NROW(an0) >= 5) {
    prov_id <- sqldf("select distinct PROVIDER_ID from an0")
    
    for (i in rownames(prov_id))
    {
      p_loop <- prov_id[i, ]
      
      k_string <-
        paste0("select * from an0 where PROVIDER_ID != '", p_loop, "'")
      
      an00 <- sqldf(k_string)
      
      p_string <-
        paste0("select * from an0 where PROVIDER_ID = '", p_loop, "'")
      doc_compare <- sqldf(p_string)
      p0_string <-
        paste0("select PROVIDER_ID, CLAIM_ID from an0 where PROVIDER_ID = '",
               p_loop,
               "'")
      doc_compare0 <- sqldf(p0_string)
      
      
      
      an1 <- an00
      an1$PROVIDER_ID <- NULL
      an1$CLAIM_ID <- NULL
      doc_compare$PROVIDER_ID <- NULL
      an1$CPT <- NULL
      doc_compare$CPT <- NULL
      doc_compare$CLAIM_ID <- NULL
      
      # remove CCS with all 0s
      an1 <- an1[sapply(an1, function(x)
        length(unique(na.omit(x)))) > 1]
      if(NCOL(an1) >= 3) {
        
        doc_compare <-
          doc_compare[sapply(doc_compare, function(x)
            length(unique(na.omit(x)))) > 1]
        if(NCOL(doc_compare) >= 3) {
          d = NROW(doc_compare)
          # ev code not removed by all being constant
          if ("REVENUE_CODE" %in% colnames(doc_compare))
          {
            doc_compare$REVENUE_CODE <- as.factor(as.character(doc_compare$REVENUE_CODE))
          }
          
          rf_model <- iForest(doc_compare, phi = d, nt= 20, seed = 77)
          iForest_score <- predict(rf_model,doc_compare )
          doc_compare0 <- data.frame(doc_compare0, iForest_score)
          
          doc_compare0$CPT <- jid_loop
          outlier_b_an <- rbind(outlier_b_an, doc_compare0)
          
        }
      }
    }
  }
}

saveRDS(outlier_b_an, file="outlier_b_an_201_399.Rda")

# do an anomolay of anomaly scores to flag providers


outlier_b_an_201_399 <- readRDS(file="outlier_b_an_201_399.Rda")
outlier_b_an_1_50 <- readRDS(file="outlier_b_an_1_50.Rda")
outlier_b_an_51_100 <- readRDS(file="outlier_b_an_51_100.Rda")
outlier_b_an_101_200 <- readRDS(file="outlier_b_an_101_200.Rda")

all_outliers <- outlier_b_an_201_399

all_outliers <- rbind(all_outliers ,outlier_b_an_1_50)
all_outliers <- rbind(all_outliers ,outlier_b_an_51_100)
all_outliers <- rbind(all_outliers ,outlier_b_an_101_200)

all_outliers_score <- sqldf("select PROVIDER_ID, iForest_score from all_outliers")



doc_descriptives <- as.data.frame(describeBy(all_outliers_score,
                                             group = list(all_outliers$PROVIDER_ID), 
                                             mat=TRUE))

doc_descriptives2 <- sqldf("select * from doc_descriptives  where vars = 2
and n >= 50
                           order by median desc")

doc_descriptives2 <- mutate(doc_descriptives2, 
                            CPT_rank = ntile(doc_descriptives2$median, 10))

doc_descriptives_top10 <- sqldf("select * from doc_descriptives2  where CPT_rank = 10
                           order by median desc")

bad_docs1 <- sqldf("select c.*, b.group1 from cluster4_j_claims2_new c, doc_descriptives_top10 b
where b.group1 = c.PROVIDER_ID")

bad_doc_id <- sqldf("select distinct group1 from bad_docs1")
cpt_id <- sqldf("select distinct CPT from bad_docs1")

good_docs1 <- sqldf("select b.group1, c.*  from cluster4_j_claims2_new c
                    left join bad_doc_id b
                    on c.PROVIDER_ID = b.group1")

good_docs1$group1<- ifelse(is.na(good_docs1$group1), '0', 
                           good_docs1$group1)


good_docs1 <- sqldf("select * from good_docs1 where group1 = '0' ")
good_docs1 <- sqldf("select g.* from good_docs1 g, cpt_id c
where c.CPT = g.CPT")


bad_docs1$bad_doc <- 1
bad_docs1$group1 <- NULL
good_docs1$bad_doc <- 0
good_docs1$group1 <- NULL

study_docs <- rbind(bad_docs1,good_docs1 )



#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")
study_docs$bad_doc <- as.factor(as.character(study_docs$bad_doc))
elixhauser_scores$CLAIM_ID <- as.numeric(elixhauser_scores$CLAIM_ID )

study_docs <- sqldf("select c.*, e.wscore_vw as elix_score from elixhauser_scores e,study_docs c
                        where c.CLAIM_ID = e.CLAIM_ID")



dx_primary <- sqldf("select d.*, c.CCS_Category_Description, c.CCS_Category as primary_CCS_Category 
              from DX_claim d, CCS c
              where d.ICD9_CODE = c.ICD10_Code
              and d.ORDER_IN_CLAIM = 0")

study_docs <- sqldf("select s.*, d.CCS_Category_Description, d.primary_CCS_Category 
                    from study_docs s, dx_primary d
                    where  s.CLAIM_ID = d.CLAIM_ID")


#saveRDS(study_docs, file="study_docs.Rda")
#study_docs <- readRDS(file="study_docs.Rda")
#str(study_docs,list.len = ncol(study_docs))


library(MatchIt)

C5model_inputs <- matchit(bad_doc ~ primary_CCS_Category + CPT,
                          data = study_docs,optmatch_max_problem_size = Inf, 
                          mmethod = "nearest", distance = "logit"
)
C5model_inputs0 <- match.data(C5model_inputs)
#saveRDS(C5model_inputs0, file="C5model_inputs0.Rda")




# study_cpt <- sqldf("select distinct CPT from study_docs where PROVIDER_ID = 29390191")
# 
# C5model_inputs_baddocf <- sqldf("select s.* from study_docs s, study_cpt c
#                                 where c.CPT = s.CPT and PROVIDER_ID = 29390191")
# 
# C5model_inputs_gooddoc <- sqldf("select s.* from study_docs s, study_cpt c
#                                 where c.CPT = s.CPT and bad_doc = 0")
# 
# C5model_inputs <- rbind(C5model_inputs_baddocf,C5model_inputs_gooddoc )



C5model_inputs <-C5model_inputs0
C5model_inputs$CLAIM_ID <- NULL
C5model_inputs <- sqldf("select distinct * from C5model_inputs order by bad_doc desc, PATIENT_ID")



C5model_inputs$PATIENT_ID  <- NULL
C5model_inputs$BILL_TYPE <- NULL
C5model_inputs$CPT_MODIFIER <- NULL
C5model_inputs$PLACE_OF_SERVICE <- NULL
C5model_inputs$CPT <- NULL
C5model_inputs$AMT_PAID <- NULL
C5model_inputs$PROVIDER_ID <- NULL
C5model_inputs$CCS_Category_Description <- NULL
C5model_inputs$distance <- NULL

# remove CCS with all 0s
C5model_inputs <- C5model_inputs[sapply(C5model_inputs, function(x)
  length(unique(na.omit(x)))) > 1]

C5model_inputs<- C5model_inputs %>% select (bad_doc, everything())
C5model_inputs <- sqldf("select distinct * from C5model_inputs ")


# run tree models 
# target is bad doc - do not split use cross validation instead
# also use C5 for rules

# for ap riori will need to flip columns to rows
# might need to have a prefix


cluster_inputs_h2o <- as.h2o((C5model_inputs))

#splits <- h2o.splitFrame(cluster_inputs_h2o, c(0.7), seed = 77)
#train <- h2o.assign(splits[[1]], "train.hex")
#test <- h2o.assign(splits[[2]], "test.hex")

y <- "bad_doc"
x <- setdiff(names(cluster_inputs_h2o), y)

response <- "bad_doc"
cluster_inputs_h2o[[response]] <- as.factor(cluster_inputs_h2o[[response]])
predictors <- setdiff(colnames(cluster_inputs_h2o),response)
# 
# nfolds <- 20
# xgboost <- h2o.xgboost(x=x,
#                        y = y,
#                        training_frame = cluster_inputs_h2o,
#                        
#                        ntrees = 200,
#                        nfolds = nfolds,
#                        fold_assignment = "Modulo",
#                        keep_cross_validation_predictions = TRUE,
#                        max_depth = 3,
#                        min_rows = 2,
#                        learn_rate =0.2,
#                        seed = 77)
# 
# summary(xgboost)
# 
# head(as.data.frame(h2o.varimp(xgboost)),n=10)
# 
# # # Random Forest
# 
# rf <- h2o.randomForest( x = predictors,
#                         y = response,
#                         training_frame = cluster_inputs_h2o,
#                         ntrees = 20,
#                         nfolds = nfolds,
#                         fold_assignment = "Modulo",
#                         keep_cross_validation_predictions = TRUE,
# 
#                         seed = 77)
# 
# 
# summary(rf)
# 
# 

# gbm with stochastics to determine best parameters
nfolds <- 20
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = cluster_inputs_h2o,
  
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  nfolds=nfolds,
  score_tree_interval = 10
)

summary(gbm2)
head(as.data.frame(h2o.varimp(gbm2)),n=10)

table(C5model_inputs$bad_doc, C5model_inputs$REVENUE_CODE)
#Other specified hereditary and degenerative nervous system conditions
table(C5model_inputs$bad_doc, C5model_inputs$NVS006)
#Cardiac dysrhythmias
table(C5model_inputs$bad_doc, C5model_inputs$CIR017)



#LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


# L codes

study_docs_L <- sqldf("select * from study_docs where SUBSTR(CPT,1,1) = 'L'")

library(MatchIt)

# exclude primary dx

C5model_inputs <- matchit(bad_doc ~  CPT,
                          data = study_docs_L,optmatch_max_problem_size = Inf, 
                          mmethod = "nearest", distance = "logit"
)
C5model_inputs0 <- match.data(C5model_inputs)
#saveRDS(C5model_inputs0, file="C5model_inputs0_Lcodes.Rda")



C5model_inputs <-C5model_inputs0
C5model_inputs$CLAIM_ID <- NULL
C5model_inputs <- sqldf("select distinct * from C5model_inputs order by bad_doc desc, PATIENT_ID")



C5model_inputs$PATIENT_ID  <- NULL
C5model_inputs$BILL_TYPE <- NULL
C5model_inputs$CPT_MODIFIER <- NULL
C5model_inputs$PLACE_OF_SERVICE <- NULL
C5model_inputs$CPT <- NULL
C5model_inputs$AMT_PAID <- NULL
C5model_inputs$PROVIDER_ID <- NULL
C5model_inputs$CCS_Category_Description <- NULL
C5model_inputs$distance <- NULL

# remove CCS with all 0s
C5model_inputs <- C5model_inputs[sapply(C5model_inputs, function(x)
  length(unique(na.omit(x)))) > 1]

C5model_inputs<- C5model_inputs %>% select (bad_doc, everything())
C5model_inputs <- sqldf("select distinct * from C5model_inputs ")


cluster_inputs_h2o <- as.h2o((C5model_inputs))

#splits <- h2o.splitFrame(cluster_inputs_h2o, c(0.7), seed = 77)
#train <- h2o.assign(splits[[1]], "train.hex")
#test <- h2o.assign(splits[[2]], "test.hex")

y <- "bad_doc"
x <- setdiff(names(cluster_inputs_h2o), y)

response <- "bad_doc"
cluster_inputs_h2o[[response]] <- as.factor(cluster_inputs_h2o[[response]])
predictors <- setdiff(colnames(cluster_inputs_h2o),response)
# 


# gbm with stochastics to determine best parameters
nfolds <- 20
gbm_L <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = cluster_inputs_h2o,
  
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  nfolds=nfolds,
  score_tree_interval = 10
)

summary(gbm_L)
head(as.data.frame(h2o.varimp(gbm_L)),n=10)
describeBy(C5model_inputs$PATIENT_AGE, C5model_inputs$bad_doc, mat = TRUE )

# tables

# good docs have these CCS bad do not matching on CPT -- not in top 5 DX ccodes
table(C5model_inputs$bad_doc, C5model_inputs$MUS023)
table(C5model_inputs$bad_doc, C5model_inputs$MUS022)
table(C5model_inputs$bad_doc, C5model_inputs$MUS038)
table(C5model_inputs$bad_doc, C5model_inputs$SYM010)


table(C5model_inputs$bad_doc, C5model_inputs$MUS006)#
table(C5model_inputs$bad_doc, C5model_inputs$MUS007)#
table(C5model_inputs$bad_doc, C5model_inputs$MUS022)


###############################################
# claim line outlier Mahalnobis

outlier_temp$MSE <- outlier_temp$Reconstruction.MSE


# # from mississippi medicaid  fee schedule
# jcode_max_units <- read.csv("CMS_Jcode_max_units.csv", sep = ",",  quote = "\"", header = TRUE)
# 
# 
# 
# # add CMS max
# outlier_temp <- sqldf("select  f.*, c.Max_Units from outlier_temp f INNER JOIN jcode_max_units c
#                       ON f.CPT = c.Code")

# add median from baseline


outlier_temp <- sqldf("select  f.*, c.median as BaseLine_Median_Units from outlier_temp f INNER JOIN jcode_descriptives_units c
                      ON f.CPT = c.group1")


outlier_temp$baseline_units_ratio <- outlier_temp$UNITS_BILLED / outlier_temp$BaseLine_Median_Units
outlier_temp$baseline_units_delta <- outlier_temp$UNITS_BILLED - outlier_temp$BaseLine_Median_Units


# # drugs discontiued or not covered by CMS are 0 add 0.01 so can do ratio
# outlier_temp$CMS_units_ratio <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_BILLED / outlier_temp$Max_Units,
#                                        0)
# outlier_temp$CMS_units_delta <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_BILLED - outlier_temp$Max_Units,
#                                        0)

#distance1 <- sqldf("select AMT_PAID,MSE,CMS_units_ratio from  outlier_temp")
distance0 <- sqldf("select r_index,AMT_PAID,MSE,baseline_units_ratio, elixhauser_score from  outlier_temp")
distance1 <- distance0
distance1$r_index <- NULL
distance1 <- scale(distance1)

# Mahalanobis from psych package
distance2 <- as.data.frame(outlier(distance1, plot = FALSE, bad = 5, xlab,ylab))
names(distance2)[1] <- "Mahalanobis"
outlier_temp2 <- cbind(outlier_temp,distance2)
distance0 <- cbind(distance0 ,distance2)

# SOM


library(SOMbrero)
library(kohonen)



distance0_scale <- scale(distance0)
som2 <- trainSOM(x.data = distance0_scale, dimension = c(9,10), nb.save = 10, maxit = 500,
                 scaling = "none")

#plot(som2, what = "obs", type = "hitmap")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=8)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)

# save SOM output
#aveRDS(som_diste, file="SOM_LCODE_L0650.Rda")




targ <- cbind(distance0,som_diste)

# #rename
names(targ)[6] <- 'SOM_CLUSTER'

#table(targ$SOM_CLUSTER)
#targ$case_1224_hit <- as.factor(as.character(targ$case_1224_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))


micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

summary(distance0)
SOM_descriptives <- as.data.frame(describeBy(targ,
                                             group = list(targ$SOM_CLUSTER), 
                                             mat=TRUE))



#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@




# arpriori for each J code of CCS

# from claim level data extract non anomaly and mahobious < 8 for case mix
# needs to be tested with smaller clausters

if(NROW(outlier_temp_b) > 0) {
  case_ids <- sqldf("select distinct CLAIM_ID from outlier_temp2_b where Units_Anomaly = 0")}

if(NROW(outlier_temp_b) == 0) {
  case_ids <- sqldf("select distinct CLAIM_ID from outlier_temp2_claim_line where Units_Anomaly = 0")}

# check mapping to correct table
claim_level1_backup<- claim_level1
claim_level1 <- sqldf("select c.* from claim_level1 c,case_ids i
              where c.CLAIM_ID = i.CLAIM_ID")




cluster4_j_claims2 <- readRDS(file="cluster4_j_claims2.Rda")
claim_level1 <- cluster4_j_claims2
SOM_descriptives2 <- readRDS(file="SOM_descriptives2.Rda")
cluster1 <- as.vector(SOM_descriptives2[4,1])
claims_line_180 <- readRDS(file="claims_line_180.Rda")
icd2 <- readRDS(file="icd2.Rda")










library(arules)
library(arulesViz)
library(visNetwork)
library(igraph)
library(plyr)
library(tibble)
library(reshape2)
library(dplyr)

# anomaly temp files
outlier_b_an <- data.frame(matrix(ncol = 62, nrow = 0))
outlier_columns_b_an <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                          'PLACE_OF_SERVICE', 'CPT', 'UNITS_BILLED','AMT_PAID', 'LOB',
                          'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                          'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                          'pud','aids','lymph','metacanc','solidtum',
                          'rheumd','coag','obes','wloss','fed',
                          'blane','dane','alcohol','drug','psycho',
                          'depre', 'days_between_admins','score', 'wscore_ahrq','wscore_vw',
                          'LHS', 'RHS', 'support', 'confidence','lift', 'count', 'tot_rules',
                          'Jaccard_rank', 'case_mix_MSE', 'Anomaly_rank',
                          'edge_betweenness', 'authority_score', 'closeness','strength','coreness', 'an_mx' , 'jac_max')



outlier_temp_b_an <- data.frame(matrix(ncol = 62, nrow = 0))
colnames(outlier_b_an) <- outlier_columns_b_an
colnames(outlier_temp_b_an) <- outlier_columns_b_an

# dummy table structure to pull from base data 
# data pull
dummy_col_names <-  c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'UNITS_BILLED','AMT_PAID', 'LOB',
                      'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                      'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                      'pud','aids','lymph','metacanc','solidtum',
                      'rheumd','coag','obes','wloss','fed',
                      'blane','dane','alcohol','drug','psycho',
                      'depre',  'days_between_admins','score', 'wscore_ahrq','wscore_vw',
                      'LHS', 'RHS', 'support', 'confidence','lift', 'count', 'tot_rules',
                      'Jaccard_rank', 'case_mix_MSE', 'Anomaly_rank',
                      'edge_betweenness', 'authority_score', 'closeness','strength','coreness', 'an_mx' , 'jac_max')

ccsnames <- c('chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
              'ond','cpd','diabunc','diabc','hypothy','rf','ld',
              'pud','aids','lymph','metacanc','solidtum',
              'rheumd','coag','obes','wloss','fed',
              'blane','dane','alcohol','drug','psycho',
              'depre')


fnames <- c( 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE',
             'PLACE_OF_SERVICE', 'CPT', 'LOB','CLAIM_ID')

intnames <- c('PATIENT_ID', 
              'UNITS_BILLED')

numnames <- c('AMT_PAID', 'support', 'confidence','lift', 'count', 'tot_rules',
              'Jaccard_rank','case_mix_MSE','Anomaly_rank', 'days_between_admins',
              'score', 'wscore_ahrq','wscore_vw', 'edge_betweenness', 'authority_score',
              'closeness','strength','coreness', 'an_mx' , 'jac_max')

charnames <- c('LHS', 'RHS')


dummy_pull <- data.frame(matrix(ncol = 62, nrow = 1))
colnames(dummy_pull) <- dummy_col_names

claim_level1[ccsnames] <- lapply(claim_level1[ccsnames], as.factor)
claim_level1[fnames] <- lapply(claim_level1[fnames], as.factor)

dummy_pull[ccsnames] <- lapply(dummy_pull[ccsnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[fnames] <- lapply(dummy_pull[fnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[intnames] <- lapply(dummy_pull[intnames], as.integer)
dummy_pull[numnames] <- lapply(dummy_pull[numnames], as.numeric)
dummy_pull[charnames] <- lapply(dummy_pull[charnames], as.character)

outlier_temp_b_an[ccsnames] <- lapply(outlier_temp_b_an[ccsnames], as.factor)
#outlier_temp_b_an[is.na(outlier_temp)] <-0
outlier_temp_b_an[fnames] <- lapply(outlier_temp_b_an[fnames], as.factor)
#outlier_temp_b_an[is.na(outlier_temp)] <-0
outlier_temp_b_an[intnames] <- lapply(outlier_temp_b_an[intnames], as.integer)
outlier_temp_b_an[numnames] <- lapply(outlier_temp_b_an[numnames], as.numeric)
outlier_temp_b_an[charnames] <- lapply(outlier_temp_b_an[charnames], as.character)



jid <- sqldf("select distinct CPT from claim_level1 ")

#jid <- sqldf("select distinct CPT from claim_level1  where CPT = 'J7686'")


# turns off graphics in R studio
graphics.off()
par("mar")
par(mar=c(1,1,1,1))

for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  j_string <- paste0("select PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                      PLACE_OF_SERVICE,  CPT,  UNITS_BILLED, AMT_PAID,  LOB, 
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                      ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                      pud, aids, lymph, metacanc, solidtum, 
                      rheumd, coag, obes, wloss, fed, 
                      blane, dane, alcohol, drug, psycho, 
                      depre, days_between_admins,score, wscore_ahrq,wscore_vw
                     from claim_level1
                     where CPT = '",jid_loop,"'")
  
  an0 <- sqldf(j_string)
  # remnove columns that all NA from dummy
  an0[sapply(an0, function(x) all(is.na(x)))] <- NULL
  
  # remove fields for anomaly run
  an1 <- an0
  an1$PATIENT_ID <- NULL
  an1$total_claim_pd <- NULL
  an1$CLAIM_ID <- NULL
  an1$Units_Anomaly <- NULL
  an1$Max_Units <- NULL
  an1$total_claim_pd <- NULL

  
  
  an1 <- an1[sapply(an1, function(x) length(unique(na.omit(x)))) >1]
  
  
  
  if(NCOL(an1) > 0) {
    
    
    
    #  CCS by claim and J code
    ap1 <- sqldf( "select distinct i.CLAIM_ID, i.multi_desc as CCS_DX from icd2 i, an0 a
                  where i.CLAIM_ID = a.CLAIM_ID
                  order by i.CLAIM_ID")
    
    # ap1 <- sqldf("select  a.*, c.multi_code as CCS_DX from ap1 a, CCSdesc c
    #              where a.multi_desc = c.multi_desc")
    
    # removed modifer
    #ap1$multi_desc <- NULL
    
    
    ap1$CLAIM_ID <- as.factor(as.character((ap1$CLAIM_ID)))
    ap1$CCS_DX <- as.factor(as.character((ap1$CCS_DX)))
    
    ap2 <- ddply(ap1, c("CLAIM_ID"),
                 function(ap1)paste(ap1$CCS_DX,
                                    collapse = ','))
    
    names(ap2)[2] <- "CCS"
    
    ap3 <- ap2
    ap3$CLAIM_ID <- NULL
    
    write.csv(ap2, file = "ccs_transactions.csv")
    
    txn <- read.transactions(file="ccs_transactions.csv", rm.duplicates = TRUE,
                             format="single", sep=",", cols=c("CLAIM_ID","CCS"))
    
    
    
    
    # remove quotes
    txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)
    
    basket_rules <- apriori(txn,parameter = list(sup = 0.01, 
                                                 conf=0.01, target="rules"))
    
    # remove redundent rules
    basket_rules <- basket_rules[!is.redundant(basket_rules)]
    CCS_Basket <- DATAFRAME(basket_rules, separate = TRUE)
    
    # have to have at least 3 rules
    if (NROW(CCS_Basket) >=3 ){
      
      # see if LHS all empty
      # if so add 0 to LHS
      CCS_Basket <-  CCS_Basket[!sapply( CCS_Basket, function(k) all(k =="{}"))]
    }
      if(NCOL(CCS_Basket) ==6){
        # remove brackets
        CCS_Basket$LHS <- gsub("[{}]","", CCS_Basket$LHS)
        CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
      }
      
      if(NCOL(CCS_Basket) ==5){
        CCS_Basket$LHS <- '0'
        CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
        #CCS_Basket <- sqldf("select LHS,RHS,support,confidence,lift,count from CCS_Basket")
      }
      
      
      # SNA
      # nodes rule id adges are rules
      
      adj1 <- sqldf("select LHS , RHS , count as weight from CCS_Basket")
      
      # add row ids for nodes
      adj1$id <- 1:nrow(adj1)
      
      
      adj1$weight <- as.integer(adj1$weight)
      adj2 <-adj1
      adj2$id <- NULL
      
      
      # 
      transferGraph <- graph_from_data_frame(adj2, directed = TRUE)
      
      # look at other layouts in igraph
      # plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
      #                                                          weights=E(transferGraph)$weight),
      #      edge.arrow.size = .2)
      
      
      # ig <- plot(basket_rules, method="graph")
      # ig_df <- get.data.frame(ig,what = "both")
      
      # 
      # visNetwork(
      #   nodes = data.frame(
      #     id = ig_df$vertices$name
      #     ,value = ig_df$vertices$lift  # try lift & confidence
      #     ,title = ifelse(ig_df$vertices$label == "", ig_df$vertices$name, ig_df$vertices$label)
      #     ,ig_df$vertices
      #   )
      #   , edges = ig_df$edges
      # ) %>%
      #   visNodes(size = 10) %>%
      #   visLegend() %>%
      #   visEdges(smooth = FALSE) %>%
      #   visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
      #   visInteraction(navigationButtons = TRUE) %>%
      #   visEdges( arrows = 'from') %>%
      #   visPhysics(
      #     solver = "barnesHut",
      #     maxVelocity = 35,
      #     forceAtlas2Based = list(gravitationalConstant = -6000)
      #     
      #   ) 
      
      
      
      # betweenness
      # ig_between <-  as.data.frame(betweenness(transferGraph))
      # names(ig_between)[2] <- "betweenness"
      
      # edge betweeness
      
      
      ig_between <-  as.data.frame(edge.betweenness(transferGraph, weights=E(transferGraph)$weight))
      names(ig_between)[1] <- "edge_betweenness"
      ig_between <- rownames_to_column(ig_between, var="id")
      
      # other metrics are at the NODE level
      
      # coreness
      ig_coreness <-  as.data.frame(coreness(transferGraph, mode="all"))
      names(ig_coreness)[1] <- "coreness"
      ig_coreness <-  rownames_to_column(ig_coreness, var="id")
      
      
      
      # strength --- numbr of edges that go from one node to another
      # lower number less connected
      ig_strength <-  as.data.frame(strength(transferGraph, weights=E(transferGraph)$weight))
      names(ig_strength)[1] <- "strength"
      ig_strength <-  rownames_to_column(ig_strength, var="id")
      
      # closeness number of steps to access other nodes - higher values less
      # centrality
      
      ig_closeness <- as.data.frame(closeness(transferGraph, normalized = TRUE, weights=E(transferGraph)$weight))
      names(ig_closeness)[1] <- "closeness"
      ig_closeness <-  rownames_to_column(ig_closeness, var="id")
      
      
      # authority score -- high authority when is linked
      #by other nodes with link other nodes
      
      ig_authority <- as.data.frame(authority_score(transferGraph,scale=TRUE,
                                                    weights=E(transferGraph)$weight)$vector)
      names(ig_authority)[1] <- "authority_score"
      ig_authority <-  rownames_to_column(ig_authority, var="id")
      ig_authority <- sqldf("select * from ig_authority where id != ''")
      
      
      
      #hist(degree(transferGraph))
      
      cl <- clusters(transferGraph)
      # plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
      #                                                          weights=E(transferGraph)$weight),
      #      vertex.color = cl$membership+1L, edge.arrow.size = 1)
      # 
      
      
      # remove rwonames after redundants deleted
      rownames(CCS_Basket) <- c()
      
      dissi <- dissimilarity(basket_rules, method = "Jaccard", which = "associations")
      
      dissi_m <- melt(as.matrix(dissi))
      p <- t(apply(dissi_m[,c(1,2)],1,FUN=sort))
      rmv1 <- which(p[,1] == p[,2])
      
      p <- paste(p[,1],p[,2], sep = "|")
      rmv2 <- which(duplicated(p))
      
      dissi_m <- as.data.frame(dissi_m[-c(rmv1,rmv2),])
      
      # filter to get all with score of 1
      # VAR is the index 
      dissi_m1 <- sqldf("select Var1 as rule_i, count(Var1) as rule_cnt from  dissi_m
                      where value = 1
                      group by Var1")
      
      dissi_m2 <- sqldf("select Var2 as rule_i, count(Var2) as rule_cnt from  dissi_m
                      where value = 1
                      group by Var2")
      
      distance_rule_cnt <- rbind(dissi_m1, dissi_m2)
      
      distance_rule_cnt <- sqldf("select rule_i, sum(rule_cnt) as tot_rules
                               from distance_rule_cnt
                               group by rule_i
                               order by tot_rules desc ")
      
      
      CCS_Basket<- data.frame(rule_index = row.names(CCS_Basket), CCS_Basket)
      #CCS_Basket$tot_rules <- ifelse(is.na(CCS_Basket$tot_rules), 0, CCS_Basket$tot_rules)
      CCS_Basket <- sqldf("select c.*, d.* from CCS_Basket c LEFT JOIN  distance_rule_cnt d
                        ON c.rule_index = d.rule_i
                        order by tot_rules desc")
      
      
      # ADD SNA metrics to market basket data
      
      
      CCS_Basket <- sqldf("select c.*, d.edge_betweenness from CCS_Basket c,  
                        ig_between d,
                        adj1 a
                        where d.id = a.id
                        AND a.LHS = c.LHS
                        AND a.RHS = c.RHS")
      
      CCS_Basket <- sqldf("select c.*, d.authority_score from  CCS_Basket c  
                         LEFT JOIN ig_authority d
                        ON c.LHS = d.id")
      
      
      CCS_Basket <- sqldf("select c.*, d.closeness from  CCS_Basket c  
                         LEFT JOIN ig_closeness d
                        ON c.LHS = d.id")
      
      
      CCS_Basket <- sqldf("select c.*, d.strength from  CCS_Basket c  
                         LEFT JOIN ig_strength d
                        ON c.LHS = d.id")
      
      CCS_Basket <- sqldf("select c.*, d.coreness from  CCS_Basket c  
                         LEFT JOIN ig_coreness d
                        ON c.LHS = d.id")
      
      
      
      
      CCS_Basket$rule_i <- NULL
      
      CCS_Basket2 <- CCS_Basket
      # remove jaccard from anomolay
      CCS_Basket2$count <- NULL
      
      CCS_Basket2_0 <- CCS_Basket2
      CCS_Basket2_0$rule_index <- 0
      CCS_Basket2_0$LHS <- 0
      CCS_Basket2_0$RHS <- 0
      
      learnname <- colnames(CCS_Basket2_0)
      CCS_Basket2_h2o <- as.h2o(CCS_Basket2_0 )
      
      # change field range to sql for  CCS_Basket2
      
      
      CCS_Basket2_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = CCS_Basket2_h2o, autoencoder = TRUE, 
                                             hidden = c(100,20,100), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                             categorical_encoding = "AUTO",standardize= TRUE,seed = 77,
                                             reproducible = TRUE)
      
      
      
      CCS_Basket2_h2o_dl2 = h2o.anomaly(CCS_Basket2_h2o_dl, CCS_Basket2_h2o)
      
      CCS_Basket2_h2o_dl2 <- as.data.frame(CCS_Basket2_h2o_dl2)
      
      CCS_Basket <- cbind(CCS_Basket ,CCS_Basket2_h2o_dl2)
      names(CCS_Basket)[14] <- "case_mix_MSE"
      
      CCS_Basket <- mutate(CCS_Basket, 
                           Anomaly_rank = ntile(CCS_Basket$case_mix_MSE, 10))
      CCS_Basket <- mutate(CCS_Basket, 
                           Jaccard_rank = ntile(CCS_Basket$tot_rules, 10))
      # select where jacard rank and anomaly both in upper quartile
      
      max_basket <- sqldf("select max(Anomaly_rank) as an_mx, max(Jaccard_rank) as jac_max from CCS_Basket")
      CCS_Basket <- cbind(CCS_Basket,max_basket)
      
      
      # select where jacard rank and anomaly both in upper quartile accounts for ties with max above
      # checks to see that jacard is not all constant
      if (length(unique(CCS_Basket[,"tot_rules"])) != 1) {
        CCS_Basket3 <- sqldf("select * from CCS_Basket where  jac_max = Jaccard_rank
                           and an_mx =Anomaly_rank")
      }
      
      # if jacard all constant just use MSE anomoly
      if (length(unique(CCS_Basket[,"tot_rules"])) == 1) {
        CCS_Basket3 <- sqldf("select * from CCS_Basket where an_mx =Anomaly_rank")
      }
      
      
      
      # match anomaly rule to base data
      an_hit1 <- sqldf("select a.CLAIM_ID as CLAIM_ID_x, c.* from ap2 a, CCS_Basket3 c
                     where a.CCS = c.LHS")
      
      an_hit2 <- sqldf("select a.CLAIM_ID as CLAIM_ID_x, c.* from ap2 a, CCS_Basket3 c
                     where a.CCS = c.RHS")
      
      an_hit2 <- rbind(an_hit1, an_hit2)
      
      an_hit2 <- sqldf("select distinct * from an_hit2 ")
      
      an_hit2 <- sqldf("select distinct n.*, a.* from an_hit2 a, an0 as n
                     where a.CLAIM_ID_x = n.CLAIM_ID")
      
      an_hit2$CLAIM_ID_x <- NULL
      an_hit2$rule_index <- NULL
      #an_hit2$CLUSTER <- 4
      
      
      # above checks for all columns to be constant - if so then will have no columns
      # confoirm no columns == 0
      #an_hit2 <- an_hit2[sapply(an_hit2, function(x) length(unique(na.omit(x)))) >1]
      
      if(NCOL(an_hit2) > 0) {
        #an_hit2$SOM_CLUSTER <- as.factor(cluster1)
        outlier_temp_b_an<- bind_rows(outlier_temp_b_an,an_hit2)
        outlier_temp_b_an$SOM_CLUSTER <- as.factor(cluster1)
        
      }
    }
  }
  
#}

prov_sna1 <- outlier_temp_b_an

prov_sna1[is.na(prov_sna1)] <- 0

prov_sna1 <- sqldf("select distinct p.*, c.PROVIDER_ID from prov_sna1 p, claims_line_180 c
                   where p.CLAIM_ID = c.CLAIM_ID
                   ")
#saveRDS(prov_sna1, file="prov_sna1.Rda")
#Cluster4_casemix_summary_df <- readRDS(file="sna_results1.Rda")




#FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

# isolation forest


cluster4_j_claims2 <- sqldf ("select CLAIM_ID,  REVENUE_CODE,
                             PLACE_OF_SERVICE, CPT, UNITS_BILLED,  PROVIDER_ID,
                             days_between_admins,score, wscore_ahrq, wscore_vw, LHS, RHS, 
                             support, confidence, lift, count, tot_rules,case_mix_MSE, 
                             edge_betweenness, authority_score, closeness, strength,coreness 
                             from prov_sna1
                             order by CPT")


prov_base1 <- cluster4_j_claims2 

# #prov_base1$CLAIM_ID <- NULL
# prov_base1$PATIENT_ID  <- NULL
# prov_base1$BILL_TYPE <- NULL
# prov_base1$CPT_MODIFIER <- NULL
# prov_base1$PLACE_OF_SERVICE <- NULL
# #prov_base1$CPT <- NULL
# prov_base1$AMT_PAID <- NULL
prov_base1$PROVIDER_ID <- as.character(prov_base1$PROVIDER_ID)
prov_base1$REVENUE_CODE <- as.factor(prov_base1$REVENUE_CODE)
prov_base1$PLACE_OF_SERVICE <-as.factor(prov_base1$PLACE_OF_SERVICE)
prov_base1$LHS <- as.factor(prov_base1$LHS)
prov_base1$RHS <- as.factor(prov_base1$RHS)



library(BBmisc)
library(isofor)
set.seed(77)


prov_base1 <- normalize(prov_base1, method="standardize")

#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
# anomaly temp files

outlier_b_an <- data.frame(matrix(ncol = 4, nrow = 0))
annames <- c('PROVIDER_ID', 'CLAIM_ID',  'iForest_score', 'CPT' )
colnames(outlier_b_an) <- annames


outlier_b_an$PROVIDER_ID <- as.character(outlier_b_an$PROVIDER_ID)
outlier_b_an$CLAIM_ID <- as.numeric(as.character(outlier_b_an$CLAIM_ID))
outlier_b_an$iForest_score <-  as.numeric(as.character(outlier_b_an$iForest_score))
outlier_b_an$CPT <-  as.factor(as.character(outlier_b_an$CPT))


jid <- sqldf("select distinct c.CPT from cluster4_j_claims2 c")
#jid <- jid[1,1, drop = FALSE]


#junk <- jid
#jid <- sqldf("select distinct c.CPT from cluster4_j_claims2 c where c.CPT = '29540' ")



for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  
  j_string <-
    paste0("select * from prov_base1 where CPT = '", jid_loop, "'")
  
  an0 <- sqldf(j_string)
  an0 <- an0[sapply(an0, function(x)
    length(unique(na.omit(x)))) > 1]
  
  if (NROW(an0) >= 5) {
    prov_id <- sqldf("select distinct PROVIDER_ID from an0")
    
    for (i in rownames(prov_id))
    {
      p_loop <- prov_id[i, ]
      
      k_string <-
        paste0("select * from an0 where PROVIDER_ID != '", p_loop, "'")
      
      an00 <- sqldf(k_string)
      
      p_string <-
        paste0("select * from an0 where PROVIDER_ID = '", p_loop, "'")
      doc_compare <- sqldf(p_string)
      p0_string <-
        paste0("select PROVIDER_ID, CLAIM_ID from an0 where PROVIDER_ID = '",
               p_loop,
               "'")
      doc_compare0 <- sqldf(p0_string)
      
      
      
      an1 <- an00
      an1$PROVIDER_ID <- NULL
      an1$CLAIM_ID <- NULL
      doc_compare$PROVIDER_ID <- NULL
      an1$CPT <- NULL
      doc_compare$CPT <- NULL
      doc_compare$CLAIM_ID <- NULL
      
      # remove CCS with all 0s
      an1 <- an1[sapply(an1, function(x)
        length(unique(na.omit(x)))) > 1]
      if(NCOL(an1) >= 3) {
        
        doc_compare <-
          doc_compare[sapply(doc_compare, function(x)
            length(unique(na.omit(x)))) > 1]
        if(NCOL(doc_compare) >= 3) {
          d = NROW(doc_compare)
          # ev code not removed by all being constant
          if ("REVENUE_CODE" %in% colnames(doc_compare))
          {
            doc_compare$REVENUE_CODE <- as.factor(as.character(doc_compare$REVENUE_CODE))
          }
          
          rf_model <- iForest(doc_compare, phi = d, nt= 20, seed = 77)
          iForest_score <- predict(rf_model,doc_compare )
          doc_compare0 <- data.frame(doc_compare0, iForest_score)
          
          doc_compare0$CPT <- jid_loop
          outlier_b_an <- rbind(outlier_b_an, doc_compare0)
          
        }
      }
    }
  }
}

prov_paid <- sqldf("select CLAIM_ID,PROVIDER_ID, AMT_PAID, CPT from prov_sna1")
prov_paid$AMT_PAID <- normalize(prov_paid$AMT_PAID, method="standardize")

provider_mahan1 <- sqldf("select distinct o.*, p.AMT_PAID from outlier_b_an o, prov_paid p
                         where o.CLAIM_ID = p.CLAIM_ID
                         and o.PROVIDER_ID = p.PROVIDER_ID
                         and o.CPT = p.CPT")

provider_mahan2 <- sqldf("select  AMT_PAID, iForest_score from provider_mahan1 
                         ")


p_distnace <- as.data.frame(outlier(provider_mahan2 , plot = FALSE, bad = 5, xlab,ylab))
names(p_distnace)[1] <- "Mahalanobis"
provider_mahan3 <- cbind(provider_mahan1,p_distnace )


prov_sna2 <- sqldf("select distinct s.*, m.iForest_score, m.Mahalanobis  from prov_sna1 s, provider_mahan3  m
                   where s.CLAIM_ID = m.CLAIM_ID
                         and s.PROVIDER_ID = m.PROVIDER_ID
                         and s.CPT = m.CPT")

#saveRDS(prov_sna2, file="prov_sna2.Rda")
# exmple of looking at abd doc link to claim line scores

junk <- sqldf("select t.* from outlier_temp2_claim_line t ,
              claims_line_180 c where 
              c.CLAIM_ID = t.CLAIM_ID
              and c.CPT = t.CPT
              and c.PROVIDER_ID = '29030860'")







# do an anomolay of anomaly scores to flag providers


all_outliers_score <- sqldf("select PROVIDER_ID, iForest_score, Mahalanobis from prov_sna2")



doc_descriptives <- as.data.frame(describeBy(all_outliers_score,
                                             group = list(all_outliers_score$PROVIDER_ID), 
                                             mat=TRUE))

doc_descriptives2 <- sqldf("select * from doc_descriptives  where vars = 2

                           order by median desc")

doc_descriptives2 <- mutate(doc_descriptives2, 
                            CPT_rank = ntile(doc_descriptives2$median, 10))

doc_descriptives_top10 <- sqldf("select * from doc_descriptives2  where CPT_rank >= 7
                           order by median desc")

bad_docs1 <- sqldf("select c.*, b.group1 from prov_sna2 c, doc_descriptives_top10 b
where b.group1 = c.PROVIDER_ID")

bad_doc_id <- sqldf("select distinct group1 from bad_docs1")
cpt_id <- sqldf("select distinct CPT from bad_docs1")

good_docs1 <- sqldf("select b.group1, c.*  from prov_sna2 c
                    left join bad_doc_id b
                    on c.PROVIDER_ID = b.group1")

good_docs1$group1<- ifelse(is.na(good_docs1$group1), '0', 
                           good_docs1$group1)


good_docs1 <- sqldf("select * from good_docs1 where group1 = '0' ")
good_docs1 <- sqldf("select g.* from good_docs1 g, cpt_id c
where c.CPT = g.CPT")


bad_docs1$bad_doc <- 1
bad_docs1$group1 <- NULL
good_docs1$bad_doc <- 0
good_docs1$group1 <- NULL

study_docs <- rbind(bad_docs1,good_docs1 )



#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")
study_docs$bad_doc <- as.factor(as.character(study_docs$bad_doc))
elixhauser_scores$CLAIM_ID <- as.numeric(elixhauser_scores$CLAIM_ID )

study_docs <- sqldf("select c.*, e.wscore_vw as elix_score from elixhauser_scores e,study_docs c
                        where c.CLAIM_ID = e.CLAIM_ID")



dx_primary <- sqldf("select d.*, c.CCS_Category_Description, c.CCS_Category as primary_CCS_Category 
              from DX_claim d, CCS c
              where d.ICD9_CODE = c.ICD10_Code
              and d.ORDER_IN_CLAIM = 0")

study_docs <- sqldf("select s.*, d.CCS_Category_Description, d.primary_CCS_Category 
                    from study_docs s, dx_primary d
                    where  s.CLAIM_ID = d.CLAIM_ID")


#saveRDS(study_docs, file="study_docs.Rda")
#study_docs <- readRDS(file="study_docs.Rda")
#str(study_docs,list.len = ncol(study_docs))












