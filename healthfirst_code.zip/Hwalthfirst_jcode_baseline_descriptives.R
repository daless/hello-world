


setwd("~/healthfirst")
library(comorbidity)
library(RODBC)
library(sqldf)
library(psych)

# library(plyr)
# library(dplyr)
# library(icd)
# 
# library(dummies)
# library(data.table)
# library(ggplot2)
# library(dataMaid)
library(lubridate)
# library(NbClust)
# library(cluster)
library(tidyr)
# library(factoextra)
# library(proxy)
# library(tibble)
# library(network)
# # descriptive stats
# library(Hmisc)

# 
# library(arules)
# library(arulesViz)
# library(visNetwork)
# library(igraph)


#library(h2o)
#h2o.init()
########h2o.init(port=54322)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)





conn_medicare = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01288;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)


# 3 yers hx data to set baselines


claims_line_medicare <- sqlQuery(
  conn_medicare,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 1095
  AND L.CPT Like '%J%'
  ")

claims_line_medicare$LOB <- "MEDICARE"


# remove human FACTOR

claims_line_medicare <- sqldf("select * from claims_line_medicare where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")


conn_medicaid = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01289;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_medicaid <- sqlQuery(
  conn_medicaid,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 1095
  AND L.CPT Like '%J%'
  ")

claims_line_medicaid$LOB <- "MEDICAID"


# remove human FACTOR

claims_line_medicaid <- sqldf("select * from claims_line_medicaid where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")




conn_comm = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01290;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_comm <- sqlQuery(
  conn_comm,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 1095
  AND L.CPT Like '%J%'
  ")

claims_line_comm$LOB <- "COMM"


# remove human FACTOR

claims_line_comm <- sqldf("select * from claims_line_comm where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")

claims_line_180 <- rbind(claims_line_medicare, claims_line_medicaid, claims_line_comm)

special1 <- readRDS(file="special1.Rda")
claims_line_180 <- sqldf("select c.*, p.specialty from claims_line_180 c, special1 p
              where c.PROVIDER_ID = p.PROVIDER_ID")


saveRDS(claims_line_180, file="claims_line_180.Rda")
#claims_line_180 <- readRDS(file="claims_line_180.Rda")


jcode_cnt <- sqldf("select CPT,  CLAIM_NO, count(CLAIM_NO) as jcnt, sum(AMT_PAID) as paid,
                   sum(UNITS_ALLOWED) as allowed_units
                   from claims_line_180
                   group by CPT, CLAIM_NO
                   order by CPT")



jcode_cnt2 <- jcode_cnt
jcode_cnt2$CLAIM_NO <- NULL

# jcode claim line descriptives

jcode_descriptives <- as.data.frame(describeBy(jcode_cnt2,
                                               group = list(jcode_cnt2$CPT), 
                                               mat=TRUE))

jcode_descriptives_pd <- sqldf("select * from jcode_descriptives where vars = 3
                            order by mean desc")

jcode_descriptives_vol <- sqldf("select * from jcode_descriptives where vars = 2
                            order by n desc")

jcode_descriptives_units <- sqldf("select * from jcode_descriptives where vars = 4
                            order by n desc")

jcode_descriptives2 <- sqldf("select v.group1 as CPT, v.n as num_admins, 
                             v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units,
                             v.median as median_num_admins, p.median as median_pd, u.median as median_units,
                             v.min as min_num_admins, v.max as max_num_admins, 
                             p.min as min_pd, p.max as max_pd,
                             u.min as min_units, u.max as max_units
                             from jcode_descriptives_pd p, jcode_descriptives_vol v, jcode_descriptives_units u
                             where v.group1 = p.group1
                             and p.group1 = u.group1
                             order by mean_pd desc")





# time between administrations

# Added 1 to days so could convert NAs to 0


library(dplyr)
library(data.table)

jcode_time <- claims_line_180 %>%
  arrange( CLAIM_ID, CPT,DATE_OF_SERVICE_BEG) %>%
  group_by(CLAIM_ID, CPT) %>%
  dplyr:::mutate(diff = DATE_OF_SERVICE_BEG - lag(DATE_OF_SERVICE_BEG,1))

# rx add 1 to all days so 0 is NA and those on same day coded as a 1
jcode_time$days_between_admins = jcode_time$diff/ddays(1)
jcode_time$days_between_admins <- ifelse(is.na(jcode_time$days_between_admins),
                                         0, jcode_time$days_between_admins + 1)


jcode_time <- sqldf("select * from jcode_time",method = "name_class")
jcode_time$diff <- NULL





jcode_time2 <- sqldf("select CPT,  days_between_admins
                   from jcode_time
                  ")

jcode_time_descriptives <- as.data.frame(describeBy(jcode_time2,
                                                    group = list(jcode_time2$CPT),
                                                    mat=TRUE))

jcode_descriptives_time <- sqldf("select * from jcode_time_descriptives where vars = 2 order by n desc")



jcode_descriptives2 <- sqldf("select v.group1 as CPT, v.n as num_admins,
                             v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units, t.mean as mean_days,
                             v.median as median_num_admins, p.median as median_pd, u.median as median_units, t.median as median_days,
                             v.min as min_num_admins, v.max as max_num_admins,t.max as max_days,
                             p.min as min_pd, p.max as max_pd,
                             u.min as min_units, u.max as max_units
                             from jcode_descriptives_pd p, jcode_descriptives_vol v,
                             jcode_descriptives_units u, jcode_descriptives_time t
                             where v.group1 = p.group1
                             and v.group1 = u.group1
                             and v.group1 = t.group1
                             order by mean_pd desc")


#jcode_descriptives2$total_paid <- jcode_descriptives2$num_admins * jcode_descriptives2$mean_pd

# calcualte deciles
jcode_descriptives2 <- mutate(jcode_descriptives2, 
                              total_paid_rank = ntile(jcode_descriptives2$median_pd, 10))


jcode_descriptives2 <- mutate(jcode_descriptives2, 
                              total_admins_rank = ntile(jcode_descriptives2$median_num_admins, 10))





saveRDS(jcode_descriptives2, file="jcode_descriptives2.Rda")