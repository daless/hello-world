




setwd("~/healthfirst")
#library(comorbidity)
library(RODBC)
library(sqldf)
#library(psych)


# library(plyr)
# library(dplyr)
# library(icd)
# 
# library(dummies)
# library(data.table)
# library(ggplot2)
# library(dataMaid)
#library(lubridate)
# library(NbClust)
# library(cluster)
#library(tidyr)
# library(factoextra)
# library(proxy)
# library(tibble)
# library(network)
# # descriptive stats
# library(Hmisc)

# 
# library(arules)
# library(arulesViz)
# library(visNetwork)
# library(igraph)


#library(h2o)
#h2o.init()
########h2o.init(port=54322)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)




#library(dplyr)
#library(data.table)
#library(proxy)

# run this code to get the descriptives Hwalthfirst_jcode_baseline_descriptives
# 
# claims_line_180 <- readRDS(file="claims_line_180.Rda")
# 
# SOM_descriptives2 <- readRDS(file="SOM_descriptives2.Rda")
# jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")
# jcode_time <- readRDS(file="jcode_time.Rda")
# # SOM_descriptives2 has the mappings of cluster to J code
# 
# # descriptives by cluster
# som_dist <- readRDS(file="som_dist.Rda")
# 
# # cluster membership
# 
# som_diste <- readRDS(file="som_diste.Rda")
# 
# 
# targ <- cbind(jcode_descriptives2,som_diste)
# 
# # #rename
# names(targ)[20] <- 'SOM_CLUSTER'
# # analyis order for clusters 6,4,2,7

#HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH

# pull for study period paid between 120 - 680 days

# original dt fences
#AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
#AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120

conn_medicare = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01288;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)

DX_claim_medicare  <- sqlQuery(
  conn_medicare,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID,
  L.CPT
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 180
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicare$LOB <- "MEDICARE"




conn_medicaid = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01289;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)


DX_claim_medicaid  <- sqlQuery(
  conn_medicaid,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID,
  L.CPT
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 180
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicaid$LOB <- "MEDICAID"


conn_comm = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01290;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)




DX_claim_comm  <- sqlQuery(
  conn_comm,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID,
  L.CPT
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 180
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_comm$LOB <- "COMM"





# remove human FACTOR


DX_claim_un <- rbind(DX_claim_medicare, DX_claim_medicaid, DX_claim_comm)

rm(DX_claim_medicare)
rm(DX_claim_medicaid)
rm(DX_claim_comm)
# get id, primary dx and all CPT


DX_claim_un_1  <- sqldf("select distinct CLAIM_ID, ICD9_CODE from DX_claim_un where ORDER_IN_CLAIM = 0")
DX_claim_un_2  <- sqldf("select distinct CLAIM_ID, CPT from DX_claim_un where CPT <= 'NA' ")


rm(DX_claim_un)

#rm(claims_420a)
#rm(claims_line_180)



DX_claim_un_3 <- sqldf("select distinct u.*, n.CPT from DX_claim_un_1 u,DX_claim_un_2 n
                       where u.CLAIM_ID = n.CLAIM_ID
                       order by ICD9_CODE, CPT")



library(arules)
library(arulesViz)
library(visNetwork)
library(igraph)
library(plyr)
library(tibble)
library(reshape2)
library(dplyr)
library(psych)


rm(DX_claim_un_2)
rm(DX_claim_un_1)

DX_claim_un_3$CLAIM_ID <- as.factor(as.character((DX_claim_un_3$CLAIM_ID)))
DX_claim_un_3$CPT <- as.factor(as.character((DX_claim_un_3$CPT)))

# relabel so can combine into a single field
dx_distinct <- sqldf("select distinct CLAIM_ID, ICD9_CODE as CPT from DX_claim_un_3" )
cpt_distinct <- sqldf("select distinct CLAIM_ID, CPT from DX_claim_un_3")


DX_claim_un_4 <- rbind(dx_distinct ,cpt_distinct )

DX_claim_un_4 <- sqldf("select * from DX_claim_un_4 order by CLAIM_ID, CPT")


ap2 <- ddply(DX_claim_un_4, c("CLAIM_ID"),
             function(DX_claim_un_4)paste(DX_claim_un_4$CPT,
                                collapse = ','))

names(ap2)[2] <- "CPT"

ap3 <- ap2
ap3$CLAIM_ID <- NULL

write.csv(ap2, file = "cpt_transactions.csv")

txn <- read.transactions(file="cpt_transactions.csv", rm.duplicates = TRUE,
                         format="single", sep=",", cols=c("CLAIM_ID","CPT"))




# remove quotes
txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)

basket_rules <- apriori(txn,parameter = list(sup = 0.00001, 
                                             conf=0.00001, target="rules"))

# remove redundent rules
#basket_rules <- basket_rules[!is.redundant(basket_rules)]
CCS_Basket <- DATAFRAME(basket_rules, separate = TRUE)



# have to have at least 3 rules
if (NROW(CCS_Basket) >=3 ){
  
  # see if LHS all empty
  # if so add 0 to LHS
  CCS_Basket <-  CCS_Basket[!sapply( CCS_Basket, function(k) all(k =="{}"))]
}
if(NCOL(CCS_Basket) ==6){
  # remove brackets
  CCS_Basket$LHS <- gsub("[{}]","", CCS_Basket$LHS)
  CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
}

if(NCOL(CCS_Basket) ==5){
  CCS_Basket$LHS <- '0'
  CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
  #CCS_Basket <- sqldf("select LHS,RHS,support,confidence,lift,count from CCS_Basket")
}


# SNA
# nodes rule id adges are rules

adj1 <- sqldf("select LHS , RHS , count as weight from CCS_Basket")

# add row ids for nodes
adj1$id <- 1:nrow(adj1)


adj1$weight <- as.integer(adj1$weight)
adj2 <-adj1
adj2$id <- NULL


# 
transferGraph <- graph_from_data_frame(adj2, directed = TRUE)



ig_between <-  as.data.frame(edge.betweenness(transferGraph, weights=E(transferGraph)$weight))
names(ig_between)[1] <- "edge_betweenness"
ig_between <- rownames_to_column(ig_between, var="id")

# other metrics are at the NODE level

# coreness
ig_coreness <-  as.data.frame(coreness(transferGraph, mode="all"))
names(ig_coreness)[1] <- "coreness"
ig_coreness <-  rownames_to_column(ig_coreness, var="id")



# strength --- numbr of edges that go from one node to another
# lower number less connected
ig_strength <-  as.data.frame(strength(transferGraph, weights=E(transferGraph)$weight))
names(ig_strength)[1] <- "strength"
ig_strength <-  rownames_to_column(ig_strength, var="id")

# closeness number of steps to access other nodes - higher values less
# centrality

ig_closeness <- as.data.frame(closeness(transferGraph, normalized = TRUE, weights=E(transferGraph)$weight))
names(ig_closeness)[1] <- "closeness"
ig_closeness <-  rownames_to_column(ig_closeness, var="id")


# authority score -- high authority when is linked
#by other nodes with link other nodes

ig_authority <- as.data.frame(authority_score(transferGraph,scale=TRUE,
                                              weights=E(transferGraph)$weight)$vector)
names(ig_authority)[1] <- "authority_score"
ig_authority <-  rownames_to_column(ig_authority, var="id")
ig_authority <- sqldf("select * from ig_authority where id != ''")



#hist(degree(transferGraph))

cl <- clusters(transferGraph)
# plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
#                                                          weights=E(transferGraph)$weight),
#      vertex.color = cl$membership+1L, edge.arrow.size = 1)
# 


# remove rwonames after redundants deleted
rownames(CCS_Basket) <- c()

dissi <- dissimilarity(basket_rules, method = "Jaccard", which = "associations")

dissi_m <- melt(as.matrix(dissi))
p <- t(apply(dissi_m[,c(1,2)],1,FUN=sort))
rmv1 <- which(p[,1] == p[,2])

p <- paste(p[,1],p[,2], sep = "|")
rmv2 <- which(duplicated(p))

dissi_m <- as.data.frame(dissi_m[-c(rmv1,rmv2),])

# filter to get all with score of 1
# VAR is the index
dissi_m1 <- sqldf("select Var1 as rule_i, count(Var1) as rule_cnt from  dissi_m
                      where value = 1
                      group by Var1")

dissi_m2 <- sqldf("select Var2 as rule_i, count(Var2) as rule_cnt from  dissi_m
                      where value = 1
                      group by Var2")

distance_rule_cnt <- rbind(dissi_m1, dissi_m2)

distance_rule_cnt <- sqldf("select rule_i, sum(rule_cnt) as tot_rules
                               from distance_rule_cnt
                               group by rule_i
                               order by tot_rules desc ")


CCS_Basket<- data.frame(rule_index = row.names(CCS_Basket), CCS_Basket)
#CCS_Basket$tot_rules <- ifelse(is.na(CCS_Basket$tot_rules), 0, CCS_Basket$tot_rules)
CCS_Basket <- sqldf("select c.*, d.* from CCS_Basket c LEFT JOIN  distance_rule_cnt d
                        ON c.rule_index = d.rule_i
                        order by tot_rules desc")


# ADD SNA metrics to market basket data


CCS_Basket <- sqldf("select c.*, d.edge_betweenness from CCS_Basket c,  
                        ig_between d,
                        adj1 a
                        where d.id = a.id
                        AND a.LHS = c.LHS
                        AND a.RHS = c.RHS")

CCS_Basket <- sqldf("select c.*, d.authority_score from  CCS_Basket c  
                         LEFT JOIN ig_authority d
                        ON c.LHS = d.id")


CCS_Basket <- sqldf("select c.*, d.closeness from  CCS_Basket c  
                         LEFT JOIN ig_closeness d
                        ON c.LHS = d.id")


CCS_Basket <- sqldf("select c.*, d.strength from  CCS_Basket c  
                         LEFT JOIN ig_strength d
                        ON c.LHS = d.id")

CCS_Basket <- sqldf("select c.*, d.coreness from  CCS_Basket c  
                         LEFT JOIN ig_coreness d
                        ON c.LHS = d.id")



#library(psych)

CCS_Basket <- mutate(CCS_Basket, 
                     confidence_rank = ntile(CCS_Basket$confidence, 10))


library(OneR)

# rules with less than 100 cnt
CCS_Basket100 <- sqldf("select * from CCS_Basket where count < 100")




CCS_Basket100$bins <- bin(CCS_Basket100$confidence, nbins = 10, method = c("length"))

bincnts <- sqldf("select bins, count(bins) as cnt from CCS_Basket100 group by bins")

confidence_band_2_3 <- sqldf("select * from CCS_Basket where confidence_rank in (2,3) ")

apri_by_bin <- sqldf("select * from CCS_Basket where bins != '(-2.2e-06,0.00124]'")












