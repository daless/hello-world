

# cenete disability


setwd("~/centene")

library(comorbidity)


library(RODBC)


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0624.aimhealth.com;DATABASE=racer00877;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)


# member ids of those with 1+ CA dx

# dbo.MEMBER has state
CA_id <- sqlQuery(
  conn,
  " select
  CLM.PATIENT_ID,
CLM.CLAIM_ID,
  max(CLM.DATE_OF_SERVICE_END) as max_end
  FROM  dbo.ICD9 DX, dbo.CLAIM CLM, dbo.SPECIAL_FIELDS S
  WHERE DX.CLAIM_ID = CLM.CLAIM_ID
AND S.ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 9
 AND CLM.DATE_OF_SERVICE_BEG >= '06-01-2018'
  AND CLM.DATE_OF_SERVICE_END <= '12-31-2018'
  AND DX.ICD9_CODE Like '%C%'
  AND CLM.AMT_PAID  > 0
 AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
AND S.FIELD1 IN( 'FL', 'IL', 'IN','KA', 'LA', 'NH', 'OH', 'TX', 'WA')
  group by CLM.PATIENT_ID,CLM.CLAIM_ID")

library(sqldf)

id <- sqldf("select distinct PATIENT_ID from CA_id")


alldx_A <- sqlQuery(
  conn,"select CLM.CLAIM_NO,
  CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.BILL_TYPE,
  DX.CLAIM_ID,
  DX.ORDER_IN_CLAIM,
  DX.ICD9_CODE,
  CLM.AMT_PAID,
  CLM.DATE_OF_SERVICE_BEG ,
  CLM.DATE_OF_SERVICE_END
  FROM  dbo.ICD9 DX, dbo.CLAIM CLM, dbo.SPECIAL_FIELDS S
  WHERE DX.CLAIM_ID = CLM.CLAIM_ID
AND S.ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 9
  AND CLM.AMT_PAID  > 0
  AND CLM.PROJECT_ID = 877
  and DX.ICD9_TYPE='DIAG10'
 AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
AND S.FIELD1 IN( 'FL', 'IL', 'IN','KA', 'LA', 'NH', 'OH', 'TX', 'WA')
  AND CLM.DATE_OF_SERVICE_BEG >= '06-01-2018'
  AND CLM.DATE_OF_SERVICE_END <= '12-31-2018'")



alldx_A <- sqldf("select a.* from alldx_A a, id i where i.PATIENT_ID = a.PATIENT_ID order by CLAIM_ID, ORDER_IN_CLAIM")

#remove decimal points in the Dx codes
alldx_A$ICD9_CODE<-as.character(alldx_A$ICD9_CODE)
alldx_A$ICD9_CODE<-gsub(".","",alldx_A$ICD9_CODE,fixed=TRUE)


elixhauser_scores <- comorbidity(x=alldx_A , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", 
                                 score = "elixhauser")

charlson <- comorbidity(x=alldx_A , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", 
                                 score = "charlson")


write.table(elixhauser_scores, file = "elixhauser_scores.csv",
            row.names = FALSE, sep ="\t")

write.table(charlson, file = "comorbidity_scores.csv",
            row.names = FALSE, sep ="\t")






CCS_lookup <- read.csv("ccs_dx_icd10cm_2018_1.csv", sep = ",",  quote = "\"", header = TRUE)


CCS_lookup$ICD9_CODE <- CCS_lookup$X.ICD.10.CM.CODE.
CCS_lookup$CCS_DX <- CCS_lookup$X.CCS.CATEGORY.
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))



alldx_B <- sqldf("select a.*, c.CCS_DX from alldx_A a,CCS_lookup c where a.ICD9_CODE = c.ICD9_CODE
                 order by CLAIM_ID, ORDER_IN_CLAIM")

write.table(alldx_B, file = "alldx_B.csv",
            row.names = FALSE, sep ="\t")

# procedures


# cpt codes

proc_A <- sqlQuery(
  conn,"select CLM.CLAIM_NO,
  CLM.CLAIM_ID,
  CLM.PATIENT_ID,
  L.CPT,
  L.CPT_MODIFIER,
  CLM.AMT_PAID,
  CLM.DATE_OF_SERVICE_BEG ,
  CLM.DATE_OF_SERVICE_END
  FROM  dbo.CLAIM_LINE L, dbo.CLAIM CLM, dbo.SPECIAL_FIELDS S
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
AND S.ID = CLM.CLAIM_ID
  AND CLM.AMT_PAID  > 0
  AND CLM.PROJECT_ID = 877
AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
AND S.FIELD1 IN( 'FL', 'IL', 'IN','KA', 'LA', 'NH', 'OH', 'TX', 'WA')
  AND CLM.DATE_OF_SERVICE_BEG >= '06-01-2018'
  AND CLM.DATE_OF_SERVICE_END <= '12-31-2018'")


proc_A <- sqldf("select a.* from proc_A a, id i where i.PATIENT_ID = a.PATIENT_ID order by CLAIM_ID")




HCPC_meta  <- read.csv("HCPC.csv", header=TRUE, sep="\t")

# HCPC BETOS
proc_B <- sqldf("select distinct p.*, h.BETOS from proc_A p LEFT JOIN HCPC_meta h ON p.CPT = h.HCPC 
                order by p.CLAIM_ID")



proc_B$BETOS <- ifelse(is.na(proc_B$BETOS),"none",proc_B$BETOS)

proc_betos1 <- sqldf("select distinct CLAIM_ID, BETOS from proc_B 
where BETOS != 'none'")


write.table(proc_B, file = "proc_B.csv",
            row.names = FALSE, sep ="\t")


write.table(proc_betos1, file = "proc_betos1.csv",
            row.names = FALSE, sep ="\t")


# add betos to CCS

alldx_C <- sqldf("select distinct a.*, b.BETOS from alldx_B a left join proc_B b
                 on a.CLAIM_ID = b.CLAIM_ID
                 and b.BETOS !='none'")

alldx_C$BETOS <- ifelse(is.na(alldx_C$BETOS),"none",alldx_C$BETOS)
alldx_C$BILL_TYPE <- ifelse(is.na(alldx_C$BILL_TYPE),"none",alldx_C$BILL_TYPE)

# last ddate of service in study
maxdate <- max (alldx_B$DATE_OF_SERVICE_END)

alldx_C <- alldx_C %>%
  mutate(diff = maxdate - DATE_OF_SERVICE_END,
       days_from_study_end = as.numeric(diff, units = 'days'))

charlson$CLAIM_ID <- as.character(charlson$CLAIM_ID)
alldx_C$CLAIM_ID <- as.character(alldx_C$CLAIM_ID)

charl <- sqldf("select CLAIM_ID, wscore as Charlson_Score from charlson ")

# need method = "name__class" becuase used date diff to calcualte date differecnes sqldf errors ut unles have this

alldx_C <- sqldf("select a.*, c.Charlson_Score from alldx_C a, charl c
              where a.CLAIM_ID = c.CLAIM_ID", method = "name__class")

alldx_D <- alldx_C
alldx_D$diff <- NULL

alldx_D$DATE_OF_SERVICE_END <- NULL
alldx_D$DATE_OF_SERVICE_BEG <- NULL
alldx_D$AMT_PAID <- NULL
alldx_D$ICD9_CODE <- NULL
alldx_D$ORDER_IN_CLAIM <- NULL
alldx_D$CLAIM_ID  <- NULL
alldx_D$PATIENT_ID  <- NULL
alldx_D$CLAIM_NO  <- NULL

# put days_from_study_end into rfm
alldx_D$days_from_study_end  <- NULL

alldx_D$BILL_TYPE <- as.factor(alldx_D$BILL_TYPE)
alldx_D$CCS_DX <- as.factor(alldx_D$CCS_DX)
alldx_D$BETOS <- as.factor(alldx_D$BETOS)

elix <- sqldf("select elixhauser_score from alldx_C_elix")


alldx_D2 <- cbind(alldx_D,elix)





library(plyr)
library(dplyr)
library(dummies)
library(data.table)
library(ggplot2)
library(dataMaid)
library(lubridate)
library(NbClust)
library(klaR)
library(kamila)
library(cluster)
library(tidyr)
library(factoextra)
library(proxy)
library(tibble)
library(network)
# descriptive stats
library(Hmisc)
library(psych)
library(rfm)
library(arules)
library(arulesViz)
library(visNetwork)
library(igraph)
library(C50)
library(h2o)
h2o.init()



learnname <- colnames(alldx_D2) 

an1_h2o <- as.h2o(alldx_D2)

an1_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = an1_h2o, autoencoder = TRUE, 
                               hidden = c(6,2,6), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                               categorical_encoding = "AUTO")


an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)


outlier <- cbind(alldx_C, an1_h2o_dl2)


# most recent score by member




#h2o.shutdown(prompt  = FALSE)

# rollup CCS for clustering





alldx_D_h2o <- as.h2o(alldx_D)

nfolds <- 10
kmeans_h2o <- h2o.kmeans(training_frame =alldx_D_h2o,
                         k = 20,
                         estimate_k = TRUE,
                         categorical_encoding = "AUTO",
                         seed = 77,
                         init = "Random",
                         nfolds= nfolds,
                         keep_cross_validation_fold_assignment = TRUE,
                         fold_assignment = "AUTO")

kmeans_h2o2 <- h2o.predict(kmeans_h2o, newdata = alldx_D_h2o)

# add cluster membership called predict in df

alldx_D_h2o <- h2o.cbind(alldx_D_h2o ,kmeans_h2o2 )

alldx_E <- as.data.frame(alldx_D_h2o)
alldx_E$predict <- alldx_E$predict + 1

N_clusters <- max(alldx_E$predict)



ggplot(C5a, aes(x=factor(Cluster), y= PATIENT_AGE, fill =factor(Cluster) ))+
  geom_boxplot(alpha=0.4) +
  stat_summary(fun.y=mean, geom="point", shape=20, size=5, color = "red", fill="red")+
  theme(legend.position = "none")+
  scale_fill_brewer(palette = "Set3")+
  labs(title = "Member Age by Cluster", x = "Cluster", y = "Age")




ggplot(C5a, aes(x=factor(Cluster), y= Charlson_Score, fill =factor(Cluster) ))+
  geom_boxplot(alpha=0.4) +
  stat_summary(fun.y=mean, geom="point", shape=20, size=5, color = "red", fill="red")+
  theme(legend.position = "none")+
  scale_fill_brewer(palette = "Set3")+
  labs(title = "Acuity by Cluster", x = "Cluster", y = "Charlosn Comorbidity Index")


cluster<- sqldf( "select predict as cluster from alldx_E")


outlier <- cbind(outlier, cluster)

names(outlier)[16] <- "Anomaly_score"

last_claim <- sqldf("select PATIENT_ID, CLAIM_NO, max(DATE_OF_SERVICE_END) as max_dates from 
                 outlier
                 group by PATIENT_ID")

max_acuity_by_claim <- sqldf("select PATIENT_ID, CLAIM_NO, cluster, DATE_OF_SERVICE_END, max(Anomaly_score) as max_score from  outlier
                          group by CLAIM_NO")

outlier2 <- sqldf ("select distinct o.* from max_acuity_by_claim o, last_claim l
                where l.PATIENT_ID = o.PATIENT_ID
                   and l.CLAIM_NO = o.CLAIM_NO
                   and l.max_dates = o.DATE_OF_SERVICE_END
                   order by o.PATIENT_ID desc, o.cluster desc, max_score desc ")



outlier2$max_score <- 1/outlier2$max_score

outlier2 <- arrange(outlier2 , desc(cluster), desc(max_score))



# bring back detail

outlier_detail <- sqldf("select distinct  o.*, m.max_score as Score from outlier o, outlier2 m
                        where m.PATIENT_ID = o.PATIENT_ID
                        and m.CLAIM_NO = o.CLAIM_NO
                        and m.DATE_OF_SERVICE_END = o.DATE_OF_SERVICE_END")

outlier_detail$DATE_OF_SERVICE_BEG <- NULL

outlier_detail$DATE_OF_SERVICE_END <- NULL

outlier2$DATE_OF_SERVICE_END <- NULL

outlier_detail$Reconstruction.MSE <- NULL
outlier_detail$diff <- NULL
outlier_detail$days_from_study_end <- NULL

# output files to ship



write.table(outlier_detail, file = "outlier_detail_5_13.csv",
            row.names = FALSE, sep ="\t")

write.table(outlier2, file = "outlier_5_13.csv",
            row.names = FALSE, sep ="\t")




alldx_D$PATIENT_ID  <- NULL
alldx_D$CLAIM_NO  <- NULL





# C5 for each cluster

file.remove("C5_by_cluster_outpt_full.txt")


C5a <- alldx_E
names(C5a)[6] <- "Cluster"



for (i in 1:N_clusters){
  
  C5a$target <- ifelse(C5a$Cluster == i,1,0)
  C5a$target <- as.factor(as.character(C5a$target))
  C5b <- C5a
  C5b$Cluster <- NULL
  
  
  y <- c("target")
  x <- colnames(C5b)
  
  # V 9f added bands that groups rules by importance
  ruleC5 <- C5.0(target ~., data = C5b, rules = TRUE, winnow = TRUE, bands = 5)
  
  write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)
  
}









#RFM

rfm1 <- sqldf( "select PATIENT_ID , max(DATE_OF_SERVICE_END) as last_date
               from alldx_C
               group by PATIENT_ID")


rfo <-  sqldf( "select PATIENT_ID , CLAIM_ID
               from alldx_C
               group by PATIENT_ID,  CLAIM_ID")

rfo <-  sqldf( "select PATIENT_ID , count(PATIENT_ID) as number_of_orders
               from rfo
               group by PATIENT_ID")

rfm1 <- sqldf( "select r.*, f.number_of_orders
               from rfm1 r, rfo f
               where r.PATIENT_ID = f.PATIENT_ID")



rfm1$last_date <- as_date(rfm1$last_date)
rfm1$last_date <- as.Date.POSIXct(rfm1$last_date)


alldx_C_elix <- sqldf("select a.*, e.wscore_vw as elixhauser_score
                      from alldx_C a, elixhauser_scores e
                      where a.CLAIM_ID = e.CLAIM_ID")

alldx_C_elix$DATE_OF_SERVICE_END <- as_date(alldx_C_elix$DATE_OF_SERVICE_END)
alldx_C_elix$DATE_OF_SERVICE_END <- as.Date.POSIXct(alldx_C_elix$DATE_OF_SERVICE_END)

last_visit_elix <- sqldf("select
 a.PATIENT_ID, a.DATE_OF_SERVICE_END, a.elixhauser_score 
from alldx_C_elix a, rfm1 r
                         where a.PATIENT_ID = r.PATIENT_ID
                         and a.DATE_OF_SERVICE_END = r.last_date

group by a.PATIENT_ID, a.DATE_OF_SERVICE_END
order by a.PATIENT_ID, a.DATE_OF_SERVICE_END
  ")


rfm2 <- sqldf ( "select r.*, l.elixhauser_score from rfm1 r,last_visit_elix l
                where r.PATIENT_ID = l.PATIENT_ID
                and r.last_date = l.DATE_OF_SERVICE_END")


rfm2$last_date <- as_date(rfm2$last_date)
maxdate <- as_date(maxdate)

rfm2$recency_days <- 1 / (as.numeric(as.character(maxdate -rfm2$last_date + 1)))



rfm2$rankR <- cut(rfm2$recency_days, 5,labels = F)
rfm2$rankF <- cut(rfm2$number_of_orders, 5,labels = F)
rfm2$rankM <- cut(rfm2$elixhauser_score, 5,labels = F)

# give acuity first priority then recenency then frequencey

rfm2$RFM <- ( rfm2$rankM * 100 )+ (rfm2$rankR * 10) +  rfm2$rankF

outlier3 <- sqldf("select o.* , r.RFM from outlier2 o, rfm2 r
              where o.PATIENT_ID = r.PATIENT_ID")

outlier3 <- arrange(outlier3 , desc(cluster, max_score))




# 
# 
# 
# 
# 
# rangeStandardize <- function(x) {
#   (x - min(x)) / diff(range(x))
# }
# 
# 
# L1Dist <- function(v1, v2) {
#   sum(abs(v1 - v2))
# }
# matchingDist <- function(v1, v2) {
#   sum(as.integer(v1) != as.integer(v2))
# }
# 
# 
# # pam function wrapper
# 
# pamix <- function(connData, catData, conWeight, nclust, ...) {
#   conData <- as.data.frame(conVars)
#   catData <- as.data.frame(catVarsFac)
#   distmat <- daisy(x= cbind(conData, catData), metric = "gower",
#                    weights = rep(c(conWeight, 1 - conWeight),
#                                  times = c(ncol(conData), ncol(catData))))
#   clustRes <- pam(x = distMat, k = nclust, diss = TRUE, ...)
#   return(list(cluster = clustRes$clustering,
#               conCenters = conData[clustRes$id.med, , drop = FALSE],
#               catCenters = catData[clustRes$id.med, , drop = FALSE]))
# }
# 
# # continuous variables
# 
# conInd <- c(names(Filter(is.numeric,alldx_D)))
# # factors
# catVarsFac <- c(names(Filter(is.factor,alldx_D)))
# 
# 
# set.seed(77)
# conVars <- alldx_D[,conInd]
# conVars <- data.frame(scale(conVars))
# #conVars <- as.data.frame(lapply(conVars, rangeStandardize))
# 
# catVarsFac[] <- lapply(catVarsFac, factor)
# catVarsDum <- dummyCodeFactorDf(catVarsFac)
# 
# colnames(alldx_D)[colSums(is.na(alldx_D)) > 0]
# 
# 
# gmsResHw <- gmsClust(conVars,catVarsDum, nclust = 4 )
# gmsResLloyd <- gmsClust(conVars,catVarsDum, nclust = 4 ,
#                         algorithm = "Lloyd", searchDensity = 10)
# 
# 
# 
# 
# kamRes2 <- kamila(conVars, catVarsFac, numClust = 2 : 6, numInit = 10,
#                   calcNumClust = "ps", numPredStrCvRun = 10, predStrThresh = 0.5,  maxIter = 50)
# 
# 
# kam_membership<- as.data.frame(kamRes2$finalMemb)
# number_clusters <- as.data.frame(kamRes2$nClust$bestNClust)
# N_clusters = kamRes2$nClust$bestNClust
# cluster_strength <- as.data.frame(kamRes2$nClust$avgPredStr)
# 
# plotDatKam <- cbind(id,conVars, catVarsFac, Cluster = factor(kamRes2$finalMemb) )
# 
# 
# # remove standardized continuous data and reload orignial data
# # this makes rules easier to implament
# 
# plotDatKam <- plotDatKam[,!colnames(plotDatKam) %in% conInd]
# conVars <- par4[,conInd]
# plotDatKam <- cbind(plotDatKam ,conVars )
# 
# 
# write.table(kam_membership, file = "kam_membership.csv",
#             row.names = FALSE, sep ="\t")
# write.table(number_clusters, file = "number_clusters.csv",
#             row.names = FALSE, sep ="\t")
# write.table(cluster_strength, file = "cluster_strength.csv",
#             row.names = FALSE, sep ="\t")
# write.table(plotDatKam, file = "plotDatKam.csv",
#             row.names = FALSE, sep ="\t")
# 
# 
# 
# 
# 
# 
# 
# 


















# create ccs transactions

ap1 <- sqldf( "select distinct i.CLAIM_ID, i.CCS_DX from alldx_B as i ")

p1 <- sqldf("select distinct i.CLAIM_ID, i.BETOS as CCS_DX from proc_betos1 as i")

ap1 <- rbind(ap1,p1)

ap1 <- sqldf("select * from ap1 order by CLAIM_ID")

ap1$CLAIM_ID <- as.factor(as.character((ap1$CLAIM_ID)))
ap1$CCS_DX <- as.factor(as.character((ap1$CCS_DX)))

ap2 <- ddply(ap1, c("CLAIM_ID"),
             function(ap1)paste(ap1$CCS_DX,
                                collapse = ','))

names(ap2)[2] <- "CCS"

ap3 <- ap2
ap3$CLAIM_ID <- NULL

write.csv(ap2, file = "ccs_transactions.csv")

txn <- read.transactions(file="ccs_transactions.csv", rm.duplicates = TRUE,
                         format="single", sep=",", cols=c("CLAIM_ID","CCS"))




# remove quotes
txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)



basket_rules <- apriori(txn,parameter = list(sup = 0.01, 
                                             conf=0.8, target="rules"))

basket_rules <- basket_rules[!is.redundant(basket_rules)]
CCS_Basket <- DATAFRAME(basket_rules, separate = TRUE)


basket_rules <- apriori(txn,parameter = list(sup = 0.001, 
                                             conf=0.001, target="rules"))

basket_rules <- basket_rules[!is.redundant(basket_rules)]
CCS_Basket <- DATAFRAME(basket_rules, separate = TRUE)





# 
# 
# proc_betos2 <- cbind(proc_betos1, dummy(proc_betos1$BETOS , sep= "_"))
# # replace with BETOS
# colnames(proc_betos2) <- (gsub("proc_betos1", "BETOS",  colnames(proc_betos2)))
# 
# proc_betos2 <- proc_betos2 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
# 
# #temporaty id to character
# proc_betos2$CLAIM_ID <- as.character(proc_betos2$CLAIM_ID)
# 
# # recode if > 0 then 1 else 0 instead of summing dummies
# proc_betos2 <- proc_betos2 %>% mutate_if(is.numeric,
#                                          function(x) case_when(
#                                            x >= 1 ~ 1,
#                                            x == 0 ~ 0
#                                          )
# )
# 
# 
# proc_betos2$BETOS <- NULL
# proc_betos2$BETOS_ <- NULL
# proc_betos2$CLAIM_IDx <- proc_betos2$CLAIM_ID
# proc_betos2$CLAIM_ID <- NULL
# proc_betos2$CLAIM_IDx <- as.character(proc_betos2$CLAIM_IDx)
# 
# proc_betos2 <- proc_betos2 %>% mutate_if(is.numeric, funs(factor(.)))
# 
# proc_betos2$CLAIM_IDx <- as.numeric(proc_betos2$CLAIM_IDx)
# 
# proc_betos2 <- sqldf("select distinct * from proc_betos2 order by CLAIM_IDx ")
# 
# 
# 
# 
# 
# 
# 
# 
# #alldx_A$CLAIM_ID <- as.character(alldx_A$CLAIM_ID)
# write.table(alldx_A, file = "dx_roll_all.csv",
#             row.names = FALSE, sep ="\t")
# 








# 
# 
# alldx_B <- sqlQuery(
#   conn,"select CLM.CLAIM_NO,
#   CLM.PATIENT_ID,
#   DX.CLAIM_ID,
#   DX.ORDER_IN_CLAIM,
#   DX.ICD9_CODE,
#   CLM.AMT_PAID,
#   CLM.DATE_OF_SERVICE_BEG ,
#   CLM.DATE_OF_SERVICE_END
#   FROM  dbo.ICD9 DX, dbo.CLAIM CLM
#   WHERE DX.CLAIM_ID = CLM.CLAIM_ID
#   AND  DX.ORDER_IN_CLAIM <= 9
#   AND CLM.AMT_PAID  > 0
#   AND CLM.DATE_OF_SERVICE_BEG >= '09-01-2018'
#   AND CLM.DATE_OF_SERVICE_END <= '12-31-2018'")
# 
# 
# alldx_B <- sqldf("select a.* from alldx_B a, id i where i.PATIENT_ID = a.PATIENT_ID ")
# 
# 
# alldx_B <- sqldf("select a.*, c.CCS_DX from alldx_B a,CCS_lookup c where a.ICD9_CODE = c.ICD9_CODE order by CLAIM_ID, ORDER_IN_CLAIM")
# 
# elixhauser_scores_B <- comorbidity(x=alldx_B , id = "CLAIM_ID",  code = "ICD9_CODE", 
#                                    score = "elixhauser")
# 
# alldx_C <- sqlQuery(
#   conn,"select CLM.CLAIM_NO,
#   CLM.PATIENT_ID,
#   DX.CLAIM_ID,
#   DX.ORDER_IN_CLAIM,
#   DX.ICD9_CODE,
#   CLM.AMT_PAID,
#   CLM.DATE_OF_SERVICE_BEG ,
#   CLM.DATE_OF_SERVICE_END
#   FROM  dbo.ICD9 DX, dbo.CLAIM CLM
#   WHERE DX.CLAIM_ID = CLM.CLAIM_ID
#   AND  DX.ORDER_IN_CLAIM <= 9
#   AND CLM.AMT_PAID  > 0
#   AND CLM.DATE_OF_SERVICE_BEG >= '05-01-2018'
#   AND CLM.DATE_OF_SERVICE_END <= '08-31-2018'")
# 
# 
# alldx_C <- sqldf("select a.* from alldx_C a, id i where i.PATIENT_ID = a.PATIENT_ID")
# 
# 
# alldx_C <- sqldf("select a.*, c.CCS_DX from alldx_C a,CCS_lookup c where a.ICD9_CODE = c.ICD9_CODE")
# 
# 
# 
# alldx_D <- sqlQuery(
#   conn,"select CLM.CLAIM_NO,
#   CLM.PATIENT_ID,
#   DX.CLAIM_ID,
#   DX.ORDER_IN_CLAIM,
#   DX.ICD9_CODE,
#   CLM.AMT_PAID,
#   CLM.DATE_OF_SERVICE_BEG ,
#   CLM.DATE_OF_SERVICE_END
#   FROM  dbo.ICD9 DX, dbo.CLAIM CLM
#   WHERE DX.CLAIM_ID = CLM.CLAIM_ID
#   AND  DX.ORDER_IN_CLAIM <= 9
#   AND CLM.AMT_PAID  > 0
#   AND CLM.DATE_OF_SERVICE_BEG >= '02-01-2018'
#   AND CLM.DATE_OF_SERVICE_END <= '05-31-2018'")
# 
# 
# alldx_D <- sqldf("select a.* from alldx_D a, id i where i.PATIENT_ID = a.PATIENT_ID")
# 
# 
# alldx_D <- sqldf("select a.*, c.CCS_DX from alldx_D a,CCS_lookup c where a.ICD9_CODE = c.ICD9_CODE")
# 
# alldx_E <- sqlQuery(
#   conn,"select CLM.CLAIM_NO,
#   CLM.PATIENT_ID,
#   DX.CLAIM_ID,
#   DX.ORDER_IN_CLAIM,
#   DX.ICD9_CODE,
#   CLM.AMT_PAID,
#   CLM.DATE_OF_SERVICE_BEG ,
#   CLM.DATE_OF_SERVICE_END
#   FROM  dbo.ICD9 DX, dbo.CLAIM CLM
#   WHERE DX.CLAIM_ID = CLM.CLAIM_ID
#   AND  DX.ORDER_IN_CLAIM <= 9
#   AND CLM.AMT_PAID  > 0
#   AND CLM.DATE_OF_SERVICE_BEG >= '9-01-2017'
#   AND CLM.DATE_OF_SERVICE_END <= '01-31-2018'")
# 
# 
# alldx_E <- sqldf("select a.* from alldx_E a, id i where i.PATIENT_ID = a.PATIENT_ID")
# 
# alldx_E <- sqldf("select a.*, c.CCS_DX from alldx_E a,CCS_lookup c where a.ICD9_CODE = c.ICD9_CODE")
# 
# 
# 
# dx_roll <- rbind(alldx_A,alldx_B)
# dx_roll <- rbind(dx_roll,alldx_C)
# dx_roll <- rbind(dx_roll,alldx_D)
# dx_roll <- rbind(dx_roll,alldx_E)
# 
# dx_roll$ID <- 1:nrow(dx_roll)
# 
# write.table(dx_roll, file = "dx_roll_all.csv",
#             row.names = FALSE, sep ="\t")
# 
# 
# 
# 
# #remove decimal points in the Dx codes
# dx_roll$ICD9_CODE<-as.character(dx_roll$ICD9_CODE)
# dx_roll$ICD9_CODE<-gsub(".","",dx_roll$ICD9_CODE,fixed=TRUE)
# 
# comorbid <- sqldf("select distinct ID,CLAIM_ID,ICD9_CODE,ORDER_IN_CLAIM from dx_roll order by CLAIM_ID,ORDER_IN_CLAIM ")
# 
# 
# 
# elixhauser_scores <- comorbidity(x=comorbid , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", 
#                                  score = "elixhauser",parallel = TRUE,  mc.cores = parallel::detectCores())
# 
# charlson_scores <- comorbidity(x=comorbid , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", 
#                                  score = "charlson",parallel = TRUE,  mc.cores = parallel::detectCores())
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# memberid <- CA_id[1,1 ]
# sdate <- CA_id[1,3]
# edate <- CA_id[1,2]
# 
# sdate<-format(sdate,"%m-%d-%Y")
# edate <-format(edate,"%m-%d-%Y")
# memberid <- as.character(memberid)
# 
# cstring <- paste0("select
#                   CLM.CLAIM_NO,
#                   CLM.PATIENT_ID,
#                   DX.CLAIM_ID,
#                   DX.ICD9_CODE,
#                   CLM.AMT_PAID,
#                   CLM.DATE_OF_SERVICE_BEG ,
#                   CLM.DATE_OF_SERVICE_END
#                   FROM  dbo.ICD9 DX, dbo.CLAIM CLM
#                   WHERE DX.CLAIM_ID = CLM.CLAIM_ID
#                   AND  DX.ORDER_IN_CLAIM <= 9
#                   AND CLM.AMT_PAID  > 0
#                   AND CLM.PATIENT_ID = '",memberid,"'
#                   AND CLM.DATE_OF_SERVICE_BEG >= '",sdate,"'
#                   AND  CLM.DATE_OF_SERVICE_END <= '",edate,"'")
# 
# 
# junk <- DBI::dbSendQuery(connn, cstring)
# 
# DX_claim  <- sqlQuery(
#   conn,
#   " select
#  CLM.CLAIM_NO,
#   CLM.PATIENT_ID,
#   DX.CLAIM_ID,
#   DX.ICD9_CODE,
#   CLM.AMT_PAID,
#  CLM.DATE_OF_SERVICE_BEG ,
#   CLM.DATE_OF_SERVICE_END
#   FROM  dbo.ICD9 DX, dbo.CLAIM CLM
#   WHERE DX.CLAIM_ID = CLM.CLAIM_ID
#   AND  DX.ORDER_IN_CLAIM <= 9
# AND AND CLM.AMT_PAID  > 0
#   AND CLM.DATE_PAID >= '09-01-2015'
#   AND CLM.DATE_PAID <= '10-30-2018'")
# 
# 
