




setwd("~/healthfirst")
library(comorbidity)
library(RODBC)
library(sqldf)
library(psych)


# library(plyr)
# library(dplyr)
# library(icd)
# 
# library(dummies)
# library(data.table)
# library(ggplot2)
# library(dataMaid)
library(lubridate)
# library(NbClust)
# library(cluster)
library(tidyr)
# library(factoextra)
# library(proxy)
# library(tibble)
# library(network)
# # descriptive stats
# library(Hmisc)

# 
# library(arules)
# library(arulesViz)
# library(visNetwork)
# library(igraph)


#library(h2o)
#h2o.init()
########h2o.init(port=54322)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)




library(dplyr)
library(data.table)
library(proxy)

# run this code to get the descriptives Hwalthfirst_jcode_baseline_descriptives
# 
# claims_line_180 <- readRDS(file="claims_line_180.Rda")
# 
# SOM_descriptives2 <- readRDS(file="SOM_descriptives2.Rda")
# jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")
# jcode_time <- readRDS(file="jcode_time.Rda")
# # SOM_descriptives2 has the mappings of cluster to J code
# 
# # descriptives by cluster
# som_dist <- readRDS(file="som_dist.Rda")
# 
# # cluster membership
# 
# som_diste <- readRDS(file="som_diste.Rda")
# 
# 
# targ <- cbind(jcode_descriptives2,som_diste)
# 
# # #rename
# names(targ)[20] <- 'SOM_CLUSTER'
# # analyis order for clusters 6,4,2,7

#HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH

# pull for study period paid between 120 - 680 days



conn_medicare = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01288;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)

claims_line_medicare <- sqlQuery(
  conn_medicare,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PATIENT_ID,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID,
  MEM.member_ID,MEM.MEMBER_NO
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock), dbo.MEMBER MEM  with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.PATIENT_ID = MEM.MEMBER_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND L.CPT in('C1767','C1783','C1784','C1787','C1789','C1820','C2622','C9600','C9601','L8614',
  'L8690','L8691','V2630','V2785')
  ")

claims_line_medicare$LOB <- "MEDICARE"



DX_claim_medicare  <- sqlQuery(
  conn_medicare,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
  AND L.CPT in('C1767','C1783','C1784','C1787','C1789','C1820','C2622','C9600','C9601','L8614',
  'L8690','L8691','V2630','V2785')
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicare$LOB <- "MEDICARE"




conn_medicaid = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01289;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_medicaid <- sqlQuery(
  conn_medicaid,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  CLM.PATIENT_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID,
   MEM.member_ID,MEM.MEMBER_NO
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock), dbo.MEMBER MEM  with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.PATIENT_ID = MEM.MEMBER_ID
  AND L.AMT_PAID  > 1
 AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND L.CPT in('C1767','C1783','C1784','C1787','C1789','C1820','C2622','C9600','C9601','L8614',
  'L8690','L8691','V2630','V2785')
  ")

claims_line_medicaid$LOB <- "MEDICAID"




DX_claim_medicaid  <- sqlQuery(
  conn_medicaid,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
  AND L.CPT in('C1767','C1783','C1784','C1787','C1789','C1820','C2622','C9600','C9601','L8614',
  'L8690','L8691','V2630','V2785')
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicaid$LOB <- "MEDICAID"


conn_comm = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01290;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_comm <- sqlQuery(
  conn_comm,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  CLM.PATIENT_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID,
   MEM.member_ID,MEM.MEMBER_NO
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock), dbo.MEMBER MEM  with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.PATIENT_ID = MEM.MEMBER_ID
  AND L.AMT_PAID  > 1
 AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND L.CPT in('C1767','C1783','C1784','C1787','C1789','C1820','C2622','C9600','C9601','L8614',
  'L8690','L8691','V2630','V2785')
  ")


DX_claim_comm  <- sqlQuery(
  conn_comm,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
   AND L.CPT in('C1767','C1783','C1784','C1787','C1789','C1820','C2622','C9600','C9601','L8614',
  'L8690','L8691','V2630','V2785')
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

claims_line_comm$LOB <- "COMM"


# remove human FACTOR


all_claims <- rbind(claims_line_medicare, claims_line_medicaid, claims_line_comm)


DX_claim_dupes <- rbind(DX_claim_medicare, DX_claim_medicaid, DX_claim_comm)


diag1 <- sqldf("select CLAIM_ID, ICD9_CODE as DIAGNOSIS_1 from DX_claim_dupes where ORDER_IN_CLAIM = 0")
diag2 <- sqldf("select CLAIM_ID, ICD9_CODE as DIAGNOSIS_2 from DX_claim_dupes where ORDER_IN_CLAIM = 1")
diag3 <- sqldf("select CLAIM_ID, ICD9_CODE as DIAGNOSIS_3 from DX_claim_dupes where ORDER_IN_CLAIM = 2")
diag4 <- sqldf("select CLAIM_ID, ICD9_CODE as DIAGNOSIS_4 from DX_claim_dupes where ORDER_IN_CLAIM = 3")
diag5 <- sqldf("select CLAIM_ID, ICD9_CODE as DIAGNOSIS_5 from DX_claim_dupes where ORDER_IN_CLAIM = 4")

all_claims <- sqldf("select d.*, i.DIAGNOSIS_1 from all_claims d left join diag1 i
                        on d.CLAIM_ID = i.CLAIM_ID")

all_claims <- sqldf("select d.*, i.DIAGNOSIS_2 from all_claims d left join diag2 i
                        on d.CLAIM_ID = i.CLAIM_ID")

all_claims <- sqldf("select d.*, i.DIAGNOSIS_3 from all_claims d left join diag3 i
                        on d.CLAIM_ID = i.CLAIM_ID")


all_claims <- sqldf("select d.*, i.DIAGNOSIS_4 from all_claims d left join diag4 i
                        on d.CLAIM_ID = i.CLAIM_ID")


all_claims <- sqldf("select d.*, i.DIAGNOSIS_5 from all_claims d left join diag5 i
                        on d.CLAIM_ID = i.CLAIM_ID")


all_claims$DIAGNOSIS_1 <- ifelse(is.na(all_claims$DIAGNOSIS_1), 'none', 
                                 all_claims$DIAGNOSIS_1)

all_claims$DIAGNOSIS_2 <- ifelse(is.na(all_claims$DIAGNOSIS_2), 'none', 
                                 all_claims$DIAGNOSIS_2)

all_claims$DIAGNOSIS_3 <- ifelse(is.na(all_claims$DIAGNOSIS_3), 'none', 
                                 all_claims$DIAGNOSIS_3)

all_claims$DIAGNOSIS_4 <- ifelse(is.na(all_claims$DIAGNOSIS_4), 'none', 
                                 all_claims$DIAGNOSIS_4)


all_claims$DIAGNOSIS_5 <- ifelse(is.na(all_claims$DIAGNOSIS_5), 'none', 
                                     all_claims$DIAGNOSIS_5)

all_claims <-  all_claims %>% replace(is.na(.), 0)

all_claims <- data.frame(ROWID = row.names(all_claims), all_claims)

all_claims$MEMBER_NO <- as.character(all_claims$MEMBER_NO)



#GOWER RUN STARTS HERE



# make empty dataframe to append to
claim_example <- sqldf("select * from all_claims where LOB = 'X'")



# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns


score_record$MEMBER_NO <- as.character(score_record$MEMBER_NO)
score_record$METHOD <- as.character(score_record$METHOD)
score_record$COUNT_BY_MEMBER <- as.character(score_record$COUNT_BY_MEMBER)
score_record$ROWID_1 <- as.factor(score_record$ROWID_1)
  score_record$ROWID_2 <- as.factor(score_record$ROWID_2)
  score_record$CLAIM_NO_1 <- as.numeric(score_record$CLAIM_NO_1)
  score_record$CLAIM_NO_2 <- as.numeric(score_record$CLAIM_NO_2)
  score_record$PAID_1 <- as.numeric(score_record$PAID_1 )
  score_record$PAID_2 <- as.numeric(score_record$PAID_2 )
  score_record$START_DATE_1 <- as.Date.POSIXct( score_record$START_DATE_1)
  score_record$START_DATE_2 <- as.Date.POSIXct( score_record$START_DATE_2)
  score_record$END_DATE_1 <- as.Date.POSIXct( score_record$END_DATE_1)
    score_record$END_DATE_2 <- as.Date.POSIXct( score_record$END_DATE_2)
    score_record$SCORE <- as.numeric(score_record$SCORE)
   
  
  

member_multi <- sqldf("select distinct MEMBER_NO from all_claims")


options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)

  mem_string <- paste0("SELECT ROWID, CLAIM_NO,LOB,UNITS_BILLED ,UNITS_ALLOWED  ,
                       AMT_PAID ,DATE_OF_SERVICE_BEG ,DATE_OF_SERVICE_END ,
                       DATE_OF_SERVICE_BEG_CLAIM,DATE_OF_SERVICE_END_CLAIM
                       DATE_PAID ,CPT ,
                       DIAGNOSIS_1 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5, 
                      MEMBER_NO ,BILL_TYPE ,
                       PLACE_OF_SERVICE ,CPT_MODIFIER
                       PROVIDER_ID  
                       FROM all_claims 
                       WHERE MEMBER_NO  ='",memberid,"'")
  cl_dup1 <- sqldf( mem_string)
  # remove duplicate row ids
  cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
  f <- sapply(cl_dup1, is.factor)
  cl_dup1[f] <- lapply(cl_dup1[f], as.character)
  cl_dup1[is.na(cl_dup1)] <- 0
  cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
  
  # other NAs to 0
  cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
  
  
  score_append <- distinct(cl_dup1, MEMBER_NO)
  cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
  dupes <-cl_dup1
  
  
  
  dupes <-  dupes %>% replace(is.na(.), 0)
  
  
  dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
  
  
  dupes$ROWID <- NULL
  dupes$CLAIM_NO <- NULL
  dupes$MEMBER_NO <- NULL
  #V6
  dupes$DATE_OF_SERVICE_BEG <- NULL
  dupes$DATE_OF_SERVICE_END <- NULL
  dupes$DATE_OF_SERVICE_BEG_CLAIM <- NULL
  dupes$DATE_PAID  <- NULL
  
  #GOWER
  
  cl_dup2 <-
    as.data.frame(as.matrix(simil(
      dupes, by_rows = TRUE,   method = "Gower"
    )))
  # end_timem <- Sys.time()
  #match_time <- end_timem - start_timem
  
  # replace diagonals with NA to 0
  cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
  cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
  
  # return claim numbers as vextor
  nam <- cl_dup1[[2]]
  
  # change column name as vector
  colnames(cl_dup2) <- nam
  
  cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
  colnames(cl_dup2)[1] <- "CLAIM_NO"
  cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
  
  
  # assigns a -1 to within claim scores
  for (k in 1:ncol(cl_dup2)) {
    for (h in 1:nrow(cl_dup2)) {
      if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
        cl_dup2[h,k] <- -1
      }
    }
  }
  cl_dup2$CLAIM_NO <-NULL
  
  
  
  # max
  member_score <- max(cl_dup2)
  score_append$Gower <- member_score
  
  hits <-
    as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
  
  
  #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
  
  # make dummy of row and column number total
  hits$r_c <- hits[,1] +  hits[,2]
  #hits <- sqldf("select * from hits group by r_c")
  # ditinct on the dummy total to bring back 1 pair of records that are ties
  hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
  hits$r_c <- NULL
  
  #ties <- hits
  # empty all rows
  #ties <- [0,]
  
  for (j in rownames(hits))
  {
    r_hits <- hits[j, 1]
    c_hits <- hits[j, 2]
    
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    #hits <- hits[1,]
    
    # r_hits <- hits[, 1]
    # c_hits <- hits[, 2]
    
    
    score_record_temp <- score_record_temp %>%
      mutate(ROWID_1 = cl_dup1[r_hits, 1],
             ROWID_2 = cl_dup1[c_hits, 1],
             CLAIM_NO_1 = cl_dup1[r_hits, 2],
             CLAIM_NO_2 = cl_dup1[c_hits, 2],
             PAID_1 = dupes[r_hits, 4],
             PAID_2 = dupes[c_hits, 4],
             START_DATE_1 = cl_dup1[r_hits, 8],
             START_DATE_2  = cl_dup1[c_hits, 8],
             END_DATE_1 = cl_dup1[r_hits, 9],
             END_DATE_2  = cl_dup1[c_hits, 9],
             SCORE  = member_score,
             COUNT_BY_MEMBER = j,
             METHOD = "Gower")
    
    
    
    score_record_temp$MEMBER_NO <- as.character(score_append$MEMBER_NO)
    
    score_record <- bind_rows(score_record, score_record_temp)
    
    cl_dup3 <-
      sqldf(
        "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
        OR d.ROWID = s.ROWID_2"
      )
    
    
    claim_example <- bind_rows(claim_example, cl_dup3)
    
  }
  
}



score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


# add CPTs to final report and sort

score_record_final <- sqldf("select distinct c.PATIENT_ID,s.* from score_record s, all_claims c
               where s.CLAIM_NO_1 = c.CLAIM_NO
               and SCORE >= 0.9
                      order by SCORE desc")


score_record_final$METHOD <- NULL
score_record_final$ROWID_1 <- NULL
score_record_final$ROWID_2 <- NULL


claim_examplea <- sqldf("select c.* from claim_example c, score_record_final s
                        where c.CLAIM_NO = s.CLAIM_NO_1")
claim_exampleb <- sqldf("select c.* from claim_example c, score_record_final s
                        where c.CLAIM_NO = s.CLAIM_NO_2")

claim_example2 <- rbind(claim_examplea, claim_examplea)

claim_example2 <- sqldf("select * from claim_example2 order by MEMBER_NO")



write.table(claim_example2, file = "dupe_claim_snapshot_6_22.csv",
            row.names = FALSE, sep ="\t")

write.table(score_record_final, file = "score_record_6_22.csv",
            row.names = FALSE, sep ="\t")


# scp dless1@apsrd9425:/home/dless1/healthfirst/dupe_claim_snapshot_6_22.csv /H/My_Doccuments
# scp dless1@apsrd9425:/home/dless1/healthfirst/score_record_6_22.csv /H/My_Doccuments


