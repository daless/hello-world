
# roll forward code compare results to baseline run and remove claims previously found
# do not ship case mix
# filter out low anomalies


# based upon LA Jcode_baseline_5B
# V 2B changed from billed to allowed, added date of service begin and end dates with day span

# Amy asked for these codes to be addedd to first cluster claim line results
# added maually -- cluster 6 is the first run
# JCCODE cluster
#J0180	6
#J1745	7
#J2505	7
#J7325	missing
#J9271	1
#J9306	6
#J9310	7
#J9352	7


setwd("~/healthfirst")
library(comorbidity)
library(RODBC)
library(sqldf)
library(psych)


# library(plyr)
# library(dplyr)
# library(icd)
# 
# library(dummies)
# library(data.table)
# library(ggplot2)
# library(dataMaid)
library(lubridate)
# library(NbClust)
# library(cluster)
library(tidyr)
# library(factoextra)
# library(proxy)
# library(tibble)
# library(network)
# # descriptive stats
# library(Hmisc)

# 
# library(arules)
# library(arulesViz)
# library(visNetwork)
# library(igraph)


#library(h2o)
#h2o.init()
########h2o.init(port=54322)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)




library(dplyr)
library(data.table)


# run this code to get the descriptives Hwalthfirst_jcode_baseline_descriptives

claims_line_180 <- readRDS(file="claims_line_180.Rda")

SOM_descriptives2 <- readRDS(file="SOM_descriptives2.Rda")
jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")
jcode_time <- readRDS(file="jcode_time.Rda")
# SOM_descriptives2 has the mappings of cluster to J code

# descriptives by cluster
som_dist <- readRDS(file="som_dist.Rda")

# cluster membership

som_diste <- readRDS(file="som_diste.Rda")


targ <- cbind(jcode_descriptives2,som_diste)

# #rename
names(targ)[20] <- 'SOM_CLUSTER'
# analyis order for clusters 6,4,2,7

#HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH

# pull for study period paid between 120 - 680 days



conn_medicare = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01288;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)

claims_line_medicare <- sqlQuery(
  conn_medicare,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PATIENT_ID,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID,
  MEM.member_ID,MEM.MEMBER_NO
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock), dbo.MEMBER MEM  with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.PATIENT_ID = MEM.MEMBER_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND L.CPT Like '%J%'
  ")

claims_line_medicare$LOB <- "MEDICARE"


# remove human FACTOR

claims_line_medicare <- sqldf("select * from claims_line_medicare where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")


DX_claim_medicare  <- sqlQuery(
  conn_medicare,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
  AND L.CPT Like '%J%'
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicare$LOB <- "MEDICARE"




conn_medicaid = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01289;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_medicaid <- sqlQuery(
  conn_medicaid,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  CLM.PATIENT_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID,
   MEM.member_ID,MEM.MEMBER_NO
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock), dbo.MEMBER MEM  with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.PATIENT_ID = MEM.MEMBER_ID
  AND L.AMT_PAID  > 1
 AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND L.CPT Like '%J%'
  ")

claims_line_medicaid$LOB <- "MEDICAID"


# remove human FACTOR

claims_line_medicaid <- sqldf("select * from claims_line_medicaid where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")




DX_claim_medicaid  <- sqlQuery(
  conn_medicaid,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
  AND L.CPT Like '%J%'
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicaid$LOB <- "MEDICAID"


conn_comm = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01290;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_comm <- sqlQuery(
  conn_comm,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  CLM.PATIENT_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID,
   MEM.member_ID,MEM.MEMBER_NO
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock), dbo.MEMBER MEM  with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.PATIENT_ID = MEM.MEMBER_ID
  AND L.AMT_PAID  > 1
 AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND L.CPT Like '%J%'
  ")

claims_line_comm$LOB <- "COMM"


# remove human FACTOR

claims_line_comm <- sqldf("select * from claims_line_comm where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")

claims_420a <- rbind(claims_line_medicare, claims_line_medicaid, claims_line_comm)

#saveRDS(claims_420a, file="claims_420a.Rda")
#claims_420a <- readRDS(file="claims_420a.Rda")

DX_claim_comm  <- sqlQuery(
  conn_comm,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
  AND L.CPT Like '%J%'
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_comm$LOB <- "COMM"


DX_claim_medicare  <- sqlQuery(
  conn_medicare,
  " select
 DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
  AND L.CPT Like '%J%'
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicare$LOB <- "MEDICARE"



DX_claim_medicaid  <- sqlQuery(
  conn_medicaid,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.ICD9 DX with (nolock), dbo.CLAIM CLM with (nolock), dbo.CLAIM_LINE L with (nolock)
  where CLM.CLAIM_ID = DX.CLAIM_ID
  and  L.CLAIM_ID = CLM.CLAIM_ID
  AND  DX.ORDER_IN_CLAIM <= 5
  AND L.AMT_PAID  > 1
  AND L.CPT Like '%J%'
    AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)

DX_claim_medicaid$LOB <- "MEDICAID"

DX_claim <- rbind(DX_claim_medicare, DX_claim_medicaid, DX_claim_comm)



#rm( DX_claim_tapestry)
DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

saveRDS(charlson_scores, file="charlson_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")




charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
elixhauser_scores$CLAIM_IDx <- as.numeric(elixhauser_scores$CLAIM_ID)

elixhauser_scores$index <- NULL
elixhauser_scores$windex_ahrq <- NULL
elixhauser_scores$windex_vw  <- NULL
elixhauser_scores$CLAIM_ID <- NULL


claims_420a <- sqldf("select distinct b.*, c.wscore as charls_score from charlson_scores c,
               claims_420a b where 
               b.CLAIM_ID = c.CLAIM_ID", method = "name_class")




claims_420a<- sqldf("select distinct b.*, c.* from elixhauser_scores c,
               claims_420a b where 
               b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")



# load CCS stripe first 3 characters of CCS for rollups for apriori

CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)

CCS_lookup <- CCS
CCS_lookup$multi_code <- CCS_lookup$CCS_Category
CCS_lookup$multi_code <- paste("CCS__",CCS_lookup$multi_code )


ccs_cols <- sqldf("select distinct multi_code, multi_desc from CCS_lookup")



# DX_claim  <- sqldf("select  d.* from DX_claim d
#                    where  d.ICD9_TYPE='DIAG10'")

icd2 <- sqldf("select i.*, c.multi_desc from DX_claim  i,CCS_lookup c where
              i.ICD9_CODE = c.ICD10_CODE ")

icd2$ICD9_TYPE <- NULL
icd2$ADMITTING_CODE <- NULL
icd2$PRINCIPAL_CODE <- NULL
icd2$CLAIM_LINE_ID <- NULL
icd2$ORDER_IN_CLAIM <- NULL
icd2$FEED_ID <-NULL

claims_420a_id <- sqldf ("select  CLAIM_ID from claims_420a group by CLAIM_ID")

# long format
icd2 <- sqldf("select i.* from icd2  i,claims_420a_id c where i.CLAIM_ID = c.CLAIM_ID ")
saveRDS(icd2, file="icd2.Rda")
#icd2 <- readRDS(file="icd2.Rda")


# cluster4_j_claims_string <- paste0("select  c.* from claims_420a c
#                            where c.CPT IN (select CPT from jcode_descriptives3 where cluster = '",cluster1,"')")
# 
# cluster4_j_claims <- sqldf(cluster4_j_claims_string)
# 
# 
# c4_ids <- sqldf("select distinct CLAIM_ID from cluster4_j_claims")
# 
# icd_C4_1 <- sqldf("select i.* from icd2  i,c4_ids c where i.CLAIM_ID = c.CLAIM_ID  order by CLAIM_ID")
# 
# 
# CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from icd_C4_1")


CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from icd2")



CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test_", "",  colnames(CCS_Dummy_test)))
# group by client id
CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy3_test <- CCS_Dummy3_test %>% mutate_if(is.numeric, funs(factor(.)))
CCS_Dummy3_test$CLAIM_ID <- as.numeric(CCS_Dummy3_test$CLAIM_ID)
CCS_Dummy3_test$multi_desc <- NULL
CCS_Dummy3_test <- sqldf("select * from CCS_Dummy3_test order by CLAIM_ID")
CCS_Dummy3_test$CLAIM_IDx <-CCS_Dummy3_test$CLAIM_ID
CCS_Dummy3_test$CLAIM_ID <- NULL

# wide format
icd_C4_2 <- CCS_Dummy3_test 
saveRDS(icd_C4_2, file="icd_C4_2.Rda")




#00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
# for clusters
library(dplyr)




                    
# change bill type code NA to 0
claims_420a$BILL_TYPE <- ifelse(is.na(claims_420a$BILL_TYPE), 0, claims_420a$BILL_TYPE)
claims_420a$BILL_TYPE <- as.factor(claims_420a$BILL_TYPE)

# place of service
claims_420a$PLACE_OF_SERVICE<- ifelse(is.na(claims_420a$PLACE_OF_SERVICE), 0, 
                                      claims_420a$PLACE_OF_SERVICE)
claims_420a$PLACE_OF_SERVICE<- as.factor(claims_420a$PLACE_OF_SERVICE)

claims_420a$CPT_MODIFIER <- ifelse(is.na(claims_420a$CPT_MODIFIER), 'none', claims_420a$CPT_MODIFIER)

claims_420a$REVENUE_CODE <- ifelse(is.na(claims_420a$REVENUE_CODE), 0, claims_420a$REVENUE_CODE)
claims_420a$REVENUE_CODE <- as.factor(claims_420a$REVENUE_CODE)

#saveRDS(claims_420a, file="claims_420a.Rda")
#claims_420a <- readRDS(file="claims_420a.Rda")



time_distinct <- sqldf("select distinct CLAIM_LINE_ID,CPT, days_between_admins 
from jcode_time", method = "name_class")

# to join time if its is cleaned up
claims_420a <- sqldf("select distinct c.*, j.days_between_admins from claims_420a c inner join time_distinct j
              on c.CLAIM_LINE_ID = j.CLAIM_LINE_ID
              and c.CPT=j.CPT", method = "name_class")


# add dervided specialty code
special1 <- readRDS(file="special1.Rda")
claims_420a <- sqldf("select c.*, p.specialty from claims_420a c, special1 p
              where c.PROVIDER_ID = p.PROVIDER_ID")


# filter for jcodes in cluster 6
cluster1 <- as.vector(SOM_descriptives2[4,1])

claims_420b_string <- paste0("select  CPT from targ
                             where SOM_CLUSTER  = '",cluster1,"'")

claims_420b <- sqldf(claims_420b_string)

cluster4_j_claims2 <- sqldf("select c.* from claims_420a c, claims_420b b
                       where c.CPT = b.CPT")

cluster4_j_claims2$CLAIM_IDx <- NULL

cluster4_j_claims2$CPT <- as.factor(cluster4_j_claims2$CPT)
cluster4_j_claims2$CPT_MODIFIER <- as.factor(cluster4_j_claims2$CPT_MODIFIER)
cluster4_j_claims2$REVENUE_CODE <- as.factor(as.character(cluster4_j_claims2$REVENUE_CODE))
cluster4_j_claims2$specialty <- as.factor(cluster4_j_claims2$specialty)


cluster4_j_claims2 <- sqldf("select DISTINCT PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                      PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB, 
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                      ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                      pud, aids, lymph, metacanc, solidtum, 
                      rheumd, coag, obes, wloss, fed, 
                      blane, dane, alcohol, drug, psycho, 
                      depre,score, wscore_ahrq,wscore_vw,days_between_admins,specialty
                            from cluster4_j_claims2")

saveRDS(cluster4_j_claims2, file="cluster4_j_claims2.Rda")
# cluster4_j_claims2 <- readRDS(file="cluster4_j_claims2.Rda")
#cluster1 <- as.vector(SOM_descriptives2[4,1])


# anomalies


outlier <- data.frame(matrix(ncol = 48, nrow = 0))
outlier_columns <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                     'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                     'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                     'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                     'pud','aids','lymph','metacanc','solidtum',
                     'rheumd','coag','obes','wloss','fed',
                     'blane','dane','alcohol','drug','psycho',
                     'depre','SOM_CLUSTER','days_between_admins', 'Reconstruction.MSE',
                     'score', 'wscore_ahrq','wscore_vw','specialty')

outlier_temp <- data.frame(matrix(ncol = 48, nrow = 0))
colnames(outlier) <- outlier_columns
colnames(outlier_temp) <- outlier_columns

# dummy table structure to pull from base data 
# data pull
dummy_col_names <-  c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                      'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                      'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                      'pud','aids','lymph','metacanc','solidtum',
                      'rheumd','coag','obes','wloss','fed',
                      'blane','dane','alcohol','drug','psycho',
                      'depre','days_between_admins', 'SOM_CLUSTER',
                      'score', 'wscore_ahrq','wscore_vw','specialty')

ccsnames <- c('chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
              'ond','cpd','diabunc','diabc','hypothy','rf','ld',
              'pud','aids','lymph','metacanc','solidtum',
              'rheumd','coag','obes','wloss','fed',
              'blane','dane','alcohol','drug','psycho',
              'depre')


fnames <- c( 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
            'PLACE_OF_SERVICE', 'CPT', 'LOB', 'SOM_CLUSTER','specialty')

intnames <- c('PATIENT_ID', 'CLAIM_ID',
               'UNITS_ALLOWED','AMT_PAID')

numnames <- c('AMT_PAID','days_between_admins','score', 'wscore_ahrq','wscore_vw')


dummy_pull <- data.frame(matrix(ncol = 47, nrow = 1))
colnames(dummy_pull) <- dummy_col_names

cluster4_j_claims2[ccsnames] <- lapply(cluster4_j_claims2[ccsnames], as.factor)
dummy_pull[ccsnames] <- lapply(dummy_pull[ccsnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[fnames] <- lapply(dummy_pull[fnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[intnames] <- lapply(dummy_pull[intnames], as.integer)
dummy_pull[numnames] <- lapply(dummy_pull[numnames], as.numeric)



outlier_temp[ccsnames] <- lapply(outlier_temp[ccsnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[fnames] <- lapply(outlier_temp[fnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[intnames] <- lapply(outlier_temp[intnames], as.integer)
outlier_temp[numnames] <- lapply(outlier_temp[numnames], as.numeric)




dummy_pull[setdiff(names(cluster4_j_claims2), names(dummy_pull))] <- NA
cluster4_j_claims2[setdiff(names(dummy_pull), names(cluster4_j_claims2))] <- NA


cluster4_j_claims2 <- rbind( dummy_pull,cluster4_j_claims2)
cluster4_j_claims2 <- sqldf("select  * from cluster4_j_claims2 where CPT != '0'")


jid <- sqldf("select distinct CPT from cluster4_j_claims2")

# force amy's Jcodes into this run from othe clusters
Ammy_Jcodes <- data.frame(matrix(ncol = 1, nrow = 5))
ammy_col_names <-  c('CPT')
Ammy_Jcodes[1,1] <- "J1745"
Ammy_Jcodes[2,1] <- "J2505"
Ammy_Jcodes[3,1] <- "J9271"
Ammy_Jcodes[4,1] <- "J9310"
Ammy_Jcodes[5,1] <- "J9352"
names(Ammy_Jcodes)[1] <- 'CPT'

jid <- rbind(jid,Ammy_Jcodes)



#jid <- sqldf("select distinct CPT from cluster4_j_claims2 where CPT = 'J9271'")
# i=1

for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  j_string <- paste0("select PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                      PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB, 
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                      ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                      pud, aids, lymph, metacanc, solidtum, 
                      rheumd, coag, obes, wloss, fed, 
                      blane, dane, alcohol, drug, psycho, 
                      depre,days_between_admins,score, wscore_ahrq, wscore_vw,specialty
                      from cluster4_j_claims2
                   where CPT = '",jid_loop,"'")
 
  an0 <- sqldf(j_string)
  # remnove columns that all NA from dummy
  an0[sapply(an0, function(x) all(is.na(x)))] <- NULL

  an1 <- an0
  an1$PATIENT_ID <- NULL
  an1$AMT_PAID <- NULL
  an1$CLAIM_ID <- NULL
  
 
  # remove columns with all constant
   an1 <- an1[sapply(an1, function(x) length(unique(na.omit(x)))) >1]
  # only run anomoly if have 3+ columns non constant
  if(NCOL(an1) >= 3) {
   
  
    learnname <- colnames(an1) 
    
    an1_h2o <- as.h2o(an1)
    
    an1_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = an1_h2o, autoencoder = TRUE, 
                                   hidden = c(100,20,100), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                   categorical_encoding = "AUTO",seed = 77,
                                   standardize= TRUE,
                                   reproducible = TRUE)
    
  
    
    
    an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
    an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)
    
    
    outlier <- cbind(an0, an1_h2o_dl2)
    
    outlier <- data.frame(r_index = row.names(outlier), outlier)
   outlier$SOM_CLUSTER <- as.factor(cluster1)
    #outlier_temp<- bind_rows(outlier, outlier_temp)
   outlier_temp<- bind_rows(outlier, outlier_temp)
    
                         
  }
  
}

###############################################
# claim line outlier Mahalnobis

outlier_temp$MSE <- outlier_temp$Reconstruction.MSE


# from CMS
jcode_max_units <- read.csv("CMS_Jcode_max_units.txt", header=TRUE, sep="\t")


# add CMS max
outlier_temp <- sqldf("select  f.*, c.Max_Units from outlier_temp f INNER JOIN jcode_max_units c
                ON f.CPT = c.Code")

# add median from baseline


outlier_temp <- sqldf("select  f.*, c.median_units as BaseLine_Median_Units from outlier_temp f INNER JOIN jcode_descriptives2 c
                ON f.CPT = c.CPT")


outlier_temp$baseline_units_ratio <- outlier_temp$UNITS_ALLOWED / outlier_temp$BaseLine_Median_Units
outlier_temp$baseline_units_delta <- outlier_temp$UNITS_ALLOWED - outlier_temp$BaseLine_Median_Units


# drugs discontiued or not covered by CMS are 0 add 0.01 so can do ratio
outlier_temp$CMS_units_ratio <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED / outlier_temp$Max_Units,
                                       0)
outlier_temp$CMS_units_delta <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED - outlier_temp$Max_Units,
                                       0)
 


distance1 <- sqldf("select AMT_PAID,MSE,CMS_units_ratio, 
                   score, wscore_ahrq, wscore_vw from  outlier_temp")

distance1 <- scale(distance1)

# Mahalanobis from psych package
distance2 <- as.data.frame(outlier(distance1, plot = FALSE, bad = 5, xlab,ylab))
names(distance2)[1] <- "Mahalanobis"
outlier_temp2 <- cbind(outlier_temp,distance2)


# add add paid date filter on last paid 
outlier_temp2 <- sqldf ("select distinct o.* , c.DATE_PAID from outlier_temp2 o,claims_420a c
               where  o.CLAIM_ID = c.CLAIM_ID")


outlier_temp2 <- mutate(outlier_temp2, 
                    Mahalanobis_rank = ntile(outlier_temp2$Mahalanobis, 10))
outlier_temp2$Reconstruction.MSE <- NULL

# make sure J0180 J9306 are in list per Amy


                                       
outlier_temp2$Units_Anomaly <- ifelse(outlier_temp2$Mahalanobis_rank >= 8 ,1,
                                      ifelse(outlier_temp2$CPT == 'J0180',1,
                                             ifelse(outlier_temp2$CPT == 'J9306',1,
                                                    ifelse(outlier_temp2$CPT == 'J1745',1,
                                                           ifelse(outlier_temp2$CPT == 'J2505' ,1,
                                                                  ifelse(outlier_temp2$CPT == 'J9271',1,
                                                                         ifelse(outlier_temp2$CPT == 'J9352' ,1,  
                                                                         ifelse(outlier_temp2$CPT == 'J9310',1, 0))))))))





#saveRDS(outlier_temp2, file="outlier_temp2_claim_line.Rda")
#outlier_temp2_claim_line <- readRDS(file="outlier_temp2_claim_line.Rda")
outlier_temp2_claim_line <- outlier_temp2

# these are units above CMS or above median of sample
outlier_temp3_unit_hits_high <- sqldf("select * from outlier_temp2 where Units_Anomaly = 1
                                 order by Mahalanobis_rank DESC")
# flag for above and below benchmarks
outlier_temp3_unit_hits_high$above_benchmarks <-1
# these are below CMS and baseline but scorredd high mahalobious and anomoly

outlier_temp3_unit_hits_low <- sqldf("select * from outlier_temp2 where Units_Anomaly = 0

                                 order by Mahalanobis_rank DESC")

outlier_temp3_unit_hits_low$above_benchmarks <-0
outlier_temp3 <- rbind(outlier_temp3_unit_hits_high,outlier_temp3_unit_hits_low )



outlier_temp3_unit_hits_high$r_index <- NULL
Cluster4_claim_line_summary_df <- sqldf("select distinct * from  outlier_temp3_unit_hits_high
                                   order by Mahalanobis desc")

Cluster4_claim_line_summary_df[is.na(Cluster4_claim_line_summary_df)] <- 0

#saveRDS(Cluster4_claim_line_summary_df, file="Cluster4_claim_line_summary_df.Rda")
#Cluster4_claim_line_summary_df <- readRDS(file="Cluster4_claim_line_summary_df.Rda")



outlier_temp3_case_mix_hits <- sqldf("select * from outlier_temp2 where Units_Anomaly = 0
                                  
                                 order by Mahalanobis_rank DESC")


# Anomaly for non unit hit anaomaly -- group by claim and total the amount of units
#CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

# claim level


claim_level0 <- sqldf("select CLAIM_ID, CPT, sum(UNITS_ALLOWED) as total_units,
sum(AMT_PAID) as total_claim_pd, count(CLAIM_ID) as jcnt
              from outlier_temp2
              group by CLAIM_ID, CPT")
 


claim_level1 <- sqldf("select PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID,
                      PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB,
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para,
                      ond, cpd, diabunc, diabc, hypothy, rf, ld,
                      pud, aids, lymph, metacanc, solidtum,
                      rheumd, coag, obes, wloss, fed,
                      blane, dane, alcohol, drug, psycho,
                      depre,
                      Max_Units, SOM_CLUSTER, Units_Anomaly, 
                      Mahalanobis_rank,days_between_admins,score, wscore_ahrq,wscore_vw,specialty
                      from outlier_temp2")





#saveRDS(claim_level1, file="claim_level1.Rda")

claim_level00 <- sqldf("select CLAIM_ID, CPT,  total_units,
 total_claim_pd,  jcnt
              from claim_level0")

jcode_cnt2 <- claim_level00
jcode_cnt2$CLAIM_NO <- NULL

# jcode claim descriptives

jcode_descriptives_claims <- as.data.frame(describeBy(jcode_cnt2,
                                               group = list(jcode_cnt2$CPT), 
                                               mat=TRUE))



#####################################################################


jcode_descriptives_claims_pd <- sqldf("select * from jcode_descriptives_claims where vars = 3
                               order by mean desc")

jcode_descriptives_claims_vol <- sqldf("select * from jcode_descriptives_claims where vars = 2
                                order by n desc")

jcode_descriptives_claims_units <- sqldf("select * from jcode_descriptives_claims where vars = 4
                                  order by n desc")

# jcode_descriptives_claims2 <- sqldf("select v.group1 as CPT, v.n as num_admins,
#                              v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units, t.mean as mean_days,
#                              v.median as median_num_admins, p.median as median_pd, u.median as median_units, t.median as median_days,
#                              v.min as min_num_admins, v.max as max_num_admins,t.max as max_days,
#                              p.min as min_pd, p.max as max_pd,
#                              u.min as min_units, u.max as max_units
#                              from jcode_descriptives_claims_pd  p, 
#                              jcode_descriptives_claims_vol v,
#                              jcode_descriptives_claims_units u, jcode_descriptives_time t
#                              where v.group1 = p.group1
#                              and v.group1 = u.group1
#                              and v.group1 = t.group1
#                              order by mean_pd desc")






#####################################################################
# claim level anomolies

# remove fields for anomaly run


outlier <- data.frame(matrix(ncol = 48, nrow = 0))
outlier_columns <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                     'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                     'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                     'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                     'pud','aids','lymph','metacanc','solidtum',
                     'rheumd','coag','obes','wloss','fed',
                     'blane','dane','alcohol','drug','psycho',
                     'depre','SOM_CLUSTER','days_between_admins', 'Reconstruction.MSE',
                     'score', 'wscore_ahrq','wscore_vw','specialty')

outlier_temp <- data.frame(matrix(ncol = 48, nrow = 0))
colnames(outlier) <- outlier_columns
colnames(outlier_temp) <- outlier_columns

# dummy table structure to pull from base data 
# data pull
dummy_col_names <-  c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                      'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                      'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                      'pud','aids','lymph','metacanc','solidtum',
                      'rheumd','coag','obes','wloss','fed',
                      'blane','dane','alcohol','drug','psycho',
                      'depre','days_between_admins', 'SOM_CLUSTER',
                      'score', 'wscore_ahrq','wscore_vw','specialty')

ccsnames <- c('chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
              'ond','cpd','diabunc','diabc','hypothy','rf','ld',
              'pud','aids','lymph','metacanc','solidtum',
              'rheumd','coag','obes','wloss','fed',
              'blane','dane','alcohol','drug','psycho',
              'depre')


fnames <- c( 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
             'PLACE_OF_SERVICE', 'CPT', 'LOB', 'SOM_CLUSTER','specialty')

intnames <- c('PATIENT_ID', 'CLAIM_ID',
              'UNITS_ALLOWED','AMT_PAID')

numnames <- c('AMT_PAID','days_between_admins','score', 'wscore_ahrq','wscore_vw')


dummy_pull <- data.frame(matrix(ncol = 47, nrow = 1))
colnames(dummy_pull) <- dummy_col_names

claim_level1[ccsnames] <- lapply(claim_level1[ccsnames], as.factor)
dummy_pull[ccsnames] <- lapply(dummy_pull[ccsnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[fnames] <- lapply(dummy_pull[fnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[intnames] <- lapply(dummy_pull[intnames], as.integer)
dummy_pull[numnames] <- lapply(dummy_pull[numnames], as.numeric)



outlier_temp[ccsnames] <- lapply(outlier_temp[ccsnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[fnames] <- lapply(outlier_temp[fnames], as.factor)
outlier_temp[is.na(outlier_temp)] <-0
outlier_temp[intnames] <- lapply(outlier_temp[intnames], as.integer)
outlier_temp[numnames] <- lapply(outlier_temp[numnames], as.numeric)




dummy_pull[setdiff(names(claim_level1), names(dummy_pull))] <- NA
claim_level1[setdiff(names(dummy_pull), names(claim_level1))] <- NA


claim_level1 <- rbind( dummy_pull,claim_level1)
claim_level1 <- sqldf("select  * from claim_level1 where CPT != '0'")



claim_level1 <- sqldf("select  c.*, s.total_units, s.total_claim_pd , jcnt
                      from claim_level1 c, claim_level0 s
                      where c.CLAIM_ID = s.CLAIM_ID
                      AND c.CPT = s.CPT
                      and c.Units_Anomaly = 0
                     ")

jid <- sqldf("select distinct CPT from claim_level1")




for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  j_string <- paste0("select PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                      PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB, 
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                      ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                      pud, aids, lymph, metacanc, solidtum, 
                      rheumd, coag, obes, wloss, fed, 
                      blane, dane, alcohol, drug, psycho, 
                      depre,days_between_admins, score, wscore_ahrq, wscore_vw,specialty
                     from claim_level1
                     where CPT = '",jid_loop,"'")
  
  an0 <- sqldf(j_string)
  
  # remnove columns that all NA from dummy
  an0[sapply(an0, function(x) all(is.na(x)))] <- NULL
  
  an1 <- an0
  an1$PATIENT_ID <- NULL
  an1$total_claim_pd <- NULL
  an1$CLAIM_ID <- NULL
  an1$Units_Anomaly <- NULL
  an1$Max_Units <- NULL
  an1$total_claim_pd <- NULL
  
  # remove columns with all constant
  an1 <- an1[sapply(an1, function(x) length(unique(na.omit(x)))) >1]
  
  if(NCOL(an1) >= 3) {
    
    learnname <- colnames(an1)
    
    an1_h2o <- as.h2o(an1)
    
    an1_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = an1_h2o, autoencoder = TRUE, 
                                   hidden = c(100,20,100), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                   categorical_encoding = "AUTO",seed = 77,
                                   standardize= TRUE,
                                   reproducible = TRUE)
    
    
    
    
    an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
    an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)
    
    
    outlier <- cbind(an0, an1_h2o_dl2)
    
    outlier <- data.frame(r_index = row.names(outlier), outlier)
    outlier$SOM_CLUSTER <- as.factor(cluster1)
    #outlier_temp<- bind_rows(outlier, outlier_temp)
    outlier_temp<- bind_rows(outlier, outlier_temp)
    
  }
  
}

###############################################
# claim outlier Mahalnobis

outlier_temp$MSE <- outlier_temp$Reconstruction.MSE


# add CMS max
outlier_temp <- sqldf("select  f.*, c.Max_Units from outlier_temp f INNER JOIN jcode_max_units c
                ON f.CPT = c.Code")

# add median from baseline


outlier_temp <- sqldf("select  f.*, c.median_units as BaseLine_Median_Units from outlier_temp f INNER JOIN jcode_descriptives2 c
                ON f.CPT = c.CPT")


outlier_temp$baseline_units_ratio <- outlier_temp$UNITS_ALLOWED / outlier_temp$BaseLine_Median_Units
outlier_temp$baseline_units_delta <- outlier_temp$UNITS_ALLOWED - outlier_temp$BaseLine_Median_Units


# drugs discontiued or not covered by CMS are 0 add 0.01 so can do ratio
outlier_temp$CMS_units_ratio <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED / outlier_temp$Max_Units,
                                       0)
outlier_temp$CMS_units_delta <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED - outlier_temp$Max_Units,
                                       0)

# add comorbidity scores

outlier_temp <- sqldf("select DISTINCT o.*, t.score, t.wscore_ahrq, t.wscore_vw, t.days_between_admins
                      from cluster4_j_claims2 t, outlier_temp o
                      where o.CLAIM_ID = t.CLAIM_ID")


distance1 <- sqldf("select AMT_PAID,MSE,CMS_units_ratio, 
                   score, wscore_ahrq, wscore_vw from  outlier_temp")

distance1 <- scale(distance1)

# Mahalanobis from psych package
distance2 <- as.data.frame(outlier(distance1, plot = FALSE, bad = 5, xlab,ylab))
names(distance2)[1] <- "Mahalanobis"
outlier_temp2 <- cbind(outlier_temp,distance2)


# add add paid date filter on last paid 
outlier_temp2 <- sqldf ("select distinct o.* , c.DATE_PAID from outlier_temp2 o,claims_420a c
               where  o.CLAIM_ID = c.CLAIM_ID")


outlier_temp2 <- mutate(outlier_temp2, 
                        Mahalanobis_rank = ntile(outlier_temp2$Mahalanobis, 10))
outlier_temp2$Reconstruction.MSE <- NULL


outlier_temp2$Units_Anomaly <- ifelse((outlier_temp2$Mahalanobis_rank >= 8 ),
                                      1, 0)


#saveRDS(outlier_temp2, file="outlier_temp2_claim.Rda")



# these are units above CMS or above median of sample
outlier_temp3_unit_hits_high <- sqldf("select * from outlier_temp2 where Units_Anomaly = 1
                                 order by Mahalanobis_rank DESC")
# flag for above and below benchmarks
outlier_temp3_unit_hits_high$above_benchmarks <-1
# these are below CMS and baseline but scorredd high mahalobious and anomoly

outlier_temp3_unit_hits_low <- sqldf("select * from outlier_temp2 where Units_Anomaly = 0

                                 order by Mahalanobis_rank DESC")

outlier_temp3_unit_hits_low$above_benchmarks <-0
outlier_temp3 <- rbind(outlier_temp3_unit_hits_high,outlier_temp3_unit_hits_low )



outlier_temp3_unit_hits_high$r_index <- NULL
Cluster4_claim_summary_df <- sqldf("select distinct * from  outlier_temp3_unit_hits_high
                                   order by Mahalanobis desc")

Cluster4_claim_summary_df[is.na(Cluster4_claim_summary_df)] <- 0

#saveRDS(Cluster4_claim_summary_df, file="Cluster4_claim_summary_df.Rda")



outlier_temp2_b <- outlier_temp2





# arpriori for each J code of CCS

# from claim level data extract non anomaly and mahobious < 8 for case mix
# needs to be tested with smaller clausters

if(NROW(outlier_temp) > 0) {
case_ids <- sqldf("select distinct CLAIM_ID from outlier_temp2_b where Units_Anomaly = 0")}

if(NROW(outlier_temp) == 0) {
  case_ids <- sqldf("select distinct CLAIM_ID from outlier_temp2_claim_line where Units_Anomaly = 0")}

# check mapping to correct table
claim_level1_backup<- claim_level1
claim_level1 <- sqldf("select c.* from claim_level1 c,case_ids i
              where c.CLAIM_ID = i.CLAIM_ID")



library(arules)
library(arulesViz)
library(visNetwork)
library(igraph)
library(plyr)
library(tibble)
library(reshape2)


# anomaly temp files
outlier_b_an <- data.frame(matrix(ncol = 57, nrow = 0))
outlier_columns_b_an <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                          'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                          'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                          'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                          'pud','aids','lymph','metacanc','solidtum',
                          'rheumd','coag','obes','wloss','fed',
                          'blane','dane','alcohol','drug','psycho',
                          'depre','SOM_CLUSTER', 'days_between_admins','score', 'wscore_ahrq','wscore_vw',
                        'LHS', 'RHS', 'support', 'confidence','lift', 'count', 'tot_rules',
                        'Jaccard_rank', 'case_mix_MSE', 'Anomaly_rank')



outlier_temp_b_an <- data.frame(matrix(ncol = 57, nrow = 0))
colnames(outlier_b_an) <- outlier_columns_b_an
colnames(outlier_temp_b_an) <- outlier_columns_b_an

# dummy table structure to pull from base data 
# data pull
dummy_col_names <-  c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'LOB',
                      'chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
                      'ond','cpd','diabunc','diabc','hypothy','rf','ld',
                      'pud','aids','lymph','metacanc','solidtum',
                      'rheumd','coag','obes','wloss','fed',
                      'blane','dane','alcohol','drug','psycho',
                      'depre','SOM_CLUSTER',  'days_between_admins','score', 'wscore_ahrq','wscore_vw',
                      'LHS', 'RHS', 'support', 'confidence','lift', 'count', 'tot_rules',
                      'Jaccard_rank', 'case_mix_MSE', 'Anomaly_rank')

ccsnames <- c('chf', 'carit','valv','pcd','pvd','hypunc','hypc','para',
              'ond','cpd','diabunc','diabc','hypothy','rf','ld',
              'pud','aids','lymph','metacanc','solidtum',
              'rheumd','coag','obes','wloss','fed',
              'blane','dane','alcohol','drug','psycho',
              'depre')


fnames <- c( 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE',
             'PLACE_OF_SERVICE', 'CPT', 'LOB','CLAIM_ID')

intnames <- c('PATIENT_ID', 
              'UNITS_ALLOWED')

numnames <- c('AMT_PAID', 'support', 'confidence','lift', 'count', 'tot_rules',
              'Jaccard_rank','case_mix_MSE','Anomaly_rank', 'days_between_admins',
              'score', 'wscore_ahrq','wscore_vw')

charnames <- c('LHS', 'RHS')


dummy_pull <- data.frame(matrix(ncol = 56, nrow = 1))
colnames(dummy_pull) <- dummy_col_names

claim_level1[ccsnames] <- lapply(claim_level1[ccsnames], as.factor)
claim_level1[fnames] <- lapply(claim_level1[fnames], as.factor)

dummy_pull[ccsnames] <- lapply(dummy_pull[ccsnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[fnames] <- lapply(dummy_pull[fnames], as.factor)
dummy_pull[is.na(dummy_pull)] <-0
dummy_pull[intnames] <- lapply(dummy_pull[intnames], as.integer)
dummy_pull[numnames] <- lapply(dummy_pull[numnames], as.numeric)
dummy_pull[charnames] <- lapply(dummy_pull[charnames], as.character)

outlier_temp_b_an[ccsnames] <- lapply(outlier_temp_b_an[ccsnames], as.factor)
#outlier_temp_b_an[is.na(outlier_temp)] <-0
outlier_temp_b_an[fnames] <- lapply(outlier_temp_b_an[fnames], as.factor)
#outlier_temp_b_an[is.na(outlier_temp)] <-0
outlier_temp_b_an[intnames] <- lapply(outlier_temp_b_an[intnames], as.integer)
outlier_temp_b_an[numnames] <- lapply(outlier_temp_b_an[numnames], as.numeric)
outlier_temp_b_an[charnames] <- lapply(outlier_temp_b_an[charnames], as.character)



jid <- sqldf("select distinct CPT from claim_level1 ")

#jid <- sqldf("select distinct CPT from claim_level1  where CPT = 'J0638'")
                      
                 
# turns off graphics in R studio
graphics.off()
par("mar")
par(mar=c(1,1,1,1))

for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  j_string <- paste0("select PATIENT_ID,  BILL_TYPE,  CPT_MODIFIER,  REVENUE_CODE, CLAIM_ID, 
                      PLACE_OF_SERVICE,  CPT,  UNITS_ALLOWED, AMT_PAID,  LOB, 
                      chf,  carit, valv, pcd, pvd, hypunc, hypc, para, 
                      ond, cpd, diabunc, diabc, hypothy, rf, ld, 
                      pud, aids, lymph, metacanc, solidtum, 
                      rheumd, coag, obes, wloss, fed, 
                      blane, dane, alcohol, drug, psycho, 
                      depre, days_between_admins,score, wscore_ahrq,wscore_vw
                     from claim_level1
                     where CPT = '",jid_loop,"'")
  
  an0 <- sqldf(j_string)
  # remnove columns that all NA from dummy
  an0[sapply(an0, function(x) all(is.na(x)))] <- NULL
  
  # remove fields for anomaly run
  an1 <- an0
  an1$PATIENT_ID <- NULL
  an1$total_claim_pd <- NULL
  an1$CLAIM_ID <- NULL
  an1$Units_Anomaly <- NULL
  an1$Max_Units <- NULL
  an1$total_claim_pd <- NULL
  
  
  an1 <- an1[sapply(an1, function(x) length(unique(na.omit(x)))) >1]
  

 
  if(NCOL(an1) > 0) {
    
    
    
    #  CCS by claim and J code
    ap1 <- sqldf( "select distinct i.CLAIM_ID, i.multi_desc as CCS_DX from icd2 i, an0 a
                  where i.CLAIM_ID = a.CLAIM_ID
                  order by i.CLAIM_ID")
    
    # ap1 <- sqldf("select  a.*, c.multi_code as CCS_DX from ap1 a, CCSdesc c
    #              where a.multi_desc = c.multi_desc")
    
   # removed modifer
    #ap1$multi_desc <- NULL
    
    
    ap1$CLAIM_ID <- as.factor(as.character((ap1$CLAIM_ID)))
    ap1$CCS_DX <- as.factor(as.character((ap1$CCS_DX)))
    
    ap2 <- ddply(ap1, c("CLAIM_ID"),
                 function(ap1)paste(ap1$CCS_DX,
                                    collapse = ','))
    
    names(ap2)[2] <- "CCS"
    
    ap3 <- ap2
    ap3$CLAIM_ID <- NULL
    
    write.csv(ap2, file = "ccs_transactions.csv")
    
    txn <- read.transactions(file="ccs_transactions.csv", rm.duplicates = TRUE,
                             format="single", sep=",", cols=c("CLAIM_ID","CCS"))
    
    
    
    
    # remove quotes
    txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)
    
    basket_rules <- apriori(txn,parameter = list(sup = 0.01, 
                                                 conf=0.01, target="rules"))
    
    # remove redundent rules
  basket_rules <- basket_rules[!is.redundant(basket_rules)]
    CCS_Basket <- DATAFRAME(basket_rules, separate = TRUE)
    
    # have to have at least 3 rules
    if (NROW(CCS_Basket) >=3 ){
    
    # see if LHS all empty
    # if so add 0 to LHS
    CCS_Basket <-  CCS_Basket[!sapply( CCS_Basket, function(k) all(k =="{}"))]
    
    if(NCOL(CCS_Basket) ==6){
       # remove brackets
    CCS_Basket$LHS <- gsub("[{}]","", CCS_Basket$LHS)
    CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
    }
    
    if(NCOL(CCS_Basket) ==5){
      CCS_Basket$LHS <- '0'
      CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)
      #CCS_Basket <- sqldf("select LHS,RHS,support,confidence,lift,count from CCS_Basket")
    }
    
    
   # SNA
        # nodes rule id adges are rules
    
    adj1 <- sqldf("select LHS , RHS , count as weight from CCS_Basket")
    
    # add row ids for nodes
    adj1$id <- 1:nrow(adj1)
    
   
    adj1$weight <- as.integer(adj1$weight)
    adj2 <-adj1
    adj2$id <- NULL
    
  
    # 
    transferGraph <- graph_from_data_frame(adj2, directed = TRUE)
   
    # look at other layouts in igraph
    # plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
    #                                                          weights=E(transferGraph)$weight),
    #      edge.arrow.size = .2)
   
    
    ig <- plot(basket_rules, method="graph")
    ig_df <- get.data.frame(ig,what = "both")
   
    # 
    # visNetwork(
    #   nodes = data.frame(
    #     id = ig_df$vertices$name
    #     ,value = ig_df$vertices$lift  # try lift & confidence
    #     ,title = ifelse(ig_df$vertices$label == "", ig_df$vertices$name, ig_df$vertices$label)
    #     ,ig_df$vertices
    #   )
    #   , edges = ig_df$edges
    # ) %>%
    #   visNodes(size = 10) %>%
    #   visLegend() %>%
    #   visEdges(smooth = FALSE) %>%
    #   visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
    #   visInteraction(navigationButtons = TRUE) %>%
    #   visEdges( arrows = 'from') %>%
    #   visPhysics(
    #     solver = "barnesHut",
    #     maxVelocity = 35,
    #     forceAtlas2Based = list(gravitationalConstant = -6000)
    #     
    #   ) 
    
    
    
    # betweenness
    # ig_between <-  as.data.frame(betweenness(transferGraph))
    # names(ig_between)[2] <- "betweenness"
    
    # edge betweeness
  
    
    ig_between <-  as.data.frame(edge.betweenness(transferGraph, weights=E(transferGraph)$weight))
    names(ig_between)[1] <- "edge_betweenness"
    ig_between <- rownames_to_column(ig_between, var="id")
    
    # other metrics are at the NODE level
    
    # coreness
    ig_coreness <-  as.data.frame(coreness(transferGraph, mode="all"))
    names(ig_coreness)[1] <- "coreness"
    ig_coreness <-  rownames_to_column(ig_coreness, var="id")
    

    
    # strength --- numbr of edges that go from one node to another
    # lower number less connected
    ig_strength <-  as.data.frame(strength(transferGraph, weights=E(transferGraph)$weight))
    names(ig_strength)[1] <- "strength"
    ig_strength <-  rownames_to_column(ig_strength, var="id")
    
    # closeness number of steps to access other nodes - higher values less
    # centrality
    
    ig_closeness <- as.data.frame(closeness(transferGraph, normalized = TRUE, weights=E(transferGraph)$weight))
    names(ig_closeness)[1] <- "closeness"
    ig_closeness <-  rownames_to_column(ig_closeness, var="id")
    
    
    # authority score -- high authority when is linked
    #by other nodes with link other nodes
    
    ig_authority <- as.data.frame(authority_score(transferGraph,scale=TRUE,
                                           weights=E(transferGraph)$weight)$vector)
    names(ig_authority)[1] <- "authority_score"
    ig_authority <-  rownames_to_column(ig_authority, var="id")
    ig_authority <- sqldf("select * from ig_authority where id != ''")
    
    
    
    hist(degree(transferGraph))
    
    cl <- clusters(transferGraph)
    plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
                                                            weights=E(transferGraph)$weight),
         vertex.color = cl$membership+1L, edge.arrow.size = 1)
    
  
    
    # remove rwonames after redundants deleted
    rownames(CCS_Basket) <- c()
    
    dissi <- dissimilarity(basket_rules, method = "Jaccard", which = "associations")
    
    dissi_m <- melt(as.matrix(dissi))
    p <- t(apply(dissi_m[,c(1,2)],1,FUN=sort))
    rmv1 <- which(p[,1] == p[,2])
    
    p <- paste(p[,1],p[,2], sep = "|")
    rmv2 <- which(duplicated(p))
    
    dissi_m <- as.data.frame(dissi_m[-c(rmv1,rmv2),])
    
    # filter to get all with score of 1
    # VAR is the index 
    dissi_m1 <- sqldf("select Var1 as rule_i, count(Var1) as rule_cnt from  dissi_m
                      where value = 1
                      group by Var1")
    
    dissi_m2 <- sqldf("select Var2 as rule_i, count(Var2) as rule_cnt from  dissi_m
                      where value = 1
                      group by Var2")
    
    distance_rule_cnt <- rbind(dissi_m1, dissi_m2)
    
    distance_rule_cnt <- sqldf("select rule_i, sum(rule_cnt) as tot_rules
                               from distance_rule_cnt
                               group by rule_i
                               order by tot_rules desc ")
    
    
    CCS_Basket<- data.frame(rule_index = row.names(CCS_Basket), CCS_Basket)
    #CCS_Basket$tot_rules <- ifelse(is.na(CCS_Basket$tot_rules), 0, CCS_Basket$tot_rules)
    CCS_Basket <- sqldf("select c.*, d.* from CCS_Basket c LEFT JOIN  distance_rule_cnt d
                        ON c.rule_index = d.rule_i
                        order by tot_rules desc")
    
    
    # ADD SNA metrics to market basket data
   
    
    CCS_Basket <- sqldf("select c.*, d.edge_betweenness from CCS_Basket c,  
                        ig_between d,
                        adj1 a
                        where d.id = a.id
                        AND a.LHS = c.LHS
                        AND a.RHS = c.RHS")
    
    CCS_Basket <- sqldf("select c.*, d.authority_score from  CCS_Basket c  
                         LEFT JOIN ig_authority d
                        ON c.LHS = d.id")
    
    
    CCS_Basket <- sqldf("select c.*, d.closeness from  CCS_Basket c  
                         LEFT JOIN ig_closeness d
                        ON c.LHS = d.id")
    
  
    CCS_Basket <- sqldf("select c.*, d.strength from  CCS_Basket c  
                         LEFT JOIN ig_strength d
                        ON c.LHS = d.id")
    
    CCS_Basket <- sqldf("select c.*, d.coreness from  CCS_Basket c  
                         LEFT JOIN ig_coreness d
                        ON c.LHS = d.id")
    
    
   
    
    CCS_Basket$rule_i <- NULL
    
    CCS_Basket2 <- CCS_Basket
    # remove jaccard from anomolay
    CCS_Basket2$count <- NULL
    
    CCS_Basket2_0 <- CCS_Basket2
    CCS_Basket2_0$rule_index <- 0
    CCS_Basket2_0$LHS <- 0
    CCS_Basket2_0$RHS <- 0
    
    learnname <- colnames(CCS_Basket2_0)
    CCS_Basket2_h2o <- as.h2o(CCS_Basket2_0 )
    
    # change field range to sql for  CCS_Basket2
    
   
    CCS_Basket2_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = CCS_Basket2_h2o, autoencoder = TRUE, 
                                           hidden = c(100,20,100), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                           categorical_encoding = "AUTO",standardize= TRUE,seed = 77,
                                           reproducible = TRUE)
  
    
    
    CCS_Basket2_h2o_dl2 = h2o.anomaly(CCS_Basket2_h2o_dl, CCS_Basket2_h2o)
    
    CCS_Basket2_h2o_dl2 <- as.data.frame(CCS_Basket2_h2o_dl2)
    
    CCS_Basket <- cbind(CCS_Basket ,CCS_Basket2_h2o_dl2)
    names(CCS_Basket)[14] <- "case_mix_MSE"
    
    CCS_Basket <- mutate(CCS_Basket, 
                         Anomaly_rank = ntile(CCS_Basket$case_mix_MSE, 10))
    CCS_Basket <- mutate(CCS_Basket, 
                         Jaccard_rank = ntile(CCS_Basket$tot_rules, 10))
    # select where jacard rank and anomaly both in upper quartile
    
    max_basket <- sqldf("select max(Anomaly_rank) as an_mx, max(Jaccard_rank) as jac_max from CCS_Basket")
    CCS_Basket <- cbind(CCS_Basket,max_basket)
    
    
    # select where jacard rank and anomaly both in upper quartile accounts for ties with max above
    # checks to see that jacard is not all constant
    if (length(unique(CCS_Basket[,"tot_rules"])) != 1) {
      CCS_Basket3 <- sqldf("select * from CCS_Basket where  jac_max = Jaccard_rank
                           and an_mx =Anomaly_rank")
    }
    
    # if jacard all constant just use MSE anomoly
    if (length(unique(CCS_Basket[,"tot_rules"])) == 1) {
      CCS_Basket3 <- sqldf("select * from CCS_Basket where an_mx =Anomaly_rank")
    }
    
    
    
    # match anomaly rule to base data
    an_hit1 <- sqldf("select a.CLAIM_ID as CLAIM_ID_x, c.* from ap2 a, CCS_Basket3 c
                     where a.CCS = c.LHS")
    
    an_hit2 <- sqldf("select a.CLAIM_ID as CLAIM_ID_x, c.* from ap2 a, CCS_Basket3 c
                     where a.CCS = c.RHS")
    
    an_hit2 <- rbind(an_hit1, an_hit2)
    
    an_hit2 <- sqldf("select distinct * from an_hit2 ")
    
    an_hit2 <- sqldf("select distinct n.*, a.* from an_hit2 a, an0 as n
                     where a.CLAIM_ID_x = n.CLAIM_ID")
    
    an_hit2$CLAIM_ID_x <- NULL
    an_hit2$rule_index <- NULL
    #an_hit2$CLUSTER <- 4
   
    
    # above checks for all columns to be constant - if so then will have no columns
    # confoirm no columns == 0
    #an_hit2 <- an_hit2[sapply(an_hit2, function(x) length(unique(na.omit(x)))) >1]
    
    if(NCOL(an_hit2) > 0) {
    outlier_temp_b_an<- bind_rows(an_hit2, outlier_temp_b_an)
    outlier_temp_b_an$SOM_CLUSTER <- as.factor(cluster1)
    
    }
    }
  }
  
}

Cluster4_casemix_summary_df <- outlier_temp_b_an

Cluster4_casemix_summary_df[is.na(Cluster4_casemix_summary_df)] <- 0

Cluster4_casemix_summary_df <- sqldf("select distinct * from Cluster4_casemix_summary_df order by Anomaly_rank desc")
#saveRDS(Cluster4_casemix_summary_df, file="sna_results1.Rda")
#Cluster4_casemix_summary_df <- readRDS(file="sna_results1.Rda")


 
 # CLUSTER 1
 # high dollar lower volume
 #################################################################################
 
 # filter for jcodes in cluster 1
 

claims_420b_string <- paste0("select  CPT from jcode_descriptives3
                             where cluster  = '",cluster2,"'")

claims_420b <- sqldf( claims_420b_string)

 

cluster2_j_claims_string <- paste0("select  c.* from claims_420a c
                                   where c.CPT IN (select CPT from jcode_descriptives3 where cluster = '",cluster2,"')")

cluster2_j_claims <- sqldf(cluster2_j_claims_string)


 
 c2_ids <- sqldf("select distinct CLAIM_ID from cluster2_j_claims")
 
 

 icd_C2_1 <- sqldf("select i.* from icd2  i,c2_ids c where i.CLAIM_ID = c.CLAIM_ID  order by CLAIM_ID")
 CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from icd_C2_1")
 
 
 CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc , sep= "_"))
 # replace with CCS
 colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test_", "",  colnames(CCS_Dummy_test)))
 # group by client id
 CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
 
 # temporarialy make claim id text
 CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)
 
 # recode if > 0 then 1 else 0 instead of summing dummies
 CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                                  function(x) case_when(
                                                    x >= 1 ~ 1,
                                                    x == 0 ~ 0
                                                  )
 )
 
 CCS_Dummy3_test <- CCS_Dummy3_test %>% mutate_if(is.numeric, funs(factor(.)))
 CCS_Dummy3_test$CLAIM_ID <- as.numeric(CCS_Dummy3_test$CLAIM_ID)
 CCS_Dummy3_test$multi_desc <- NULL
 CCS_Dummy3_test <- sqldf("select * from CCS_Dummy3_test order by CLAIM_ID")
 CCS_Dummy3_test$CLAIM_IDx <-CCS_Dummy3_test$CLAIM_ID
 CCS_Dummy3_test$CLAIM_ID <- NULL
 
 
 
 
 icd_C2_2 <- CCS_Dummy3_test
 
 
 
 cluster2_j_claims2 <- sqldf ("select CLAIM_ID, PATIENT_ID,  BILL_TYPE,CPT_MODIFIER,REVENUE_CODE,
                              PLACE_OF_SERVICE, CPT, UNITS_ALLOWED, AMT_PAID
                              from cluster2_j_claims
                              order by CPT")
 
 # merge CCS to J codes
 # the older claims have ICD9 codes do inner join
 
 cluster2_j_claims2 <- sqldf ("select j.*, i.* from   cluster2_j_claims2 j INNER join icd_C2_2 i
                              ON j.CLAIM_ID = i.CLAIM_IDX")
 
 cluster2_j_claims2$CLAIM_IDx <- NULL
 
 cluster2_j_claims2$CPT <- as.factor(cluster2_j_claims2$CPT)
 cluster2_j_claims2$CPT_MODIFIER <- as.factor(cluster2_j_claims2$CPT_MODIFIER)
 cluster2_j_claims2$REVENUE_CODE <- as.factor(as.character(cluster2_j_claims2$REVENUE_CODE))
 
 

 
 # anomalies
 
 
 outlier <- data.frame(matrix(ncol = 27, nrow = 0))
 outlier_columns <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'Congenital_anomalies',
                      'Diseases_of_the_blood', 'Diseases_of_the_circulatory_system',
                      'Diseases_of_the_digestive_system', 'Diseases_of_the_genitourinary_system', 
                      'Diseases_of_the_musculoskeletal_system_and_connective_tissue', 
                      'Diseases_of_the_nervous_system_and_sense_organs', 
                      'Diseases_of_the_respiratory_system', 
                      'Diseases_of_the_skin_and_subcutaneous_tissue', 
                      'Endocrine_metabolic_diseases_immunity_disorder', 
                      'Infectious_and_parasitic_diseases', 'Injury_and_poisoning',
                      'Mental_Illness', 'Neoplasms', 'Residual_codes', 'Symptoms_signs',
                      'CLUSTER', 'Reconstruction.MSE')
 
 outlier_temp <- data.frame(matrix(ncol = 27, nrow = 0))
 colnames(outlier) <- outlier_columns
 colnames(outlier_temp) <- outlier_columns
 
 # dummy table structure to pull from base data so that all CCS codes are included in
 # data pull
 dummy_col_names <-  c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                       'PLACE_OF_SERVICE', 'CPT', 'UNITS_ALLOWED','AMT_PAID', 'Congenital_anomalies',
                       'Diseases_of_the_blood', 'Diseases_of_the_circulatory_system',
                       'Diseases_of_the_digestive_system', 'Diseases_of_the_genitourinary_system', 
                       'Diseases_of_the_musculoskeletal_system_and_connective_tissue', 
                       'Diseases_of_the_nervous_system_and_sense_organs', 
                       'Diseases_of_the_respiratory_system', 
                       'Diseases_of_the_skin_and_subcutaneous_tissue', 
                       'Endocrine_metabolic_diseases_immunity_disorder', 
                       'Infectious_and_parasitic_diseases', 'Injury_and_poisoning',
                       'Mental_Illness', 'Neoplasms', 'Residual_codes', 'Symptoms_signs')
 
 ccsnames <- c('Congenital_anomalies',
               'Diseases_of_the_blood', 'Diseases_of_the_circulatory_system',
               'Diseases_of_the_digestive_system', 'Diseases_of_the_genitourinary_system', 
               'Diseases_of_the_musculoskeletal_system_and_connective_tissue', 
               'Diseases_of_the_nervous_system_and_sense_organs', 
               'Diseases_of_the_respiratory_system', 
               'Diseases_of_the_skin_and_subcutaneous_tissue', 
               'Endocrine_metabolic_diseases_immunity_disorder', 
               'Infectious_and_parasitic_diseases', 'Injury_and_poisoning',
               'Mental_Illness', 'Neoplasms', 'Residual_codes', 'Symptoms_signs')
 
 
 fnames <- c( 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
              'PLACE_OF_SERVICE', 'CPT')
 
 intnames <- c('PATIENT_ID', 'CLAIM_ID',
               'UNITS_ALLOWED','AMT_PAID')
 
 numnames <- c('AMT_PAID')
 
 
 dummy_pull <- data.frame(matrix(ncol = 25, nrow = 1))
 colnames(dummy_pull) <- dummy_col_names
 
 
 dummy_pull[ccsnames] <- lapply(dummy_pull[ccsnames], as.factor)
 dummy_pull[is.na(dummy_pull)] <-0
 dummy_pull[fnames] <- lapply(dummy_pull[fnames], as.factor)
 dummy_pull[is.na(dummy_pull)] <-0
 dummy_pull[intnames] <- lapply(dummy_pull[intnames], as.integer)
 dummy_pull[numnames] <- lapply(dummy_pull[numnames], as.numeric)
 
 
 
 dummy_pull[setdiff(names(cluster4_j_claims2), names(dummy_pull))] <- NA
 cluster2_j_claims2 [setdiff(names(dummy_pull), names(cluster2_j_claims2))] <- NA
 
 
 cluster2_j_claims2  <- rbind( dummy_pull,cluster2_j_claims2 )
 cluster2_j_claims2 <- sqldf("select  * from cluster2_j_claims2  where CPT != '0'")
 
 jid <- sqldf("select distinct CPT from cluster2_j_claims2")
 
 #jid <- sqldf("select distinct CPT from cluster2_j_claims2 where CPT = 'J0180'")


 for (i in rownames(jid))
 {
   jid_loop <- jid[i, ]
  
   
   j_string <- paste0("select PATIENT_ID, BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,CLAIM_ID,
                      PLACE_OF_SERVICE, CPT, UNITS_ALLOWED, AMT_PAID, Congenital_anomalies,
                      Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                      Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                      Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                      Diseases_of_the_nervous_system_and_sense_organs, 
                      Diseases_of_the_respiratory_system, 
                      Diseases_of_the_skin_and_subcutaneous_tissue, 
                      Endocrine_metabolic_diseases_immunity_disorder, 
                      Infectious_and_parasitic_diseases, Injury_and_poisoning,
                      Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs
                      from cluster2_j_claims2
                      where CPT = '",jid_loop,"'")
   
   an0 <- sqldf(j_string)
   # remnove columns that all NA from dummy
   an0[sapply(an0, function(x) all(is.na(x)))] <- NULL
   
   #jid_loop
   an1 <- an0
   an1$PATIENT_ID <- NULL
   an1$AMT_PAID <- NULL
   an1$CLAIM_ID <- NULL
   
   #const_check <- an1[,!apply(an1, MARGIN = 2, function(x) max(x,na.rm = TRUE) == min(x, na.rm = TRUE))]
   
   # above checks for all columns to be constant - if so then will have no columns
   # confoirm no columns == 0
   
   #if(dim(const_check)[2] != 0) {
     
     # remove columns with all constant
     an1 <- an1[sapply(an1, function(x) length(unique(na.omit(x)))) >1]
     # only run anomoly if have 3+ columns non constant
     if(NCOL(an1) >= 3) {
       
       
       learnname <- colnames(an1) 
       
       an1_h2o <- as.h2o(an1)
       
       an1_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = an1_h2o, autoencoder = TRUE, 
                                      hidden = c(10,2,10), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                      categorical_encoding = "AUTO")
       
       
       an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
       an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)
     
     
     outlier <- cbind(an0, an1_h2o_dl2)
     
     outlier <- data.frame(r_index = row.names(outlier), outlier)
     outlier$CLUSTER <- cluster2
     outlier_temp<- bind_rows(outlier, outlier_temp)
     #outlier_temp<- rbind(outlier, outlier_temp)
     
     }  
   
 }
 
   
   ###############################################
   # claim line outlier Mahalnobis
 outlier_temp[is.na( outlier_temp)] <- 0
   outlier_temp$MSE <- outlier_temp$Reconstruction.MSE
   
   
   # from mississippi medicaid  fee schedule
   jcode_max_units <- read.csv("CMS_Jcode_max_units.csv", sep = ",",  quote = "\"", header = TRUE)
   # add CMS max
   outlier_temp <- sqldf("select  f.*, c.Max_Units from outlier_temp f INNER JOIN jcode_max_units c
                         ON f.CPT = c.Code")
   
   # add median from baseline
   
   
   outlier_temp <- sqldf("select  f.*, c.median as BaseLine_Median_Units from outlier_temp f INNER JOIN jcode_descriptives_units c
                         ON f.CPT = c.group1")
   
   
   outlier_temp$baseline_units_ratio <- outlier_temp$UNITS_ALLOWED / outlier_temp$BaseLine_Median_Units
   outlier_temp$baseline_units_delta <- outlier_temp$UNITS_ALLOWED - outlier_temp$BaseLine_Median_Units
   
   
   # drugs discontiued or not covered by CMS are 0 add 0.01 so can do ratio
   outlier_temp$CMS_units_ratio <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED / outlier_temp$Max_Units,
                                          0)
   outlier_temp$CMS_units_delta <- ifelse(outlier_temp$Max_Units != 0, outlier_temp$UNITS_ALLOWED - outlier_temp$Max_Units,
                                          0)
   
   distance1 <- sqldf("select AMT_PAID,MSE,CMS_units_ratio from  outlier_temp")
   distance1 <- scale(distance1)
   
   
   # Mahalanobis from psych package
   distance2 <- as.data.frame(outlier(distance1, plot = FALSE, bad = 5, xlab,ylab))
   names(distance2)[1] <- "Mahalanobis"
   outlier_temp2 <- cbind(outlier_temp,distance2)
   
   
   pd_dates  <- sqlQuery(
     conn,
     " select DISTINCT
     L.CLAIM_ID,
     CLM.DATE_PAID
     FROM dbo.CLAIM_LINE L, dbo.CLAIM CLM
     WHERE L.CLAIM_ID = CLM.CLAIM_ID
     AND L.PROJECT_ID = 1138
     AND L.AMT_PAID  > 0
     AND L.CPT Like '%J%
     AND CLM.DATE_PAID >= '05-06-2018' ")
   
   
   # add add paid date filter on 420 days last paid --- for hx data hard coded to 1/5/18
   outlier_temp2<- sqldf ("select  o.* , c.DATE_PAID from outlier_temp2 o,pd_dates c
                          where  o.CLAIM_ID = c.CLAIM_ID")
   
   
   outlier_temp2 <- mutate(outlier_temp2, 
                           Mahalanobis_rank = ntile(outlier_temp2$Mahalanobis, 10))
   outlier_temp2$Reconstruction.MSE <- NULL
   
   
   outlier_temp2$Units_Anomaly <- ifelse((outlier_temp2$Mahalanobis_rank >= 8 ),
                                         1, 0)
   
   # these are units above CMS or above median of sample
   outlier_temp3_unit_hits_high <- sqldf("select * from outlier_temp2 where Units_Anomaly = 1
                                         order by Mahalanobis_rank DESC")
   # flag for above and below benchmarks
   outlier_temp3_unit_hits_high$above_benchmarks <-1
   # these are below CMS and baseline but scorredd high mahalobious and anomoly
   
   outlier_temp3_unit_hits_low <- sqldf("select * from outlier_temp2 where Units_Anomaly = 0
                                        
                                        order by Mahalanobis_rank DESC")
   
   outlier_temp3_unit_hits_low$above_benchmarks <-0
   outlier_temp3 <- rbind(outlier_temp3_unit_hits_high,outlier_temp3_unit_hits_low )
   
   
   
   outlier_temp3_unit_hits_high$r_index <- NULL
   Cluster1_claim_line_summary_df <- sqldf("select distinct * from outlier_temp3_unit_hits_high 
                                      order by Mahalanobis desc")
   
   Cluster1_claim_line_summary_df[is.na(Cluster1_claim_line_summary_df)] <- 0
   
  

   
   outlier_temp3_case_mix_hits <- sqldf("select * from outlier_temp2 where Units_Anomaly = 0
                                        
                                        order by Mahalanobis_rank DESC")
  
 
 # claim level
 
   claim_level0 <- sqldf("select CLAIM_ID, CPT, sum(UNITS_ALLOWED) as total_units, sum(AMT_PAID) as total_claim_pd
                      from outlier_temp2
                      group by CLAIM_ID, CPT")
 
 
  funk

 claim_level1 <- sqldf("select  PATIENT_ID, BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,CLAIM_ID,
                       PLACE_OF_SERVICE, CPT,  Congenital_anomalies,
                       Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                       Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                       Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                       Diseases_of_the_nervous_system_and_sense_organs, 
                       Diseases_of_the_respiratory_system, 
                       Diseases_of_the_skin_and_subcutaneous_tissue, 
                       Endocrine_metabolic_diseases_immunity_disorder, 
                       Infectious_and_parasitic_diseases, Injury_and_poisoning,
                       Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs,
                       Max_Units, CLUSTER, Units_Anomaly, Mahalanobis_rank
                       from outlier_temp2")
 
 claim_level1 <- sqldf("select  c.*, s.total_units, s.total_claim_pd 
                       from claim_level1 c, claim_level0 s
                       where c.CLAIM_ID = s.CLAIM_ID
                       AND c.CPT = s.CPT
                       and c.Units_Anomaly = 0
                       ")
 
 #####################################################################
 
 jcode_descriptives <- as.data.frame(describeBy(claim_level1,
                                                group = list(claim_level1$CPT), 
                                                mat=TRUE))
 
 jcode_descriptives_pd <- sqldf("select * from jcode_descriptives where vars = 3
                                order by mean desc")
 
 jcode_descriptives_vol <- sqldf("select * from jcode_descriptives where vars = 2
                                 order by n desc")
 
 jcode_descriptives_units <- sqldf("select * from jcode_descriptives where vars = 4
                                   order by n desc")
 
 jcode_descriptives2 <- sqldf("select v.group1 as CPT, v.n as num_admins, 
                              v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units,
                              v.median as median_num_admins, p.median as median_pd, u.median as median_units,
                              v.min as min_num_admins, v.max as max_num_admins, 
                              p.min as min_pd, p.max as max_pd,
                              u.min as min_units, u.max as max_units
                              from jcode_descriptives_pd p, jcode_descriptives_vol v, jcode_descriptives_units u
                              where v.group1 = p.group1
                              and v.group1 = u.group1
                              order by mean_pd desc")
 
 
 #####################################################################
 # claim level anomolies
 
 # remove fields for anomaly run
 
 
 #####################################################################
 
 
 
 
 outlier_b <- data.frame(matrix(ncol = 27, nrow = 0))
 outlier_columns <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                      'PLACE_OF_SERVICE', 'CPT', 'total_units', 'total_claim_pd', 'Congenital_anomalies',
                      'Diseases_of_the_blood', 'Diseases_of_the_circulatory_system',
                      'Diseases_of_the_digestive_system', 'Diseases_of_the_genitourinary_system', 
                      'Diseases_of_the_musculoskeletal_system_and_connective_tissue', 
                      'Diseases_of_the_nervous_system_and_sense_organs', 
                      'Diseases_of_the_respiratory_system', 
                      'Diseases_of_the_skin_and_subcutaneous_tissue', 
                      'Endocrine_metabolic_diseases_immunity_disorder', 
                      'Infectious_and_parasitic_diseases', 'Injury_and_poisoning',
                      'Mental_Illness', 'Neoplasms', 'Residual_codes', 'Symptoms_signs',
                      'CLUSTER', 'Reconstruction.MSE')
 
 outlier_temp_b <- data.frame(matrix(ncol = 27, nrow = 0))
 colnames(outlier_b) <- outlier_columns
 colnames(outlier_temp_b) <- outlier_columns
 
 
 # anomaly temp files
 outlier_b_an <- data.frame(matrix(ncol = 37, nrow = 0))
 outlier_columns_an <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                         'PLACE_OF_SERVICE', 'CPT', 'total_units', 'total_claim_pd', 'Congenital_anomalies',
                         'Diseases_of_the_blood', 'Diseases_of_the_circulatory_system',
                         'Diseases_of_the_digestive_system', 'Diseases_of_the_genitourinary_system', 
                         'Diseases_of_the_musculoskeletal_system_and_connective_tissue', 
                         'Diseases_of_the_nervous_system_and_sense_organs', 
                         'Diseases_of_the_respiratory_system', 
                         'Diseases_of_the_skin_and_subcutaneous_tissue', 
                         'Endocrine_metabolic_diseases_immunity_disorder', 
                         'Infectious_and_parasitic_diseases', 'Injury_and_poisoning',
                         'Mental_Illness', 'Neoplasms', 'Residual_codes', 'Symptoms_signs',
                         'CLUSTER', 'Reconstruction.MSE',
                         'LHS', 'RHS', 'support', 'confidence','lift', 'count', 'tot_rules',
                         'Jaccard_rank', 'case_mix_MSE', 'Anomaly_rank')
 
 outlier_temp_b_an <- data.frame(matrix(ncol = 37, nrow = 0))
 colnames(outlier_b_an) <- outlier_columns_an
 colnames(outlier_temp_b_an) <- outlier_columns_an
 
  jid <- sqldf("select distinct CPT from claim_level1 ")
 
 
 
 
 
 for (i in rownames(jid)) {
   jid_loop <- jid[i, ]
   
   j_string <- paste0("select PATIENT_ID, BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,CLAIM_ID,
                      PLACE_OF_SERVICE, CPT, total_units, total_claim_pd, Congenital_anomalies,
                      Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                      Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                      Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                      Diseases_of_the_nervous_system_and_sense_organs, 
                      Diseases_of_the_respiratory_system, 
                      Diseases_of_the_skin_and_subcutaneous_tissue, 
                      Endocrine_metabolic_diseases_immunity_disorder, 
                      Infectious_and_parasitic_diseases, Injury_and_poisoning,
                      Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs
                      from claim_level1
                      where CPT = '",jid_loop,"'")
   
   an0 <- sqldf(j_string)
   
   # remnove columns that all NA from dummy
   an0[sapply(an0, function(x) all(is.na(x)))] <- NULL
   
   an1 <- an0
   an1$PATIENT_ID <- NULL
   an1$total_claim_pd <- NULL
   an1$CLAIM_ID <- NULL
   an1$Units_Anomaly <- NULL
   an1$Max_Units <- NULL
   an1$total_claim_pd <- NULL
   
   # remove columns with all constant
   an1 <- an1[sapply(an1, function(x) length(unique(na.omit(x)))) >1]
   
   if(NCOL(an1) >= 3) {
     
     learnname <- colnames(an1)
     
     an1_h2o <- as.h2o(an1)
     
     an1_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = an1_h2o, autoencoder = TRUE, 
                                    hidden = c(10,2,10), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                    categorical_encoding = "AUTO")
     
     
     an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
     #head(an1_h2o_dl2 )
     
     
     
     
     an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)
     #plot(sort(an1_h2o_dl2$Reconstruction.MSE), main=i)
     
     outlier_b <- cbind(an0, an1_h2o_dl2)
     
     outlier_b <- data.frame(r_index = row.names(outlier_b), outlier_b)
     outlier_b$CLUSTER <- cluster2
     outlier_temp_b<- bind_rows(outlier_b, outlier_temp_b)
     
     
     
   }
   
 }
 
 ###############################################
 # claim outlier Mahalnobis
  outlier_temp_b[is.na( outlier_temp_b)] <- 0
  outlier_temp_b$MSE <- outlier_temp_b$Reconstruction.MSE
  
  
  
  # add CMS max
  outlier_temp_b <- sqldf("select  f.*, c.Max_Units from outlier_temp_b f INNER JOIN jcode_max_units c
                          ON f.CPT = c.Code")
  
  # add median from baseline
  
  # add median from baseline
  
  
  outlier_temp_b <- sqldf("select  f.*, c.median_units as BaseLine_Median_Units from outlier_temp_b f
                          INNER JOIN jcode_descriptives3 c
                          ON f.CPT = c.CPT")
  
  # add median from baseline
  
  
  outlier_temp_b$baseline_units_ratio <- outlier_temp_b$total_units  / outlier_temp_b$BaseLine_Median_Units
  outlier_temp_b$baseline_units_delta <- outlier_temp_b$total_units  - outlier_temp_b$BaseLine_Median_Units
  
  
  # drugs discontiued or not covered by CMS are 0 add 0.01 so can do ratio
  outlier_temp_b$CMS_units_ratio <- ifelse(outlier_temp_b$Max_Units != 0, outlier_temp_b$total_units / outlier_temp_b$Max_Units,
                                           0)
  outlier_temp_b$CMS_units_delta <- ifelse(outlier_temp_b$Max_Units != 0, outlier_temp_b$total_units - outlier_temp_b$Max_Units,
                                           0)
  
  distance1 <- sqldf("select total_claim_pd ,MSE,CMS_units_ratio from  outlier_temp_b")
  distance1 <- scale(distance1)
  
  # Mahalanobis from psych package
  distance2 <- as.data.frame(outlier(distance1, plot = FALSE, bad = 5, xlab,ylab))
  names(distance2)[1] <- "Mahalanobis"
  outlier_temp2_b <- cbind(outlier_temp_b,distance2)
  outlier_temp2_b <- mutate(outlier_temp2_b, 
                            Mahalanobis_rank = ntile(outlier_temp2_b$Mahalanobis, 10))
  outlier_temp2_b$Reconstruction.MSE <- NULL
  
  
  outlier_temp2_b$Units_Anomaly <- ifelse((outlier_temp2_b$Mahalanobis_rank >= 6 ),
                                          1, 0)
  
  # these are units above CMS or above median of sample
  outlier_temp3_unit_hits_high_b <- sqldf("select * from outlier_temp2_b where Units_Anomaly = 1
                                          order by Mahalanobis_rank DESC")
  # flag for above and below benchmarks
  outlier_temp3_unit_hits_high_b$above_benchmarks <-1
  # these are below CMS and baseline but scorredd high mahalobious and anomoly
  
  outlier_temp3_unit_hits_low_b <- sqldf("select * from outlier_temp2_b where Units_Anomaly = 0
                                         
                                         order by Mahalanobis_rank DESC")
  
  outlier_temp3_unit_hits_low_b$above_benchmarks <-0
  outlier_temp3_b <- rbind(outlier_temp3_unit_hits_high_b,outlier_temp3_unit_hits_low_b )
  
  
  outlier_temp3_unit_hits_high_b$r_index <- NULL
  Cluster1_claim_summary_df <- sqldf("select distinct * from outlier_temp3_unit_hits_high_b 
                                     order by Mahalanobis desc")
  
  Cluster1_claim_summary_df[is.na(Cluster1_claim_summary_df)] <- 0
  
  
  
  # arpriori for each J code of CCS
  
  # from claim level data extract non anomaly and mahobious < 8 for case mix
  
  if(NROW(outlier_temp_b) > 0) {
    case_ids <- sqldf("select distinct CLAIM_ID from outlier_temp2_b where Units_Anomaly = 0")}
  
  if(NROW(outlier_temp_b) == 0) {
    case_ids <- sqldf("select distinct CLAIM_ID from outlier_temp2 where Units_Anomaly = 0")}
  
  
  claim_level1 <- sqldf("select c.* from claim_level1 c,case_ids i
                        where c.CLAIM_ID = i.CLAIM_ID")
  
  # anomaly temp files
  outlier_b_an <- data.frame(matrix(ncol = 35, nrow = 0))
  outlier_columns_an <- c('PATIENT_ID', 'BILL_TYPE', 'CPT_MODIFIER', 'REVENUE_CODE','CLAIM_ID',
                          'PLACE_OF_SERVICE', 'CPT', 'total_units', 'total_claim_pd', 'Congenital_anomalies',
                          'Diseases_of_the_blood', 'Diseases_of_the_circulatory_system',
                          'Diseases_of_the_digestive_system', 'Diseases_of_the_genitourinary_system', 
                          'Diseases_of_the_musculoskeletal_system_and_connective_tissue', 
                          'Diseases_of_the_nervous_system_and_sense_organs', 
                          'Diseases_of_the_respiratory_system', 
                          'Diseases_of_the_skin_and_subcutaneous_tissue', 
                          'Endocrine_metabolic_diseases_immunity_disorder', 
                          'Infectious_and_parasitic_diseases', 'Injury_and_poisoning',
                          'Mental_Illness', 'Neoplasms', 'Residual_codes', 'Symptoms_signs',
                          'LHS', 'RHS', 'support', 'confidence','lift', 'count', 'tot_rules',
                          'Jaccard_rank', 'case_mix_MSE', 'Anomaly_rank')
  
  outlier_temp_b_an <- data.frame(matrix(ncol = 35, nrow = 0))
  colnames(outlier_b_an) <- outlier_columns_an
  colnames(outlier_temp_b_an) <- outlier_columns_an
  
  
    jid <- sqldf("select distinct CPT from claim_level1 ")
  
  
  
    
    
    for (i in rownames(jid)){
      jid_loop <- jid[i, ]
      
      j_string <- paste0("select PATIENT_ID, BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,CLAIM_ID,
                       PLACE_OF_SERVICE, CPT, total_units, total_claim_pd, Congenital_anomalies,
                       Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                       Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                       Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                       Diseases_of_the_nervous_system_and_sense_organs, 
                       Diseases_of_the_respiratory_system, 
                       Diseases_of_the_skin_and_subcutaneous_tissue, 
                       Endocrine_metabolic_diseases_immunity_disorder, 
                       Infectious_and_parasitic_diseases, Injury_and_poisoning,
                       Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs
                       from claim_level1
                       where CPT = '",jid_loop,"'")
      
      an0 <- sqldf(j_string)
      # remnove columns that all NA from dummy
      an0[sapply(an0, function(x) all(is.na(x)))] <- NULL
      
      # remove fields for anomaly run
      an1 <- an0
      an1$PATIENT_ID <- NULL
      an1$total_claim_pd <- NULL
      an1$CLAIM_ID <- NULL
      an1$Units_Anomaly <- NULL
      an1$Max_Units <- NULL
      an1$total_claim_pd <- NULL
      
      
      if(NCOL(an1) > 0) {
        
        
        
        #  CCS by claim and J code
        ap1 <- sqldf( "select distinct i.CLAIM_ID, i.multi_desc from icd_C2_1 i, an0 a
                    where i.CLAIM_ID = a.CLAIM_ID
                    order by i.CLAIM_ID")
        
        ap1 <- sqldf("select  a.*, c.multi_code as CCS_DX from ap1 a, CCSdesc c
                   where a.multi_desc = c.multi_desc")
        
        # removed modifer
        ap1$multi_desc <- NULL
        
        
        ap1$CLAIM_ID <- as.factor(as.character((ap1$CLAIM_ID)))
        ap1$CCS_DX <- as.factor(as.character((ap1$CCS_DX)))
        
        ap2 <- ddply(ap1, c("CLAIM_ID"),
                     function(ap1)paste(ap1$CCS_DX,
                                        collapse = ','))
        
        
        names(ap2)[2] <- "CCS"
        
        ap3 <- ap2
        ap3$CLAIM_ID <- NULL
        
        write.csv(ap2, file = "ccs_transactions.csv")
        
        txn <- read.transactions(file="ccs_transactions.csv", rm.duplicates = TRUE,
                                 format="single", sep=",", cols=c("CLAIM_ID","CCS"))
        
        
        
        
        # remove quotes
        txn@itemInfo$labels <- gsub("\"","",txn@itemInfo$labels)
        
        basket_rules <- apriori(txn,parameter = list(sup = 0.01, 
                                                     conf=0.01, target="rules"))
        # remove redundent rules
        basket_rules <- basket_rules[!is.redundant(basket_rules)]
        CCS_Basket <- DATAFRAME(basket_rules, separate = TRUE)
        
        # have to have at least 3 rules
        if (NROW(CCS_Basket) >=3 ){
          
          # see if LHS all empty
          # if so add 0 to LHS
         CCS_Basket <-  CCS_Basket[!sapply( CCS_Basket, function(k) all(k =="{}"))]
          
          if(NCOL(CCS_Basket) ==6){
            # remove brackets
            CCS_Basket$LHS <- gsub("[{}]","", CCS_Basket$LHS)
            CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)}
          
          if(NCOL(CCS_Basket) ==5){
            CCS_Basket$LHS <- '0'
            CCS_Basket$RHS <- gsub("[{}]","", CCS_Basket$RHS)}
          
          
          # SNA
          # nodes rule id adges are rules
          
          adj1 <- sqldf("select LHS , RHS , count as weight from CCS_Basket")
          
          # add row ids for nodes
          adj1$id <- 1:nrow(adj1)
          
          
          adj1$weight <- as.integer(adj1$weight)
          adj2 <-adj1
          adj2$id <- NULL
          
          
          # 
          transferGraph <- graph_from_data_frame(adj2, directed = TRUE)
          
          # look at other layouts in igraph
          plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
                                                                   weights=E(transferGraph)$weight),
               edge.arrow.size = .2)
          
          
          ig <- plot(basket_rules, method="graph")
          ig_df <- get.data.frame(ig,what = "both")
          
          
          visNetwork(
            nodes = data.frame(
              id = ig_df$vertices$name
              ,value = ig_df$vertices$lift  # try lift & confidence
              ,title = ifelse(ig_df$vertices$label == "", ig_df$vertices$name, ig_df$vertices$label)
              ,ig_df$vertices
            )
            , edges = ig_df$edges
          ) %>%
            visNodes(size = 10) %>%
            visLegend() %>%
            visEdges(smooth = FALSE) %>%
            visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
            visInteraction(navigationButtons = TRUE) %>%
            visEdges( arrows = 'from') %>%
            visPhysics(
              solver = "barnesHut",
              maxVelocity = 35,
              forceAtlas2Based = list(gravitationalConstant = -6000)
              
            ) 
          
          
          
          # betweenness
          # ig_between <-  as.data.frame(betweenness(transferGraph))
          # names(ig_between)[2] <- "betweenness"
          
          # edge betweeness
          
          
          ig_between <-  as.data.frame(edge.betweenness(transferGraph, weights=E(transferGraph)$weight))
          names(ig_between)[1] <- "edge_betweenness"
          ig_between <- rownames_to_column(ig_between, var="id")
          
          # other metrics are at the NODE level
          
          # coreness
          ig_coreness <-  as.data.frame(coreness(transferGraph, mode="all"))
          names(ig_coreness)[1] <- "coreness"
          ig_coreness <-  rownames_to_column(ig_coreness, var="id")
          
          
          
          # strength --- numbr of edges that go from one node to another
          # lower number less connected
          ig_strength <-  as.data.frame(strength(transferGraph, weights=E(transferGraph)$weight))
          names(ig_strength)[1] <- "strength"
          ig_strength <-  rownames_to_column(ig_strength, var="id")
          
          # closeness number of steps to access other nodes - higher values less
          # centrality
          
          ig_closeness <- as.data.frame(closeness(transferGraph, normalized = TRUE, weights=E(transferGraph)$weight))
          names(ig_closeness)[1] <- "closeness"
          ig_closeness <-  rownames_to_column(ig_closeness, var="id")
          
          
          # authority score -- high authority when is linked
          #by other nodes with link other nodes
          
          ig_authority <- as.data.frame(authority_score(transferGraph,scale=TRUE,
                                                        weights=E(transferGraph)$weight)$vector)
          names(ig_authority)[1] <- "authority_score"
          ig_authority <-  rownames_to_column(ig_authority, var="id")
          ig_authority <- sqldf("select * from ig_authority where id != ''")
          
          
          
          hist(degree(transferGraph))
          
          cl <- clusters(transferGraph)
          plot(transferGraph, layout = layout.fruchterman.reingold(transferGraph,
                                                                   weights=E(transferGraph)$weight),
               vertex.color = cl$membership+1L, edge.arrow.size = 1)
          
          
          
          # remove rwonames after redundants deleted
          rownames(CCS_Basket) <- c()
          
          dissi <- dissimilarity(basket_rules, method = "Jaccard", which = "associations")
          
          dissi_m <- melt(as.matrix(dissi))
          p <- t(apply(dissi_m[,c(1,2)],1,FUN=sort))
          rmv1 <- which(p[,1] == p[,2])
          
          p <- paste(p[,1],p[,2], sep = "|")
          rmv2 <- which(duplicated(p))
          
          dissi_m <- as.data.frame(dissi_m[-c(rmv1,rmv2),])
          
          # filter to get all with score of 1
          # VAR is the index 
          dissi_m1 <- sqldf("select Var1 as rule_i, count(Var1) as rule_cnt from  dissi_m
                          where value = 1
                          group by Var1")
          
          dissi_m2 <- sqldf("select Var2 as rule_i, count(Var2) as rule_cnt from  dissi_m
                          where value = 1
                          group by Var2")
          
          distance_rule_cnt <- rbind(dissi_m1, dissi_m2)
          
          distance_rule_cnt <- sqldf("select rule_i, sum(rule_cnt) as tot_rules
                                   from distance_rule_cnt
                                   group by rule_i
                                   order by tot_rules desc ")
          
          
          CCS_Basket<- data.frame(rule_index = row.names(CCS_Basket), CCS_Basket)
          #CCS_Basket$tot_rules <- ifelse(is.na(CCS_Basket$tot_rules), 0, CCS_Basket$tot_rules)
          CCS_Basket <- sqldf("select c.*, d.* from CCS_Basket c LEFT JOIN  distance_rule_cnt d
                            ON c.rule_index = d.rule_i
                            order by tot_rules desc")
          
          
          # ADD SNA metrics to market basket data
          
          
          CCS_Basket <- sqldf("select c.*, d.edge_betweenness from CCS_Basket c,  
                            ig_between d,
                            adj1 a
                            where d.id = a.id
                            AND a.LHS = c.LHS
                            AND a.RHS = c.RHS")
          
          CCS_Basket <- sqldf("select c.*, d.authority_score from  CCS_Basket c  
                            LEFT JOIN ig_authority d
                            ON c.LHS = d.id")
          
          
          CCS_Basket <- sqldf("select c.*, d.closeness from  CCS_Basket c  
                            LEFT JOIN ig_closeness d
                            ON c.LHS = d.id")
          
          
          CCS_Basket <- sqldf("select c.*, d.strength from  CCS_Basket c  
                            LEFT JOIN ig_strength d
                            ON c.LHS = d.id")
          
          CCS_Basket <- sqldf("select c.*, d.coreness from  CCS_Basket c  
                            LEFT JOIN ig_coreness d
                            ON c.LHS = d.id")
          
          
          
          
          CCS_Basket$rule_i <- NULL
          
          CCS_Basket2 <- CCS_Basket
          # remove jaccard from anomolay
          CCS_Basket2$count <- NULL
          
          CCS_Basket2_0 <- CCS_Basket2
          CCS_Basket2_0$rule_index <- 0
          CCS_Basket2_0$LHS <- 0
          CCS_Basket2_0$RHS <- 0
          
          learnname <- colnames(CCS_Basket2_0)
          CCS_Basket2_h2o <- as.h2o(CCS_Basket2_0 )
          
          # change field range to sql for  CCS_Basket2
          
          CCS_Basket2_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = CCS_Basket2_h2o, autoencoder = TRUE, 
                                                 hidden = c(10,2,10), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                                                 categorical_encoding = "AUTO")
          
          
          
          CCS_Basket2_h2o_dl2 = h2o.anomaly(CCS_Basket2_h2o_dl, CCS_Basket2_h2o)
          
          CCS_Basket2_h2o_dl2 <- as.data.frame(CCS_Basket2_h2o_dl2)
          
          CCS_Basket <- cbind(CCS_Basket ,CCS_Basket2_h2o_dl2)
          names(CCS_Basket)[14] <- "case_mix_MSE"
          
          CCS_Basket <- mutate(CCS_Basket, 
                               Anomaly_rank = ntile(CCS_Basket$case_mix_MSE, 10))
          CCS_Basket <- mutate(CCS_Basket, 
                               Jaccard_rank = ntile(CCS_Basket$tot_rules, 10))
          # select where jacard rank and anomaly both in upper quartile
          
          max_basket <- sqldf("select max(Anomaly_rank) as an_mx, max(Jaccard_rank) as jac_max from CCS_Basket")
          CCS_Basket <- cbind(CCS_Basket,max_basket)
          
          
          # select where jacard rank and anomaly both in upper quartile accounts for ties with max above
          # checks to see that jacard is not all constant
          if (length(unique(CCS_Basket[,"tot_rules"])) != 1) {
            CCS_Basket3 <- sqldf("select * from CCS_Basket where  jac_max = Jaccard_rank
                               and an_mx =Anomaly_rank")}
          
          # if jacard all constant just use MSE anomoly
          if (length(unique(CCS_Basket[,"tot_rules"])) == 1) {
            CCS_Basket3 <- sqldf("select * from CCS_Basket where an_mx =Anomaly_rank")}
          
          
          
          # match anomaly rule to base data
          an_hit1 <- sqldf("select a.CLAIM_ID as CLAIM_ID_x, c.* from ap2 a, CCS_Basket3 c
                         where a.CCS = c.LHS")
          
          an_hit2 <- sqldf("select a.CLAIM_ID as CLAIM_ID_x, c.* from ap2 a, CCS_Basket3 c
                         where a.CCS = c.RHS")
          
          an_hit2 <- rbind(an_hit1, an_hit2)
          
          an_hit2 <- sqldf("select distinct * from an_hit2 ")
          
          an_hit2 <- sqldf("select distinct n.*, a.* from an_hit2 a, an0 as n
                         where a.CLAIM_ID_x = n.CLAIM_ID")
          
          an_hit2$CLAIM_ID_x <- NULL
          an_hit2$rule_index <- NULL
          
          
          
         
          if(NCOL(an_hit2) > 0) {
            outlier_temp_b_an<- bind_rows(an_hit2, outlier_temp_b_an)
            outlier_temp_b_an$Cluster <- cluster2}
          
        }
      }
    }
    
  Cluster1_casemix_summary_df <- outlier_temp_b_an
  Cluster1_casemix_summary_df[is.na(Cluster1_casemix_summary_df)] <- 0
  
  Cluster1_casemix_summary_df <- sqldf("select * from Cluster1_casemix_summary_df order by Anomaly_rank desc")
  

  
  
  ######################  OOOOOOOOOOOOOOOOOOOOOOOOOOOOO
  
  # reformat output files and write out
  outputid <- sqldf("select distinct CLAIM_NO, CLAIM_ID as CLAIM_ID_x from claims_420a ")
  
  output_cluster4_line <- sqldf("select distinct
  Mahalanobis as Score, Mahalanobis_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
  PATIENT_ID, c.DATE_PAID,
  CPT, UNITS_ALLOWED,AMT_PAID, 
  Max_Units, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
  BILL_TYPE, CPT_MODIFIER, REVENUE_CODE
  PLACE_OF_SERVICE,
  Congenital_anomalies,
  Diseases_of_the_blood, Diseases_of_the_circulatory_system,
  Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
  Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
  Diseases_of_the_nervous_system_and_sense_organs, 
  Diseases_of_the_respiratory_system, 
  Diseases_of_the_skin_and_subcutaneous_tissue, 
  Endocrine_metabolic_diseases_immunity_disorder, 
  Infectious_and_parasitic_diseases, Injury_and_poisoning,
  Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs from Cluster4_claim_line_summary_df,outputid c
where  CLAIM_ID = c.CLAIM_ID_x")
  
  
  
  
  output_cluster1_line <- sqldf("select distinct
  Mahalanobis as Score, Mahalanobis_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, c.DATE_PAID,
                                CPT, UNITS_ALLOWED,AMT_PAID, 
                                Max_Units, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE
                                PLACE_OF_SERVICE,
                                Congenital_anomalies,
                                Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                                Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                                Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                                Diseases_of_the_nervous_system_and_sense_organs, 
                                Diseases_of_the_respiratory_system, 
                                Diseases_of_the_skin_and_subcutaneous_tissue, 
                                Endocrine_metabolic_diseases_immunity_disorder, 
                                Infectious_and_parasitic_diseases, Injury_and_poisoning,
                                Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs from Cluster1_claim_line_summary_df,outputid c
                                where  CLAIM_ID = c.CLAIM_ID_x")
  
  
  
  ###################
  
  outputid <- sqldf("select distinct CLAIM_NO, CLAIM_ID as CLAIM_ID_x, DATE_PAID from claims_420a ")
  
  output_cluster4_claim <- sqldf("select distinct
  Mahalanobis as Score, Mahalanobis_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, c.DATE_PAID,
                                CPT, total_units, total_claim_pd, 
                                Max_Units, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE
                                PLACE_OF_SERVICE,
                                Congenital_anomalies,
                                Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                                Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                                Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                                Diseases_of_the_nervous_system_and_sense_organs, 
                                Diseases_of_the_respiratory_system, 
                                Diseases_of_the_skin_and_subcutaneous_tissue, 
                                Endocrine_metabolic_diseases_immunity_disorder, 
                                Infectious_and_parasitic_diseases, Injury_and_poisoning,
                                Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs from Cluster4_claim_summary_df,outputid c
                                where  CLAIM_ID = c.CLAIM_ID_x")
  
  
  output_cluster1_claim <- sqldf("select distinct
  Mahalanobis as Score, Mahalanobis_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, c.DATE_PAID,
                                CPT, total_units, total_claim_pd, 
                                Max_Units, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE
                                PLACE_OF_SERVICE,
                                Congenital_anomalies,
                                Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                                Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                                Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                                Diseases_of_the_nervous_system_and_sense_organs, 
                                Diseases_of_the_respiratory_system, 
                                Diseases_of_the_skin_and_subcutaneous_tissue, 
                                Endocrine_metabolic_diseases_immunity_disorder, 
                                Infectious_and_parasitic_diseases, Injury_and_poisoning,
                                Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs from Cluster1_claim_summary_df,outputid c
                                where  CLAIM_ID = c.CLAIM_ID_x")
  
  ##############################
  
  output_cluster1_casemix <- sqldf("select distinct
                                case_mix_MSE as Score, Anomaly_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, c.DATE_PAID,
                                CPT, total_units,total_claim_pd,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE
                                PLACE_OF_SERVICE,
                                Congenital_anomalies,
                                Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                                Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                                Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                                Diseases_of_the_nervous_system_and_sense_organs, 
                                Diseases_of_the_respiratory_system, 
                                Diseases_of_the_skin_and_subcutaneous_tissue, 
                                Endocrine_metabolic_diseases_immunity_disorder, 
                                Infectious_and_parasitic_diseases, Injury_and_poisoning,
                                Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs from Cluster1_casemix_summary_df,outputid c
                                where  CLAIM_ID = c.CLAIM_ID_x")
  
  
  output_cluster4_casemix <- sqldf("select distinct
                                case_mix_MSE as Score, Anomaly_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
                                   PATIENT_ID, c.DATE_PAID,
                                   CPT, total_units,total_claim_pd,
                                   BILL_TYPE, CPT_MODIFIER, REVENUE_CODE
                                   PLACE_OF_SERVICE,
                                   Congenital_anomalies,
                                   Diseases_of_the_blood, Diseases_of_the_circulatory_system,
                                   Diseases_of_the_digestive_system, Diseases_of_the_genitourinary_system, 
                                   Diseases_of_the_musculoskeletal_system_and_connective_tissue, 
                                   Diseases_of_the_nervous_system_and_sense_organs, 
                                   Diseases_of_the_respiratory_system, 
                                   Diseases_of_the_skin_and_subcutaneous_tissue, 
                                   Endocrine_metabolic_diseases_immunity_disorder, 
                                   Infectious_and_parasitic_diseases, Injury_and_poisoning,
                                   Mental_Illness, Neoplasms, Residual_codes, Symptoms_signs from Cluster4_casemix_summary_df,outputid c
                                   where  CLAIM_ID = c.CLAIM_ID_x")
  
  
# outer joins to old data to pick up new anomalies
  # remove anomalies < baseline
  
  old_cluster_4_claim_line <- read.csv("cluster_4_claim_line.csv", sep = "\t",  quote = "\"", header = TRUE)
  old_cluster4_claim <- read.csv("cluster4_claim.csv", sep = "\t",  quote = "\"", header = TRUE)
  old_cluster_1_claim_line <- read.csv("cluster_1_claim_line.csv", sep = "\t",  quote = "\"", header = TRUE)
  old_cluster1claim  <- read.csv("cluster1claim.csv", sep = "\t",  quote = "\"", header = TRUE)

  old_cluster_4_claim_line <- sqldf("select distinct CLAIM_NO as CLAIM_NO_x from old_cluster_4_claim_line")
  old_cluster4_claim <- sqldf("select distinct CLAIM_NO as CLAIM_NO_x from old_cluster4_claim")
  old_cluster_1_claim_line <- sqldf("select distinct CLAIM_NO as CLAIM_NO_x from old_cluster_1_claim_line")
  old_cluster1claim  <- sqldf("select distinct CLAIM_NO as CLAIM_NO_x from old_cluster1claim")
  
  
  output_cluster4_line_2 <- sqldf("select distinct o.*, l.CLAIM_NO_x from output_cluster4_line o
                                  left join old_cluster_4_claim_line l
                                  on o.CLAIM_NO = l.CLAIM_NO_x")
  output_cluster4_line_2$CLAIM_NO_x <- ifelse(is.na(output_cluster4_line_2$CLAIM_NO_x), 0,
                                              output_cluster4_line_2$CLAIM_NO_x)
  output_cluster4_line <- sqldf("select * from output_cluster4_line_2
                                  where CLAIM_NO_x = 0
                                  and baseline_units_ratio > 1")
  output_cluster4_line$CLAIM_NO_x<- NULL
  
  

  output_cluster4_claim_2 <- sqldf("select distinct o.*, l.CLAIM_NO_x from output_cluster4_claim o
                                  left join old_cluster4_claim l
                                  on o.CLAIM_NO = l.CLAIM_NO_x")
  output_cluster4_claim_2$CLAIM_NO_x <- ifelse(is.na(output_cluster4_claim_2$CLAIM_NO_x), 0,
                                               output_cluster4_claim_2$CLAIM_NO_x)
  output_cluster4_claim <- sqldf("select * from output_cluster4_claim_2
                                  where CLAIM_NO_x = 0
                                  and baseline_units_ratio > 1")
  output_cluster4_claim$CLAIM_NO_x <- NULL
  
  
  output_cluster1_line_2 <- sqldf("select distinct o.*, l.CLAIM_NO_x from output_cluster1_line o
                                  left join old_cluster_1_claim_line l
                                  on o.CLAIM_NO = l.CLAIM_NO_x")
  output_cluster1_line_2$CLAIM_NO_x <- ifelse(is.na(output_cluster1_line_2$CLAIM_NO_x), 0,
                                              output_cluster1_line_2$CLAIM_NO_x)
  output_cluster1_line <- sqldf("select * from output_cluster1_line_2
                                  where CLAIM_NO_x = 0
                                  and baseline_units_ratio > 1")
  output_cluster1_line$CLAIM_NO_x <- NULL
  
  
  output_cluster1_claim_2 <- sqldf("select distinct o.*, l.CLAIM_NO_x from output_cluster1_claim o
                                  left join  old_cluster1claim l
                                  on o.CLAIM_NO = l.CLAIM_NO_x")
  output_cluster1_claim_2$CLAIM_NO_x <- ifelse(is.na(output_cluster1_claim_2$CLAIM_NO_x), 0,
                                               output_cluster1_claim_2$CLAIM_NO_x)
  output_cluster1_claim <- sqldf("select * from output_cluster1_claim_2
                                  where CLAIM_NO_x = 0
                                  and baseline_units_ratio > 1")
  output_cluster1_claim$CLAIM_NO_x <- NULL
  

  
  
  write.table(output_cluster4_line, file = "cluster_4_claim_line_7_16.csv",
              row.names = FALSE, sep ="\t")
  write.table(output_cluster4_claim, file = "cluster4_claim_7_16.csv",
              row.names = FALSE, sep ="\t")
  write.table(output_cluster4_casemix, file = "cluster4_case_mix_7_16.csv",
              row.names = FALSE, sep ="\t")

  write.table(output_cluster1_line, file = "cluster_1_claim_line_7_16.csv",
              row.names = FALSE, sep ="\t")

  write.table( output_cluster1_claim, file = "cluster1claim_7_16.csv",
              row.names = FALSE, sep ="\t")
  write.table(output_cluster1_casemix, file = "Cluster1_casemix_7_16.csv",
              row.names = FALSE, sep ="\t")
  
  
  
  
  
  
  #HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH]
  
  # healthfirst output files
  
  # add DATE_OF_SERVICE_BEG_CLAIM, DATE_OF_SERVICE_END_CLAIM  and do day diff
  
  # CLAIM LINES
  
  
  claim_line_output1 <- Cluster4_claim_line_summary_df

names(claim_line_output1)[names(claim_line_output1) == "carit"] <- 'arrythmias' 
names(claim_line_output1)[names(claim_line_output1) == 'valv'] <- 'valvular_dz'
names(claim_line_output1)[names(claim_line_output1) == 'pcd'] <- 'pulmonary_circulation_dis'
names(claim_line_output1)[names(claim_line_output1) == 'pvd'] <- 'pvd'
names(claim_line_output1)[names(claim_line_output1) == 'hypunc'] <- 'hypertension_uncomplicated'
names(claim_line_output1)[names(claim_line_output1) == 'hypc'] <- 'hypertension_complicated'
names(claim_line_output1)[names(claim_line_output1) == 'para'] <- 'paralysis'
names(claim_line_output1)[names(claim_line_output1) == 'ond'] <- 'other_neuro'
names(claim_line_output1)[names(claim_line_output1) == 'cpd'] <- 'chronic_pulmonary_dis'
names(claim_line_output1)[names(claim_line_output1) == 'diabunc'] <- 'diabetes_uncomplicated'
names(claim_line_output1)[names(claim_line_output1) == 'diabc'] <- 'diabetes_complicated'
names(claim_line_output1)[names(claim_line_output1) == 'hypothy'] <- 'hypothyroidism'
names(claim_line_output1)[names(claim_line_output1) == 'rf'] <- 'renal_failure'
names(claim_line_output1)[names(claim_line_output1) == 'ld'] <- 'liver_dis'
names(claim_line_output1)[names(claim_line_output1) == 'pud'] <- 'peptic_ulcer'
names(claim_line_output1)[names(claim_line_output1) == 'aids'] <- 'HIV'
names(claim_line_output1)[names(claim_line_output1) == 'lymph'] <- 'lymphoma'
names(claim_line_output1)[names(claim_line_output1) == 'metacanc'] <- 'metastatic_cancer'
names(claim_line_output1)[names(claim_line_output1) == 'solidtum'] <- 'solid_tumour'
names(claim_line_output1)[names(claim_line_output1) == 'rheumd'] <- 'rheumatoid_arthritis'
names(claim_line_output1)[names(claim_line_output1) == 'coag'] <- 'coagulopathy'
names(claim_line_output1)[names(claim_line_output1) == 'obes'] <- 'obesity'
names(claim_line_output1)[names(claim_line_output1) == 'wloss'] <- 'weight_loss'
names(claim_line_output1)[names(claim_line_output1) == 'fed'] <- 'fluid_electorlyte'
names(claim_line_output1)[names(claim_line_output1) == 'blane'] <- 'blood_loss_anaemia'
names(claim_line_output1)[names(claim_line_output1) == 'dane'] <- 'deficiency_anaemia'
names(claim_line_output1)[names(claim_line_output1) == 'alcohol'] <- 'alcohol_abuse'
names(claim_line_output1)[names(claim_line_output1) == 'drug'] <- 'drug_abuse'
names(claim_line_output1)[names(claim_line_output1) == 'psycho'] <- 'psychoses'
names(claim_line_output1)[names(claim_line_output1) == 'depre'] <- 'depression'
names(claim_line_output1)[names(claim_line_output1) == 'days_between_admins'] <- 'days_between_admins'
names(claim_line_output1)[names(claim_line_output1) == 'score'] <- 'Charlson_score'
names(claim_line_output1)[names(claim_line_output1) == 'wscore_ahrq'] <- 'AHRQ_score'
names(claim_line_output1)[names(claim_line_output1) == 'wscore_vw'] <- 'Elix_score'
names(claim_line_output1)[names(claim_line_output1) == 'SOM_CLUSTER'] <- 'cluster_id'

# TC only links to missings
# add TC
# NDC_TC_HCPC$HCPCS <- str_trim(as.character(NDC_TC_HCPC$HCPCS))
# claim_line_output1$CPT <- str_trim(claim_line_output1$CPT)
# junk <- sqldf("select c.*, t.Therapeutic_Class from claim_line_output1 c,
#               NDC_TC_HCPC t
#               where c.CPT = t.HCPCS")

outputid <- sqldf("select distinct CLAIM_ID as CLAIM_ID_x,  CLAIM_NO,DATE_OF_SERVICE_BEG, DATE_OF_SERVICE_END from claims_420a")
top3_dx <-  sqldf("select distinct CLAIM_ID as CLAIM_ID_x,  ICD9_CODE, ORDER_IN_CLAIM from DX_claim where ORDER_IN_CLAIM <= 2")
top3_dx1 <- sqldf("select * from top3_dx where ORDER_IN_CLAIM = 0")
top3_dx2 <- sqldf("select * from top3_dx where ORDER_IN_CLAIM = 1")
top3_dx3 <- sqldf("select * from top3_dx where ORDER_IN_CLAIM = 2")


claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX1 from claim_line_output1 c left join top3_dx1 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")

claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX2 from claim_line_output1 c left join top3_dx2 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")

claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX3 from claim_line_output1 c left join top3_dx3 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")


output_cluster1_line <- sqldf("select distinct
  Mahalanobis as Score, Mahalanobis_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, DATE_PAID, c.DATE_OF_SERVICE_BEG, c.DATE_OF_SERVICE_END,
                                CPT, UNITS_ALLOWED,AMT_PAID, 
                                Max_Units as CMS_MUE, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,
                                PLACE_OF_SERVICE,
                                LOB, days_between_admins,DX1, DX2, DX3, Charlson_score, AHRQ_score,
                                Elix_score, specialty, chf, arrythmias, valvular_dz, 
                                pulmonary_circulation_dis, pvd, hypertension_uncomplicated,
                                hypertension_complicated, paralysis, other_neuro, 
                                chronic_pulmonary_dis, diabetes_uncomplicated,
                                diabetes_complicated, hypothyroidism, renal_failure, 
                                liver_dis,peptic_ulcer, HIV, lymphoma, metastatic_cancer,
                                solid_tumour, rheumatoid_arthritis, coagulopathy, 
                                obesity, weight_loss, fluid_electorlyte,blood_loss_anaemia,
                                deficiency_anaemia, alcohol_abuse, drug_abuse,psychoses,
                                depression
                                from claim_line_output1,outputid c
                                where  CLAIM_ID = c.CLAIM_ID_x
                              order by Mahalanobis desc")

output_cluster1_line$DATE_PAID <-as.POSIXct(output_cluster1_line$DATE_PAID, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_BEG <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_BEG, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_END <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_END, origin="1970-01-01")
output_cluster1_line$Service_Days <- difftime(output_cluster1_line$DATE_OF_SERVICE_END , output_cluster1_line$DATE_OF_SERVICE_BEG, units = "days"  )


library(BBmisc)


output_cluster1_line$Score_Normalized <- normalize(output_cluster1_line$Score, method="range", range=c(0,1))



output_cluster1_line <- sqldf("select distinct
 Score_Normalized,  Score_Rank,CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, DATE_PAID, DATE_OF_SERVICE_BEG, DATE_OF_SERVICE_END,Service_Days,
                                CPT, UNITS_ALLOWED,AMT_PAID, 
                                CMS_MUE, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,
                                PLACE_OF_SERVICE,
                                LOB, days_between_admins,DX1, DX2, DX3,Charlson_score, AHRQ_score,
                                Elix_score, specialty, chf, arrythmias, valvular_dz, 
                                pulmonary_circulation_dis, pvd, hypertension_uncomplicated,
                                hypertension_complicated, paralysis, other_neuro, 
                                chronic_pulmonary_dis, diabetes_uncomplicated,
                                diabetes_complicated, hypothyroidism, renal_failure, 
                                liver_dis,peptic_ulcer, HIV, lymphoma, metastatic_cancer,
                                solid_tumour, rheumatoid_arthritis, coagulopathy, 
                                obesity, weight_loss, fluid_electorlyte,blood_loss_anaemia,
                                deficiency_anaemia, alcohol_abuse, drug_abuse,psychoses,
                                depression
                                from output_cluster1_line
                              order by Score desc", method = "name_class")

output_cluster1_line$DATE_PAID <-as.POSIXct(output_cluster1_line$DATE_PAID, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_BEG <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_BEG, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_END <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_END, origin="1970-01-01")


write.table(output_cluster1_line, file = "output_cluster1_line_6_22.csv",
            row.names = FALSE, sep ="\t")



#LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


# CLAIMS



claim_line_output1 <- Cluster4_claim_summary_df

names(claim_line_output1)[names(claim_line_output1) == "carit"] <- 'arrythmias' 
names(claim_line_output1)[names(claim_line_output1) == 'valv'] <- 'valvular_dz'
names(claim_line_output1)[names(claim_line_output1) == 'pcd'] <- 'pulmonary_circulation_dis'
names(claim_line_output1)[names(claim_line_output1) == 'pvd'] <- 'pvd'
names(claim_line_output1)[names(claim_line_output1) == 'hypunc'] <- 'hypertension_uncomplicated'
names(claim_line_output1)[names(claim_line_output1) == 'hypc'] <- 'hypertension_complicated'
names(claim_line_output1)[names(claim_line_output1) == 'para'] <- 'paralysis'
names(claim_line_output1)[names(claim_line_output1) == 'ond'] <- 'other_neuro'
names(claim_line_output1)[names(claim_line_output1) == 'cpd'] <- 'chronic_pulmonary_dis'
names(claim_line_output1)[names(claim_line_output1) == 'diabunc'] <- 'diabetes_uncomplicated'
names(claim_line_output1)[names(claim_line_output1) == 'diabc'] <- 'diabetes_complicated'
names(claim_line_output1)[names(claim_line_output1) == 'hypothy'] <- 'hypothyroidism'
names(claim_line_output1)[names(claim_line_output1) == 'rf'] <- 'renal_failure'
names(claim_line_output1)[names(claim_line_output1) == 'ld'] <- 'liver_dis'
names(claim_line_output1)[names(claim_line_output1) == 'pud'] <- 'peptic_ulcer'
names(claim_line_output1)[names(claim_line_output1) == 'aids'] <- 'HIV'
names(claim_line_output1)[names(claim_line_output1) == 'lymph'] <- 'lymphoma'
names(claim_line_output1)[names(claim_line_output1) == 'metacanc'] <- 'metastatic_cancer'
names(claim_line_output1)[names(claim_line_output1) == 'solidtum'] <- 'solid_tumour'
names(claim_line_output1)[names(claim_line_output1) == 'rheumd'] <- 'rheumatoid_arthritis'
names(claim_line_output1)[names(claim_line_output1) == 'coag'] <- 'coagulopathy'
names(claim_line_output1)[names(claim_line_output1) == 'obes'] <- 'obesity'
names(claim_line_output1)[names(claim_line_output1) == 'wloss'] <- 'weight_loss'
names(claim_line_output1)[names(claim_line_output1) == 'fed'] <- 'fluid_electorlyte'
names(claim_line_output1)[names(claim_line_output1) == 'blane'] <- 'blood_loss_anaemia'
names(claim_line_output1)[names(claim_line_output1) == 'dane'] <- 'deficiency_anaemia'
names(claim_line_output1)[names(claim_line_output1) == 'alcohol'] <- 'alcohol_abuse'
names(claim_line_output1)[names(claim_line_output1) == 'drug'] <- 'drug_abuse'
names(claim_line_output1)[names(claim_line_output1) == 'psycho'] <- 'psychoses'
names(claim_line_output1)[names(claim_line_output1) == 'depre'] <- 'depression'
names(claim_line_output1)[names(claim_line_output1) == 'days_between_admins'] <- 'days_between_admins'
names(claim_line_output1)[names(claim_line_output1) == 'score'] <- 'Charlson_score'
names(claim_line_output1)[names(claim_line_output1) == 'wscore_ahrq'] <- 'AHRQ_score'
names(claim_line_output1)[names(claim_line_output1) == 'wscore_vw'] <- 'Elix_score'
names(claim_line_output1)[names(claim_line_output1) == 'SOM_CLUSTER'] <- 'cluster_id'

# TC only links to missings
# add TC
# NDC_TC_HCPC$HCPCS <- str_trim(as.character(NDC_TC_HCPC$HCPCS))
# claim_line_output1$CPT <- str_trim(claim_line_output1$CPT)
# junk <- sqldf("select c.*, t.Therapeutic_Class from claim_line_output1 c,
#               NDC_TC_HCPC t
#               where c.CPT = t.HCPCS")

outputid <- sqldf("select distinct CLAIM_ID as CLAIM_ID_x,  CLAIM_NO,DATE_OF_SERVICE_BEG, DATE_OF_SERVICE_END from claims_420a")
top3_dx <-  sqldf("select distinct CLAIM_ID as CLAIM_ID_x,  ICD9_CODE, ORDER_IN_CLAIM from DX_claim where ORDER_IN_CLAIM <= 2")
top3_dx1 <- sqldf("select * from top3_dx where ORDER_IN_CLAIM = 0")
top3_dx2 <- sqldf("select * from top3_dx where ORDER_IN_CLAIM = 1")
top3_dx3 <- sqldf("select * from top3_dx where ORDER_IN_CLAIM = 2")


claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX1 from claim_line_output1 c left join top3_dx1 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")

claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX2 from claim_line_output1 c left join top3_dx2 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")

claim_line_output1 <- sqldf("select c.*, t.ICD9_CODE as DX3 from claim_line_output1 c left join top3_dx3 t
                            ON c.CLAIM_ID = t.CLAIM_ID_x")


output_cluster1_line <- sqldf("select distinct
  Mahalanobis as Score, Mahalanobis_rank as Score_Rank,c.CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, DATE_PAID, c.DATE_OF_SERVICE_BEG, c.DATE_OF_SERVICE_END,
                                CPT, UNITS_ALLOWED,AMT_PAID, 
                                Max_Units as CMS_MUE, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,
                                PLACE_OF_SERVICE,
                                LOB, days_between_admins,DX1, DX2, DX3, Charlson_score, AHRQ_score,
                                Elix_score, specialty, chf, arrythmias, valvular_dz, 
                                pulmonary_circulation_dis, pvd, hypertension_uncomplicated,
                                hypertension_complicated, paralysis, other_neuro, 
                                chronic_pulmonary_dis, diabetes_uncomplicated,
                                diabetes_complicated, hypothyroidism, renal_failure, 
                                liver_dis,peptic_ulcer, HIV, lymphoma, metastatic_cancer,
                                solid_tumour, rheumatoid_arthritis, coagulopathy, 
                                obesity, weight_loss, fluid_electorlyte,blood_loss_anaemia,
                                deficiency_anaemia, alcohol_abuse, drug_abuse,psychoses,
                                depression
                                from claim_line_output1,outputid c
                                where  CLAIM_ID = c.CLAIM_ID_x
                              order by Mahalanobis desc")

output_cluster1_line$DATE_PAID <-as.POSIXct(output_cluster1_line$DATE_PAID, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_BEG <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_BEG, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_END <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_END, origin="1970-01-01")
output_cluster1_line$Service_Days <- difftime(output_cluster1_line$DATE_OF_SERVICE_END , output_cluster1_line$DATE_OF_SERVICE_BEG, units = "days"  )


#library(BBmisc)


output_cluster1_line$Score_Normalized <- normalize(output_cluster1_line$Score, method="range", range=c(0,1))



output_cluster1_line <- sqldf("select distinct
 Score_Normalized,  Score_Rank,CLAIM_NO,CLAIM_ID,
                                PATIENT_ID, DATE_PAID, DATE_OF_SERVICE_BEG, DATE_OF_SERVICE_END,Service_Days,
                                CPT, UNITS_ALLOWED,AMT_PAID, 
                                CMS_MUE, BaseLine_Median_Units, baseline_units_ratio, baseline_units_delta, CMS_units_ratio, CMS_units_delta,
                                BILL_TYPE, CPT_MODIFIER, REVENUE_CODE,
                                PLACE_OF_SERVICE,
                                LOB, days_between_admins,DX1, DX2, DX3,Charlson_score, AHRQ_score,
                                Elix_score, specialty, chf, arrythmias, valvular_dz, 
                                pulmonary_circulation_dis, pvd, hypertension_uncomplicated,
                                hypertension_complicated, paralysis, other_neuro, 
                                chronic_pulmonary_dis, diabetes_uncomplicated,
                                diabetes_complicated, hypothyroidism, renal_failure, 
                                liver_dis,peptic_ulcer, HIV, lymphoma, metastatic_cancer,
                                solid_tumour, rheumatoid_arthritis, coagulopathy, 
                                obesity, weight_loss, fluid_electorlyte,blood_loss_anaemia,
                                deficiency_anaemia, alcohol_abuse, drug_abuse,psychoses,
                                depression
                                from output_cluster1_line
                              order by Score desc", method = "name_class")

output_cluster1_line$DATE_PAID <-as.POSIXct(output_cluster1_line$DATE_PAID, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_BEG <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_BEG, origin="1970-01-01")
output_cluster1_line$DATE_OF_SERVICE_END <-as.POSIXct(output_cluster1_line$DATE_OF_SERVICE_END, origin="1970-01-01")


write.table(output_cluster1_line, file = "output_cluster1_claim_6_22.csv",
            row.names = FALSE, sep ="\t")


#output_cluster1_line_6_22  <- read.csv("output_cluster1_claim_6_22.csv", header=TRUE, sep="\t")


conn99 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;database=racerresearch;
                         UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')



sqlSave(conn99,output_cluster1_line_6_22,tablename="dbo.output_cluster1_line_6_22",rownames=FALSE)

# scp dless1@apsrd9425:/home/dless1/healthfirst/output_cluster1_line_6_22.csv /H/My_Doccuments
# scp dless1@apsrd9425:/home/dless1/healthfirst/output_cluster1_claim_6_22.csv /H/My_Doccuments

