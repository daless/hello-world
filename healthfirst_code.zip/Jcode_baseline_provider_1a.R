
# based upon LA Jcode_baseline_5B

# creates 3 year baseline data
#SOM clusters
# prvovider specialty
# CCS rollups




setwd("~/healthfirst")
library(comorbidity)
library(RODBC)
library(sqldf)
library(psych)

# library(plyr)
# library(dplyr)
# library(icd)
# 
# library(dummies)
# library(data.table)
# library(ggplot2)
# library(dataMaid)
library(lubridate)
# library(NbClust)
# library(cluster)
library(tidyr)
# library(factoextra)
# library(proxy)
# library(tibble)
# library(network)
# # descriptive stats
# library(Hmisc)

# 
# library(arules)
# library(arulesViz)
# library(visNetwork)
# library(igraph)


#library(h2o)
#h2o.init()
########h2o.init(port=54322)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)





conn_medicare = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01288;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)

# junk <- sqlQuery(conn_medicare, 
#                 "select * from dbo.CLAIM_LINE with (nolock)",
#                  max = 10)

#claim_fields <- sqlColumns(conn_medicare, "dbo.CLAIM"  )

#table_listing <- as.data.frame(sqlTables(conn))

#table_listing <- sqldf("select * from table_listing where TABLE_SCHEM = 'dbo' order by TABLE_NAME")

#claim <- sqlColumns(conn, "dbo.ICD9"  )
#claim <- sqlColumns(conn, "dbo.CLAIM"  )


#library(h2o)
#h2o.init()


# 3 yers hx data to set baselines


claims_line_medicare <- sqlQuery(
  conn_medicare,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 1095
  AND L.CPT Like '%J%'
  ")

claims_line_medicare$LOB <- "MEDICARE"


# remove human FACTOR

claims_line_medicare <- sqldf("select * from claims_line_medicare where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")


conn_medicaid = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01289;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_medicaid <- sqlQuery(
  conn_medicaid,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 1095
  AND L.CPT Like '%J%'
  ")

claims_line_medicaid$LOB <- "MEDICAID"


# remove human FACTOR

claims_line_medicaid <- sqldf("select * from claims_line_medicaid where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")




conn_comm = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0809.aimhealth.com;DATABASE=racer01290;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)



claims_line_comm <- sqlQuery(
  conn_comm,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.PROVIDER_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  CLM.DATE_PAID,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 1095
  AND L.CPT Like '%J%'
  ")

claims_line_comm$LOB <- "COMM"


# remove human FACTOR

claims_line_comm <- sqldf("select * from claims_line_comm where CPT not in ('J7177', 'J7178', 'J7179', 'J7180', 
                                                           'J7181', 'J7182', 'J7183', 'J7184',
                                                           'J7185', 'J7186', 'J7187', 'J7188',
                                                           'J7189', 'J7190', 'J7191', 'J7192',
                                                           'J7193', 'J7194', 'J7195', 'J7196',
                                                           'J7197', 'J7198', 'J7199', 'J7200',
                                                           'J7201', 'J7202', 'J7203', 'J7204',
                                                           'J7205', 'J7206', 'J7207', 'J7208',
                                                           'J7209', 'J7210', 'J7211')")

claims_line_180 <- rbind(claims_line_medicare, claims_line_medicaid, claims_line_comm)

special1 <- readRDS(file="special1.Rda")
claims_line_180 <- sqldf("select c.*, p.specialty from claims_line_180 c, special1 p
              where c.PROVIDER_ID = p.PROVIDER_ID")


saveRDS(claims_line_180, file="claims_line_180.Rda")
#claims_line_180 <- readRDS(file="claims_line_180.Rda")


jcode_cnt <- sqldf("select CPT,  CLAIM_NO, count(CLAIM_NO) as jcnt, sum(AMT_PAID) as paid,
                   sum(UNITS_BILLED) as billed_units
                   from claims_line_180
                   group by CPT, CLAIM_NO
                   order by CPT")



jcode_cnt2 <- jcode_cnt
jcode_cnt2$CLAIM_NO <- NULL

# jcode claim line descriptives

jcode_descriptives <- as.data.frame(describeBy(jcode_cnt2,
                                               group = list(jcode_cnt2$CPT), 
                                               mat=TRUE))

jcode_descriptives_pd <- sqldf("select * from jcode_descriptives where vars = 3
                            order by mean desc")

jcode_descriptives_vol <- sqldf("select * from jcode_descriptives where vars = 2
                            order by n desc")

jcode_descriptives_units <- sqldf("select * from jcode_descriptives where vars = 4
                            order by n desc")

jcode_descriptives2 <- sqldf("select v.group1 as CPT, v.n as num_admins, 
                             v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units,
                             v.median as median_num_admins, p.median as median_pd, u.median as median_units,
                             v.min as min_num_admins, v.max as max_num_admins, 
                             p.min as min_pd, p.max as max_pd,
                             u.min as min_units, u.max as max_units
                             from jcode_descriptives_pd p, jcode_descriptives_vol v, jcode_descriptives_units u
                             where v.group1 = p.group1
                             and p.group1 = u.group1
                             order by mean_pd desc")





# time between administrations

# Added 1 to days so could convert NAs to 0


library(dplyr)
library(data.table)

jcode_time <- claims_line_180 %>%
  arrange( CLAIM_ID, CPT,DATE_OF_SERVICE_BEG) %>%
  group_by(CLAIM_ID, CPT) %>%
  dplyr:::mutate(diff = DATE_OF_SERVICE_BEG - lag(DATE_OF_SERVICE_BEG,1))

# rx add 1 to all days so 0 is NA and those on same day coded as a 1
jcode_time$days_between_admins = jcode_time$diff/ddays(1)
jcode_time$days_between_admins <- ifelse(is.na(jcode_time$days_between_admins),
                                         0, jcode_time$days_between_admins + 1)


jcode_time <- sqldf("select * from jcode_time",method = "name_class")
jcode_time$diff <- NULL



# jcode_time <- funk %>%
#   arrange( CLAIM_NO, CPT,DATE_OF_SERVICE_BEG) %>%
#   group_by(CLAIM_NO, CPT, DATE_OF_SERVICE_BEG_CLAIM) %>%
#   mutate(previous = lag(DATE_OF_SERVICE_BEG, 1)) %>%
#   mutate(diff = difftime( DATE_OF_SERVICE_END , lag(DATE_OF_SERVICE_BEG,))) %>%
#   mutate(diff2 = DATE_OF_SERVICE_END  - lag(DATE_OF_SERVICE_BEG)) %>%
#   mutate(diff3 = as.duration(DATE_OF_SERVICE_END  %--% lag(DATE_OF_SERVICE_BEG))) %>%
#   mutate(diff4 = diff3/ddays(1))


# 
# saveRDS(jcode_time, file="jcode_time.Rda")
#jcode_time <- readRDS(file="jcode_time.Rda")




jcode_time2 <- sqldf("select CPT,  days_between_admins
                   from jcode_time
                  ")

jcode_time_descriptives <- as.data.frame(describeBy(jcode_time2,
                                                    group = list(jcode_time2$CPT),
                                                    mat=TRUE))

jcode_descriptives_time <- sqldf("select * from jcode_time_descriptives where vars = 2 order by n desc")



jcode_descriptives2 <- sqldf("select v.group1 as CPT, v.n as num_admins,
                             v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units, t.mean as mean_days,
                             v.median as median_num_admins, p.median as median_pd, u.median as median_units, t.median as median_days,
                             v.min as min_num_admins, v.max as max_num_admins,t.max as max_days,
                             p.min as min_pd, p.max as max_pd,
                             u.min as min_units, u.max as max_units
                             from jcode_descriptives_pd p, jcode_descriptives_vol v,
                             jcode_descriptives_units u, jcode_descriptives_time t
                             where v.group1 = p.group1
                             and v.group1 = u.group1
                             and v.group1 = t.group1
                             order by mean_pd desc")


#jcode_descriptives2$total_paid <- jcode_descriptives2$num_admins * jcode_descriptives2$mean_pd

# calcualte deciles
jcode_descriptives2 <- mutate(jcode_descriptives2, 
                              total_paid_rank = ntile(jcode_descriptives2$median_pd, 10))


jcode_descriptives2 <- mutate(jcode_descriptives2, 
                              total_admins_rank = ntile(jcode_descriptives2$median_num_admins, 10))


high_dol_vol <- sqldf("select * from jcode_descriptives2 where
total_paid_rank = 10 
and  total_admins_rank >= 6")


saveRDS(jcode_descriptives2, file="jcode_descriptives2.Rda")
#jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")


library(ggplot2)
library(NbClust)
library(cluster)
library(factoextra)
# clustering rather than deciles

data_2_cluster <- sqldf("select median_num_admins, median_pd from jcode_descriptives2 ")

#scale and make data a matric=x for clusters

data_2_cluster2 <- scale(data_2_cluster)

# force to max of 5

nb <- NbClust(data_2_cluster2, diss = NULL, distance = "euclidean",
              min.nc = 2, max.nc = 5, method = "kmeans",
              index = "all", alphaBeale = 0.1)

hist(nb$Best.nc[1,], breaks = max(na.omit(nb$Best.nc[1,])))


km <- kmeans(data_2_cluster2, centers = 5, nstart = 25)
fviz_cluster (km, data =data_2_cluster2 , pointsize = 0.5, labelsize = 2, main = "Clusters of Paid Amount and Number Claims Normalized")

# extract cluster assignment vector from the kmeans model
clust_km <- km$cluster
table(som2$clustering)
centers <- as.data.frame(km$centers)
# add cluster to dataframe
jcode_descriptives3_initial <- mutate(jcode_descriptives2, cluster = clust_km)

#  J3399 mean $208,3337.000	chemo  cluster 5
# J2560  cluster 4 high dollar low admins
# J3398 low $ high admins


detach("package:psych", unload = TRUE)
detach("package:dplyr", unload = TRUE)

library(SOMbrero)
library(kohonen)



data_2_cluster <- sqldf("select median_num_admins, median_pd
                        from jcode_descriptives2 ")

#scale and make data a matric=x for clusters

data_2_cluster2 <- scale(data_2_cluster)
distance0_scale <- scale(data_2_cluster2)
som2 <- trainSOM(x.data = distance0_scale, dimension = c(2,4), nb.save = 10, maxit = 500,
                 scaling = "none")

# don't plot SOM locks up
table(som2$clustering)


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=8)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)

# save SOM output
# descriptives by cluster
#saveRDS(som_dist, file="som_dist.Rda")
# cluster membership
#saveRDS(som_diste, file="som_diste.Rda")
#som_diste <- readRDS(file="som_diste.Rda")



targ <- cbind(jcode_descriptives2,som_diste)

# #rename
names(targ)[20] <- 'SOM_CLUSTER'

#table(targ$SOM_CLUSTER)
#targ$case_1224_hit <- as.factor(as.character(targ$case_1224_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))


micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
library(dummies)
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
#micro_cluster$SOM_CLUSTER <- NULL

#summary(distance0)
library(psych)
SOM_descriptives <- as.data.frame(describeBy(targ,
                                             group = list(targ$SOM_CLUSTER), 
                                             mat=TRUE))


SOM_descriptives_pd <- sqldf("select * from SOM_descriptives where vars = 4
                            order by mean desc")

SOM_descriptives_vol <- sqldf("select * from SOM_descriptives where vars = 7
                            order by n desc")

SOM_descriptives_units <- sqldf("select * from SOM_descriptives where vars = 9
                            order by n desc")

SOM_descriptives_time <- sqldf("select * from SOM_descriptives where vars = 6
                            order by n desc")

SOM_descriptives2 <- sqldf("select v.group1 as micro_cluster, v.n as num_admins, 
                             v.mean as mean_num_admins, p.mean as mean_pd, u.mean as mean_units,
                             v.median as median_num_admins, p.median as median_pd, u.median as median_units, 
                             t.median as median_days,
                             v.min as min_num_admins, v.max as max_num_admins, 
                             p.min as min_pd, p.max as max_pd,
                             u.min as min_units, u.max as max_units,
                             t.min as min_time, t.max as max_time
                             from SOM_descriptives_pd p, SOM_descriptives_vol v, SOM_descriptives_units u,
                             SOM_descriptives_time t
                             where v.group1 = p.group1
                             and v.group1 = u.group1
                             and v.group1 = t.group1
                             order by mean_pd desc")


#saveRDS(targ, file="targ.Rda")
#targ <- readRDS(file="targ.Rda")

#saveRDS(SOM_descriptives2, file="SOM_descriptives2.Rda")
#SOM_descriptives2 <- readRDS(file="SOM_descriptives2.Rda")
#jcode_descriptives2 <- readRDS(file="jcode_descriptives2.Rda")

# SOM_descriptives2 has the mappings of cluster to J code




# provider specialty


prov_comm <- sqlQuery(
  conn_comm,
  " select
  CLM.PROVIDER_ID,
  count(CLM.PROVIDER_ID) as CNT,
  L.ICD9_CODE,
  count(L.ICD9_CODE) as ICD9_CODE_CNT,
  sum(CLM.AMT_PAID) as TOT_PAID
   FROM dbo.ICD9 L with (nolock), dbo.CLAIM CLM with (nolock)
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND CLM.AMT_PAID  > 1
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) <= 680
  AND DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) >= 120
  AND  L.ORDER_IN_CLAIM <= 5
  group by CLM.PROVIDER_ID, L.ICD9_CODE
  ")

prov_comm$ICD9_CODE<-as.character(prov_comm$ICD9_CODE)
prov_comm$ICD10_CODE<- prov_comm$ICD9_CODE
prov_comm$ICD9_CODE<- gsub(".","",prov_comm$ICD9_CODE,fixed=TRUE)

# this is after CCS code has been parsed
#CCS$multi_desc <- substr(CCS$CCS_Category,1,3)


CCSROLLUP <- read.csv("CCSROLLUP.txt", header = TRUE, sep="\t")



prov_comm2 <- sqldf("select i.*, c.multi_desc from  DX_claim i,CCS c where
              i.ICD9_CODE = c.ICD10_CODE ")
prov_comm2 <- sqldf("select c.*, i.CCS_roll_up from  CCSROLLUP i,prov_comm2 c where
              i.multi_desc = c.multi_desc ")






prov_comm3 <- sqldf("select PROVIDER_ID, count(PROVIDER_ID) as prov_cnt,
                    CCS_roll_up as multi_desc,
                    count(CCS_roll_up) as tot_dx
                    from prov_comm2
                    group by PROVIDER_ID,
                    CCS_roll_up
                    order by PROVIDER_ID, tot_dx desc
                    ")


prov_comm_top3 <- data.table(prov_comm3, key="PROVIDER_ID")
prov_comm_top3 <-prov_comm_top3[, head(.SD, 3), by=PROVIDER_ID]
prov_comm_top3 <- sqldf("select PROVIDER_ID,  multi_desc,tot_dx from prov_comm_top3 order by PROVIDER_ID, tot_dx desc")

prov_comm_top3$num <- ave(prov_comm_top3$multi_desc, prov_comm_top3$PROVIDER_ID, FUN = seq_along)

special1 <- sqldf("select PROVIDER_ID, multi_desc as spec1 from prov_comm_top3 where num = 1")
special2 <- sqldf("select PROVIDER_ID, multi_desc as spec2  from prov_comm_top3  where num = 2")
special3 <- sqldf("select PROVIDER_ID, multi_desc as spec3  from prov_comm_top3 where num = 3")

special1 <- sqldf("select s.* , x.spec2 from special1 s left join special2 x
                  on s.PROVIDER_ID = x.PROVIDER_ID")
special1 <- sqldf("select s.* , x.spec3 from special1 s left join special3 x
                  on s.PROVIDER_ID = x.PROVIDER_ID")

special1$spec2<- ifelse(is.na(special1$spec2), '', 
                        special1$spec2)
special1$spec3<- ifelse(is.na(special1$spec3), '', 
                        special1$spec3)
special1$specialty <- do.call(paste, c(special1[c("spec1", "spec2", "spec3")],sep="_" ))

saveRDS(special1, file="special1.Rda")








# HCPC theraputic class for final report
# NDC_TC <- read.csv("NDC_TC.txt", header = TRUE, sep="\t")
# NDC_HCPC <- read.csv("NDC_HCPC3.txt", header = TRUE, sep="\t")
# 
# 
# NDC_TC_HCPC <- sqldf("select distinct t.*, h.HCPCS from NDC_HCPC h left join NDC_TC t
#                      on h.NDC = t.NDC_Code")
# 
# NDC_TC_HCPC$Therapeutic_Class <- ifelse(is.na(NDC_TC_HCPC$Therapeutic_Class),'MISSING', NDC_TC_HCPC$Therapeutic_Class)


