setwd("~/aetna")





library(comorbidity)
library(RODBC)
library(sqldf)
library(dplyr)




conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)

# 
# 
# 
# stuff = sqlQuery(
#   conn,
#   "SELECT  p.* from RACER00222.dbo.PARS p,RACER00222.dbo.CLAIM_STATUS s
# where s.CLAIM_ID = p.ORIG_CLAIM_ID
# and p.post_OPTUM_LEAKAGE_FLAG='1' 
# and  p.PROJECT_ID=222
# and  p.Age_at_time_of_claim >18
# and  p.Age_at_time_of_claim < 65
# and s.CASE_ID=1224
# and s.STATUS_CODE in (2,50,55)
# and s.CURRENT_STATUS=1
# AND ( p.externalvendor like '%COB%'		
#      AND left( p.externalvendor,5) <> 'OPTUM'	
#      AND left( p.externalvendor,3) <> 'AIM')",
#   max=100)      
# 
# 
# 
case_id_list <- sqlQuery(
  conn,
  "SELECT  * from RACER00222.dbo.CASE_DATA CD
  where CASE_ID = 566")



aetna_pars = sqlQuery(
  conn,
  "SELECT  p.* from racerresearch.dbo.PARS p
where p.post_OPTUM_LEAKAGE_FLAG='1' 
and  p.PROJECT_ID=222
and  p.Age_at_time_of_claim >18
and  p.Age_at_time_of_claim < 65

AND ( p.externalvendor like '%COB%'		
     AND left( p.externalvendor,5) <> 'OPTUM'	
     AND left( p.externalvendor,3) <> 'AIM')")


# and DATEDIFF(D,  p.ORIGINAL_DATE_PAID, GETDATE()) < 730
# CLAIM_ID
# and status_code in (2,50,55) and current_status=1


statuses = sqlQuery(
  conn, "select * from racer00222.dbo.Claim_Status
where case_id=1224 ")  


# other commercial insurance no hits
Other_Insurance_Is_Primary = sqlQuery(
  conn, "select * from racer00222.dbo.Claim_Status
where case_id=566 ")  


# only 30 aetna in PARS and staus with case_id = 1224
stuff <- sqldf ("select a.* from aetna_pars a, statuses s
                     where a.ORIG_CLAIM_ID = s.CLAIM_ID")





cs_A = sqlQuery(
  conn,
  "SELECT DISTINCT c.PATIENT_ID,
  c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,SUBSTRING(c.CLAIM_NO, 1, 12) AS CLAIM_CLAIM_NO                                                                          
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID 
,c.PROJECT_ID
,c.INS_GROUP_ID
,c.GROUP_SIZE
,c.PROVIDER_ID
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID

from racer00222.DBO.CLAIM c
INNER JOIN racer00222.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
INNER JOIN racer00222.dbo.Claim_Status cs                                                                        
on c.claim_id = cs.claim_id
  WHERE c.PROJECT_ID = 222
  and c.CLAIM_ID IS NOT NULL
  and cs.case_id=1224
  and c.PATIENT_AGE > 18
  and c.PATIENT_AGE <65
  ")


cs_A$case_control <-1

control_group1 <-  sqlQuery(
  conn,
  "SELECT DISTINCT c.PATIENT_ID,
  c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,SUBSTRING(c.CLAIM_NO, 1, 12) AS CLAIM_CLAIM_NO                                                                          
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID 
,c.PROJECT_ID
,c.INS_GROUP_ID
,c.GROUP_SIZE
,c.PROVIDER_ID
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
from racer00222.DBO.CLAIM c
INNER JOIN racer00222.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
INNER JOIN racer00222.dbo.Claim_Status cs                                                                        
on c.claim_id = cs.claim_id
  WHERE c.PROJECT_ID = 222
  and c.CLAIM_ID IS NOT NULL
  and case_id !=1224
  and c.PATIENT_AGE > 18
  and c.PATIENT_AGE <65
  and DATEDIFF(D,  c.DATE_PAID, GETDATE()) < 90")
  
  
control_group1$case_control <-0


cs_b <- rbind(cs_A ,control_group1[,names(cs_A)] )

#saveRDS(cs_b, file="cs_b.Rda")

DX_claim_cc  <- sqlQuery(
  conn,
  " select
  DISTINCT c.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM racer00222.dbo.CLAIM c
  INNER JOIN racer00222.dbo.ICD9 DX
  ON c.CLAIM_ID = DX.CLAIM_ID
  where c.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 5
  and c.PATIENT_AGE > 18
  and c.PATIENT_AGE <65
  and DATEDIFF(D,  c.DATE_PAID, GETDATE()) < 90"
)

cl_id_cc <- sqldf("select distinct CLAIM_CLAIM_ID from cs_b ")


library(dplyr)

#library(tidyverse)

DX_claim_cc <- inner_join(DX_claim_cc, cl_id_cc, by = c("CLAIM_ID" = "CLAIM_CLAIM_ID") )





DX_claim_cc$ICD9_CODE<-as.character(DX_claim_cc$ICD9_CODE)
DX_claim_cc$ICD10_CODE<-DX_claim_cc$ICD9_CODE
DX_claim_cc$ICD9_CODE<-gsub(".","",DX_claim_cc$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim_cc, file="DX_claim_cc.Rda")



#DX_claim_cc <- readRDS(file="DX_claim_cc.Rda")



DX_claimids_Diag_cc <- sqldf("select distinct * from DX_claim_cc where ICD9_TYPE='DIAG' order by 
                             CLAIM_ID,ORDER_IN_CLAIM")

#charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")


elixhauser_scores_cc <- comorbidity(x=DX_claimids_Diag_cc , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores_cc, file="elixhauser_scores_cc.Rda")

elixhauser_scores_cc <- elixhauser_scores_cc[,1:33]

elixhauser_scores_cc2<- elixhauser_scores_cc %>%
  mutate_if(is.numeric, ~as.factor(as.character(.)))

elixhauser_scores_cc2$CLAIM_ID <- as.numeric(elixhauser_scores_cc2$CLAIM_ID)

elixhauser_scores_cc2$CLAIM_IDx <-elixhauser_scores_cc2$CLAIM_ID 



cs_c <- sqldf("select distinct c.*, e.* from cs_b c, elixhauser_scores_cc2 e
              where c.CLAIM_CLAIM_ID  = e.CLAIM_IDx")

saveRDS(cs_c, file="cs_c.Rda")

library(MatchIt)

cs_c$case_control <- as.factor(as.character(cs_c$case_control))
#str(cs_c,list.len = ncol(cs_c))
cs_c$CLAIM_IDx <- NULL
cs_c$CLAIM_DATE_RECEIVED<- NULL
cs_c$GROUP_SIZE<- NULL
cs_c$CLAIM_DATE_ENTERED<- NULL
cs_c$CLAIM_LINE_LINE_NO <- NULL
cs_c$CLAIM_LINE_DATE_PAID<- NULL
cs_c$CLAIM_LINE_CPT_MODIFIER<- NULL

cs_c$CLAIM_LINE_REVENUE_CODE <- ifelse(is.na(cs_c$CLAIM_LINE_REVENUE_CODE), 0, 
                                       cs_c$CLAIM_LINE_REVENUE_CODE)
cs_c$CLAIM_LINE_CPT <- ifelse(is.na(cs_c$CLAIM_LINE_CPT), '0', 
                                       cs_c$CLAIM_LINE_CPT)

colnames(cs_c)[colSums(is.na(cs_c)) > 0]


cs_c$age_group <- cut(cs_c$CLAIM_PATIENT_AGE,
                      breaks=c(-Inf,35,45,66,Inf),
                      labels=c(1,2,3,4))

cs_c$CLAIM_PLACE_OF_SERVICE <- as.factor(cs_c$CLAIM_PLACE_OF_SERVICE)

deletes <- c('CLAIM_LINE_REVENUE_CODE', 
             'CLAIM_LINE_AMT_BILLED', 
             'CLAIM_LINE_AMT_PAID', 
             'CLAIM_LINE_CPT', 
             'CLAIM_LINE_LINE_NO', 
             'CLAIM_LINE_CPT_MODIFIER', 
             'CLAIM_LINE_AMT_ALLOWED', 
             'CLAIM_LINE_DATE_PAID')

cs_c <- cs_c[,setdiff(names(cs_c),deletes)]

cs_c <- sqldf("select distinct * from cs_c")

# reduce size on controls

control2 <- sqldf("select * from cs_c where case_control = 0")

cases2 <- sqldf("select * from cs_c where case_control = 1")


set.seed(77)
idx <- sample(seq(1,2), size = nrow(control2), replace = TRUE, prob = c(0.001, 0.099))
control2 <- control2[idx == 1,]

cases3 <- rbind(control2,cases2 )



library(optmatch)
library(rgenoud)
library(psych)

# changed from 2 to 5:1
matched_optimal <- matchit(case_control ~ age_group + CLAIM_PATIENT_GENDER + CLAIM_PLACE_OF_SERVICE,
                           data =cases3, method = "optimal" , ratio = 5, optmatch_max_problem_size = Inf)

summary(matched_optimal)

#atched_genetic <- matchit(case_control ~  age_group + CLAIM_PATIENT_GENDER + CLAIM_PLACE_OF_SERVICE,
#                          data =cases3, method = "genetic" , optmatch_max_problem_size = Inf)

pre_matched <- match.data(matched_optimal)



str(pre_matched,list.len = ncol(pre_matched))

pre_matched2 <- pre_matched 

pre_matched2$PATIENT_ID <- NULL
pre_matched2$CLAIM_CLAIM_NO <- NULL
pre_matched2$CLAIM_FEED_ID <- NULL
pre_matched2$CLAIM_PAR<- NULL
pre_matched2$age_group<- NULL
pre_matched2$distance <- NULL
pre_matched2$weights<- NULL
pre_matched2$subclass<- NULL
pre_matched2$CLAIM_ID<- NULL
pre_matched2$PROJECT_ID <- NULL
pre_matched2$CLAIM_DATE_PAID<- NULL
pre_matched2$CLAIM_AMT_BILLED<- NULL
pre_matched2$CLAIM_DATE_DISCHARGED<- NULL
pre_matched2$CLAIM_DATE_ADMITTED<- NULL
pre_matched2$CLAIM_DATE_OF_SERVICE_END <- NULL
pre_matched2$CLAIM_DATE_OF_SERVICE_BEG <- NULL
pre_matched2$CLAIM_CLAIM_ID  <- NULL
pre_matched2$PROVIDER_ID  <- NULL


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)
# build CCS dx table

# pre_matched2 <- distinct(pre_matched2 %>%
#                      left_join(select(CCS, CCS_Category,ICD10_Code), 
#                                by = c("ICD10_Code" = "CLAIM_PRINCIPAL_DIAG")))

pre_matched2$CLAIM_PRINCIPAL_DIAG<-as.character(pre_matched2$CLAIM_PRINCIPAL_DIAG)
pre_matched2$CLAIM_PRINCIPAL_DIAG<-gsub(".","",pre_matched2$CLAIM_PRINCIPAL_DIAG,fixed=TRUE)

pre_matched2 <- sqldf("select distinct p.*, c.CCS_Category
                      from pre_matched2 p left join CCS c  on
                      p.CLAIM_PRINCIPAL_DIAG = c.ICD10_Code")

pre_matched2$CCS_Category <- ifelse(is.na(pre_matched2$CCS_Category), 0, pre_matched2$CCS_Category)

pre_matched2$CCS_Category <-as.factor(pre_matched2$CCS_Category)
pre_matched2$CLAIM_PRINCIPAL_DIAG <- NULL
pre_matched2$CLAIM_AMT_ALLOWED <- NULL
pre_matched2$CLAIM_PROVIDER_ID <- as.factor(as.character((pre_matched2$CLAIM_PROVIDER_ID)))
pre_matched2$INS_GROUP_ID <- as.factor(as.character((pre_matched2$INS_GROUP_ID)))
pre_matched2$score <- as.numeric(as.character(pre_matched2$score))
pre_matched2$CLAIM_PROVIDER_ID<- NULL
pre_matched2$INS_GROUP_ID<- NULL

#library(h2o)
#h2o.init(port=54333)

idx <- sample(seq(1,2), size = nrow(pre_matched2), replace = TRUE, prob = c(0.7, 0.3))
train <- pre_matched2[idx == 1,]
test <- pre_matched2[idx == 2,]

test_false_mod2 <- test

#str(test_false_mod2,list.len = ncol(test_false_mod2))


train_auto_ml <- train
test_auto_ml <- test


train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "case_control"
x <- setdiff(names(train), y)



response <- "case_control"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)

nfolds = 10

rf_3 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         validation_frame = test,
                         ntrees = 500,
                         nfolds = nfolds,
                         nbins = 50,
                         balance_classes = TRUE,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)

# pred_rf_3 <- h2o.performance(rf_3, newdata = test,  valid = TRUE)
# pred_rf_3

summary(rf_3)

head(as.data.frame(h2o.varimp(rf_3)),n=100)


(describeBy(pre_matched2,pre_matched2$case_control))

describeData(pre_matched2)




numlist <- c(names(Filter(is.numeric,pre_matched2)))
#pre_matched2_numerics <- match(numlist, names(pre_matched2))

modelList <- lapply(numlist, function(resp) {
  mF <- formula(paste(resp,"~ case_control" ))
  aov(mF, data = pre_matched2)
})

lapply(modelList, summary)

# anova loop

# anova_formula <- as.formula(paste0("cbind(", paste(names(pre_matched2_numerics), collapse = ","), ") ~ case_control"))
# 
# amnova_fit <- aov(anova_formula, data = pre_matched2)


# chi square loop

factor_list3 <- c(names(Filter(is.factor,pre_matched2)))
fact_match3 <- match(factor_list3, names(pre_matched2))
catVarsFac <- pre_matched2[,fact_match3]

nms <- names(catVarsFac)


result <- sapply(nms, FUN = function(x, catVarsFac) {
  qinq <- catVarsFac[, c("case_control", x)]
  by(data = qinq, INDICES = catVarsFac$case_control, FUN = function(y, qinq) {
    chisq.test(table(y[, x]), p =  table(qinq[, x]), rescale.p = TRUE)
  }, qinq = qinq)
}, catVarsFac = catVarsFac, simplify = FALSE)




