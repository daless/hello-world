
# 5B reduced number of features


setwd("~/aetna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(NbClust)
library(cluster)
library(broom)
library(factoextra)
library(proxy)
library(reshape2)
library(plyr)
library(kamila)
library(cluster)
library(MASS)

#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)





conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

#######################################################

# with new analytics table



# C.CLAIM_NO is the unique claim key

# old sample was at 500

distinct_members <- sqlQuery( conn, "select DISTINCT  C.PAT_MEMBER_NO, C.CLAIM_NO
                   FROM dbo.AetnaDuplicateResearch C
                  ORDER by C.PAT_MEMBER_NO, C.CLAIM_NO", max = 1500)



member_multi <- sqldf("select PAT_MEMBER_NO 
                     from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")



# junk <- sqlQuery( conn, "select *
#                    FROM dbo.AetnaDuplicateResearch C
#                               where Claimant_Number = '162623343D02'")
#glimpse(junk)
# 
# str(junk, list.len=ncol(junk))
# 


# member_multix <- member_multi
# 
# member_multi <- sqldf("select * from member_multix limit 50")

# 
# write.table(member_multi, file = "member_multi.csv",
#             row.names = FALSE, sep ="\t")
# 
# 
# member_multi <- read.csv("member_multi.csv", header=TRUE, sep="\t")
# 
# 
# member_multi <- sqldf("select * from member_multi where PAT_MEMBER_NO = 10009040500042400")
# 



# dupe score file to append to


scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 7, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','PAID_1', 'PAID_2', 'SCORE')
score_record_temp <- data.frame(matrix(ncol = 7, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims
claim_example <- sqlQuery(conn, "SELECT  C.ROWID
                     ,C.Account
                          ,C.Business_Line
                          ,C.CL_AMT_ALLOWED
                          ,C.CL_AMT_BILLED
                          ,C.CL_AMT_PAID
                          ,C.CL_DATE_OF_SERVICE_BEG
                          ,C.CL_DATE_OF_SERVICE_END
                          ,C.CL_DATE_PAID
                          ,C.CLAIM_NO
                          ,C.CLAIM_NUMBER
                          ,C.CLAIM_SUFFIX
                          ,C.Claimant_Number
                          ,C.Claims_Status
                          ,C.Coinsurance_Amt
                          ,C.Copay_Amt
                          ,C.CPT
                          ,C.Deductible_Amt
                          ,C.DIAGNOSIS_1
                          ,C.DIAGNOSIS_10
                          ,C.DIAGNOSIS_11
                          ,C.DIAGNOSIS_2
                          ,C.DIAGNOSIS_3
                          ,C.DIAGNOSIS_4
                          ,C.DIAGNOSIS_5
                          ,C.DIAGNOSIS_6
                          ,C.DIAGNOSIS_7
                          ,C.DIAGNOSIS_8
                          ,C.DIAGNOSIS_9
                          ,C.Employer_Group_No
                          ,C.Funding_Arrangement_Code
                          ,C.Line_Of_Business
                          ,C.Other_Ins_Paid_Amt
                          ,C.PAT_MEMBER_NO
                          ,C.PIN7
                          ,C.Place_Of_Service
                          ,C.PRINCIPAL_DIAG
                          ,C.Procedure_Code
                          ,C.PROCEDURE_CODE_2
                          ,C.PROVIDER_NO
                          ,C.REVENUE_CODE
                          ,C.Suffix
                          ,C.TAX_ID
                          ,C.Type_Of_Service
                          ,C.Universal_Claim_Key
                          FROM dbo.AetnaDuplicateResearch C where C.CLAIM_NO = 'X' ")








#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0(
    "
    SELECT  C.ROWID
    ,C.Account
    ,C.Business_Line
    ,C.CL_AMT_ALLOWED
    ,C.CL_AMT_BILLED
    ,C.CL_AMT_PAID
    ,C.CL_DATE_OF_SERVICE_BEG
    ,C.CL_DATE_OF_SERVICE_END
    ,C.CL_DATE_PAID
    ,C.CLAIM_NO
    ,C.CLAIM_NUMBER
    ,C.CLAIM_SUFFIX
    ,C.Claimant_Number
    ,C.Claims_Status
    ,C.Coinsurance_Amt
    ,C.Copay_Amt
    ,C.CPT
    ,C.Deductible_Amt
    ,C.DIAGNOSIS_1
    ,C.DIAGNOSIS_10
    ,C.DIAGNOSIS_11
    ,C.DIAGNOSIS_2
    ,C.DIAGNOSIS_3
    ,C.DIAGNOSIS_4
    ,C.DIAGNOSIS_5
    ,C.DIAGNOSIS_6
    ,C.DIAGNOSIS_7
    ,C.DIAGNOSIS_8
    ,C.DIAGNOSIS_9
    ,C.Employer_Group_No
    ,C.Funding_Arrangement_Code
    ,C.Line_Of_Business
    ,C.Other_Ins_Paid_Amt
    ,C.PAT_MEMBER_NO
    ,C.PIN7
    ,C.Place_Of_Service
    ,C.PRINCIPAL_DIAG
    ,C.Procedure_Code
    ,C.PROCEDURE_CODE_2
    ,C.PROVIDER_NO
    ,C.REVENUE_CODE
    ,C.Suffix
    ,C.TAX_ID
    ,C.Type_Of_Service
    ,C.Universal_Claim_Key
    FROM dbo.AetnaDuplicateResearch C
    WHERE C.PAT_MEMBER_NO  ='",
    memberid,
    "'"
  )
  
  cl_dup1 <- sqlQuery(conn, mem_string)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- sqldf("select distinct PAT_MEMBER_NO from cl_dup1")
    
    dupes <- cl_dup1
    
    dupes <- dupes %>%
      mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
             CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
             CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
      )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    dupes <- dupes %>%
      mutate(CLAIM_SUFFIX = as.factor(as.character(CLAIM_SUFFIX)),
             DIAGNOSIS_1 = as.factor(as.character(DIAGNOSIS_1)),
             DIAGNOSIS_2  =  as.factor(as.character(DIAGNOSIS_2)),
             DIAGNOSIS_3  =  as.factor(as.character(DIAGNOSIS_3)),
             DIAGNOSIS_4  =  as.factor(as.character(DIAGNOSIS_4)),
             DIAGNOSIS_5  =  as.factor(as.character(DIAGNOSIS_5)),
             DIAGNOSIS_6  =  as.factor(as.character(DIAGNOSIS_6)),
             DIAGNOSIS_7  =  as.factor(as.character(DIAGNOSIS_7)),
             DIAGNOSIS_8  =  as.factor(as.character(DIAGNOSIS_8)),
             DIAGNOSIS_9  =  as.factor(as.character(DIAGNOSIS_9)),
             DIAGNOSIS_10  =  as.factor(as.character(DIAGNOSIS_10)),
             DIAGNOSIS_11  =  as.factor(as.character(DIAGNOSIS_11)),
             Employer_Group_No  = 
               as.factor(as.character(Employer_Group_No)),
             Funding_Arrangement_Code  = 
               as.factor(as.character(Funding_Arrangement_Code)),
             PAT_MEMBER_NO  =  as.factor(as.character(PAT_MEMBER_NO)),
             PIN7  =  as.factor(as.character(PIN7)),
             Place_Of_Service  = 
               as.factor(as.character(Place_Of_Service)),
             Procedure_Code  = 
               as.factor(as.character(Procedure_Code)),
             #Procedure_Code2  =  as.factor(as.character(Procedure_Code2)),
             PROVIDER_NO  =  as.factor(as.character(PROVIDER_NO)),
             REVENUE_CODE   =  as.factor(as.character(REVENUE_CODE)),
             Suffix   =  as.factor(as.character(Suffix)),
             Type_Of_Service   = 
               as.factor(as.character(Type_Of_Service)),
             Universal_Claim_Key   = 
               as.factor(as.character(Universal_Claim_Key)),
             CLAIM_NO  =  as.factor(CLAIM_NO)
             
             
      )
    
   
    
    dupes$ROWID <- NULL
    dupes$PAT_MEMBER_NOPAT_MEMBER_NO <- NULL
    
    
    #GOWER
    
    # gower works across the table not just numeric
    
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    hits <- hits[1,]
    
    r_hits <- hits[, 1]
    c_hits <- hits[, 2]
    
    # row ids
    r_hits_i <- cl_dup1[r_hits, 1]
    c_hits_i <- cl_dup1[c_hits, 1]
    
    # paid amounts
    p1_hits <- dupes[r_hits, 5]
    p2_hits <- dupes[c_hits, 5]
    
    
    score_record_temp <- score_record_temp %>%
      mutate(ROWID_1 = r_hits_i,
             ROWID_2 = c_hits_i,
             PAID_1 = p1_hits,
             PAID_2 = p2_hits,
             SCORE  = member_score,
             METHOD = "Gower"
        
      )
    
    score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
    
    score_record <- rbind(score_record, score_record_temp)
    
    cl_dup3 <-
      sqldf(
        "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
        OR d.ROWID = s.ROWID_2"
      )
    claim_example <- rbind(claim_example, cl_dup3)
    
    
    
    
    
  }
}

score_record[is.na(score_record)] <-0

score_record$score_transformed <- log(score_record$SCORE)

perfect_match <- score_record
perfect_match %>% filter(score_record$SCORE == 1)

near_match <- score_record
near_match %>% filter(score_record$SCORE < 1)

# top 1 % near match
near_match %>% filter(SCORE < quantile(near_match$SCORE, 0.99))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")




write.table(score_record2, file = "traditional_Gower_scoresc.csv",
           row.names = FALSE, sep ="\t")

# write.table(score_record, file = "traditional_Gower_scores_sample.csv",
#             row.names = FALSE, sep ="\t")
# 
# write.table(claim_example, file = "claim_example.csv",
#             row.names = FALSE, sep ="\t")
# 



 #perfect <- sqlQuery(conn, "select * from dbo.AetnaDuplicateResearch where 
#ROWID = 22212076 OR ROWID = 22212077")
# 
# perfect_95 <- sqlQuery(conn, "select * from dbo.AetnaDuplicateResearch where ROWID = 4978114 OR ROWID = 4978110")


data_2_cluster <- sqldf("select PAID_1, SCORE from score_record where SCORE < 1 and SCORE > 0.99")

data_2_cluster_base <- data_2_cluster

data_2_cluster2 <- scale(data_2_cluster)

nb <- NbClust(data_2_cluster2, diss = NULL, distance = "euclidean",
              min.nc = 2, max.nc = 5, method = "kmeans",
              index = "all", alphaBeale = 0.1)

hist(nb$Best.nc[1,], breaks = max(na.omit(nb$Best.nc[1,])))


km <- kmeans(data_2_cluster2, centers = 4, nstart = 25)
fviz_cluster (km, data =data_2_cluster2 , pointsize = 0.5, labelsize = 2, main = "Clusters of Paiamount and Distance Score Normalized")

# extract cluster assignment vector from the kmeans model
clust_km <- km$cluster

# add cluster to dataframe
data_2_cluster3 <- mutate(data_2_cluster_base, cluster = clust_km)

write.table(data_2_cluster3, file = "traditional_Gower_scores_cluster.csv",
            row.names = FALSE, sep ="\t")


# box plot by cluster

ggplot(data_2_cluster_base, aes(y=SCORE, x= cluster)) + geom_boxplot() + theme_gray()
