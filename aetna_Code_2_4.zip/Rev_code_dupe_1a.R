

setwd("~/aetna")


library(tidyverse)
library(sqldf)
library(dplyr)
library(readr)
library(RecordLinkage)
library(tidyr)



# 
# library(odbc)
# 
# connn <- dbConnect(odbc(),
#                    driver='ODBCSQLSvr',
#                    server='dbswp0625.aimhealth.com',
#                    database='RACERRESEARCH',
#                    uid='COBUnixToSQL',
#                    pwd='COBUn!xT0Sql')

library(RODBC)


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

#library(DBI)


 rev_code_list <- c(360,361,362,367,369)
# 
# distinct_membersq <- DBI::dbSendQuery( connn, statement = paste(
#   "SELECT DISTINCT PAT_MEMBER_NO, CLAIM_NO FROM dbo.AetnaDuplicateResearch where REVENUE_CODE in(360,361,362,367,369) ",
#   "ORDER BY PAT_MEMBER_NO, CLAIM_NO"))
# 
# distinct_members <- dbFetch(distinct_membersq, n=2000)
# 
# 
# member_multi <- sqldf("select PAT_MEMBER_NO 
#                       from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

 

 
distinct_membersq <- sqlQuery(conn,"SELECT  CLAIM_NO, PAT_MEMBER_NO, PROVIDER_NO, Account ,Business_Line ,
                              Line_Of_Business , Type_Of_Service ,REVENUE_CODE,
                              PROCEDURE_CODE_2, CL_AMT_PAID, CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END
                              FROM dbo.AetnaDuplicateResearch 
                              where REVENUE_CODE in(360,361,362,367,369)", max = 40000)


member_multi <- sqldf("select PAT_MEMBER_NO 
                      from distinct_membersq group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

distinct_members <- sqldf("select m.* from distinct_membersq m, member_multi i
                where i.PAT_MEMBER_NO = m.PAT_MEMBER_NO ")

distinct_members <- data.frame(r_index = row.names(distinct_members), distinct_members)

claims1 <- distinct_members
#claims1$r_index <- NULL
claims1$CLAIM_NO <- NULL




claims1$PAT_MEMBER_NO <- as.character(claims1$PAT_MEMBER_NO)
claims1$PROVIDER_NO  <- as.character(claims1$PROVIDER_NO)
claims1$Account  <- as.character(claims1$Account)
claims1$Business_Line  <- as.character(claims1$Business_Line)
claims1$Line_Of_Business   <- as.character(claims1$Line_Of_Business )
claims1$Type_Of_Service    <- as.character(claims1$Type_Of_Service  )
claims1$REVENUE_CODE    <- as.character(claims1$REVENUE_CODE  )
claims1$PROCEDURE_CODE_2    <- as.character(claims1$PROCEDURE_CODE_2  )
claims1$CL_AMT_PAID    <- as.character(claims1$CL_AMT_PAID  )
claims1$CL_DATE_OF_SERVICE_BEG    <- as.character(claims1$CL_DATE_OF_SERVICE_BEG )
claims1$CL_DATE_OF_SERVICE_END    <- as.character(claims1$CL_DATE_OF_SERVICE_END )

str(claims1)
rpairs <- compare.dedup(claims1, blockfld = c("PAT_MEMBER_NO", "PROVIDER_NO", "Account" ,"Business_Line" ,
                                              "Line_Of_Business" , "Type_Of_Service" ,"REVENUE_CODE"),
                        identity = claims1$r_index
                        ,strcmp = TRUE )
summary(rpairs)
rpairs <- emWeights(rpairs)
hist(rpairs$Wdata, plot=FALSE)
summary(rpairs)

match1 <- as.data.frame(getPairs(rpairs, 55,50, single.rows=TRUE))

# rename
names(match1)[2] <-"r_index_1"
names(match1)[15] <-"r_index_2"

match1 <- sqldf("select d.CLAIM_NO as CLAIM_NO_2, m.* from match1 m, distinct_members d
                where d.r_index = m.r_index_2")

match1 <- sqldf("select d.CLAIM_NO as CLAIM_NO_1, m.* from match1 m, distinct_members d
                where d.r_index = m.r_index_1")



names(match1)[12] <-"PROCEDURE_CODE_2_1"
names(match1)[13] <-"CL_AMT_PAID_1"

match_counts <- sqldf("select  PROCEDURE_CODE_2_1, count(PROCEDURE_CODE_2_1) as Total,
                      sum(CL_AMT_PAID_1) / count(id1) as Average_Paid_Amount
                      from match1 group by PROCEDURE_CODE_2_1
                      order by Total desc")

write.table(match_counts, file = "match_counts.csv",
            row.names = FALSE, sep ="\t")

write.table(match1, file = "one_line_per_pair.csv",
            row.names = FALSE, sep ="\t")

###############################################################

#looping logic



revcode <- sqlQuery(conn,"SELECT REVENUE_CODE
                    FROM dbo.AetnaDuplicateResearch 
                    group by REVENUE_CODE")
# do in blocks of 5


#for (i in rownames(revcode))
#{

revcode_z <- revcode[i, ]
revcode_z <- as.character(revcode_z)


mem_string <- paste0("CLAIM_NO, PAT_MEMBER_NO, PROVIDER_NO, Account ,Business_Line ,
                     Line_Of_Business , Type_Of_Service ,REVENUE_CODE,
                     PROCEDURE_CODE_2, CL_AMT_PAID, CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END
                     FROM dbo.AetnaDuplicateResearch 
                     where REVENUE_CODE  ='",revcode_z,"'")


member_multi <- sqldf("select PAT_MEMBER_NO 
                      from distinct_membersq group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

distinct_members <- sqldf("select m.* from distinct_membersq m, member_multi i
                          where i.PAT_MEMBER_NO = m.PAT_MEMBER_NO ")

distinct_members <- data.frame(r_index = row.names(distinct_members), distinct_members)

claims1 <- distinct_members
#claims1$r_index <- NULL
claims1$CLAIM_NO <- NULL




claims1$PAT_MEMBER_NO <- as.character(claims1$PAT_MEMBER_NO)
claims1$PROVIDER_NO  <- as.character(claims1$PROVIDER_NO)
claims1$Account  <- as.character(claims1$Account)
claims1$Business_Line  <- as.character(claims1$Business_Line)
claims1$Line_Of_Business   <- as.character(claims1$Line_Of_Business )
claims1$Type_Of_Service    <- as.character(claims1$Type_Of_Service  )
claims1$REVENUE_CODE    <- as.character(claims1$REVENUE_CODE  )
claims1$PROCEDURE_CODE_2    <- as.character(claims1$PROCEDURE_CODE_2  )
claims1$CL_AMT_PAID    <- as.character(claims1$CL_AMT_PAID  )
claims1$CL_DATE_OF_SERVICE_BEG    <- as.character(claims1$CL_DATE_OF_SERVICE_BEG )
claims1$CL_DATE_OF_SERVICE_END    <- as.character(claims1$CL_DATE_OF_SERVICE_END )


rpairs <- compare.dedup(claims1, blockfld = c("PAT_MEMBER_NO", "PROVIDER_NO", "Account" ,"Business_Line" ,
                                              "Line_Of_Business" , "Type_Of_Service" ,"REVENUE_CODE"),
                        identity = claims1$r_index
                        ,strcmp = TRUE )

rpairs <- emWeights(rpairs)
summary(rpairs)
match1 <- as.data.frame(getPairs(rpairs, 1.0,0.8, single.rows=TRUE))

# get calim no 1 and 2






