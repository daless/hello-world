#make clusters of group id ,  ploduct line
# find ratio of refunds to toal number of members
# calc ratio billed to paid ? segments or overall


# ? cluster CCS groups - spherical K means - or neural net feature reduction without a target

# SOM - ratio clusters, specialty, comorbidity scores


setwd("~/aetna")


library(comorbidity)
library(RODBC)
library(sqldf)
#library(dplyr)
library(tidyverse)
library(dummies)
library(SOMbrero)
library(kohonen)
library(broom)




# scp analytic_data2020_0_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp FIPS_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp USDA.txt dless1@apsrd9425:/home/dless1/aetna


# connection: dbswp0625
# database: RacerResearch
# schema: dbo
# view: vwAetnaTradMemClaimCoverage



conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)



base1 <- sqlQuery(
  conn,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,
CLM.AMT_DISALLOWED,
CLM.AMT_COB_PAID,
CLM.AMT_DISCOUNT,
CLM.AMT_COVERED,
CLM.AMT_NOT_COVERED,
CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,
SF.FIELD19,
MEM.member_ID,MEM.MEMBER_NO, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
as cd_SUBCATEGORY, CS.STATUS_CODE, cs.amt_of_refund as Amount_refund,cs.case_id
FROM dbo.CLAIM CLM  with (nolock)
INNER JOIN dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
INNER JOIN dbo.CASE_DATA CD  with (nolock)
ON CS.CASE_ID = CD.CASE_ID
INNER JOIN dbo.STATUS_CODE SC  with (nolock)
ON CS.STATUS_CODE = SC.STATUS_CODE
INNER JOIN dbo.SPECIAL_FIELDS SF  with (nolock)
ON CLM.CLAIM_ID = SF.ID
WHERE CS.HDS_LOB_ID = 2
AND CD.SUBCATEGORY = 10
AND cs.CURRENT_STATUS = 1
AND CS.STATUS_CODE IN (2,50,55)
AND CLM.PROJECT_ID = 222
AND IsValidSSN = 1
and CLM.FEED_ID between 150 and 209
")

WHERE CS.HDS_LOB_ID = 2
AND CD.SUBCATEGORY = 10
AND CS.STATUS_CODE IN (2,50,55)
AND CLM.PROJECT_ID = 222
AND IsValidSSN = 1
--and clm.feed_id between 150 and 200
--AND CLM.PATIENT_AGE < 65
--AND CLM.PATIENT_AGE > 18
--and CLM.DATE_OF_SERVICE_END >  (Getdate() - 365)
and ISNULL(CLM.AMT_PAID, 0) > 0

base1$Days_of_service <- difftime("2021-1-1",base1$DATE_OF_SERVICE_END ,
                                                  units = c("days")) 

base1$Days_of_service <- as.integer(base1$Days_of_service)

base1 <- sqldf(
  "select DISTINCT *
FROM base1
WHERE Days_of_service <= 365
and  PATIENT_AGE between 18 and 64
  and AMT_PAID > 0")



summary(base1
        )


DX_claim  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.CLAIM CLM  with (nolock)
  INNER JOIN DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  where CLM.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 5
  and CLM.FEED_ID >= 150
  and CLM.FEED_ID <= 208
AND CLM.PATIENT_AGE < 65
AND CLM.PATIENT_AGE > 18
and  DATEDIFF(D,   CLM.DATE_OF_SERVICE_END, GETDATE()) < 365
and ISNULL(CLM.AMT_PAID, 0) > 0
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)



refund_members <- sqldf("select distinct PATIENT_ID,
INS_GROUP_ID,
PRODUCT_LINE_ID,
LINE_OF_BUSINESS_ID
                        from base1")

non_refund_members <-  sqlQuery(
  conn,
  "select DISTINCT
CLM.PATIENT_ID,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.LINE_OF_BUSINESS_ID

FROM dbo.CLAIM CLM  with (nolock)
INNER JOIN dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
INNER JOIN dbo.CASE_DATA CD  with (nolock)
ON CS.CASE_ID = CD.CASE_ID
INNER JOIN dbo.STATUS_CODE SC  with (nolock)
ON CS.STATUS_CODE = SC.STATUS_CODE
INNER JOIN dbo.SPECIAL_FIELDS SF  with (nolock)
ON CLM.CLAIM_ID = SF.ID
WHERE CS.HDS_LOB_ID = 2
AND CD.SUBCATEGORY = 10
AND cs.CURRENT_STATUS = 1
AND CS.STATUS_CODE !='2'
  or CS.STATUS_CODE !='50'
  or CS.STATUS_CODE !='55'
AND CLM.PROJECT_ID != 222
AND IsValidSSN = 1
and CLM.FEED_ID >= 150
  and CLM.FEED_ID <= 208
AND CLM.PATIENT_AGE < 65
AND CLM.PATIENT_AGE > 18
and  DATEDIFF(D,   CLM.DATE_OF_SERVICE_END, GETDATE()) < 365
and ISNULL(CLM.AMT_PAID, 0) > 0")


  









cl_id <- sqldf("select distinct CLAIM_ID from base1 ")


DX_claimfoo <- sqldf("select d.* from DX_claim d, cl_id c
                  where trim(d.CLAIM_ID) = trim(c.CLAIM_ID)")





DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")


elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")


cs = sqlQuery(
  conn,
  "SELECT  * from DBO.PROVIDER with (nolock)",
  max=100)

cl = sqlQuery(
  conn,
  "SELECT  max(FEED_ID) as mx from dbo.CLAIM with (nolock) where FEED_ID < 999",
  max=100)

1689113361
170520849







membs <- sqldf("select distinct member_ID from base1")
