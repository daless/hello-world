
# pull of 1500 , 203 had 2 + claims 13.5%

# 30 members score 1
# 203 members 15%




# 5B reduced number of features


setwd("~/aetna")




library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(NbClust)
library(cluster)
library(broom)
library(factoextra)
library(proxy)
library(reshape2)
library(plyr)
library(kamila)
library(cluster)
library(MASS)

#library(dbplyr)
#library(sparklyr)


#sc <- spark_connect(master = "local", version = "2.2.1")
#spark_disconnect(sc)

# sparkling water package
#library(rsparkling)

#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)




library(odbc)

connn <- dbConnect(odbc(),
                   driver='ODBCSQLSvr',
                   server='dbswp0625.aimhealth.com',
                   database='RACERRESEARCH',
                   uid='COBUnixToSQL',
                   pwd='COBUn!xT0Sql')



library(DBI)
# connn <- dbConnect(odbc::odbc(),
#                    driver='ODBCSQLSvr',
#                    server='dbswp0625.aimhealth.com',
#                    database='RACERRESEARCH',
#                    uid='COBUnixToSQL',
#                    pwd='COBUn!xT0Sql')


# connn <- DBI::dbConnect(odbc::odbc(),
#                         driver='ODBCSQLSvr',
#                         server='dbswp0625.aimhealth.com',
#                         database='RACERRESEARCH',
#                         uid='COBUnixToSQL',
#                         pwd='COBUn!xT0Sql')

# junk <- DBI::dbGetQuery( sc, "select *
#                     FROM dbo.AetnaDuplicateResearch where Claimant_Number = '162623343D02'")



# get query returns data fram
# junk <- DBI::dbGetQuery( connn, "select *
#                     FROM dbo.AetnaDuplicateResearch where Claimant_Number = '162623343D02'")
# 
# # copy to spark
# sdf_copy_to(sc, junk, "spark_junk")
# 
# 
# # send query brings back odbc connection
# junk <- DBI::dbSendQuery( connn, "select *
#                     FROM dbo.AetnaDuplicateResearch where Claimant_Number = '162623343D02'")
# 
# 
# # bring back first 10 records
# junk100 <- dbFetch(junk, n=10)





#######################################################

# with new analytics table



# C.CLAIM_NO is the unique claim key

# old sample was at 500


distinct_membersq <- DBI::dbSendQuery( connn, statement = paste(
  "SELECT DISTINCT PAT_MEMBER_NO, CLAIM_NO FROM dbo.AetnaDuplicateResearch ",
  "ORDER BY PAT_MEMBER_NO, CLAIM_NO"))


distinct_members <- dbFetch(distinct_membersq, n=1500)

member_multi <- sqldf("select PAT_MEMBER_NO 
                     from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")


# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 12, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','PAID_1', 'PAID_2', 'START_DATE_1',
                         'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 12, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                  CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                  CL_DATE_PAID ,CLAIM_SUFFIX ,
                                  Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                  DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                  DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                  Line_Of_Business ,Other_Ins_Paid_Amt ,
                                  PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                  PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                                   FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
 
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                          FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
                       
                       
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    dupes <- cl_dup1
    
    dupes <- dupes %>%
      mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
             CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
             CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
      )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    
    
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
   # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
    
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    #hits <- hits[1,]
    
   # r_hits <- hits[, 1]
   # c_hits <- hits[, 2]
    
    
    score_record_temp <- score_record_temp %>%
      mutate(ROWID_1 = cl_dup1[r_hits, 1],
             ROWID_2 = cl_dup1[c_hits, 1],
             PAID_1 = dupes[r_hits, 5],
             PAID_2 = dupes[c_hits, 5],
             START_DATE_1 = cl_dup1[r_hits, 7],
             START_DATE_2  = cl_dup1[c_hits, 7],
             END_DATE_1 = cl_dup1[r_hits, 8],
             END_DATE_2  = cl_dup1[c_hits, 8],
             SCORE  = member_score,
             COUNT_BY_MEMBER = j,
             METHOD = "Gower")
    
    
    
    score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
    
    score_record <- bind_rows(score_record, score_record_temp)
    
    cl_dup3 <-
      sqldf(
        "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
        OR d.ROWID = s.ROWID_2"
      )
    
  
    claim_example <- bind_rows(claim_example, cl_dup3)
    
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")


#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                       difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                       difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)







score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top 1 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.90))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select  s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")









write.table(score_record2, file = "traditional_Gower_scoresc_12_12.csv",
           row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_12_12.csv",
            row.names = FALSE, sep ="\t")


# write.table(score_record, file = "traditional_Gower_scores_sample.csv",
#             row.names = FALSE, sep ="\t")
# 
 



 #perfect <- sqlQuery(conn, "select * from dbo.AetnaDuplicateResearch where 
#ROWID = 22212076 OR ROWID = 22212077")
# 
# perfect_95 <- sqlQuery(conn, "select * from dbo.AetnaDuplicateResearch where ROWID = 4978114 OR ROWID = 4978110")


data_2_cluster <- sqldf("select PAID_1, SCORE from score_record where SCORE < 1 and SCORE > 0.99")

data_2_cluster_base <- data_2_cluster

data_2_cluster2 <- scale(data_2_cluster)

nb <- NbClust(data_2_cluster2, diss = NULL, distance = "euclidean",
              min.nc = 2, max.nc = 5, method = "kmeans",
              index = "all", alphaBeale = 0.1)

hist(nb$Best.nc[1,], breaks = max(na.omit(nb$Best.nc[1,])))


km <- kmeans(data_2_cluster2, centers = 4, nstart = 25)
fviz_cluster (km, data =data_2_cluster2 , pointsize = 0.5, labelsize = 2, main = "Clusters of Paiamount and Distance Score Normalized")

# extract cluster assignment vector from the kmeans model
clust_km <- km$cluster

# add cluster to dataframe
data_2_cluster3 <- mutate(data_2_cluster_base, cluster = clust_km)

write.table(data_2_cluster3, file = "traditional_Gower_scores_cluster_11_15.csv",
            row.names = FALSE, sep ="\t")


# box plot by cluster

ggplot(data_2_cluster_base, aes(y=SCORE, x= cluster)) + geom_boxplot() + theme_gray()
