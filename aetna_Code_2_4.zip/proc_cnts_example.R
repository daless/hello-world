

# uses LA data as test
# inpatient only


setwd("~/BCBSLA")



library(RODBC)
library(sqldf)
library(dplyr)


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;DATABASE=racer01138;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)



claims_line_180 <- sqlQuery(
  conn,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
CLM.PATIENT_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L, dbo.CLAIM CLM
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.PROJECT_ID = 1138
  AND L.AMT_PAID  > 0
  AND CLM.DATE_PAID >= '06-01-2018'
  AND CLM.DATE_PAID <= '10-30-2018'
  AND CLM.PLACE_OF_SERVICE = 21
  ")



proccnt <- sqldf( "select PATIENT_ID, CPT, count(CPT) as cpt_cnt, sum(AMT_PAID) as tot_pd
                  from claims_line_180
where CPT !=''
                  group by PATIENT_ID, CPT
                  order by cpt_cnt desc")

memcnt <- sqldf(" select CPT, count(PATIENT_ID) as mem_cnt, sum(cpt_cnt) as tot_cpt, sum(tot_pd) as mem_dol
                from proccnt
                group by CPT
                order by  tot_cpt desc")

# calc ratios


memcnt$cpt_per_member <- memcnt$tot_cpt / memcnt$mem_cnt
memcnt$pd_per_member <- memcnt$mem_dol /  memcnt$mem_cnt




