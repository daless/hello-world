setwd("~/aetna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(kamila)
library(cluster)
library(arules)
library(proxy)
library(reshape2)
library(plyr)


#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)
# 
# table_listing <- as.data.frame(sqlTables(conn))
# 
# 
# 
# junk <- sqlQuery( conn, "select * FROM dbo.CLAIM CLM  where CLM.CLAIM_NO = 'E0FBW6VMG'")
# junk2 <- sqlQuery( conn, "select * FROM dbo.CLAIM CLM  where CLM.PATIENT_ID = 1045949144")  
#  


# test feed 169

claim1 <- sqlQuery( conn, "select * FROM dbo.CLAIM CLM  where  CLM.FEED_ID IN (169) and CLM.PROJECT_ID = 222")


member_multi <- sqldf("select PATIENT_ID, count(PATIENT_ID) as memcnt from claim1 group by PATIENT_ID having memcnt >= 2")


claim1 <-sqldf("select distinct c.* from claim1 c, member_multi m where c.PATIENT_ID = m.PATIENT_ID")



DX_test  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID,
CLM.PATIENT_ID
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE DX.FEED_ID IN (169)
  AND CLM.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 9
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc"
)



DX_test <-sqldf("select distinct c.* from DX_test c, member_multi m where c.PATIENT_ID = m.PATIENT_ID")


# procedure
claim_line <- sqlColumns(
conn, "dbo.CLAIM_LINE"  )

proc <- sqlQuery(
  conn, "select distinct  p.CLAIM_ID, p.CPT, p.REVENUE_CODE, p.CPT_MODIFIER, CLM.PATIENT_ID
from dbo.CLAIM_LINE p, dbo.CLAIM CLM
              where CLM.CLAIM_ID = p.CLAIM_ID
              and CLM.FEED_ID IN (169)
              AND CLM.PROJECT_ID = 222
                order by p.CLAIM_ID")


proc <-sqldf("select distinct c.* from proc c, member_multi m where c.PATIENT_ID = m.PATIENT_ID")



prov_list <-
  sqldf(
    "select distinct CLAIM_ID , PATIENT_ID as PROVIDER_NO, PATIENT_ID
    from claim1
    order by PATIENT_ID, PROVIDER_NO"
  )


# dupe score file to append to

scores <- data.frame(matrix(ncol = 10, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Jaccard', 'Kulczynski1', 'Kulczynski2', "Mountford", 'Fager', 'Russel', 
                   'simple_matching', 'Hamman', 'Faith')
colnames(scores) <- score_columns


# make empty df for formatting

icd_base <- data.frame(matrix(ncol = 11, nrow = 0))
b <- c('CLAIM_ID', 'DX1', 'DX2', 'DX3', 'DX4', 'DX5', 'DX6', 'DX7', 'DX8', 'DX9', 'DX10')
colnames(icd_base) <- b

proc_base <- data.frame(matrix(ncol = 11, nrow = 0))
p <- c('CLAIM_ID', 'PROC1', 'PROC2', 'PROC3', 'PROC4', 'PROC5', 'PROC6', 'PROC7', 'PROC8', 'PROC9', 'PROC10')
colnames(proc_base) <- p

doc_base <- data.frame(matrix(ncol = 6, nrow = 0))
d <- c('CLAIM_ID', 'PROV1', 'PROV2', 'PROV3', 'PROV4', 'PROV5')
colnames(doc_base) <- d

# dummy df dx codes
dummy_dx <- data.frame(matrix(ncol = 3, nrow = 10))
dumb <- c('CLAIM_ID', 'ICD9_CODE', 'icd_cntr')
colnames(dummy_dx) <- dumb
dummy_dx$CLAIM_ID <- -1
dummy_dx$ICD9_CODE <- 'FOO'
dummy_dx$icd_cntr <- 1:nrow(dummy_dx)

# dummy for proc codes
dummy_p <- data.frame(matrix(ncol = 3, nrow = 10))
dumbp <- c('CLAIM_ID', 'CPT', 'proc_cntr')
colnames(dummy_p) <- dumbp
dummy_p$CLAIM_ID <- -1
dummy_p$CPT <- 'FOO'
dummy_p$proc_cntr <- 1:nrow(dummy_p)

# dummy for providers
dummy_doc <- data.frame(matrix(ncol = 3, nrow = 5))
dumbd <- c('CLAIM_ID', 'PROVIDER_NO', 'prov_cntr')
colnames(dummy_doc) <- dumbd
dummy_doc$CLAIM_ID <- -1
dummy_doc$PROVIDER_NO <- 'FOO'
dummy_doc$prov_cntr <- 1:nrow(dummy_doc)





# test with single member
# loop logic start here
####################### LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


cl_dup1 <- sqldf("select c.* from claim1 c where c.PATIENT_ID = 1108119")



str(cl_dup1 , list.len=ncol(cl_dup1))

# remove extra fields
deletes_claims <- c( 	'PROJECT_ID', 
                      'FEED_ID', 
                      'DATE_RECEIVED', 
                      'DATE_ENTERED', 
                      'DATE_ADMITTED', 
                      'DATE_DISCHARGED', 
                      'PATIENT_AGE', 
                      'SUBSCRIBER_AGE', 
                      'DATE_PAID', 
                      'DATE_CREATED', 
                      'DATE_UPDATED', 
                      'USERNAME', 
                      'ADJ_CLAIM_FLAG', 
                      'PAR', 
                      'VENDOR_ID', 
                      'PATIENT_ACCT_NO_CLIENT', 
                      'PAR_CLIENT', 
                      'CHECK_NUMBER_CLIENT', 
                      'SERVICE_ID', 
                      'ROWID')


cl_dup1[deletes_claims] <- NULL


cl_dup1$DATE_OF_SERVICE_BEG <-
  as.factor(as.character(cl_dup1$DATE_OF_SERVICE_BEG))
cl_dup1$DATE_OF_SERVICE_END  <-
  as.factor(as.character(cl_dup1$DATE_OF_SERVICE_END))



# write.table(claim1, file = "claim1.csv",
#             row.names = FALSE, sep ="\t")
# 
# 
# write.table(proc, file = "proc.csv",
#             row.names = FALSE, sep ="\t")
# 
# write.table(DX_test , file = "DX_test.csv",
#             row.names = FALSE, sep ="\t")
# 
# 
# write.table(member_multi , file = "member_multi.csv",
#             row.names = FALSE, sep ="\t")

# add dx codes

icd_dup1 <-
  sqldf(
    "select i.CLAIM_ID, i.ICD9_CODE from DX_test i , cl_dup1 c
    where i.CLAIM_ID = c.CLAIM_ID
    order by i.CLAIM_ID"
  )
# if no dx append blank with -1 claimid
if (nrow(icd_dup1) == 0) {
  icd_dup1[nrow(icd_dup1) + 1, ] <- -1  }
# add counter for dx code
icd_dup1 <-
  ddply(icd_dup1, .(CLAIM_ID), mutate, icd_cntr = seq_along(ICD9_CODE))
# add dummy rows to make max 10 dx codes
icd_dup1 <- rbind(icd_dup1, dummy_dx)

icd_dup1 <-
  dcast(icd_dup1,  CLAIM_ID ~ icd_cntr, value.var = "ICD9_CODE")
j <- colnames(icd_dup1)
icd_dup1 <- icd_dup1  %>% rename_at(vars(j), ~ b)
# remove dummy
icd_dup1 <- sqldf("select * from icd_dup1 where CLAIM_ID != -1")
icd_dup1 <- icd_dup1 %>% replace(is.na(.), 0)


# procedures

proc_dup1 <- sqldf(
  "select p.CLAIM_ID, p.CPT FROM proc p, cl_dup1 c
    where p.CLAIM_ID = c.CLAIM_ID
    and p.CPT != ''
    order by p.CLAIM_ID, p.CPT "
)



if (nrow(proc_dup1) == 0) {
  proc_dup1[nrow(proc_dup1) + 1, ] <- -1  }

# add counter for proc code
proc_dup1 <-
  ddply(proc_dup1, .(CLAIM_ID), mutate, proc_cntr = seq_along(CPT))

# TOP 10 PROC CODES
proc_dup1 <- sqldf("select * from proc_dup1 where proc_cntr <= 10")

# add dummy rows to make max 10 dx codes
proc_dup1 <- rbind(proc_dup1, dummy_p)

# transpose
proc_dup1 <-
  dcast(proc_dup1,  CLAIM_ID ~ proc_cntr, value.var = "CPT")
pd <- colnames(proc_dup1)
proc_dup1 <- proc_dup1  %>% rename_at(vars(pd), ~ p)
# remove dummy
proc_dup1 <- sqldf("select * from proc_dup1 where CLAIM_ID != -1")
proc_dup1 <- proc_dup1 %>% replace(is.na(.), 0)



# providers



prov_dup1 <- sqldf(
  "select p.CLAIM_ID, p.PROVIDER_NO FROM prov_list p, cl_dup1 c
  where p.CLAIM_ID = c.CLAIM_ID
  order by p.CLAIM_ID, p.PROVIDER_NO "
)

if (nrow(prov_dup1) == 0) {
  prov_dup1[nrow(prov_dup1) + 1, ] <- -1  }
# add counter for prov code
prov_dup1 <-
  ddply(prov_dup1, .(CLAIM_ID), mutate, prov_cntr = seq_along(PROVIDER_NO))

# TOP 5 PROv CODES
prov_dup1 <- sqldf("select * from prov_dup1 where prov_cntr <= 5")

# add dummy rows to make max 10 dx codes
prov_dup1 <- rbind(prov_dup1, dummy_doc)

# transpose
prov_dup1 <-
  dcast(prov_dup1,  CLAIM_ID ~ prov_cntr, value.var = "PROVIDER_NO")
pv <- colnames(prov_dup1)
prov_dup1 <- prov_dup1  %>% rename_at(vars(pv), ~ d)
# remove dummy
prov_dup1 <- sqldf("select * from prov_dup1 where CLAIM_ID != -1")
prov_dup1 <- prov_dup1 %>% replace(is.na(.), 0)



# merge files
cl_dup1$CLAIM_IDx <- cl_dup1$CLAIM_ID
cl_dup1$CLAIM_ID <- NULL


dupes <-
  sqldf("select * from cl_dup1 d, icd_dup1 i where d.CLAIM_IDx = i.CLAIM_ID")
dupes$CLAIM_ID <- NULL
dupes <-
  sqldf("select * from cl_dup1 d, proc_dup1  i where d.CLAIM_IDx = i.CLAIM_ID")
dupes$CLAIM_ID <- NULL
dupes <-
  sqldf(
    "select * from cl_dup1 d,prov_dup1  i where d.CLAIM_IDx = i.CLAIM_ID ORDER BY DATE_OF_SERVICE_BEG"
  )
dupes$CLAIM_IDx <- NULL




score_append <- sqldf("select distinct PATIENT_ID from dupes")

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "simple matching"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$simple_matching <- member_score

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Jaccard"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$Jaccard <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Kulczynski1"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$Kulczynski1 <- member_score

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Kulczynski2"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0

# WRITE THIS TO OUTPUT FILE THEN DIVIDE BY MAX SCOE OF MATRIX FOR EXAMPLE IF 10 COLUMNS MAX SCORE WOULD BE 100
member_score <- sum(cl_dup2)
score_append$Kulczynski2 <- member_score

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Mountford"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0

member_score <- sum(cl_dup2)
score_append$Mountford <- member_score

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Fager"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0

member_score <- sum(cl_dup2)
score_append$Fager <- member_score

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Russel"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0

member_score <- sum(cl_dup2)
score_append$Russel <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Hamman"
  )))
# replace diagonals with NA to 0
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0

member_score <- sum(cl_dup2)
score_append$Hamman <- member_score



cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes, by_rows = TRUE,   method = "Faith"
  )))
# replace diagonals with NA to 1
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0

member_score <- sum(cl_dup2)
score_append$Faith <- member_score

scores <- rbind(scores, score_append)

# score continuous data


dupes$DATE_OF_SERVICE_BEG <- as.numeric(as.POSIXct(as.character(dupes$DATE_OF_SERVICE_BEG)))
dupes$DATE_OF_SERVICE_END <- as.numeric(as.POSIXct(as.character(dupes$DATE_OF_SERVICE_END)))
dupes$PATIENT_DOB <- as.numeric(as.POSIXct(as.character(dupes$PATIENT_DOB)))
dupes$SUBSCRIBER_DOB <- as.numeric(as.POSIXct(as.character(dupes$SUBSCRIBER_DOB)))


number_list <- c(names(Filter(is.numeric,dupes)))

dupes_numeric <- dupes[,number_list]
dupes_numeric[is.na(dupes_numeric)] <- 0

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Euclidean"
  )))

# replace diagonals with NA to 0
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0



# disimialirty find smallest
member_score <- min(cl_dup2)
score_append$Euclidean <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Pearson"
  )))

# replace diagonals with NA to 0
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# max
member_score <- max(cl_dup2)
score_append$Pearson <- member_score




cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Gower"
  )))

# replace diagonals with NA to 0
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# max
member_score <- max(cl_dup2)
score_append$Gower <- member_score



cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Bhjattacharyya"
  )))

# replace diagonals with NA to 0
cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# disimialrity score so use min
member_score <- min(cl_dup2)
score_append$Gower <- member_score




cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Manhattan"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# disimialrity score so use min
member_score <- min(cl_dup2)
score_append$Manhattan <- member_score



cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "supremum"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# disimialrity score so use min
member_score <- min(cl_dup2)
score_append$supremum <- member_score





cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "cosine"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# simialrity score so use max
member_score <- max(cl_dup2)
score_append$cosine <- member_score




cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "eJaccard"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# simialrity score so use max
member_score <- max(cl_dup2)
score_append$eJaccard <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "correlation"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# simialrity score so use max
member_score <- max(cl_dup2)
score_append$correlation <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Canberra"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# dissimialrity score so use max
member_score <- min(cl_dup2)
score_append$Canberra <- member_score

cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "divergence"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# dissimialrity score so use max
member_score <- min(cl_dup2)
score_append$divergence <- member_score




cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Bray"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# dissimialrity score so use max
member_score <- min(cl_dup2)
score_append$Bray <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Soergel"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# dissimialrity score so use max
member_score <- min(cl_dup2)
score_append$Soergel <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Chord"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# dissimialrity score so use max
member_score <- min(cl_dup2)
score_append$Chord <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Whittaker"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# dissimialrity score so use max
member_score <- min(cl_dup2)
score_append$Whittaker <- member_score


cl_dup2 <-
  as.data.frame(as.matrix(simil(
    dupes_numeric, by_rows = TRUE,   method = "Hellinger"
  )))

cl_dup2 <- cl_dup2 %>% replace(is.na(.), 1)
cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0


# dissimialrity score so use max
member_score <- min(cl_dup2)

hits <- as.data.frame(which(cl_dup2 == min(cl_dup2), arr.ind = TRUE))

r_hits <- hits[1,1]
c_hits <- hits[1,2]

junk$claim_id_hit1 <- dupes_numeric[r_hits,29]
junk$claim_id_hit2 <- dupes_numeric[c_hits,29]




score_append$Hellinger <- member_score





