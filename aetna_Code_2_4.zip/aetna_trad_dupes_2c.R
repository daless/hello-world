


setwd("~/aetna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(kamila)
library(cluster)
library(arules)
library(proxy)
library(reshape2)
library(plyr)


#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=dmfeed00222;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)



conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)


table_listing <- as.data.frame(sqlTables(conn))



#.  Project ID for TRAD is 222 and for HMO it’s 212

junk <- sqlQuery( conn, "select * FROM dbo.AetnaDuplicateResearch   
                  ", max=10)


junk2 <- sqlQuery( conn, "select * FROM dbo.FD_AETNA_TRAD_CLM CLM where 
                  CLM.PROJECT_ID = 222
                  AND CLM.CLAIM_NUMBER = 'EPFB5VHY700'
                  ", max=10)


junk <- sqlQuery( conn, "select * FROM dbo.FD_AETNA_TRAD_CLM CLM  ", max=10)

str(junk , list.len=ncol(junk))
str(junk2 , list.len=ncol(junk2))

#Member table in provisional would be FD_AETNA_TRAD_MEM.  You can join to FD_AETNA_TRAD_CLM on pat_member_no and feed_id

#For the provider tables, we use FD_AETNA_TRAD_PROV if we need address info on the billing provider.  That’s about all that’s in there. You could join to FD_AETNA_TRAD_CLM on provider_no and feed_id. 

#FD_AETNA_TRAD_PROV_PINS table for servicing provider info.  Provider type and specialty codes are in there, as well as the par/non-par indicator. You could join to FD_AETNA_TRAD_CLM on pin7 and feed_id. 


max_feedid <- sqlQuery( conn, "select max(FEED_ID) as max_feed_id FROM dbo.FD_AETNA_TRAD_CLM CLM
                        where CLM.PROJECT_ID = 222")


test <- sqlQuery( conn, "select FEED_ID, CLAIM_ID, PAT_MEMBER_NO, CLAIM_NUMBER, Claims_Status , DATE_PAID, CLAIM_NO
FROM dbo.FD_AETNA_TRAD_CLM
where FEED_ID = (select max(FEED_ID) FROM dbo.FD_AETNA_TRAD_CLM CLM)
and PROJECT_ID = 222
ORDER BY PAT_MEMBER_NO, CLAIM_ID", max = 100)


test2 <- sqlQuery( conn, "select  distinct FEED_ID, PAT_MEMBER_NO, DATE_PAID
                  FROM dbo.FD_AETNA_TRAD_CLM
                   where FEED_ID = (select max(FEED_ID) FROM dbo.FD_AETNA_TRAD_CLM CLM
                   where PROJECT_ID = 222)
AND PROJECT_ID = 222
                   ORDER BY PAT_MEMBER_NO", max = 100)



test3 <- sqlQuery( conn, "select C.FEED_ID, C.CLAIM_ID, C.PAT_MEMBER_NO, C.CLAIM_NUMBER, C.Claims_Status , C.DATE_PAID,
                   C.CLAIM_NO, sub.DATE_PAID as DATE_PAID_anchor
                   FROM dbo.FD_AETNA_TRAD_CLM C
                   JOIN (select  distinct FEED_ID, PAT_MEMBER_NO, DATE_PAID
                   FROM dbo.FD_AETNA_TRAD_CLM
                   where FEED_ID = (select max(FEED_ID) FROM dbo.FD_AETNA_TRAD_CLM CLM)
                   and PROJECT_ID = 222) sub
                   ON C.PAT_MEMBER_NO = sub.PAT_MEMBER_NO
                   AND C.DATE_PAID < sub.DATE_PAID
                   AND C.PROJECT_ID = 222", max = 100)


test4 <- sqlQuery( conn, "select DISTINCT C.FEED_ID, C.CLAIM_ID, C.PAT_MEMBER_NO, C.CLAIM_NUMBER, C.Claims_Status , C.DATE_PAID,
                   C.CLAIM_NO, sub.DATE_PAID as DATE_PAID_anchor
                   FROM dbo.FD_AETNA_TRAD_CLM C
                   JOIN (select  distinct FEED_ID, PAT_MEMBER_NO, DATE_PAID
                   FROM dbo.FD_AETNA_TRAD_CLM
                   where FEED_ID = (select max(FEED_ID) FROM dbo.FD_AETNA_TRAD_CLM CLM)
                   and PROJECT_ID = 222) sub
                   ON C.PAT_MEMBER_NO = sub.PAT_MEMBER_NO
                   AND sub.DATE_PAID - C.DATE_PAID <= 720
AND C.Claims_Status != 'A'
                   AND C.PROJECT_ID = 222", max = 100)


test5 <- sqlQuery( conn, "select DISTINCT C.PAT_MEMBER_NO,
                   C.CLAIM_NO, sub.DATE_PAID as DATE_PAID_anchor
                   FROM dbo.FD_AETNA_TRAD_CLM C
                   JOIN (select  distinct FEED_ID, PAT_MEMBER_NO, DATE_PAID
                   FROM dbo.FD_AETNA_TRAD_CLM
                   where FEED_ID = (select max(FEED_ID) FROM dbo.FD_AETNA_TRAD_CLM CLM)
                   and PROJECT_ID = 222) sub
                   ON C.PAT_MEMBER_NO = sub.PAT_MEMBER_NO
                   AND sub.DATE_PAID - C.DATE_PAID <= 720
                   AND C.Claims_Status != 'A'
                   AND C.PROJECT_ID = 222", max = 100)



test6 <- sqlQuery( conn, "select   C.PAT_MEMBER_NO, count(sub2.PAT_MEMBER_NO) as memcnt
                  FROM dbo.FD_AETNA_TRAD_CLM C
                   JOIN (select DISTINCT C.PAT_MEMBER_NO,
                   C.CLAIM_NO, sub.DATE_PAID as DATE_PAID_anchor
                   FROM dbo.FD_AETNA_TRAD_CLM C
                   JOIN (select  distinct FEED_ID, PAT_MEMBER_NO, DATE_PAID
                   FROM dbo.FD_AETNA_TRAD_CLM
                   where FEED_ID = (select max(FEED_ID) FROM dbo.FD_AETNA_TRAD_CLM CLM)
                   and PROJECT_ID = 222) sub
                   ON C.PAT_MEMBER_NO = sub.PAT_MEMBER_NO
                   AND sub.DATE_PAID - C.DATE_PAID <= 720
                   AND C.Claims_Status != 'A'
                   AND C.PROJECT_ID = 222) sub2
                   ON C.PAT_MEMBER_NO = sub2.PAT_MEMBER_NO
                   AND C.CLAIM_NO = sub2.CLAIM_NO
                   AND C.Claims_Status != 'A'
                   GROUP BY C.PAT_MEMBER_NO HAVING count(sub2.PAT_MEMBER_NO) >= 2", max = 100)


test7 <- sqlQuery( conn, "SELECT C.FEED_ID
	,C.CLAIM_ID
                   ,C.PAT_MEMBER_NO
                   ,C.CLAIM_NUMBER
                   ,C.Claims_Status
                   ,C.DATE_PAID
                   ,C.CLAIM_NO
                   ,sub.DATE_PAID AS DATE_PAID_anchor
                   FROM dbo.FD_AETNA_TRAD_CLM C(SELECT C.PAT_MEMBER_NO, count(sub2.PAT_MEMBER_NO) AS memcnt FROM dbo.FD_AETNA_TRAD_CLM C JOIN (
                   SELECT DISTINCT C.PAT_MEMBER_NO
                   ,C.CLAIM_NO
                   ,sub.DATE_PAID AS DATE_PAID_anchor
                   FROM dbo.FD_AETNA_TRAD_CLM C
                   JOIN (
                   SELECT DISTINCT FEED_ID
                   ,PAT_MEMBER_NO
                   ,DATE_PAID
                   FROM dbo.FD_AETNA_TRAD_CLM
                   WHERE FEED_ID = (
                   SELECT max(FEED_ID)
                   FROM dbo.FD_AETNA_TRAD_CLM CLM
                   )
                   AND PROJECT_ID = 222
                   ) sub ON C.PAT_MEMBER_NO = sub.PAT_MEMBER_NO
                   AND sub.DATE_PAID - C.DATE_PAID <= 720
                   AND C.Claims_Status != 'A'
                   AND C.PROJECT_ID = 222
                   ) sub2 ON C.PAT_MEMBER_NO = sub2.PAT_MEMBER_NO
                   AND C.CLAIM_NO = sub2.CLAIM_NO
                   AND C.Claims_Status != 'A' GROUP BY C.PAT_MEMBER_NO HAVING count(sub2.PAT_MEMBER_NO) >= 2) sub3 
                   ON C.PAT_MEMBER_NO = sub3.PAT_MEMBER_NO
                   AND sub.DATE_PAID - C.DATE_PAID <= 720
                   AND C.Claims_Status != 'A'
                   AND C.PROJECT_ID = 222", max = 100)


#######################################################

# with new analytics table



# C.CLAIM_NO is the unique claim key

distinct_members <- sqlQuery( conn, "select DISTINCT  C.PAT_MEMBER_NO, C.CLAIM_NO
                   FROM dbo.AetnaDuplicateResearch C
                  ORDER by C.PAT_MEMBER_NO, C.CLAIM_NO", max = 100)


# change from 9 to 2 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!



member_multi <- sqldf("select PAT_MEMBER_NO, count(PAT_MEMBER_NO) as memcnt 
                      from distinct_members group by PAT_MEMBER_NO having memcnt >= 9")





for (i in rownames(member_multi))
{
  memberid <- member_multi[i,]
  
mem_string <- paste("
SELECT C.ROWID
,C.Account
,C.AMT_ALLOWED
,C.AMT_BILLED
,C.AMT_PAID
,C.Benefit_Package_ID
,C.Business_Line
,C.C_REVENUE_CODE
,C.Capitated_Service_Ind
,C.CL_AMT_ALLOWED
,C.CL_AMT_BILLED
,C.CL_AMT_PAID
,C.CL_DATE_OF_SERVICE_BEG
,C.CL_DATE_OF_SERVICE_END
,C.CL_DATE_PAID
,C.CLAIM_NO
,C.CLAIM_NUMBER
,C.Claim_Office_Number
,C.CLAIM_SUFFIX
,C.Claim_System_Id
,C.Claimant_Number
,C.Claims_Status
,C.Coinsurance_Amt
,C.Copay_Amt
,C.CPT
,C.DATE_OF_SERVICE_BEG
,C.DATE_OF_SERVICE_END
,C.DATE_PAID
,C.Deductible_Amt
,C.DIAGNOSIS_1
,C.DIAGNOSIS_10
,C.DIAGNOSIS_11
,C.DIAGNOSIS_2
,C.DIAGNOSIS_3
,C.DIAGNOSIS_4
,C.DIAGNOSIS_5
,C.DIAGNOSIS_6
,C.DIAGNOSIS_7
,C.DIAGNOSIS_8
,C.DIAGNOSIS_9
,C.Employer_Group_No
,C.Funding_Arrangement_Code
,C.Line_Of_Business
,C.Other_Ins_Paid_Amt
,C.PAT_MEMBER_NO
,C.PIN7
,C.Place_Of_Service
,C.Primary_Payer_Coverage_Code
,C.PRINCIPAL_DIAG
,C.Procedure_Code
,C.PROCEDURE_CODE_2
,C.Product_Distinction_Code
,C.PROVIDER_NO
,C.REVENUE_CODE
,C.Suffix
,C.TAX_ID
,C.Type_Of_Service
,C.Universal_Claim_Key
FROM dbo.AetnaDuplicateResearch C
WHERE C.PAT_MEMBER_NO IN", memberid, sep="")

cl_dup1 <- sqlQuery(conn, mem_string)

}

