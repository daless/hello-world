setwd("~/aetna")


library(comorbidity)
library(RODBC)
library(sqldf)
#library(dplyr)
library(tidyverse)
library(dummies)
library(SOMbrero)
library(kohonen)
library(broom)

# scp analytic_data2020_0_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp FIPS_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp USDA.txt dless1@apsrd9425:/home/dless1/aetna

county_hlth  <- read.csv("analytic_data2020_0_tab.txt", header=TRUE, sep="\t")
FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


# connection: dbswp0625
# database: RacerResearch
# schema: dbo
# view: vwAetnaTradMemClaimCoverage





#conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RacerResearch;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
#)
conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)

# WORKS
unkmem <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.vwAetnaTradMemClaimCoverage  p  with (nolock)",
  max=50)
str(unkmem,list.len = ncol(unkmem))

# date clean up
v1224 <- sqlQuery(
  conn,
  "SELECT v.PAT_MEMBER_NO,
v.member_id_number,
v.member_rel_code,
v.member_sex,
v.member_state,
SUBSTRING(v.member_zip_code,1,5) as zipcode,
v.PAT_DATE_OF_BIRTH,
v.member_age,
v.Pat_Date_Effective,
v.Pat_Date_Expiration,
v.cumb_id,
v.is_subscriber,
v.CLAIM_ID,
v.CLAIM_NO,
v.COVERAGE_CODE,
v.GROUP_NAME,
v.PROC_CD,
v.C_DRG,
v.ICD_DX_CD_1,
v.ICD_DX_CD_2,
v.ICD_DX_CD_3,
v.ICD_DX_CD_4,
v.ICD_DX_CD_5,
v.ICD_DX_CD_6,
v.ICD_DX_CD_7,
v.ICD_DX_CD_8,
v.ICD_DX_CD_9,
v.ICD_DX_CD_10,
v.ICD_DX_CD_11,
v.ICD_DX_CD_12,
v.DATE_OF_SERVICE_BEG,
v.DATE_OF_SERVICE_END,
v.days_of_service,
v.REVENUE_CODE,
v.Place_Of_Service,
v.Type_Of_Service,
v.Line_Of_Business,
v.CL_ELIG_EVENT,
v.CL_ELIG_COV,
v.CL_COB_TYPE,
v.CL_COB_OTHER_PAID,
v.CL_COB_CODE,
v.COB_TYPE,
v.case_1224_hit,
v.case_17_hit,
v.case_18_hit,
v.case_25_hit,
v.case_568_hit,
v.case_815_hit,
v.case_829_hit,
v.case_1227_hit,
v.case_1334_hit,
v.coveragetype,
v.coveragestatus,
v.coveragestatusreason,
v.InsCoName,
v.EffectiveDate,
v.TermDate,
v.REL_TO_INS_ID
  from RacerResearch.DBO.vwAetnaTradMemClaimCoverage  v  with (nolock)
  where DATEDIFF(D,  v.Pat_Date_Effective, GETDATE()) < 365",
  max=10000)


v1224 <- data.frame(id = row.names(v1224), v1224)

dx_a <- sqldf("select v.id,
v.ICD_DX_CD_1,
v.ICD_DX_CD_2,
v.ICD_DX_CD_3,
v.ICD_DX_CD_4,
v.ICD_DX_CD_5,
v.ICD_DX_CD_6,
v.ICD_DX_CD_7,
v.ICD_DX_CD_8,
v.ICD_DX_CD_9,
v.ICD_DX_CD_10,
v.ICD_DX_CD_11,
v.ICD_DX_CD_12
from v1224 v")

dx_b <- dx_a %>%
  tidyr::pivot_longer(
    cols = starts_with("ICD"),
    names_to = "DX",
    values_to = "ICD10",
    names_prefix = "ICD_DX_CD_"
  )

dx_b <-drop_na(dx_b)

dx_b$ICD10<-as.character(dx_b$ICD10)
dx_b$ICD10<-gsub(".","",dx_b$ICD10,fixed=TRUE)


elixhauser_scores <- comorbidity(x=dx_b , id = "id",  code = "ICD10", icd = "icd10", score = "elixhauser")
elixhauser <- sqldf("select id, score as elixhouser_score from elixhauser_scores")

# add external data


v1224_b <- sqldf("select v.*, f.COUNTY from FIPS f, v1224 v
                 where v.zipcode = f.zip")

v1224_b <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from USDA f, v1224_b v
                 where v.COUNTY = f.FIPS")

# #rename
names(county_hlth)[3] <- 'long_fips'
names(county_hlth)[140] <- 'physician_rate'
names(county_hlth)[152] <- 'MH_providers'
names(county_hlth)[8] <- 'premature_death'
names(county_hlth)[397] <- 'diabetes_preval'
names(county_hlth)[477] <- 'ratio_PCP_other'


county_hlth2 <- sqldf("select long_fips,
physician_rate,
                       premature_death,
                       MH_providers,
                      diabetes_preval,
                      ratio_PCP_other
                      from county_hlth
                      where long_fips !='0' ")

v1224_b <- sqldf("select v.*, 
c.physician_rate,
                       c.premature_death,
                       c.MH_providers,
                      c.diabetes_preval,
                      c.ratio_PCP_other
                      from v1224_b v, county_hlth2 c
                 where v.COUNTY = c.long_fips")


saveRDS(v1224_b, file="v1224_b1yr.Rda")

#str(county_hlth,list.len = ncol(county_hlth))


# remove county splits

v1224_c <- sqldf("select * from v1224_b group by id")

str(v1224_c,list.len = ncol(v1224_c))
# case id 1224

# 12 hits out of 10,000
case1224 <- sqldf("select * from v1224_c where case_1224_hit = 1")


# get number of claims and total paid


conn_racer = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)

# get number of claims and total paid all effective last year and claims last year
bucks_clm_cnt <- sqlQuery(
  conn_racer,
  " select 
  MEM.MEMBER_NO,
  count(CLM.CLAIM_NO) as tot_claims,
  SUM(CLM.AMT_PAID) as tot_paid
FROM dbo.CLAIM CLM
INNER JOIN dbo.MEMBER MEM
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where  DATEDIFF(D,  MEM.DATE_EFFECTIVE, GETDATE()) < 365
and DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 365
group by MEM.MEMBER_NO")

saveRDS(bucks_clm_cnt, file="bucks_clm_cnt.Rda")


v1224_d <- sqldf("select distinct v.*, m.tot_claims, m.tot_paid
                 from v1224_b v, bucks_clm_cnt m
                 where m.MEMBER_NO = v.PAT_MEMBER_NO")


v1224_e <- sqldf("select *
                 from v1224_d group by id")

# prep for SOM
# add GROUP_NAME, insurance name into supervised coveragetype,coveragestatus,coveragestatusreason,

v1224_e <- sqldf("select member_age,
is_subscriber,
COVERAGE_CODE,

days_of_service,
REVENUE_CODE,
Place_Of_Service,
Type_Of_Service,
Line_Of_Business,
CL_ELIG_EVENT,
CL_ELIG_COV,
CL_COB_TYPE,
CL_COB_CODE,
COB_TYPE,
case_1224_hit,
REL_TO_INS_ID,
USDA_urban_rural,
physician_rate,
premature_death,
MH_providers,
diabetes_preval,
ratio_PCP_other,
tot_claims,
tot_paid
from v1224_e ")


v1224_e$COVERAGE_CODE <- as.numeric(as.character(v1224_e$COVERAGE_CODE))
v1224_e$Line_Of_Business <- as.numeric(as.character(v1224_e$Line_Of_Business))

v1224_e <- v1224_e %>%
  mutate_if(is.character, ~replace(., is.na(.),'0'))
v1224_e <- v1224_e %>%
  mutate_if(is.numeric, ~replace(., is.na(.),0))
v1224_e <- v1224_e %>%
  mutate_if(is.integer, ~replace(., is.na(.),0))



eligability_event <- sqldf("select CL_ELIG_EVENT from v1224_e")
eligability_event <- cbind(eligability_event, dummy(eligability_event$CL_ELIG_EVENT , sep= "_"))
eligability_event$CL_ELIG_EVENT <- NULL

cov <- sqldf("select CL_ELIG_COV  from v1224_e")
cov <- cbind(cov, dummy(cov$CL_ELIG_COV , sep= "_"))
cov$CL_ELIG_COV <- NULL

ctype <- sqldf("select CL_COB_TYPE  from v1224_e")
ctype <- cbind(ctype, dummy(ctype$CL_COB_TYPE , sep= "_"))
ctype$CL_COB_TYPE <- NULL

COB_CODE  <- sqldf("select CL_COB_CODE  from v1224_e")
COB_CODE <- cbind(COB_CODE, dummy(COB_CODE$CL_COB_CODE , sep= "_"))
COB_CODE$CL_COB_CODE <- NULL

v1224_e <- cbind(v1224_e,ctype)
v1224_e <- cbind(v1224_e,cov)
v1224_e <- cbind(v1224_e,eligability_event)
v1224_e <- cbind(v1224_e,COB_CODE)

v1224_e$physician_rate <- as.numeric(as.character(v1224_e$physician_rate))
v1224_e$premature_death <- as.numeric(as.character(v1224_e$premature_death))
v1224_e$MH_providers <- as.numeric(as.character(v1224_e$MH_providers))
v1224_e$diabetes_preval <- as.numeric(as.character(v1224_e$diabetes_preval))
v1224_e$ratio_PCP_other <- as.numeric(as.character(v1224_e$ratio_PCP_other))

v1224_e$physician_rate <- ifelse(is.na(v1224_e$physician_rate), 0, v1224_e$physician_rate)
v1224_e$premature_death <- ifelse(is.na(v1224_e$premature_death), 0, v1224_e$premature_death)
v1224_e$MH_providers <- ifelse(is.na(v1224_e$MH_providers), 0, v1224_e$MH_providers)
v1224_e$diabetes_preval <- ifelse(is.na(v1224_e$diabetes_preval), 0, v1224_e$diabetes_preval)
v1224_e$ratio_PCP_other <- ifelse(is.na(v1224_e$ratio_PCP_other), 0, v1224_e$ratio_PCP_other)

v1224_e$CL_ELIG_EVENT <- NULL
v1224_e$CL_ELIG_COV <- NULL
v1224_e$CL_COB_TYPE <- NULL
v1224_e$CL_COB_CODE <- NULL
v1224_e$is_subscriber <- NULL



# scale all numeric
v1224_f <- v1224_e %>% mutate_if(is.numeric, scale)


som2 <- trainSOM(x.data = v1224_f, dimension = c(7,7), nb.save = 10, maxit = 500,
                 scaling = "none")

#plot(som2, what = "obs", type = "hitmap")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=5)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)


targ <- sqldf("select case_1224_hit from  v1224_d")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_1224_hit <- as.factor(as.character(targ$case_1224_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_1224_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_1224_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_1224_hit==0,0,1)
micro_cluster2$case_1224_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")















#DMFeed00222.dbo.fd_aetna_trad_rce_c10

# 
# junk2 <- sqlQuery(
#   conn,
#   "SELECT  p.* from dmfeed00222.dbo.fd_aetna_trad_mem_vdsa  p  with (nolock)",
#   max=50)
# 
# str(junk2,list.len = ncol(junk2))
# 
# junk2 <- sqlQuery(
#   conn,
#   "SELECT  p.DMTRAD_CUMBID from dmfeed00222.dbo.fd_aetna_trad_mem_vdsa  p  with (nolock)",
#   max=50)
# 
# junk2 <- sqlQuery(
#   conn,
#   "SELECT replace(str(p.DMTRAD_CUMBID,10,0),' ','0') as foo from dmfeed00222.dbo.fd_aetna_trad_mem_vdsa  p  with (nolock)",
#   max=50)
# 
# 
# junk2 <- sqlQuery(
#   conn,
#   "SELECT RIGHT('000000000' + convert(char(10),p.DMTRAD_CUMBID), 10) as foo from dmfeed00222.dbo.fd_aetna_trad_mem_vdsa  p  with (nolock)",
#   max=50)
# 
# 
# junk3 <- sqlQuery(
#   conn,
#   "SELECT * from dmfeed00222.dbo.fd_aetna_trad_vdsa vdsa with (nolock)
# inner join dmfeed00222.dbo.fd_aetna_trad_rce_clm clm with (nolock)
# on clm.cumb_id_w + clm.cumb_id = vdsa.MEMB_id_card_no
#   where vdsa.MEMB_CUMBOC_HICN != 'NONE'",
#   max=500)
# 
# junk3mem <- sqlQuery(
#   conn,
#   "SELECT * from dmfeed00222.dbo.fd_aetna_trad_vdsa vdsa with (nolock)
# inner join dmfeed00222.dbo.fd_aetna_trad_rce_clm clm with (nolock)
# on clm.cumb_id_w + clm.cumb_id = vdsa.MEMB_id_card_no
#   where vdsa.MEMB_CUMB_ID = 349678882")
# 
# MEMB_CUMB_ID 
# 328756009
# 
# 
# 
# 
# 

conn_racer = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)

# 
# junk4 <- sqlQuery(
#   conn_racer,
#   "SELECT * from dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob with (nolock)
#   where MEMB_CUMBOC_HICN != 'NONE'",
#   max=50)
# 
# junk4 <- sqlQuery(
#   conn_racer,
#   "SELECT * from dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob with (nolock)
#   ",
#   max=50)
# str(junk4,list.len = ncol(junk4))
# 
# 
# 
options(scipen = 999)
junk5 <- sqlQuery(
  conn_racer,
  "SELECT * from dbo.MEMBER with (nolock)
where MEMBER_NO = '32258388146225'

  ",
  max=50)
# 
# 
# str(junk5,list.len = ncol(junk5))
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# 
# junk4mem <- sqlQuery(
#   conn_racer,
#   "SELECT * from dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob with (nolock)
#   where MEMB_CUMB_ID = 349678882")
# 
# junk4feed <- sqlQuery(
#   conn_racer,
#   "SELECT max(FEED_ID) as mx from dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob with (nolock)
#   where FEED_ID != 999")
# 
# 
# over_lap1 <- sqlQuery(
#   conn_racer,
#   "SELECT * from dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob with (nolock)
#   where MEMB_CUMBOC_COBCD != 'CN'
#   and DATEDIFF(D,   MEMB_DOB, GETDATE()) < 23725
#    and DATEDIFF(D,   MEMB_EFFTV_DT, GETDATE()) < 180
#   order by MEMB_CUMB_ID, MEMB_EFFTV_DT")
# 
# # over_lap2 <- sqldf(
# #   "SELECT MEMB_CUMB_ID, MEMB_EFFTV_DT, count(MEMB_CUMB_ID) as cnt from over_lap1
# #   group by MEMB_CUMB_ID, MEMB_EFFTV_DT
# #   having cnt >1")
# # 
# # over_lap11 <- sqlQuery(
# #   conn_racer,
# #   "SELECT MEMB_CUMB_ID, MEMB_EFFTV_DT, MEMB_TERM_DT from dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob with (nolock)
# #   where FEED_ID > 156
# #   and FEED_ID != 999
# #   order by MEMB_CUMB_ID, MEMB_EFFTV_DT")
# 
# 
# over_lap1$DM_EXTRACT_DT <- NULL
# over_lap1$NMSPSEND_HIC <- NULL
# over_lap1$NMSPRESP_CMSDCN <- NULL
# 
# over_lap1 <- sqldf("select distinct * from over_lap1")
# over_lap2 <- sqldf(
#   "SELECT MEMB_CUMB_ID, count(MEMB_CUMB_ID) as cnt from over_lap1
#   group by MEMB_CUMB_ID
#   having cnt >1")
# 
# 
# over_lap1<- sqldf("select  a.* from over_lap1 a, over_lap2 b
#                  where a.MEMB_CUMB_ID = b.MEMB_CUMB_ID
#                  order by a.MEMB_CUMB_ID, a.MEMB_EFFTV_DT")
# 
# #over_lap1 <- data.frame(r_index = row.names(over_lap1), over_lap1)
# 
# #library(dplyr)
# 
# over_lap1a <- over_lap1 %>%
#   arrange(MEMB_CUMB_ID, MEMB_EFFTV_DT) %>%
#   group_by(MEMB_CUMB_ID) %>%
#   mutate(diff = MEMB_EFFTV_DT - lag(MEMB_EFFTV_DT),
#          overlap_days = as.numeric(diff, units = 'days'))
# 
# over_lap1a$overlap_days<- ifelse(is.na(over_lap1a$overlap_days), 0, 
#                                      over_lap1a$overlap_days)
# over_lap1a$overlap_days <- as.numeric(as.character(over_lap1a$overlap_days))
# 
# over_lap1b <- sqldf("select distinct MEMB_CUMB_ID from over_lap1a where overlap_days > 0" , method = "name_class")
# 
# over_lap1aa <- sqldf("select distinct * from over_lap1 where MEMB_CUMB_ID = '206888302'")
# over_lap1aa <- over_lap1aa %>%
#   select(MEMB_CUMBOC_COBCARRNM , everything())
# 
# over_lap1aaa <- sqldf( "select a.* from over_lap1 a, over_lap1b b where a.MEMB_CUMB_ID = b.MEMB_CUMB_ID"
#                      )
# 
# 
# over_lap1aaa <- over_lap1aaa %>%
#   select(MEMB_CUMBOC_COBCARRNM , everything())
# 
# write.csv(over_lap1aaa, file = "over_lap1aaa.csv")
#scp dless1@apsrd9425:/home/dless1/aetna/over_lap1aaa.csv /H/My_Doccuments

# 
# over_lap1a <- sqldf("select distinct r_index, MEMB_CUMB_ID, MEMB_EFFTV_DT as start_date
#                     from over_lap1")
# 
# over_lap1b <- sqldf("select distinct MEMB_CUMB_ID, MEMB_EFFTV_DT as end_date,r_index as end_index 
#                     from over_lap1")
# 
# 
# over_lap1c <- sqldf("select distinct o.*, b.end_date
#                     from over_lap1a o, over_lap1b b
#                     where o.MEMB_CUMB_ID = b.MEMB_CUMB_ID
#                     and o.r_index != b.end_index
#                     and o.start_date != b.end_date
#                     order by o.MEMB_CUMB_ID")
# 
# #MEMB_AETNA_PRI_2ND_IND
# 
# over_lap3 <- over_lap1c %>%
#   rowwise() %>%
#   do(data_frame(MEMB_CUMB_ID = .$MEMB_CUMB_ID,
#                 Date = seq(.$start_date, .$end_index, by = 1))) %>%
#   distinct()  %>%
#   ungroup() %>%
#   count(MEMB_CUMB_ID)


dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob

junk5 <- sqlQuery(
  conn_racer,
  "SELECT * from dbswp0625.RACERRESEARCH.dbo.vwAetnaMembersUnique with (nolock)
  order by member_id_number
  ",
  max=50)
write.csv(junk5, file = "com_member_example.csv")
scp dless1@apsrd9425:/home/dless1/aetna/com_member_example.csv /H/My_Doccuments



dbswp0625.RACERRESEARCH.dbo.vwAetnaMembersUnique

str(junk5,list.len = ncol(junk5))


Dbswp0625.RacerResearch.dbo.vwAetnaMemberCob




over_lap1 <- sqlQuery(
  conn_racer,
  "SELECT * from dbswp0625.RACERRESEARCH.dbo.vwAetnaMembersUnique with (nolock)
  where DATEDIFF(D,   Pat_Date_Effective, GETDATE()) < 180
  order by member_id_number, Pat_Date_Effective")

# over_lap2 <- sqldf(
#   "SELECT MEMB_CUMB_ID, MEMB_EFFTV_DT, count(MEMB_CUMB_ID) as cnt from over_lap1
#   group by MEMB_CUMB_ID, MEMB_EFFTV_DT
#   having cnt >1")
# 
# over_lap11 <- sqlQuery(
#   conn_racer,
#   "SELECT MEMB_CUMB_ID, MEMB_EFFTV_DT, MEMB_TERM_DT from dbswp0625.RACERRESEARCH.dbo.vwAetnaMemberCob with (nolock)
#   where FEED_ID > 156
#   and FEED_ID != 999
#   order by MEMB_CUMB_ID, MEMB_EFFTV_DT")


# over_lap1$DM_EXTRACT_DT <- NULL
# over_lap1$NMSPSEND_HIC <- NULL
# over_lap1$NMSPRESP_CMSDCN <- NULL
# 
# over_lap1 <- sqldf("select distinct * from over_lap1")
over_lap2 <- sqldf(
  "SELECT member_id_number, count(member_id_number) as cnt from over_lap1
  group by member_id_number
  having cnt >1")


over_lap1b<- sqldf("select  a.* from over_lap1 a, over_lap2 b
                 where a.member_id_number = b.member_id_number
                 order by a.member_id_number, a.Pat_Date_Effective")

write.csv(over_lap1b, file = "over_lap1b.csv")
scp dless1@apsrd9425:/home/dless1/aetna/over_lap1b.csv /H/My_Doccuments





















conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
                               )

 
# 
# 
# 
# stuff = sqlQuery(
#   conn,
#   "SELECT  p.* from RACER00222.dbo.PARS p,RACER00222.dbo.CLAIM_STATUS s
# where s.CLAIM_ID = p.ORIG_CLAIM_ID
# and p.post_OPTUM_LEAKAGE_FLAG='1' 
# and  p.PROJECT_ID=222
# and  p.Age_at_time_of_claim >18
# and  p.Age_at_time_of_claim < 65
# and s.CASE_ID=1224
# and s.STATUS_CODE in (2,50,55)
# and s.CURRENT_STATUS=1
# AND ( p.externalvendor like '%COB%'		
#      AND left( p.externalvendor,5) <> 'OPTUM'	
#      AND left( p.externalvendor,3) <> 'AIM')",
#   max=100)      
# 
# 
# 
case_id_list <- sqlQuery(
  conn,
  "SELECT  * from RACER00222.dbo.CASE_DATA CD
  where CASE_ID = 566")



aetna_pars = sqlQuery(
  conn,
  "SELECT  p.* from racerresearch.dbo.PARS p
where p.post_OPTUM_LEAKAGE_FLAG='1' 
and  p.PROJECT_ID=222
and  p.Age_at_time_of_claim >18
and  p.Age_at_time_of_claim < 65

AND ( p.externalvendor like '%COB%'		
     AND left( p.externalvendor,5) <> 'OPTUM'	
     AND left( p.externalvendor,3) <> 'AIM')")


# and DATEDIFF(D,  p.ORIGINAL_DATE_PAID, GETDATE()) < 730
# CLAIM_ID
# and status_code in (2,50,55) and current_status=1


statuses = sqlQuery(
  conn, "select * from racer00222.dbo.Claim_Status
where case_id=1224 ")  


# other commercial insurance no hits
Other_Insurance_Is_Primary = sqlQuery(
  conn, "select * from racer00222.dbo.Claim_Status
where case_id=566 ")  


# only 30 aetna in PARS and staus with case_id = 1224
stuff <- sqldf ("select a.* from aetna_pars a, statuses s
                     where a.ORIG_CLAIM_ID = s.CLAIM_ID")





cs_A = sqlQuery(
  conn,
  "SELECT DISTINCT c.PATIENT_ID,
  c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,SUBSTRING(c.CLAIM_NO, 1, 12) AS CLAIM_CLAIM_NO                                                                          
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID 
,c.PROJECT_ID
,c.INS_GROUP_ID
,c.GROUP_SIZE
,c.PROVIDER_ID
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID

from racer00222.DBO.CLAIM c
INNER JOIN racer00222.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
INNER JOIN racer00222.dbo.Claim_Status cs                                                                        
on c.claim_id = cs.claim_id
  WHERE c.PROJECT_ID = 222
  and c.CLAIM_ID IS NOT NULL
  and cs.case_id=1224
  and c.PATIENT_AGE > 18
  and c.PATIENT_AGE <65
  ")


cs_A$case_control <-1

control_group1 <-  sqlQuery(
  conn,
  "SELECT DISTINCT c.PATIENT_ID,
  c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,SUBSTRING(c.CLAIM_NO, 1, 12) AS CLAIM_CLAIM_NO                                                                          
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID 
,c.PROJECT_ID
,c.INS_GROUP_ID
,c.GROUP_SIZE
,c.PROVIDER_ID
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
from racer00222.DBO.CLAIM c
INNER JOIN racer00222.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
INNER JOIN racer00222.dbo.Claim_Status cs                                                                        
on c.claim_id = cs.claim_id
  WHERE c.PROJECT_ID = 222
  and c.CLAIM_ID IS NOT NULL
  and case_id !=1224
  and c.PATIENT_AGE > 18
  and c.PATIENT_AGE <65
  and DATEDIFF(D,  c.DATE_PAID, GETDATE()) < 90")
  
  
control_group1$case_control <-0


cs_b <- rbind(cs_A ,control_group1[,names(cs_A)] )

#saveRDS(cs_b, file="cs_b.Rda")

DX_claim_cc  <- sqlQuery(
  conn,
  " select
  DISTINCT c.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM racer00222.dbo.CLAIM c
  INNER JOIN racer00222.dbo.ICD9 DX
  ON c.CLAIM_ID = DX.CLAIM_ID
  where c.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 5
  and c.PATIENT_AGE > 18
  and c.PATIENT_AGE <65
  and DATEDIFF(D,  c.DATE_PAID, GETDATE()) < 90"
)

cl_id_cc <- sqldf("select distinct CLAIM_CLAIM_ID from cs_b ")


library(dplyr)

#library(tidyverse)

DX_claim_cc <- inner_join(DX_claim_cc, cl_id_cc, by = c("CLAIM_ID" = "CLAIM_CLAIM_ID") )





DX_claim_cc$ICD9_CODE<-as.character(DX_claim_cc$ICD9_CODE)
DX_claim_cc$ICD10_CODE<-DX_claim_cc$ICD9_CODE
DX_claim_cc$ICD9_CODE<-gsub(".","",DX_claim_cc$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim_cc, file="DX_claim_cc.Rda")



#DX_claim_cc <- readRDS(file="DX_claim_cc.Rda")



DX_claimids_Diag_cc <- sqldf("select distinct * from DX_claim_cc where ICD9_TYPE='DIAG' order by 
                             CLAIM_ID,ORDER_IN_CLAIM")

#charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")


elixhauser_scores_cc <- comorbidity(x=DX_claimids_Diag_cc , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores_cc, file="elixhauser_scores_cc.Rda")

elixhauser_scores_cc <- elixhauser_scores_cc[,1:33]

elixhauser_scores_cc2<- elixhauser_scores_cc %>%
  mutate_if(is.numeric, ~as.factor(as.character(.)))

elixhauser_scores_cc2$CLAIM_ID <- as.numeric(elixhauser_scores_cc2$CLAIM_ID)

elixhauser_scores_cc2$CLAIM_IDx <-elixhauser_scores_cc2$CLAIM_ID 



cs_c <- sqldf("select distinct c.*, e.* from cs_b c, elixhauser_scores_cc2 e
              where c.CLAIM_CLAIM_ID  = e.CLAIM_IDx")

saveRDS(cs_c, file="cs_c.Rda")

library(MatchIt)

cs_c$case_control <- as.factor(as.character(cs_c$case_control))
#str(cs_c,list.len = ncol(cs_c))
cs_c$CLAIM_IDx <- NULL
cs_c$CLAIM_DATE_RECEIVED<- NULL
cs_c$GROUP_SIZE<- NULL
cs_c$CLAIM_DATE_ENTERED<- NULL
cs_c$CLAIM_LINE_LINE_NO <- NULL
cs_c$CLAIM_LINE_DATE_PAID<- NULL
cs_c$CLAIM_LINE_CPT_MODIFIER<- NULL

cs_c$CLAIM_LINE_REVENUE_CODE <- ifelse(is.na(cs_c$CLAIM_LINE_REVENUE_CODE), 0, 
                                       cs_c$CLAIM_LINE_REVENUE_CODE)
cs_c$CLAIM_LINE_CPT <- ifelse(is.na(cs_c$CLAIM_LINE_CPT), '0', 
                                       cs_c$CLAIM_LINE_CPT)

colnames(cs_c)[colSums(is.na(cs_c)) > 0]


cs_c$age_group <- cut(cs_c$CLAIM_PATIENT_AGE,
                      breaks=c(-Inf,35,45,66,Inf),
                      labels=c(1,2,3,4))

cs_c$CLAIM_PLACE_OF_SERVICE <- as.factor(cs_c$CLAIM_PLACE_OF_SERVICE)

deletes <- c('CLAIM_LINE_REVENUE_CODE', 
             'CLAIM_LINE_AMT_BILLED', 
             'CLAIM_LINE_AMT_PAID', 
             'CLAIM_LINE_CPT', 
             'CLAIM_LINE_LINE_NO', 
             'CLAIM_LINE_CPT_MODIFIER', 
             'CLAIM_LINE_AMT_ALLOWED', 
             'CLAIM_LINE_DATE_PAID')

cs_c <- cs_c[,setdiff(names(cs_c),deletes)]

cs_c <- sqldf("select distinct * from cs_c")

# reduce size on controls

control2 <- sqldf("select * from cs_c where case_control = 0")

cases2 <- sqldf("select * from cs_c where case_control = 1")


set.seed(77)
idx <- sample(seq(1,2), size = nrow(control2), replace = TRUE, prob = c(0.001, 0.099))
control2 <- control2[idx == 1,]

cases3 <- rbind(control2,cases2 )



library(optmatch)
library(rgenoud)
library(psych)

# changed from 2 to 5:1
matched_optimal <- matchit(case_control ~ age_group + CLAIM_PATIENT_GENDER + CLAIM_PLACE_OF_SERVICE,
                           data =cases3, method = "optimal" , ratio = 5, optmatch_max_problem_size = Inf)

summary(matched_optimal)

#atched_genetic <- matchit(case_control ~  age_group + CLAIM_PATIENT_GENDER + CLAIM_PLACE_OF_SERVICE,
#                          data =cases3, method = "genetic" , optmatch_max_problem_size = Inf)

pre_matched <- match.data(matched_optimal)



str(pre_matched,list.len = ncol(pre_matched))

pre_matched2 <- pre_matched 

pre_matched2$PATIENT_ID <- NULL
pre_matched2$CLAIM_CLAIM_NO <- NULL
pre_matched2$CLAIM_FEED_ID <- NULL
pre_matched2$CLAIM_PAR<- NULL
pre_matched2$age_group<- NULL
pre_matched2$distance <- NULL
pre_matched2$weights<- NULL
pre_matched2$subclass<- NULL
pre_matched2$CLAIM_ID<- NULL
pre_matched2$PROJECT_ID <- NULL
pre_matched2$CLAIM_DATE_PAID<- NULL
pre_matched2$CLAIM_AMT_BILLED<- NULL
pre_matched2$CLAIM_DATE_DISCHARGED<- NULL
pre_matched2$CLAIM_DATE_ADMITTED<- NULL
pre_matched2$CLAIM_DATE_OF_SERVICE_END <- NULL
pre_matched2$CLAIM_DATE_OF_SERVICE_BEG <- NULL
pre_matched2$CLAIM_CLAIM_ID  <- NULL
pre_matched2$PROVIDER_ID  <- NULL


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)
# build CCS dx table

# pre_matched2 <- distinct(pre_matched2 %>%
#                      left_join(select(CCS, CCS_Category,ICD10_Code), 
#                                by = c("ICD10_Code" = "CLAIM_PRINCIPAL_DIAG")))

pre_matched2$CLAIM_PRINCIPAL_DIAG<-as.character(pre_matched2$CLAIM_PRINCIPAL_DIAG)
pre_matched2$CLAIM_PRINCIPAL_DIAG<-gsub(".","",pre_matched2$CLAIM_PRINCIPAL_DIAG,fixed=TRUE)

pre_matched2 <- sqldf("select distinct p.*, c.CCS_Category
                      from pre_matched2 p left join CCS c  on
                      p.CLAIM_PRINCIPAL_DIAG = c.ICD10_Code")

pre_matched2$CCS_Category <- ifelse(is.na(pre_matched2$CCS_Category), 0, pre_matched2$CCS_Category)

pre_matched2$CCS_Category <-as.factor(pre_matched2$CCS_Category)
pre_matched2$CLAIM_PRINCIPAL_DIAG <- NULL
pre_matched2$CLAIM_AMT_ALLOWED <- NULL
pre_matched2$CLAIM_PROVIDER_ID <- as.factor(as.character((pre_matched2$CLAIM_PROVIDER_ID)))
pre_matched2$INS_GROUP_ID <- as.factor(as.character((pre_matched2$INS_GROUP_ID)))
pre_matched2$score <- as.numeric(as.character(pre_matched2$score))
pre_matched2$CLAIM_PROVIDER_ID<- NULL
pre_matched2$INS_GROUP_ID<- NULL

#library(h2o)
#h2o.init(port=54333)

idx <- sample(seq(1,2), size = nrow(pre_matched2), replace = TRUE, prob = c(0.7, 0.3))
train <- pre_matched2[idx == 1,]
test <- pre_matched2[idx == 2,]

test_false_mod2 <- test

#str(test_false_mod2,list.len = ncol(test_false_mod2))


train_auto_ml <- train
test_auto_ml <- test


train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "case_control"
x <- setdiff(names(train), y)



response <- "case_control"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)

nfolds = 10

rf_3 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         validation_frame = test,
                         ntrees = 500,
                         nfolds = nfolds,
                         nbins = 50,
                         balance_classes = TRUE,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)

# pred_rf_3 <- h2o.performance(rf_3, newdata = test,  valid = TRUE)
# pred_rf_3

summary(rf_3)

head(as.data.frame(h2o.varimp(rf_3)),n=100)


(describeBy(pre_matched2,pre_matched2$case_control))

describeData(pre_matched2)




numlist <- c(names(Filter(is.numeric,pre_matched2)))
#pre_matched2_numerics <- match(numlist, names(pre_matched2))

modelList <- lapply(numlist, function(resp) {
  mF <- formula(paste(resp,"~ case_control" ))
  aov(mF, data = pre_matched2)
})

lapply(modelList, summary)

# anova loop

# anova_formula <- as.formula(paste0("cbind(", paste(names(pre_matched2_numerics), collapse = ","), ") ~ case_control"))
# 
# amnova_fit <- aov(anova_formula, data = pre_matched2)


# chi square loop

factor_list3 <- c(names(Filter(is.factor,pre_matched2)))
fact_match3 <- match(factor_list3, names(pre_matched2))
catVarsFac <- pre_matched2[,fact_match3]

nms <- names(catVarsFac)


result <- sapply(nms, FUN = function(x, catVarsFac) {
  qinq <- catVarsFac[, c("case_control", x)]
  by(data = qinq, INDICES = catVarsFac$case_control, FUN = function(y, qinq) {
    chisq.test(table(y[, x]), p =  table(qinq[, x]), rescale.p = TRUE)
  }, qinq = qinq)
}, catVarsFac = catVarsFac, simplify = FALSE)









########################################################################



# PARS only


aetna_pars = sqlQuery(
  conn,
  "SELECT  p.* from racerresearch.dbo.PARS p
where p.post_OPTUM_LEAKAGE_FLAG='1' 
and  p.PROJECT_ID=222
and  p.Age_at_time_of_claim >18
and  p.Age_at_time_of_claim < 65

AND (	
     left( p.externalvendor,5) <> 'OPTUM'	
     AND left( p.externalvendor,3) <> 'AIM')")



str(aetna_pars,list.len = ncol(aetna_pars))

aetna_par_leakage= sqlQuery(
  conn,
  "SELECT  p.* from racerresearch.dbo.PARS p,RACER00222.dbo.CLAIM_STATUS s
where s.CLAIM_ID = p.ORIG_CLAIM_ID
and p.post_OPTUM_LEAKAGE_FLAG='1'
and  p.PROJECT_ID=222
and  p.Age_at_time_of_claim >18
and  p.Age_at_time_of_claim < 65
and s.CASE_ID=1224")

aetna_par= sqlQuery(
  conn,
  "SELECT  p.* from racerresearch.dbo.PARS p,RACER00222.dbo.CLAIM_STATUS s
where s.CLAIM_ID = p.ORIG_CLAIM_ID
and  p.PROJECT_ID=222
and  p.Age_at_time_of_claim >18
and  p.Age_at_time_of_claim < 65
and s.CASE_ID=1224")

write.table(aetna_par, file = "aetna_par.csv",
            row.names = FALSE, sep ="\t")

#scp dless1@apsrd9425:/home/dless1/aetna/aetna_par.csv ~/Desktop


#and p.post_OPTUM_LEAKAGE_FLAG='1'





dbswp0625.RACERRESEARCH.dbo.vwAetnaMembersUnique