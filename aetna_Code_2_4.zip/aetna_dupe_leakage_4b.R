
# V 6 caseid 30

setwd("~/aetna")




library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
#library(tcltk)
library(DMwR)

library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)

library(lubridate)
library(caret)
library(klaR)

library(broom)
library(factoextra)
library(reshape2)
library(plyr)

library(MASS)
library(tidyr)
library(readr)
library(RecordLinkage)

#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


library(RODBC)


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

options(scipen = 999)

all_fileds <- sqlQuery( conn, 
                        "SELECT  * 
                        FROM dbo.AetnaDuplicateResearch " , max=500)



str(all_fileds, list.len=ncol(all_fileds))


cl_dup1  <- sqlQuery( conn, 
                  "SELECT  ROWID ,CLAIM_NO, Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                  CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                  CL_DATE_PAID ,CLAIM_SUFFIX ,
                  Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                  DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                  DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                  Line_Of_Business ,Other_Ins_Paid_Amt ,
                  PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                  PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service,L_MDFR1_CD ,
L_MDFR2_CD , L_MDFR3_CD ,l_units
                  FROM dbo.AetnaDuplicateResearch " )



# change factors with NA to 0
f <- sapply(cl_dup1, is.factor)
cl_dup1[f] <- lapply(cl_dup1[f], as.character)
cl_dup1[is.na(cl_dup1)] <- 0
cl_dup1[f] <- lapply(cl_dup1[f], as.factor)

# other NAs to 0
cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)


score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
cl_dup1 <- data.frame(r_index = row.names(cl_dup1),cl_dup1)
dupes <-cl_dup1

dupes <-  dupes %>% replace(is.na(.), 0)


dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
dupes[sapply(dupes,is.integer)] <- lapply(dupes[sapply(dupes, is.integer)], as.factor)

dupes$REVENUE_CODE <- as.factor(as.character(dupes$REVENUE_CODE))
dupes$Procedure_Code  <- as.factor(as.character(dupes$Procedure_Code ))
dupes$PAT_MEMBER_NO  <- as.factor(as.character(dupes$PAT_MEMBER_NO ))


dupes$ROWID <- NULL

#dupes$PAT_MEMBER_NO <- NULL

dupes$CL_DATE_OF_SERVICE_BEG <- NULL
dupes$CL_DATE_OF_SERVICE_END <- NULL
dupes$CL_DATE_PAID  <- NULL
dupes$r_index <- NULL

dupes$PROVIDER_NO  <- NULL

dupes$PAT_MEMBER_NO <- as.character(dupes$PAT_MEMBER_NO)
dupes$PIN7 <- as.character(dupes$PIN7)
dupes$TAX_ID <- as.character(dupes$TAX_ID)

#str(dupes, list.len=ncol(dupes))
colnames(dupes)[colSums(is.na(dupes)) > 0]


new_identity <- dupes$CLAIM_NO
dupes$CLAIM_NO <- NULL
# works
# block on memberid
rpairs <- compare.dedup(dupes, blockfld =list(25) ,identity = new_identity,
                        strcmp =  c("Account", "Business_Line", "CL_AMT_ALLOWED", "CL_AMT_BILLED",
                                    "CL_AMT_PAID", "CLAIM_SUFFIX", "Claims_Status", "Coinsurance_Amt",
                                    "Copay_Amt", "CPT", "Deductible_Amt", "DIAGNOSIS_1", "Line_Of_Business",
                                    "Other_Ins_Paid_Amt",  "Place_Of_Service",
                                    "PRINCIPAL_DIAG",   "Procedure_Code", "PROCEDURE_CODE_2",
                                    "REVENUE_CODE", "Suffix", "Type_Of_Service", "PIN7", "TAX_ID"
                                    ))

summary(rpairs)

result=classifyUnsup(rpairs,method="kmeans")

summary(result)

matches1 <-result$pairs

str(matches1, list.len=ncol(matches1))



match_pred <- as.data.frame(result$prediction)
# rename
names(match_pred)[1] <- "prediction"




#sigle row
matched_mail <- as.data.frame(getPairs(result, single.rows=TRUE))
# sum columnhs to get score

matches1$Total <- as.numeric(apply(matches1[,3:40], 1, sum))
matches1$Total <- (matches1$Total / max(matches1$Total)) * 100
matches1$PAT_MEMBER_NO <- NULL


matches1 <- data.frame(dupe_index = row.names(matches1),matches1)

# score 100 perfect matches <100 are near dupes
hits <- sqldf("select * from matches1 where Total > 99 and is_match = 1")

hits<- sqldf("select distinct m.*, h.Total from matched_mail m, hits h
where h.id1 = m.id1
              and h.id2 = m.id2
              order by h.Total desc")


hits <- sqldf("select distinct m.*, c.CL_DATE_OF_SERVICE_BEG as CL_DATE_OF_SERVICE_BEG_2,
c.CL_DATE_OF_SERVICE_END as CL_DATE_OF_SERVICE_END_2,
c.CL_DATE_PAID as CL_DATE_PAID_2,
c.PROVIDER_NO as PROVIDER_NO_2,
c.PAT_MEMBER_NO as PAT_MEMBER_NO_2,
c.CLAIM_NO as CLAIM_NO_2
from hits m, cl_dup1 c
                  where m.id2 = c.r_index")

hits <- sqldf("select distinct m.*, 
c.CLAIM_NO as CLAIM_NO_1
from hits m, cl_dup1 c
                  where m.id1 = c.r_index")


str(hits, list.len=ncol(hits))



write.table(hits, file = "matches1_7_5.csv",
            row.names = FALSE, sep ="\t")


# only 100% matches
hits100 <- sqldf("select * from hits where Total = 100")


write.table(hits100, file = "matches100_7_5.csv",
            row.names = FALSE, sep ="\t")


