
# V 6 caseid 30

setwd("~/aetna")




library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
#library(tcltk)
library(DMwR)

library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)

library(lubridate)
library(caret)
library(klaR)

library(broom)
library(factoextra)
library(reshape2)
library(plyr)

library(MASS)
library(tidyr)
library(readr)
library(RecordLinkage)


#library(dbplyr)
#library(sparklyr)


#sc <- spark_connect(master = "local", version = "2.2.1")
#spark_disconnect(sc)

# sparkling water package
#library(rsparkling)

#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


library(RODBC)


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

# pin7 is a modified provider id

options(scipen = 999)

all_fileds <- sqlQuery( conn, 
                        "SELECT  * 
                        FROM dbo.AetnaDuplicateResearch " , max=500)



str(all_fileds, list.len=ncol(all_fileds))


cl_dup1  <- sqlQuery( conn, 
                  "SELECT  ROWID ,CLAIM_NO, Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                  CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                  CL_DATE_PAID ,CLAIM_SUFFIX ,
                  Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                  DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                  DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                  Line_Of_Business ,Other_Ins_Paid_Amt ,
                  PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                  PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service,IS_ADJUSTED,L_MDFR1_CD ,
L_MDFR2_CD , L_MDFR3_CD ,l_units,source,claim_type
                  FROM dbo.AetnaDuplicateResearch " , max=500)



# remove duplicate row ids
#cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
# change factors with NA to 0
f <- sapply(cl_dup1, is.factor)
cl_dup1[f] <- lapply(cl_dup1[f], as.character)
cl_dup1[is.na(cl_dup1)] <- 0
cl_dup1[f] <- lapply(cl_dup1[f], as.factor)

# other NAs to 0
cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)


score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
cl_dup1 <- data.frame(r_index = row.names(cl_dup1),cl_dup1)
dupes <-cl_dup1

# dupes <- dupes %>%
#   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
#          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
#          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
#   )

dupes <-  dupes %>% replace(is.na(.), 0)


dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
dupes[sapply(dupes,is.integer)] <- lapply(dupes[sapply(dupes, is.integer)], as.factor)

dupes$REVENUE_CODE <- as.factor(as.character(dupes$REVENUE_CODE))
dupes$Procedure_Code  <- as.factor(as.character(dupes$Procedure_Code ))
dupes$PAT_MEMBER_NO  <- as.factor(as.character(dupes$PAT_MEMBER_NO ))


dupes$ROWID <- NULL

#dupes$PAT_MEMBER_NO <- NULL

dupes$CL_DATE_OF_SERVICE_BEG <- NULL
dupes$CL_DATE_OF_SERVICE_END <- NULL
dupes$CL_DATE_PAID  <- NULL
dupes$source <- NULL
dupes$r_index <- NULL

dupes$PROVIDER_NO  <- NULL

dupes$PAT_MEMBER_NO <- as.character(dupes$PAT_MEMBER_NO)
dupes$PIN7 <- as.character(dupes$PIN7)
dupes$TAX_ID <- as.character(dupes$TAX_ID)

#str(dupes, list.len=ncol(dupes))
colnames(dupes)[colSums(is.na(dupes)) > 0]
# 
# rpairs <- compare.dedup(dupes, blockfld =list(25) ,phonetic = FALSE,
#                          strcmp =  c("Account", "Business_Line", "CL_AMT_ALLOWED", "CL_AMT_BILLED",
#                                      "CL_AMT_PAID", "CLAIM_SUFFIX", "Claims_Status", "Coinsurance_Amt",
#                                      "Copay_Amt", "CPT", "Deductible_Amt", "DIAGNOSIS_1", "DIAGNOSIS_10",
#                                      "DIAGNOSIS_11", "DIAGNOSIS_2", "DIAGNOSIS_3", "DIAGNOSIS_4", "DIAGNOSIS_5",
#                                      "DIAGNOSIS_6", "DIAGNOSIS_7", "DIAGNOSIS_8", "DIAGNOSIS_9", "Line_Of_Business",
#                                      "Other_Ins_Paid_Amt",  "Place_Of_Service",
#                                      "PRINCIPAL_DIAG", "Procedure_Code", "PROCEDURE_CODE_2", "PROVIDER_NO",
#                                      "REVENUE_CODE", "Suffix", "Type_Of_Service", "IS_ADJUSTED", "PIN7", "TAX_ID"))


new_identity <- dupes$CLAIM_NO
dupes$CLAIM_NO <- NULL
# works
# block on memberid
rpairs <- compare.dedup(dupes, blockfld =list(25) ,identity = new_identity,
                        strcmp =  c("Account", "Business_Line", "CL_AMT_ALLOWED", "CL_AMT_BILLED",
                                    "CL_AMT_PAID", "CLAIM_SUFFIX", "Claims_Status", "Coinsurance_Amt",
                                    "Copay_Amt", "CPT", "Deductible_Amt", "DIAGNOSIS_1", "Line_Of_Business",
                                    "Other_Ins_Paid_Amt",  "Place_Of_Service",
                                    "PRINCIPAL_DIAG",   "Procedure_Code", "PROCEDURE_CODE_2",
                                    "REVENUE_CODE", "Suffix", "Type_Of_Service", "IS_ADJUSTED", "PIN7", "TAX_ID"
                                    ))

# works does string match on dx code
# rpairs <- compare.dedup(dupes, blockfld =list(25) ,identity = new_identity,
#                         strcmp =  c("PRINCIPAL_DIAG",  "Procedure_Code", "PROCEDURE_CODE_2"
#                         ))
result=classifyUnsup(rpairs,method="bclust")

summary(result)
matches1 <-result$pairs

#sigle row
matched_mail <- as.data.frame(getPairs(result, single.rows=TRUE))
# sum columnhs to get score

matches1$Total <- as.numeric(apply(matches1[,3:42], 1, sum))
matches1$Total <- (matches1$Total / max(matches1$Total)) * 100

matches2 <- sqldf("select m.*, c.CL_DATE_OF_SERVICE_BEG,
c.CL_DATE_OF_SERVICE_END,
c.CL_DATE_PAID,
c.PROVIDER_NO,
c.source
from matches1 m, cl_dup1 c
                  where m.id1 = c.r_index")


ggplot(matches2, aes(x=factor(source), y= Total, fill =factor(source) ))+
  geom_boxplot(alpha=0.4) +
  stat_summary(fun.y=mean, geom="point", shape=20, size=5, color = "red", fill="red")+
  theme(legend.position = "none")+
  scale_fill_brewer(palette = "Set3")+
  labs(title = "Score by Source", x = "source", y = "Total")


matches2$no_want <- ifelse(matches2$source == "do not want these", 1, 0)
matches2$leakage <- ifelse(matches2$source == "leakage", 1, 0)
matches2$past_refunds <- ifelse(matches2$source == "past refunds", 1, 0)


anova_no_want <- aov(Total ~ no_want, data = matches2)
summary(anova_no_want)
anova_leakage <- aov(Total ~ leakage, data = matches2)
summary(anova_leakage)
anova_past_refunds <- aov(Total ~ past_refunds, data = matches2)
summary(anova_past_refunds)





