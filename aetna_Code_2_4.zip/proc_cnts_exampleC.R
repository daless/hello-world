


# inpatient only


setwd("~/aetna")


library(RODBC)
library(sqldf)
library(dplyr)
library(psych)
library(plyr)

conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)




claims_line_180 <- sqlQuery(
  conn,
  " select L.CLAIM_LINE_ID,
  L.CLAIM_ID,
  CLM.CLAIM_NO,
CLM.PATIENT_ID,
  L.PROJECT_ID,
  L.LINE_NO,
  L.FEED_ID,
  L.DATE_OF_SERVICE_BEG,
  L.DATE_OF_SERVICE_END,
  CLM.DATE_OF_SERVICE_BEG as DATE_OF_SERVICE_BEG_CLAIM,
  CLM.DATE_OF_SERVICE_END as DATE_OF_SERVICE_END_CLAIM,
  CLM.BILL_TYPE,
  CLM.PLACE_OF_SERVICE,
CLM.PRINCIPAL_DIAG,
  L.CPT,
  L.CPT_MODIFIER,
  L.UNITS_BILLED,
  L.UNITS_ALLOWED,
  L.REVENUE_CODE,
  L.AMT_PAID
  FROM dbo.CLAIM_LINE L, dbo.CLAIM CLM
  WHERE L.CLAIM_ID = CLM.CLAIM_ID
  AND L.PROJECT_ID = 222
  AND L.AMT_PAID  > 0
  AND CLM.DATE_PAID >= '01-01-2018'
  AND CLM.DATE_PAID <= '12-31-2018'
  AND CLM.BILL_TYPE = 111
  ")


# primary dx by claim

primary_dx <- sqldf("select distinct CLAIM_NO,PATIENT_ID, PRINCIPAL_DIAG as ICD9_CODE,
 DATE_OF_SERVICE_BEG_CLAIM,
                    DATE_OF_SERVICE_END_CLAIM from claims_line_180")


primary_dx$ICD9_CODE <- gsub(".","",primary_dx$ICD9_CODE, fixed = TRUE)



#  CCS DX
CCS_lookup <- read.csv("ccs_dx_icd10cm_2018_1.csv", sep = ",",  quote = "\"", header = TRUE)
# rename columns
CCS_lookup$ICD9_CODE <- CCS_lookup$X.ICD.10.CM.CODE.
CCS_lookup$CCS_DX <- CCS_lookup$X.CCS.CATEGORY.
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))

# build CCS dx table
CCS_Codes_test <- sqldf("select DISTINCT d.*,  c.CCS_DX
                        from primary_dx d left join CCS_lookup c on d.ICD9_CODE = c.ICD9_CODE
                        order by d.CLAIM_NO ")
CCS_Codes_test$CCS_DX <- ifelse(is.na(CCS_Codes_test$CCS_DX), 0, CCS_Codes_test$CCS_DX)

CCS_Codes_test$CCS_DX <-as.factor(CCS_Codes_test$CCS_DX)


dx_cnts <- sqldf("select CLAIM_NO,  count(CPT) as cpt_cnt_claim , CPT from claims_line_180
where CPT != ''
                 group by CLAIM_NO" )

CCS_Codes_test2 <- sqldf("select  c.*, d.CPT, d.cpt_cnt_claim from CCS_Codes_test c, dx_cnts d
where c.CLAIM_NO = d.CLAIM_NO ")

# time between claims by member

CCS_Codes_test3 <- CCS_Codes_test2 %>%
  arrange( PATIENT_ID, DATE_OF_SERVICE_BEG_CLAIM) %>%
  group_by( PATIENT_ID) %>%
  dplyr::mutate(diff =  DATE_OF_SERVICE_BEG_CLAIM - lag(DATE_OF_SERVICE_END_CLAIM),
                days_between_admins = as.numeric(diff, units = 'days'))


CCS_Codes_test3$days_between_admins <- ifelse(is.na(CCS_Codes_test3$days_between_admins),
                                         0, CCS_Codes_test3$days_between_admins + 1)

names(CCS_Codes_test3)[10] <- "days_between_admins"


CCS_Codes_test_time_diff <- sqldf("select CLAIM_NO , PATIENT_ID,  ICD9_CODE, DATE_OF_SERVICE_BEG_CLAIM, DATE_OF_SERVICE_END_CLAIM,
              CCS_DX , CPT, cpt_cnt_claim, days_between_admins
              from CCS_Codes_test3 where days_between_admins > 0")


claim_level1 <- sqldf("select CCS_DX,CPT,cpt_cnt_claim from  CCS_Codes_test3")

claim_level1$CPT <- as.factor(claim_level1$CPT)

claim_level1_descriptives <- claim_level1 %>%
  group_by(CCS_DX,CPT ) %>%
  dplyr::summarize(median_cpt_cnt = median(cpt_cnt_claim, na.rm=TRUE))

claim_level1_descriptives2 <- claim_level1 %>%
  group_by(CCS_DX,CPT ) %>%
  dplyr::summarize(mean_cpt_cnt = mean(cpt_cnt_claim, na.rm=TRUE))  



names(claim_level1_descriptives)[3] <- "median_cpt_cnt"
names(claim_level1_descriptives2)[3] <- "mean_cpt_cnt"

claim_level1_descriptives$CCS_DX <- NULL
claim_level1_descriptives$CPT <- NULL


claim_level1_descriptives_all <- cbind(claim_level1_descriptives2, claim_level1_descriptives)

# time spans

claim_level1_descriptives_time <- CCS_Codes_test_time_diff %>%
  group_by(CCS_DX,CPT ) %>%
  dplyr::summarize(median_cpt_cnt = median(days_between_admins, na.rm=TRUE))

claim_level1_descriptives2_time <- CCS_Codes_test_time_diff %>%
  group_by(CCS_DX,CPT ) %>%
  dplyr::summarize(mean_cpt_cnt = mean(days_between_admins, na.rm=TRUE))



claim_level1_descriptives_time_all <- cbind(claim_level1_descriptives_time,
                                            claim_level1_descriptives2_time)



# member level bechmarks


dx_cnts_member <- sqldf("select CLAIM_NO,  count(CPT) as cpt_cnt_claim , CPT from claims_line_180
                 where d.CPT != ''
                 group by PATIENT_ID" )

CCS_Codes_test2_member <- sqldf("select  c.*, d.CPT from CCS_Codes_test c, dx_cnts_member d
                         where c.PATIENT_ID = d.PATIENT_ID ")




CCS_Codes_test4 <- CCS_Codes_test2_member %>%
  arrange( CLAIM_NO, CPT,DATE_OF_SERVICE_BEG_CLAIM) %>%
  group_by(PATIENT_ID, CLAIM_NO) %>%
  mutate(diff =  DATE_OF_SERVICE_BEG_CLAIM - lag(DATE_OF_SERVICE_END_CLAIM),
         days_between_admins = as.numeric(diff, units = 'days'))

CCS_Codes_test4$days_between_admins <- ifelse(is.na(CCS_Codes_test4$days_between_admins),
                                              0, CCS_Codes_test3$days_between_admins + 1)


member_level1 <- sqldf("select PATIENT_ID, CCS_DX,CPT,cpt_cnt_claim from  CCS_Codes_test4")


member_level1$CPT <- as.factor(member_level1$CPT)

member_level1_descriptives <- member_level1 %>%
  group_by(PATIENT_ID, CCS_DX,CPT ) %>%
  dplyr::summarize(median_cpt_cnt = median(cpt_cnt_claim, na.rm=TRUE))

member_level1_descriptives2 <- member_level1  %>%
  group_by(PATIENT_ID, CCS_DX,CPT ) %>%
  dplyr::summarize(mean_cpt_cnt = mean(cpt_cnt_claim, na.rm=TRUE))  


# rolll up member data to CCS
member_level2_descriptives <- member_level1_descriptives %>%
  group_by( CCS_DX,CPT ) %>%
  dplyr::summarize(median_cpt_cnt_member = median(median_cpt_cnt, na.rm=TRUE))

member_level2_descriptives2 <- member_level1_descriptives2  %>%
  group_by( CCS_DX,CPT ) %>%
  dplyr::summarize(mean_cpt_cnt_member = mean(mean_cpt_cnt, na.rm=TRUE))


names(member_level2_descriptives)[3] <- "median_cpt_cnt_member"
names(member_level2_descriptives2)[3] <- "mean_cpt_cnt_member"

member_level2_descriptives$CCS_DX <- NULL
member_level2_descriptives$CPT <- NULL


member_level2_descriptives2 <- cbind(member_level2_descriptives2, member_level2_descriptives)



# time medians and averages


time1 <- CCS_Codes_test_time_diff %>%
  group_by(CCS_DX,CPT ) %>%
  dplyr::summarize(median_time = median(days_between_admins, na.rm=TRUE))

time2 <- CCS_Codes_test_time_diff %>%
  group_by(CCS_DX,CPT ) %>%
  dplyr::summarize(mean_time = mean(days_between_admins, na.rm=TRUE))  


time2$CCS_DX <- NULL
time2$CPT <- NULL


time2 <- cbind(time1, time2)

member_descriptives3 <- sqldf("select m.*, t.mean_time, t.median_time
                                     from member_level2_descriptives2 m, time2 t
                                     where m.CCS_DX = t.CCS_DX
                                     and m.CPT = t.CPT")

  
write.table(member_descriptives3, file = "baseline_CPT_counts.csv",
            row.names = FALSE, sep ="\t")



# calc ratios

# 
# memcnt$cpt_per_member <- memcnt$tot_cpt / memcnt$mem_cnt
# memcnt$pd_per_member <- memcnt$mem_dol /  memcnt$mem_cnt
# 
# 
# 

