#make clusters of group id ,  ploduct line
# find ratio of refunds to toal number of members
# calc ratio billed to paid ? segments or overall


# ? cluster CCS groups - spherical K means - or neural net feature reduction without a target

# SOM - ratio clusters,  comorbidity scores, age
# neural network with no target ? CCS, elixhouser diseases

setwd("~/aetna")


library(comorbidity)
library(RODBC)
library(sqldf)
#library(dplyr)
library(tidyverse)
library(dummies)
library(SOMbrero)
library(kohonen)
library(broom)
library(cluster)

library(SOMbrero)
library(kohonen)


# scp analytic_data2020_0_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp FIPS_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp USDA.txt dless1@apsrd9425:/home/dless1/aetna


# connection: dbswp0625
# database: RacerResearch
# schema: dbo
# view: vwAetnaTradMemClaimCoverage



conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)



base1 <- sqlQuery(
  conn,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,

CLM.AMT_COB_PAID,


CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,

MEM.member_ID,MEM.MEMBER_NO, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
as cd_SUBCATEGORY, CS.STATUS_CODE, cs.amt_of_refund as Amount_refund,cs.case_id
FROM dbo.CLAIM CLM  with (nolock)
INNER JOIN dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
INNER JOIN dbo.CASE_DATA CD  with (nolock)
ON CS.CASE_ID = CD.CASE_ID
INNER JOIN dbo.STATUS_CODE SC  with (nolock)
ON CS.STATUS_CODE = SC.STATUS_CODE
INNER JOIN dbo.SPECIAL_FIELDS SF  with (nolock)
ON CLM.CLAIM_ID = SF.ID
WHERE CS.HDS_LOB_ID = 2
AND CD.SUBCATEGORY = 10

AND CS.STATUS_CODE IN (2,50,55)
AND CLM.PROJECT_ID = 222
AND IsValidSSN = 1
and CLM.FEED_ID between 150 and 209
")

# base1$Days_of_service <- difftime("2021-1-1",base1$DATE_OF_SERVICE_END ,
#                                                   units = c("days")) 
# 
# base1$Days_of_service <- as.integer(base1$Days_of_service)
# 
# Days_of_service <= 365

base1 <- sqldf(
  "select DISTINCT *
FROM base1
WHERE  PATIENT_AGE >= 18 and PATIENT_AGE <=64
and AMT_PAID >0
  ")



summary(base1
        )


DX_claim  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.CLAIM CLM  with (nolock)
  INNER JOIN DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
  where CLM.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 5
  AND CS.STATUS_CODE IN (2,50,55)
  and CLM.FEED_ID >= 150
 and CLM.FEED_ID between 150 and 209


  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)


cl_id <- sqldf("select distinct CLAIM_ID from base1 ")


DX_claim <- sqldf("select d.* from DX_claim d, cl_id c
                  where d.CLAIM_ID = c.CLAIM_ID")



refund_members <- sqldf("select distinct PATIENT_ID,
INS_GROUP_ID,
PRODUCT_LINE_ID
                        from base1")


refund_members_cnt <- sqldf("select count(INS_GROUP_ID) as ref_cnt from
refund_members group by INS_GROUP_ID order by ref_cnt desc" )


non_refund_members <-  sqlQuery(
  conn,
  "select DISTINCT
CLM.PATIENT_ID,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID
FROM dbo.CLAIM CLM  with (nolock)
INNER JOIN dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
INNER JOIN dbo.CASE_DATA CD  with (nolock)
ON CS.CASE_ID = CD.CASE_ID
INNER JOIN dbo.STATUS_CODE SC  with (nolock)
ON CS.STATUS_CODE = SC.STATUS_CODE
INNER JOIN dbo.SPECIAL_FIELDS SF  with (nolock)
ON CLM.CLAIM_ID = SF.ID
WHERE CS.HDS_LOB_ID = 2
AND CD.SUBCATEGORY = 10
AND CS.STATUS_CODE !='2'
  or CS.STATUS_CODE !='50'
  or CS.STATUS_CODE !='55'
AND CLM.PROJECT_ID != 222
AND IsValidSSN = 1
and CLM.FEED_ID >= 150
  and CLM.FEED_ID <= 209
AND CLM.PATIENT_AGE < 65
AND CLM.PATIENT_AGE > 18
and ISNULL(CLM.AMT_PAID, 0) > 0")


refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as ref_cnt from
refund_members group by INS_GROUP_ID order by ref_cnt desc" )
  
non_refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as non_ref_cnt from
non_refund_members group by INS_GROUP_ID order by non_ref_cnt desc" )

groupid_ratio <- sqldf("select r.*, n.non_ref_cnt from non_refund_members_cnt n, 
                       refund_members_cnt r where r.INS_GROUP_ID = n.INS_GROUP_ID")

groupid_ratio$groupid_refund_rate <- (groupid_ratio$ref_cnt / groupid_ratio$non_ref_cnt) *100000


base2 <- sqldf("select b.*, g.groupid_refund_rate from base1 b , groupid_ratio g
               where b.INS_GROUP_ID = g.INS_GROUP_ID")


base2$ratio_billed_to_paid<-(base2$AMT_BILLED + 1 )/(base2$AMT_PAID +1 )
base2$ratio_allowed_to_paid<-(base2$AMT_ALLOWED +1 ) /(base2$AMT_PAID +1)

base2$PLACE_OF_SERVICE<- ifelse(is.na(base2$PLACE_OF_SERVICE), 0, 
                                base2$PLACE_OF_SERVICE)

base2$BILL_TYPE<- ifelse(base2$BILL_TYPE == '', "0", base1$BILL_TYPE)

# base2$INS_GROUP_ID <- as.factor(as.character(base2$INS_GROUP_ID ))
# base2$PRODUCT_LINE_ID <- as.factor(as.character(base2$PRODUCT_LINE_ID ))

# distance_factors <- sqldf("select groupid_refund_rate,ratio_billed_to_paid,
# ratio_allowed_to_paid
#   from base2  ")
# 
# distance_factors <- as.data.frame(scale(distance_factors))
# distance_factors <- cbind(distance_factors,base2$PRODUCT_LINE_ID)
# # rename
# names(distance_factors)[4] <- "PRODUCT_LINE_ID"
# 
# gower_dist <- daisy(distance_factors,
#                     metric = "gower",
#                     stand = FALSE)
# 
# 
# gower_dist_df <- as.data.frame(as.matrix((gower_dist)))
# 
# 
# summary(gower_dist )
# 
# distance_factors <- sqldf("select groupid_refund_rate,ratio_billed_to_paid,
# ratio_allowed_to_paid, PRODUCT_LINE_ID
#   from base2  ")
# 
# gower_mat <- as.matrix(gower_dist)
# # Output most similar pair
# distance_factors[
#   which(gower_mat == min(gower_mat[gower_mat != min(gower_mat)]),
#         arr.ind = TRUE)[1, ], ]
# 
# 
# # Output most dissimilar pair
# distance_factors[
#   which(gower_mat == max(gower_mat[gower_mat != max(gower_mat)]),
#         arr.ind = TRUE)[1, ], ]

# 
# # Calculate silhouette width for many k using PAM
# sil_width <- c(NA)
# for(i in 2:10){
#   
#   pam_fit <- pam(gower_dist,
#                  diss = TRUE,
#                  k = i)
#   
#   sil_width[i] <- pam_fit$silinfo$avg.width
#   
# }
# 
# sil_width <- as.data.frame(sil_width )
# 
# # 3 clusters
# 
# pam_fit <- pam(gower_dist, diss = TRUE, k = 3)
# 
# pam_results <- distance_factors %>%
#   dplyr::select(PRODUCT_LINE_ID)%>%
#   mutate(cluster = pam_fit$clustering) %>%
#   group_by(cluster) %>%
#   do(the_summary = summary(.))
# pam_results$the_summary
# 
# distance_factors[pam_fit$medoids, ]
# 
# 
# # Plot sihouette width (higher is better)
# plot(1:10, sil_width,
#      xlab = "Number of clusters",
#      ylab = "Silhouette Width")
# lines(1:10, sil_width)




DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")


elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")


base3 <- sqldf("select b.*, e.wscore_vw as elixhauser from elixhauser_scores e, base2 b
               where b.CLAIM_ID = e.CLAIM_ID")


base3 <- sqldf("select b.*, e.wscore as charlson from charlson_scores e, base3 b
               where b.CLAIM_ID = e.CLAIM_ID")

base3 <- sqldf("select b.* from base3 b
               group by b.PATIENT_ID")



SOM_inputs <- sqldf("select PATIENT_AGE,groupid_refund_rate, ratio_billed_to_paid, ratio_allowed_to_paid,  charlson,elixhauser
                    from base3")





distance0_scale <- scale(SOM_inputs)
som2 <- trainSOM(x.data = distance0_scale, dimension = c(6,6), nb.save = 10, maxit = 500,
                 scaling = "none")

#plot(som2, what = "obs", type = "hitmap")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=8)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)


targ <- cbind(base3,som_diste)

# #rename
names(targ)[47] <- 'SOM_CLUSTER'

targ$SOM_CLUSTER <- as.factor(as.character(targ$SOM_CLUSTER))



base4 <- sqldf("select SOM_CLUSTER,
 PATIENT_GENDER,PLACE_OF_SERVICE,BILL_TYPE,PRODUCT_LINE_ID
from targ")


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)

base4$BILL_TYPE<- ifelse(is.na(base4$BILL_TYPE), 0, 
                                base4$BILL_TYPE)

#base4$INS_GROUP_ID <- as.factor(as.character(base4$INS_GROUP_ID ))
base4$PRODUCT_LINE_ID <- as.factor(as.character(base4$PRODUCT_LINE_ID ))
base4$BILL_TYPE <- as.factor(as.character(base4$BILL_TYPE ))


gower_dist <- daisy(base4,
                    metric = "gower",
                    stand = TRUE)


gower_dist_df <- as.data.frame(as.matrix((gower_dist)))


summary(gower_dist )


gower_mat <- as.matrix(gower_dist)
# Output most similar pair
base4[
  which(gower_mat == min(gower_mat[gower_mat != min(gower_mat)]),
        arr.ind = TRUE)[1, ], ]


# Output most dissimilar pair
targ[
  which(gower_mat == max(gower_mat[gower_mat != max(gower_mat)]),
        arr.ind = TRUE)[1, ], ]



# Calculate silhouette width for many k using PAM
sil_width <- c(NA)
for(i in 2:20){

  pam_fit <- pam(gower_dist,
                 diss = TRUE,
                 k = i)

  sil_width[i] <- pam_fit$silinfo$avg.width

}

sil_width <- as.data.frame(sil_width )

# 3 clusters

pam_fit <- pam(gower_dist, diss = TRUE, k = 5)

pam_results <- targ %>%
  dplyr::select(SOM_CLUSTER)%>%
  mutate(cluster = pam_fit$clustering) %>%
  group_by(cluster) %>%
  do(the_summary = summary(.))
pam_results$the_summary


sum29<- sqldf("select * from targ where SOM_CLUSTER IN(29) ")


sum3<- sqldf("select * from targ where SOM_CLUSTER IN(3) ")


summary(sum29)
summary(sum3)









cs = sqlQuery(
  conn,
  "SELECT  * from DBO.PROVIDER with (nolock)",
  max=100)

cl = sqlQuery(
  conn,
  "SELECT  max(FEED_ID) as mx from dbo.CLAIM with (nolock) where FEED_ID < 999",
  max=100)








membs <- sqldf("select distinct member_ID from base1")
