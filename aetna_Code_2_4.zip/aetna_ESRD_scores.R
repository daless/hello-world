



setwd("~/aetna")

library(RODBC)



conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)



library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
#library(smbinning)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(h2o)
h2o.init()
library(h2oEnsemble)



member_claim_inv_test <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.PRODUCT_LINE_ID,
  CLM.LINE_OF_BUSINESS_ID,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  CLM.PROVIDER_ID,
  SF.FIELD19,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  INNER JOIN dbo.SPECIAL_FIELDS SF
  ON CLM.CLAIM_ID = SF.ID
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (0,-1)
  AND CLM.FEED_ID IN (167)
  AND CLM.PROJECT_ID = 222
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  
  order by CLM.PATIENT_ID desc"
)



# group number exclusions
excl_grp<-  sqlQuery(
  conn, "select distinct Exclusion from ExclusionsGroupNumber where ProjectID  = 222" )

member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_grp e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

# provider exclusions

excl_p<-  sqlQuery(
  conn, "select distinct Exclusion from ExclusionsProviderNumber where ProjectID  = 222" )
member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_p e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

# special field exclusion
excl_s<-  sqlQuery(
  conn, "select DISTINCT Exclusion from ExclusionsSpecialFields where ProjectID  = 222" )
member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_s e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

# product line exclusions
excl_i<-  sqlQuery(
  conn, "select DISTINCT Exclusion from ExclusionsProductLine where ProjectID  = 222" )
member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_i e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

rm(excl_grp,excl_p,excl_s, excl_i )




#rm(member_list)
# DX codes

DX_test  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE DX.FEED_ID IN (167)
  AND CLM.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc"
)

clm_id <- sqldf("select distinct CLAIM_ID from  member_claim_inv_test")

DX_test  <- sqldf("SELECT DISTINCT d.* from DX_test d INNER JOIN clm_id as m 
                  ON d.CLAIM_ID =m.CLAIM_ID")




# LOS
member_claim_inv_test$Days_of_service <- difftime(member_claim_inv_test$DATE_OF_SERVICE_END , 
                                                  member_claim_inv_test$DATE_OF_SERVICE_BEG,
                                                  units = c("days")) 



# removes 0 days of service
# remove positive skew of LOS
member_claim_inv_test$Days_of_service <- round(sqrt(as.integer(member_claim_inv_test$Days_of_service + 1)))
# remove decimals from princiapl dx code
member_claim_inv_test$Principal_Dx <- as.character(member_claim_inv_test$Principal_Dx)
member_claim_inv_test$Principal_Dx <- gsub(".","",member_claim_inv_test$Principal_Dx, fixed = TRUE)

# change bill type code NA to 0
member_claim_inv_test$BILL_TYPE <- ifelse(is.na(member_claim_inv_test$BILL_TYPE), 0, member_claim_inv_test$BILL_TYPE)
member_claim_inv_test$BILL_TYPE <- as.factor(member_claim_inv_test$BILL_TYPE)

# place of service
member_claim_inv_test$PLACE_OF_SERVICE<- ifelse(is.na(member_claim_inv_test$PLACE_OF_SERVICE), 0, 
                                                member_claim_inv_test$PLACE_OF_SERVICE)
member_claim_inv_test$PLACE_OF_SERVICE<- as.factor(member_claim_inv_test$PLACE_OF_SERVICE)

#### EXPORT CSV member_claim_inv_test here
write.table(member_claim_inv_test, file = "member_claim_inv_test_3mo_OSOD167.csv",
            row.names = FALSE, sep ="\t")

#member_claim_inv_test <- read.csv("member_claim_inv_test_3mo_OSOD167.csv", header=TRUE, sep="\t")

write.table(DX_test, file = "DX_test_3mo_OSOD167.csv",
            row.names = FALSE, sep ="\t")

#DX_test <- read.csv("DX_test_3mo_OSOD167.csv", header=TRUE, sep="\t")

# remove decimals from diagnosis codes
DX_test$ICD9_CODE <- as.character(DX_test$ICD9_CODE)
DX_test$ICD9_CODE <- gsub(".","",DX_test$ICD9_CODE, fixed = TRUE)


# comorbidity where ICD9_TYPE = 'DIAG' anthem is DIAG10
DX__diag_test <- sqldf("select distinct * from DX_test where ICD9_TYPE = 'DIAG' order by CLAIM_ID, ICD9_CODE  ")



charlson_scores <- comorbidity(x=DX__diag_test, id = "CLAIM_ID",  code = "ICD9_CODE", score = "charlson_icd10")

write.table(charlson_scores, file = "charlson_scores_3mo_OSOD167.csv",
            row.names = FALSE, sep ="\t")

#charlson_scores <- read.csv("charlson_scores_3mo_OSOD167.csv", header=TRUE, sep="\t")

elixhauser_scores <- comorbidity(x=DX__diag_test, id = "CLAIM_ID", code = "ICD9_CODE", score = "elixhauser_icd10")

write.table(elixhauser_scores, file = "elixhauser_scores_3mo_OSOD167.csv",
            row.names = FALSE, sep ="\t")

#elixhauser_scores <- read.csv("elixhauser_scores_3mo_OSOD167.csv", header=TRUE, sep="\t")

#  CCS DX
CCS_lookup <- read.csv("~/anthem/ccs_dx_icd10cm_2018_1.csv", sep = ",",  quote = "\"", header = TRUE)
# rename columns
CCS_lookup$ICD9_CODE <- CCS_lookup$X.ICD.10.CM.CODE.
CCS_lookup$CCS_DX <- CCS_lookup$X.CCS.CATEGORY.
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))

# build CCS dx table
CCS_Codes_test <- sqldf("select DISTINCT d.CLAIM_ID, d.ICD9_CODE, d.ORDER_IN_CLAIM, c.CCS_DX
                        from DX_test d left join CCS_lookup c on d.ICD9_CODE = c.ICD9_CODE
                        order by d.CLAIM_ID , d.ORDER_IN_CLAIM")
CCS_Codes_test$CCS_DX <- ifelse(is.na(CCS_Codes_test$CCS_DX), 0, CCS_Codes_test$CCS_DX)

CCS_Codes_test$CCS_DX <-as.factor(CCS_Codes_test$CCS_DX)


# make dummies, transpose then 1 record per client id
CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_DX from CCS_Codes_test order by CLAIM_ID")

CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_DX , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test", "CCS_",  colnames(CCS_Dummy_test)))
# group by client id
CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy3_test <- lapply(CCS_Dummy3_test, factor)
CCS_Dummy3_test <- as.data.frame(CCS_Dummy3_test)
CCS_Dummy3_test$CLAIM_ID <- as.numeric(as.character(CCS_Dummy3_test$CLAIM_ID))
CCS_Dummy3_test$CCS__0 <- NULL



write.table(CCS_Dummy3_test, file = "CCS_Dummy3_test_OSOD167.csv",
            row.names = FALSE, sep ="\t")




# POS
POS <- sqldf("select DISTINCT CLAIM_ID, PLACE_OF_SERVICE as POS from member_claim_inv_test")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS2 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS2$CLAIM_ID <- as.character(POS2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS3 <- POS2 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS3 <- lapply(POS3, factor) 
POS3 <- as.data.frame(POS3)
POS3$CLAIM_ID <- as.numeric(as.character((POS3$CLAIM_ID)))
POS3$POS <- NULL

#str(POS3, list.len=ncol(POS3))
#rm(POS2, POS)



# DX codes for nephrology related codes and ALS
# from nccd cdc data
icd_10 <- c("A1811",	"A5275",	"B520",	"C641",	"C642",	"C649",	"C689",	"D4100",	"D4101",
            "D4102",	"D4110",	"D4111",	"D4112",	"D4120",	"D4121",	"D4122",	"D593",	
            "E0821",	"E0822",	"E0829",	"E0921",	"E0922",	"E1065",	"E1121",	"E1122",
            "E1129",	"E1165",	"E11321",	"E113211",	"E113212",	"E113213",	"E113219",
            "E748",	"I120",	"I129",	"I130",	"I1311",	"I132",	"K767",	"M1030",	"M1031",
            "M3214",	"M3215",	"N131",	"N131",	"N132",	"N1330",	"N1339",	"N150",	"N158",
            "N159",	"N16",	"N181",	"N182",	"N183",	"N184",	"N185",	"N188",	"N189",	"N19",
            "N261",	"N269",	"O10411",	"O10412",	"O10413",	"O10419",	"O9089",	"Q6102",	"R944",
            "N010",	"N011",	"N012",	"N013",	"N014",	"N015",	"N016",	"N017",	"N018",	"N019",	
            "N020",	"N021",	"N022",	"N023",	"N024",	"N025",	"N026",	"N027",	"N028",	"N029",	
            "N030",	"N031",	"N032",	"N033",	"N034",	"N035",	"N036",	"N037",	"N038",	"N039",	
            "N040",	"N041",	"N042",	"N043",	"N044",	"N045",	"N046",	"N047",	"N048",	"N049",	
            "N050",	"N051",	"N052",	"N053",	"N054",	"N055",	"N056",	"N057",	"N058",	"N059",	
            "N060",	"N061",	"N062",	"N063",	"N064",	"N065",	"N066",	"N067",	"N068",	"N069",
            "N070",	"N071",	"N072",	"N073",	"N074",	"N075",	"N076",	"N077",	"N078",	"N079",
            "N08",	"D3000",	"D3001",	"D3002",	"D3010",	"D3011",	"D3012",	"D3020",	
            "D3021",	"D3022",	"D303",	"D304",	"D308",	"D309",	"N140",	"N141",	"N142",
            "N143",	"N144",	"N170",	"N171",	"N172",	"N178",	"N179",	"N250",	"N251",	"N2581",
            "N2589",	"N259",	"O1200",	"O1201",	"O1202",	"O1203",	"O1204",	"O1205",
            "O1210",	"O1211",	"O1212",	"O1213",	"O1214",	"O1215",	"O1220",	"O1221",
            "O1222",	"O1223",	"O1224",	"O1225",	"O26831",	"O26832",	"O26833",	"O26839",
            "Q6111",	"Q6119",	"Q612",	"Q613",	"Q614",	"Q615",	"Q618",	"Q260",	"Q261",	"Q262",
            "Q263",	"E1322",	"E1329",	"E1021",	"E1022",	"G1221")
ICD9_CODE_neph <- data.frame(icd_10)
icd_neph <- ICD9_CODE_neph

neph_test <- sqldf("select DISTINCT d.CLAIM_ID, d.ICD9_CODE, d.ORDER_IN_CLAIM, c.icd_10 as ICD9_CODE_neph
                   from DX_test d left join icd_neph c on d.ICD9_CODE = c.icd_10
                   order by d.CLAIM_ID , d.ORDER_IN_CLAIM")
neph_test$ICD9_CODE_neph[is.na(neph_test$ICD9_CODE_neph )] <- 0
neph_test$ICD9_CODE_neph <- ifelse(neph_test$ICD9_CODE_neph == 0,0,1)
neph_test$ICD9_CODE_neph <- as.numeric(neph_test$ICD9_CODE_neph)
neph_test <- sqldf("select DISTINCT CLAIM_ID, ICD9_CODE_neph from neph_test")


# group by client id
neph_test2 <- neph_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
neph_test2$CLAIM_ID <- as.character(neph_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
neph_test3 <- neph_test2 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)
neph_test3 <- lapply(neph_test3, factor) 
neph_test3 <- as.data.frame(neph_test3)
neph_test3$CLAIM_ID <- as.numeric(as.character(neph_test3$CLAIM_ID))

rm(icd_10, ICD9_CODE_neph, icd_neph, neph_test, neph_test2)
table(neph_test3$ICD9_CODE_neph)




# create study table of single record per encounter
# this will be post adjudication

member_claim_inv_test <- member_claim_inv_test [order(member_claim_inv_test$CLAIM_ID), ]


##############################
# build study table at the encounter - claim level
# with real data confirm no missing comorbidity or dx  CCS codes

base_table1 <- sqldf("SELECT DISTINCT CLAIM_ID, FEED_ID, PATIENT_AGE, PATIENT_GENDER, BILL_TYPE,
                     member_ID,  
                     sqrt(AMT_ALLOWED / AMT_PAID) as ratio_allowed_to_paid ,
                     Days_of_service from member_claim_inv_test")

# add comorbidities
base_table2 <- sqldf("SELECT DISTINCT b.*, c.wscore as Charlson_score from base_table1 b left join charlson_scores c
                     on b.CLAIM_ID = c.CLAIM_ID")

base_table2 <- sqldf("SELECT DISTINCT b.*, c.wscore as Elixhauser_score from base_table2 b left join elixhauser_scores c
                     on b.CLAIM_ID = c.CLAIM_ID")


base_table2$Charlson_score <-  ifelse(is.na(base_table2$Charlson_score),1,base_table2$Charlson_score)
base_table2$Elixhauser_score <-  ifelse(is.na(base_table2$Elixhauser_score),1,base_table2$Elixhauser_score)
base_table2$CLAIM_ID <- as.numeric(base_table2$CLAIM_ID )

str(base_table2, list.len=ncol(base_table2))

# CCS dx
CCS_Dummy3_test$CLAIM_IDx <- CCS_Dummy3_test$CLAIM_ID
CCS_Dummy3_test$CLAIM_ID <- NULL
str(CCS_Dummy3_test, list.len=ncol(CCS_Dummy3_test))
base_table3 <- sqldf("SELECT DISTINCT b.*, c.* from base_table2 b inner join CCS_Dummy3_test c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table3$CLAIM_IDx <- NULL
CCS_Dummy3_test$CLAIM_ID <- CCS_Dummy3_test$CLAIM_IDx
CCS_Dummy3_test$CLAIM_IDx <- NULL
str(base_table3, list.len=ncol(base_table3))




# POS -- v3 not using procedure code grouper

POS3$CLAIM_IDx <- POS3$CLAIM_ID
POS3$CLAIM_ID <- NULL
base_table5 <- sqldf("SELECT DISTINCT b.*, c.* from base_table3 b left join POS3 c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table5$CLAIM_IDx <- NULL
POS3$CLAIM_ID <- POS3$CLAIM_IDx
#str(base_table5, list.len=ncol(base_table5))



# neph als dx for targets for ccs feature extraction
neph_test3$CLAIM_IDx <- neph_test3$CLAIM_ID
neph_test3$CLAIM_ID <- NULL
base_table6 <- sqldf("SELECT DISTINCT b.*, c.* from base_table5 b left join neph_test3 c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table6$CLAIM_IDx <- NULL
base_table6$target_neph <- as.factor(base_table6$ICD9_CODE_neph)
base_table6$target_neph <- as.factor(base_table6$target_neph)
# replace NA with 0
base_table6$target_neph[is.na(base_table6$target_neph )] <- 0
base_table6$ICD9_CODE_neph <- NULL
table(base_table6$target_neph)
prop.table(table(base_table6$target_neph))



dep_0 <- sqlQuery(
  conn,
  " select DISTINCT MC.MemberID,  MED.*
  fROM dbo.MemberCoverage MC , dbo.MedicareCoverage MED
  where MC.MemberCoverageId = MED.MemberCoverageId
  and MED.EntitlementReasonId IN (3,4,5)
  order by MC.MemberID "
)

# dependent variable
dep <- sqldf("select distinct MemberID as MemberIDx from  dep_0")


base_table6 <- sqldf ("SELECT DISTINCT b.*, dep.MemberIDx from base_table6 b
                      left join dep ON b.member_ID = dep.MemberIDx")
base_table6$target<- as.factor(ifelse(!is.na(base_table6$MemberIDx),1,0))


#str(base_table6, list.len=ncol(base_table6))
# feture reduction - CCS
base_table6$CCS__99 <- NULL
base_table6$CCS__158 <- NULL
base_table6$CCS__81 <- NULL 
base_table6$CCS__NA <- NULL
base_table6$CCS__157 <- NULL
base_table6$CCS__0 <- NULL
base_table6$MemberIDx  <- NULL
base_table6$BILL_TYPE <- as.factor(base_table6$BILL_TYPE)


# for testing of dummy target remove CCS that are in target
str(base_table6, list.len=ncol(base_table6))


base_table7 <- base_table6


CCS_list <- base_table7 %>% dplyr:: select (starts_with("CCS__"))
t_var <- sqldf("select target_neph from base_table7")
CCS_list2 <- cbind(t_var,CCS_list)

# feature reduction using random forest
# take top 15 based upon gini index

# change target to target_neph 




CCS_list3_import <- read.csv("CCS_import.csv", header=TRUE, sep="\t")



# get CCS comorbid list
j1 <- cbind(CCS_list3_import, dummy(CCS_list3_import$CCS , sep= "_"))
colnames(j1) <- (gsub("CCS_list3_import_", "",  colnames(j1)))
j1$CCS <- NULL
j1$variable <- NULL
j1$relative_importance  <- NULL
j1$scaled_importance  <- NULL
j1$percentage  <- NULL

neph_names <- colnames(j1)

# keep neph comordities
neph_match <- match(neph_names, names(CCS_list2))





neph_match <- CCS_list2[,neph_match]

# remove CCS from base data
no_ccs <- base_table7 [,!grepl("^CCS",names(base_table7 ))]
base_table7 <- cbind(no_ccs, neph_match)
base_table7$CLAIM_ID.1 <- NULL


# normalize patient age
base_table7$PATIENT_AGE_norm <- (base_table7$PATIENT_AGE - mean(base_table7$PATIENT_AGE)) / sd(base_table7$PATIENT_AGE)
base_table7$PATIENT_AGE <- NULL
base_table7$target_neph <- NULL


str(base_table7, list.len=ncol(base_table7))


# auto ML
train_auto_ml <- base_table7


# write.table(train_auto_ml, file = "train_auto_ml_OSOD167.csv",
#             row.names = FALSE, sep ="\t")





train_auto_ml$member_ID <- NULL
train_auto_ml$CLAIM_ID <- NULL
train_auto_ml$FEED_ID <- NULL





# train_auto_ml <- read.csv("train_auto_ml_OSOD167.csv", header=TRUE, sep="\t")
# 
# # run below if loading from CSV
# str(train_auto_ml, list.len=ncol(train_auto_ml))
# 
# train_auto_ml$BILL_TYPE <- as.character(train_auto_ml$BILL_TYPE)
# train_auto_ml$BILL_TYPE <- as.factor(train_auto_ml$BILL_TYPE)
# str(train_auto_ml, list.len=ncol(train_auto_ml))


data_to_score <- as.h2o(train_auto_ml)


y <- "target"
x <- setdiff(names(data_to_score), y)



ensemble_train_test <- h2o.loadModel("/home/dless1/aetna/ensemble/ensemble_binomial")
#print(ensemble_train_test)



# ouput for scoring results - to be written to a file

pred_ensemble <- h2o.predict(ensemble_train_test, newdata = data_to_score)

ped_df <- as.data.frame(pred_ensemble)

cl_ids <- sqldf("select member_ID, CLAIM_ID,FEED_ID, target from base_table7  ")


claim_probabilities <- cbind(cl_ids,ped_df )

claims_to_investigate <- sqldf("select * from claim_probabilities where predict = 1 and p1 >= 0.983 order by p1 desc")

ftable(xtabs(~target + predict, data = claims_to_investigate ))

#CrossTable(junk$target, junk$predict)



# 
# 
# ensemble_train_test_167 <- h2o.performance(ensemble_train_test,data_to_score )
# 
# 
# ensemble_train_test_167
# plot(ensemble_train_test_167)
# 








# 
# 
# # xgboost
# 
# xgboost_train_test <- h2o.loadModel("/home/dless1/aetna/xgboost/XGBoost_model_R_1525280852323_2754")
# 
# 
# xgboost_train_test_167 <- h2o.performance(xgboost_train_test,data_to_score )
# 
# 
# xgboost_train_test_167
# plot(xgboost_train_test_167)
# 
# 
