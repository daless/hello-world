


setwd("~/aetna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(kamila)
library(cluster)
library(arules)
library(proxy)
library(reshape2)
library(plyr)


#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=dmfeed00222;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

table_listing <- as.data.frame(sqlTables(conn))



#.  Project ID for TRAD is 222 and for HMO it’s 212

junk <- sqlQuery( conn, "select * FROM dbo.FD_AETNA_TRAD_CLM CLM where 
                  CLM.PROJECT_ID = 222
                  AND CLM.CLAIM_NO = 'E0FBW6VMG'
                  order by CLM.L_CLAIM_LINE ", max=10)

junk <- sqlQuery( conn, "select * FROM dbo.FD_AETNA_TRAD_CLM CLM  ", max=10)

str(junk , list.len=ncol(junk))
str(junk2 , list.len=ncol(junk2))

#Member table in provisional would be FD_AETNA_TRAD_MEM.  You can join to FD_AETNA_TRAD_CLM on pat_member_no and feed_id

#For the provider tables, we use FD_AETNA_TRAD_PROV if we need address info on the billing provider.  That’s about all that’s in there. You could join to FD_AETNA_TRAD_CLM on provider_no and feed_id. 

#FD_AETNA_TRAD_PROV_PINS table for servicing provider info.  Provider type and specialty codes are in there, as well as the par/non-par indicator. You could join to FD_AETNA_TRAD_CLM on pin7 and feed_id. 

