
# finds diseases and condition for high costs


# als

als <- sqldf("select * from CCS where ICD10_Code = 'G1221'")
als <- sqldf("select * from CCS where CCS_Category_Description = 'NVS006'")

CIDP <- sqldf("select * from CCS where ICD10_Code = 'G6181'")
CIDP<- sqldf("select * from CCS where CCS_Category_Description = 'NVS015'")


# use CCS for chron's and ulcerative colitus 
crohn <- sqldf("select * from CCS where ICD10_Code = 'K5090'")
crohn<- sqldf("select * from CCS where CCS_Category_Description = 'DIG011'")

#use ccs
CF <- sqldf("select * from CCS where ICD10_Code = 'E849'")
CF<- sqldf("select * from CCS where CCS_Category_Description = 'END012'")


goucher <- sqldf("select * from CCS where ICD10_Code = 'E7522'")
goucher<- sqldf("select * from CCS where CCS_Category_Description = 'END016'")


# use CCS
hemo <- sqldf("select * from CCS where ICD10_Code = 'D68311'")
hemo<- sqldf("select * from CCS where CCS_Category_Description = 'BLD006'")

# use CCS
HIV <- sqldf("select * from CCS where ICD10_Code = 'B20'")
HIV<- sqldf("select * from CCS where CCS_Category_Description = 'INF006'")

MS <- sqldf("select * from CCS where ICD10_Code = 'G35'")
MS<- sqldf("select * from CCS where CCS_Category_Description = 'NVS005'")

MG <- sqldf("select * from CCS where ICD10_Code = 'G7000'")
MG<- sqldf("select * from CCS where CCS_Category_Description = 'NVS018'")

# use CCS
Myo <- sqldf("select * from CCS where ICD10_Code = 'M609'")
Myo<- sqldf("select * from CCS where CCS_Category_Description = 'MUS026'")

# use CCS
PD <- sqldf("select * from CCS where ICD10_Code = 'G20'")
PD<- sqldf("select * from CCS where CCS_Category_Description = 'NVS004'")

# use CCS
RA <- sqldf("select * from CCS where ICD10_Code = 'M069'")
RA<- sqldf("select * from CCS where CCS_Category_Description = 'MUS003'")

scler <- sqldf("select * from CCS where ICD10_Code = 'L940'")
scler<- sqldf("select * from CCS where CCS_Category_Description = 'SKN007'")

#use ccs
lupus <- sqldf("select * from CCS where ICD10_Code = 'M329'")
lupus<- sqldf("select * from CCS where CCS_Category_Description = 'MUS024'")



conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)

all_ccs <- rbind(lupus,scler,RA, PD, Myo, HIV, hemo, CF, crohn)

# in_clause <- paste0("('", paste0(all_ccs$CCS_Category_Description, collapse = "','"), "')")
# 
# sql_text <- paste0("select distinct v.PAT_MEMBER_NO,
# v.member_id_number,
# v.ICD_DX_CD_1 from 
#                    RacerResearch.DBO.vwAetnaTradMemClaimCoverage  v  with (nolock)
#                    where DATEDIFF(D,  v.Pat_Date_Effective, GETDATE()) < 365
#   and V.member_age <65
#                    and v.ICD_DX_CD_1 in", in_clause)
# 
# CCS_dx <- sqlQuery(conn, sql_text)

sql_text <- paste0("select distinct v.PAT_MEMBER_NO,
v.member_id_number,
v.ICD_DX_CD_1 from 
                   RacerResearch.DBO.vwAetnaTradMemClaimCoverage  v  with (nolock)
                   where DATEDIFF(D,  v.Pat_Date_Effective, GETDATE()) < 365
  and V.member_age <65
                  ")

CCS_dx <- sqlQuery(conn, sql_text)

CCS_dx$ICD_DX_CD_1<-gsub("'","",CCS_dx$ICD_DX_CD_1,fixed=TRUE)

CCS_dx2 <- sqldf("select c.*, a.ICD10_Code_Description as CCS_desc,
a.CCS_Category_Description CCS_CODES
from CCS_dx c, all_ccs a
                 where c.ICD_DX_CD_1 = a.ICD10_code")


dxbucks <- sqldf("select * from CCS_dx
                 where ICD_DX_CD_1 in(
                   'G1221',
                   'G6181',
                   'E7522',
                   'G35',
                   'G7000',
                   'L940'
                 )")

list_to_ship1 <- sqldf("select PAT_MEMBER_NO, member_id_number from dxbucks")
list_to_ship2 <- sqldf("select PAT_MEMBER_NO, member_id_number from CCS_dx2 ")   

list_to_ship <- rbind(list_to_ship1 , list_to_ship2)

write.table(list_to_ship, file = "list_to_ship.csv",
            row.names = FALSE, sep ="\t")

#scp dless1@apsrd9425:/home/dless1/aetna/list_to_ship.csv /H/My_Doccuments



                 
