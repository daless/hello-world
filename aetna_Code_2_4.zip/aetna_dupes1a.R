setwd("~/aetna")



library(RODBC)
library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(kamila)
library(cluster)
library(arules)
#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)

table_listing <- as.data.frame(sqlTables(conn))



junk <- sqlQuery( conn, "select * FROM dbo.CLAIM CLM  where CLM.CLAIM_NO = 'E0FBW6VMG'")
junk2 <- sqlQuery( conn, "select * FROM dbo.CLAIM CLM  where CLM.PATIENT_ID = 1045949144")  
 


# test feed 169

claim1 <- sqlQuery( conn, "select * FROM dbo.CLAIM CLM  where  CLM.FEED_ID IN (169) and CLM.PROJECT_ID = 222")


member_multi <- sqldf("select PATIENT_ID, count(PATIENT_ID) as memcnt from claim1 group by PATIENT_ID having memcnt >= 2")


claim1 <-sqldf("select distinct c.* from claim1 c, member_multi m where c.PATIENT_ID = m.PATIENT_ID")



DX_test  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID,
CLM.PATIENT_ID
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE DX.FEED_ID IN (169)
  AND CLM.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 9
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc"
)



DX_test <-sqldf("select distinct c.* from DX_test c, member_multi m where c.PATIENT_ID = m.PATIENT_ID")


# procedure
claim_line <- sqlColumns(
conn, "dbo.CLAIM_LINE"  )

proc <- sqlQuery(
  conn, "select distinct  p.CLAIM_ID, p.CPT, p.REVENUE_CODE, p.CPT_MODIFIER, CLM.PATIENT_ID
from dbo.CLAIM_LINE p, dbo.CLAIM CLM
              where CLM.CLAIM_ID = p.CLAIM_ID
              and CLM.FEED_ID IN (169)
              AND CLM.PROJECT_ID = 222
                order by p.CLAIM_ID")


proc <-sqldf("select distinct c.* from proc c, member_multi m where c.PATIENT_ID = m.PATIENT_ID")






# dupe score file to append to

scores <- data.frame(matrix(ncol = 10, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Jaccard', 'Kulczynski1', 'Kulczynski2', "Mountford", 'Fager', 'Russel', 
                   'simple_matching', 'Hamman', 'Faith')
colnames(scores) <- score_columns


# make empty df for formatting

icd_base <- data.frame(matrix(ncol = 11, nrow = 0))
b <- c('CLAIM_ID', 'DX1', 'DX2', 'DX3', 'DX4', 'DX5', 'DX6', 'DX7', 'DX8', 'DX9', 'DX10')
colnames(icd_base) <- b

proc_base <- data.frame(matrix(ncol = 11, nrow = 0))
p <- c('CLAIM_ID', 'PROC1', 'PROC2', 'PROC3', 'PROC4', 'PROC5', 'PROC6', 'PROC7', 'PROC8', 'PROC9', 'PROC10')
colnames(proc_base) <- p

doc_base <- data.frame(matrix(ncol = 6, nrow = 0))
d <- c('CLAIM_ID', 'PROV1', 'PROV2', 'PROV3', 'PROV4', 'PROV5')
colnames(doc_base) <- d

# dummy df dx codes
dummy_dx <- data.frame(matrix(ncol = 3, nrow = 10))
dumb <- c('CLAIM_ID', 'ICD9_CODE', 'icd_cntr')
colnames(dummy_dx) <- dumb
dummy_dx$CLAIM_ID <- -1
dummy_dx$ICD9_CODE <- 'FOO'
dummy_dx$icd_cntr <- 1:nrow(dummy_dx)

# dummy for proc codes
dummy_p <- data.frame(matrix(ncol = 3, nrow = 10))
dumbp <- c('CLAIM_ID', 'CPT', 'proc_cntr')
colnames(dummy_p) <- dumbp
dummy_p$CLAIM_ID <- -1
dummy_p$CPT <- 'FOO'
dummy_p$proc_cntr <- 1:nrow(dummy_p)

# dummy for providers
dummy_doc <- data.frame(matrix(ncol = 3, nrow = 5))
dumbd <- c('CLAIM_ID', 'PROVIDER_NO', 'prov_cntr')
colnames(dummy_doc) <- dumbd
dummy_doc$CLAIM_ID <- -1
dummy_doc$PROVIDER_NO <- 'FOO'
dummy_doc$prov_cntr <- 1:nrow(dummy_doc)





# test with single member
# loop logic start here
####################### LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


cl_dup1 <- sqldf("select c.* from claim1 c where c.PATIENT_ID = 1108119")



str(cl_dup1 , list.len=ncol(cl_dup1))

# remove extra fields
deletes_claims <- c( 	'PROJECT_ID', 
                      'FEED_ID', 
                      'DATE_RECEIVED', 
                      'DATE_ENTERED', 
                      'DATE_ADMITTED', 
                      'DATE_DISCHARGED', 
                      'PATIENT_AGE', 
                      'SUBSCRIBER_AGE', 
                      'DATE_PAID', 
                      'DATE_CREATED', 
                      'DATE_UPDATED', 
                      'USERNAME', 
                      'ADJ_CLAIM_FLAG', 
                      'PAR', 
                      'VENDOR_ID', 
                      'PATIENT_ACCT_NO_CLIENT', 
                      'PAR_CLIENT', 
                      'CHECK_NUMBER_CLIENT', 
                      'SERVICE_ID', 
                      'ROWID')


cl_dup1[deletes_claims] <- NULL


cl_dup1$DATE_OF_SERVICE_BEG <-
  as.factor(as.character(cl_dup1$DATE_OF_SERVICE_BEG))
cl_dup1$DATE_OF_SERVICE_END  <-
  as.factor(as.character(cl_dup1$DATE_OF_SERVICE_END))



write.table(claim1, file = "claim1.csv",
            row.names = FALSE, sep ="\t")


write.table(proc, file = "proc.csv",
            row.names = FALSE, sep ="\t")

write.table(DX_test , file = "DX_test.csv",
            row.names = FALSE, sep ="\t")


write.table(member_multi , file = "member_multi.csv",
            row.names = FALSE, sep ="\t")


