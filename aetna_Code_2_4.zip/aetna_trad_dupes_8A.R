
# V 6 caseid 30

setwd("~/aetna")




library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
#library(tcltk)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(caret)
library(klaR)
library(NbClust)
library(cluster)
library(broom)
library(factoextra)
library(proxy)
library(reshape2)
library(plyr)
library(kamila)
library(cluster)
library(MASS)
library(tidyr)
library(RODBC)
#library(dbplyr)
#library(sparklyr)


#sc <- spark_connect(master = "local", version = "2.2.1")
#spark_disconnect(sc)

# sparkling water package
#library(rsparkling)

#library(h2o)
#h2o.init()
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)



connn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RACERRESEARCH;UID=COBUnixToSQL;PWD=COBUn!xT0Sql')


distinct_members <- sqlQuery(
  connn,
  " SELECT DISTINCT PAT_MEMBER_NO, CLAIM_NO  FROM dbo.AetnaDuplicateResearch", max=500)



 member_multi0 <- sqldf("select PAT_MEMBER_NO
                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")


 

 
 # split the member list into 10 groups
 idx <- sample(seq(1,10),size = nrow(member_multi0), replace = TRUE,
               prob = c(.10, .10, .10, .10, .10, .10, .10, .10, .10, .10))
 member_multia <- as.data.frame(member_multi0[idx == 1,])
 member_multib <- as.data.frame(member_multi0[idx == 2,])
 member_multic <- as.data.frame(member_multi0[idx == 3,])
 member_multid <- as.data.frame(member_multi0[idx == 4,])
 member_multie <- as.data.frame(member_multi0[idx == 5,])
 member_multif <- as.data.frame(member_multi0[idx == 6,])
 member_multig <- as.data.frame(member_multi0[idx == 7,])
 member_multih <- as.data.frame(member_multi0[idx == 8,])
 member_multii <- as.data.frame(member_multi0[idx == 9,])
 member_multij <- as.data.frame(member_multi0[idx == 10,])
 
 ### LOOP  slices of member data and write to files
 
 
 
member_multi <- member_multia

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                         'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- sqlQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                  CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                  CL_DATE_PAID ,CLAIM_SUFFIX ,
                                  Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                  DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                  DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                  Line_Of_Business ,Other_Ins_Paid_Amt ,
                                  PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                  PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                                   FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
 
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                          FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
                       
                       
  #cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  #cl_dup1 <- dbFetch(cl_dup1p)
  cl_dup1 <- sqlQuery(connn, mem_string)
  
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
   dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
   # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
 
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
        cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
    
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    #hits <- hits[1,]
    
   # r_hits <- hits[, 1]
   # c_hits <- hits[, 2]
    
    
    score_record_temp <- score_record_temp %>%
      mutate(ROWID_1 = cl_dup1[r_hits, 1],
             ROWID_2 = cl_dup1[c_hits, 1],
             CLAIM_NO_1 = cl_dup1[r_hits, 2],
             CLAIM_NO_2 = cl_dup1[c_hits, 2],
             PAID_1 = dupes[r_hits, 5],
             PAID_2 = dupes[c_hits, 5],
             START_DATE_1 = cl_dup1[r_hits, 8],
             START_DATE_2  = cl_dup1[c_hits, 8],
             END_DATE_1 = cl_dup1[r_hits, 9],
             END_DATE_2  = cl_dup1[c_hits, 9],
             SCORE  = member_score,
             COUNT_BY_MEMBER = j,
             METHOD = "Gower")
    
    
    
    score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
    
    score_record <- bind_rows(score_record, score_record_temp)
    
    cl_dup3 <-
      sqldf(
        "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
        OR d.ROWID = s.ROWID_2"
      )
    
  
    claim_example <- bind_rows(claim_example, cl_dup3)
    
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                       difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                       difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")









write.table(score_record2, file = "traditional_Gower_scoresc_6_5a.csv",
           row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5a.csv",
            row.names = FALSE, sep ="\t")



#22222222222222222222222222222222222222222222222



member_multi <- member_multib

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service  
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")









write.table(score_record2, file = "traditional_Gower_scoresc_6_5b.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5b.csv",
            row.names = FALSE, sep ="\t")



#3333333333333333333333333333333333333333333333333333333333333333333333333333333333333




member_multi <- member_multic

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")








write.table(score_record2, file = "traditional_Gower_scoresc_6_5c.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5c.csv",
            row.names = FALSE, sep ="\t")


#44444444444444444444444444444444444444444444444444444444444444444444444444




member_multi <- member_multid

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")







write.table(score_record2, file = "traditional_Gower_scoresc_6_5d.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5d.csv",
            row.names = FALSE, sep ="\t")



#EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE



member_multi <- member_multie

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service  
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")









write.table(score_record2, file = "traditional_Gower_scoresc_6_5e.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5e.csv",
            row.names = FALSE, sep ="\t")




#ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff




member_multi <- member_multif

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")


write.table(score_record2, file = "traditional_Gower_scoresc_6_5f.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5f.csv",
            row.names = FALSE, sep ="\t")








#ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg




member_multi <- member_multig

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service  
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")


write.table(score_record2, file = "traditional_Gower_scoresc_6_5g.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5g.csv",
            row.names = FALSE, sep ="\t")





#hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh




member_multi <- member_multih

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service 
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service  
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")


write.table(score_record2, file = "traditional_Gower_scoresc_6_5h.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5h.csv",
            row.names = FALSE, sep ="\t")











#iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii





member_multi <- member_multii

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")


write.table(score_record2, file = "traditional_Gower_scoresc_6_5i.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5i.csv",
            row.names = FALSE, sep ="\t")








#jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj






member_multi <- member_multij

# member_multi <- sqldf("select PAT_MEMBER_NO 
#                      from distinct_members group by PAT_MEMBER_NO having count(PAT_MEMBER_NO) >= 2")

# dupe score file to append to

scores <- data.frame(matrix(ncol = 26, nrow = 0))
score_columns <- c('PAT_MEMBER_NO', 'Gower' )
colnames(scores) <- score_columns



score_record <- data.frame(matrix(ncol = 14, nrow = 0))
score_record_columns <- c('PAT_MEMBER_NO', 'METHOD', 'ROWID_1','ROWID_2','CLAIM_NO_1', 'CLAIM_NO_2',
                          'PAID_1', 'PAID_2', 'START_DATE_1',
                          'START_DATE_2', 'END_DATE_1', 'END_DATE_2', 'SCORE', 'COUNT_BY_MEMBER')
score_record_temp <- data.frame(matrix(ncol = 14, nrow = 1))
colnames(score_record) <- score_record_columns
colnames(score_record_temp) <- score_record_columns



# to grab axample claims

claim_example <- DBI::dbGetQuery(connn, "SELECT  ROWID ,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                                 CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                                 CL_DATE_PAID ,CLAIM_SUFFIX ,
                                 Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,Deductible_Amt ,DIAGNOSIS_1 ,
                                 DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,
                                 DIAGNOSIS_6 ,DIAGNOSIS_7 ,DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                                 Line_Of_Business ,Other_Ins_Paid_Amt ,
                                 PAT_MEMBER_NO ,PIN7 ,Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,
                                 PROCEDURE_CODE_2 ,PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service
                                 FROM dbo.AetnaDuplicateResearch C where CLAIM_NO = 'X' ")



#The CL_ usually represents line level info instead of claim level.  So the sum of all the CL_AMT_PAID amounts
#for each claim should be equal to the AMT_PAID (total claim amt paid).

# change scientific notation
options(scipen = 999)

for (i in rownames(member_multi))
{
  #sleep_for_a_minute <- function() {Sys.sleep(60)}
  #start_time <- Sys.time()
  #sleep_for_a_minute()
  
  memberid <- member_multi[i, ]
  format(memberid, scientifc = F)
  memberid <- as.character(memberid)
  
  mem_string <- paste0("SELECT ROWID ,CLAIM_NO,Account ,Business_Line ,CL_AMT_ALLOWED ,CL_AMT_BILLED ,
                       CL_AMT_PAID ,CL_DATE_OF_SERVICE_BEG ,CL_DATE_OF_SERVICE_END ,
                       CL_DATE_PAID ,CLAIM_SUFFIX ,
                       Claims_Status ,Coinsurance_Amt ,Copay_Amt ,CPT ,
                       Deductible_Amt ,DIAGNOSIS_1 ,DIAGNOSIS_10 ,DIAGNOSIS_11 ,DIAGNOSIS_2 ,
                       DIAGNOSIS_3 ,DIAGNOSIS_4 ,DIAGNOSIS_5 ,DIAGNOSIS_6 ,DIAGNOSIS_7 ,
                       DIAGNOSIS_8 ,DIAGNOSIS_9 ,
                       Line_Of_Business ,Other_Ins_Paid_Amt ,PAT_MEMBER_NO ,PIN7 ,
                       Place_Of_Service ,PRINCIPAL_DIAG ,Procedure_Code ,PROCEDURE_CODE_2 ,
                       PROVIDER_NO ,REVENUE_CODE ,Suffix ,TAX_ID ,Type_Of_Service  
                       FROM dbo.AetnaDuplicateResearch 
                       WHERE PAT_MEMBER_NO  ='",memberid,"'")
  
  
  cl_dup1p <- DBI::dbSendQuery(connn, mem_string)
  cl_dup1 <- dbFetch(cl_dup1p)
  
  # if no rows retuned because of varchar issue
  if (dim(cl_dup1)[1] != 0) {
    # remove duplicate row ids
    cl_dup1 <- cl_dup1 %>% dplyr::distinct(ROWID, .keep_all = TRUE)
    # change factors with NA to 0
    f <- sapply(cl_dup1, is.factor)
    cl_dup1[f] <- lapply(cl_dup1[f], as.character)
    cl_dup1[is.na(cl_dup1)] <- 0
    cl_dup1[f] <- lapply(cl_dup1[f], as.factor)
    
    # other NAs to 0
    cl_dup1 <-  cl_dup1 %>% replace(is.na(.), 0)
    
    
    score_append <- distinct(cl_dup1, PAT_MEMBER_NO)
    cl_dup1 <- sqldf("select * from cl_dup1 order by CLAIM_NO")
    dupes <-cl_dup1
    
    # dupes <- dupes %>%
    #   mutate(CL_DATE_OF_SERVICE_BEG = as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_BEG))),
    #          CL_DATE_OF_SERVICE_END =   as.numeric(as.POSIXct(as.character(CL_DATE_OF_SERVICE_END))),
    #          CL_DATE_PAID = as.numeric(as.POSIXct(as.character(CL_DATE_PAID)))
    #   )
    
    dupes <-  dupes %>% replace(is.na(.), 0)
    
    
    dupes[sapply(dupes,is.character)] <- lapply(dupes[sapply(dupes, is.character)], as.factor)
    
    
    dupes$ROWID <- NULL
    dupes$CLAIM_NO <- NULL
    dupes$PAT_MEMBER_NO <- NULL
    #V6
    dupes$CL_DATE_OF_SERVICE_BEG <- NULL
    dupes$CL_DATE_OF_SERVICE_END <- NULL
    dupes$CL_DATE_PAID  <- NULL
    
    #GOWER
    
    # gower works across the table not just numeric
    #start_timem <- Sys.time()
    cl_dup2 <-
      as.data.frame(as.matrix(simil(
        dupes, by_rows = TRUE,   method = "Gower"
      )))
    # end_timem <- Sys.time()
    #match_time <- end_timem - start_timem
    
    # replace diagonals with NA to 0
    cl_dup2 <- cl_dup2 %>% replace(is.na(.), 0)
    cl_dup2[sapply(cl_dup2 , simplify = 'matrix', is.infinite)] <- 0
    
    # return claim numbers as vextor
    nam <- cl_dup1[[2]]
    
    # change column name as vector
    colnames(cl_dup2) <- nam
    
    cl_dup2 <- cbind(cl_dup1[[2]], cl_dup2)
    colnames(cl_dup2)[1] <- "CLAIM_NO"
    cl_dup2$CLAIM_NO <- as.character(cl_dup2$CLAIM_NO)
    
    
    # assigns a -1 to within claim scores
    for (k in 1:ncol(cl_dup2)) {
      for (h in 1:nrow(cl_dup2)) {
        if(colnames(cl_dup2)[k] == cl_dup2$CLAIM_NO[h]){
          cl_dup2[h,k] <- -1
        }
      }
    }
    cl_dup2$CLAIM_NO <-NULL
    
    
    
    # max
    member_score <- max(cl_dup2)
    score_append$Gower <- member_score
    
    hits <-
      as.data.frame(which(cl_dup2 == max(cl_dup2), arr.ind = TRUE))
    
    
    #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
    
    # make dummy of row and column number total
    hits$r_c <- hits[,1] +  hits[,2]
    #hits <- sqldf("select * from hits group by r_c")
    # ditinct on the dummy total to bring back 1 pair of records that are ties
    hits <- hits %>% dplyr::distinct(r_c, .keep_all = TRUE)
    hits$r_c <- NULL
    
    #ties <- hits
    # empty all rows
    #ties <- [0,]
    
    for (j in rownames(hits))
    {
      r_hits <- hits[j, 1]
      c_hits <- hits[j, 2]
      
      
      
      #EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
      #hits <- hits[1,]
      
      # r_hits <- hits[, 1]
      # c_hits <- hits[, 2]
      
      
      score_record_temp <- score_record_temp %>%
        mutate(ROWID_1 = cl_dup1[r_hits, 1],
               ROWID_2 = cl_dup1[c_hits, 1],
               CLAIM_NO_1 = cl_dup1[r_hits, 2],
               CLAIM_NO_2 = cl_dup1[c_hits, 2],
               PAID_1 = dupes[r_hits, 5],
               PAID_2 = dupes[c_hits, 5],
               START_DATE_1 = cl_dup1[r_hits, 8],
               START_DATE_2  = cl_dup1[c_hits, 8],
               END_DATE_1 = cl_dup1[r_hits, 9],
               END_DATE_2  = cl_dup1[c_hits, 9],
               SCORE  = member_score,
               COUNT_BY_MEMBER = j,
               METHOD = "Gower")
      
      
      
      score_record_temp$PAT_MEMBER_NO <- score_append$PAT_MEMBER_NO
      
      score_record <- bind_rows(score_record, score_record_temp)
      
      cl_dup3 <-
        sqldf(
          "select d.* from cl_dup1 d, score_record_temp s where d.ROWID = s.ROWID_1
          OR d.ROWID = s.ROWID_2"
        )
      
      
      claim_example <- bind_rows(claim_example, cl_dup3)
      
    }
    
  }
}

score_record$START_DATE_1 <- as.POSIXct(score_record$START_DATE_1, origin ="1970-01-01")
score_record$START_DATE_2 <- as.POSIXct(score_record$START_DATE_2, origin ="1970-01-01")






#find difference in start and end dates for claim pair
score_record$START_DATE_DIFF <- ifelse(score_record$START_DATE_1 > score_record$START_DATE_2,
                                       difftime(score_record$START_DATE_1 , score_record$START_DATE_2, units = c("days")),
                                       difftime(score_record$START_DATE_2 , score_record$START_DATE_1, units = c("days")))



score_record$END_DATE_DIFF <- ifelse(score_record$END_DATE_1 > score_record$END_DATE_2,
                                     difftime(score_record$END_DATE_1 , score_record$END_DATE_2, units = c("days")),
                                     difftime(score_record$END_DATE_2 , score_record$END_DATE_1, units = c("days")))


ggplot(score_record, aes(x=SCORE)) + geom_histogram(binwidth = 0.001)



hi_score <- sqldf("select sum(PAID_1) from score_record where SCORE >0.999")










score_record[is.na(score_record)] <-0

score_record$score_transformed <-  (log(score_record$SCORE)  + 1)

perfect_match <- score_record
perfect_match <- perfect_match %>% filter(score_record$SCORE == 1.0)

near_match <- score_record
near_match <- near_match %>% filter(score_record$SCORE < 1)

# top .05 % near match
near_match <- near_match %>% filter(SCORE > quantile(near_match$SCORE, 0.95))

score_record_top <- rbind(perfect_match, near_match)
score_record2 <- sqldf("select distinct * from score_record_top ORDER BY score_transformed DESC ")
score_record2$score_transformed <- NULL


score_record2id <- sqldf("select distinct PAT_MEMBER_NO, SCORE from score_record2")


claim_example2 <- sqldf("select distinct s.SCORE,  c.* from claim_example c, score_record2id s
                        where s.PAT_MEMBER_NO = c.PAT_MEMBER_NO
                        order by  s.SCORE DESC")


write.table(score_record2, file = "traditional_Gower_scoresc_6_5j.csv",
            row.names = FALSE, sep ="\t")

write.table(claim_example2, file = "claim_examplec_6_5j.csv",
            row.names = FALSE, sep ="\t")













# 
# 
# 
# # write.table(score_record, file = "traditional_Gower_scores_sample.csv",
# #             row.names = FALSE, sep ="\t")
# # 
#  
# 
# 
# 
#  #perfect <- sqlQuery(conn, "select * from dbo.AetnaDuplicateResearch where 
# #ROWID = 22212076 OR ROWID = 22212077")
# # 
# # perfect_95 <- sqlQuery(conn, "select * from dbo.AetnaDuplicateResearch where ROWID = 4978114 OR ROWID = 4978110")
# 
# 
# data_2_cluster <- sqldf("select PAID_1, SCORE from score_record where SCORE < 1 and SCORE > 0.99")
# 
# data_2_cluster_base <- data_2_cluster
# 
# data_2_cluster2 <- scale(data_2_cluster)
# 
# nb <- NbClust(data_2_cluster2, diss = NULL, distance = "euclidean",
#               min.nc = 2, max.nc = 5, method = "kmeans",
#               index = "all", alphaBeale = 0.1)
# 
# hist(nb$Best.nc[1,], breaks = max(na.omit(nb$Best.nc[1,])))
# 
# 
# km <- kmeans(data_2_cluster2, centers = 4, nstart = 25)
# fviz_cluster (km, data =data_2_cluster2 , pointsize = 0.5, labelsize = 2, main = "Clusters of Paid Amount and Distance Score Normalized")
# 
# # extract cluster assignment vector from the kmeans model
# clust_km <- km$cluster
# 
# # add cluster to dataframe
# data_2_cluster3 <- mutate(data_2_cluster_base, cluster = clust_km)
# 
# write.table(data_2_cluster3, file = "traditional_Gower_scores_cluster_11_15.csv",
#             row.names = FALSE, sep ="\t")
# 
# 
# # box plot by cluster
# 
# ggplot(data_2_cluster_base, aes(y=SCORE, x= cluster)) + geom_boxplot() + theme_gray()
# 



#BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB


# baseline comparison

CCS_lookup <- read.csv("ccs_dx_icd10cm_2018_1.csv", sep = ",",  quote = "\"", header = TRUE)

dup4 <-  read.csv("traditional_Gower_scoresc_6_5d.csv", sep = "\t",  quote = "\"", header = TRUE)
dup1 <-  read.csv("traditional_Gower_scoresc_6_5a.csv", sep = "\t",  quote = "\"", header = TRUE)
dup2 <-  read.csv("traditional_Gower_scoresc_6_5b.csv", sep = "\t",  quote = "\"", header = TRUE)
dup3 <-  read.csv("traditional_Gower_scoresc_6_5c.csv", sep = "\t",  quote = "\"", header = TRUE)
dup5 <-  read.csv("traditional_Gower_scoresc_6_5e.csv", sep = "\t",  quote = "\"", header = TRUE)
dup6 <-  read.csv("traditional_Gower_scoresc_6_5f.csv", sep = "\t",  quote = "\"", header = TRUE)
dup7 <-  read.csv("traditional_Gower_scoresc_6_5g.csv", sep = "\t",  quote = "\"", header = TRUE)
dup8 <-  read.csv("traditional_Gower_scoresc_6_5h.csv", sep = "\t",  quote = "\"", header = TRUE)
dup9 <-  read.csv("traditional_Gower_scoresc_6_5i.csv", sep = "\t",  quote = "\"", header = TRUE)
dup10 <-  read.csv("traditional_Gower_scoresc_6_5j.csv", sep = "\t",  quote = "\"", header = TRUE)



claimdetail4 <-  read.csv("claim_examplec_6_5d.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail1 <-  read.csv("claim_examplec_6_5a.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail2 <-  read.csv("claim_examplec_6_5b.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail3 <-  read.csv("claim_examplec_6_5c.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail5 <-  read.csv("claim_examplec_6_5e.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail6 <-  read.csv("claim_examplec_6_5f.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail7 <-  read.csv("claim_examplec_6_5g.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail8 <-  read.csv("claim_examplec_6_5h.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail9 <-  read.csv("claim_examplec_6_5i.csv", sep = "\t",  quote = "\"", header = TRUE)
claimdetail10 <-  read.csv("claim_examplec_6_5j.csv", sep = "\t",  quote = "\"", header = TRUE)






dupe_all1 <- rbind(dup1,dup2)
dupe_all1 <- rbind(dupe_all1,dup3)
dupe_all1 <- rbind(dupe_all1,dup4)
dupe_all1 <- rbind(dupe_all1,dup5)
dupe_all1 <- rbind(dupe_all1,dup6)
dupe_all1 <- rbind(dupe_all1,dup7)
dupe_all1 <- rbind(dupe_all1,dup8)
dupe_all1 <- rbind(dupe_all1,dup9)
dupe_all1 <- rbind(dupe_all1,dup10)


claims_all1 <- rbind(claimdetail1, claimdetail2)
claims_all1 <- rbind(claims_all1, claimdetail3)
claims_all1 <- rbind(claims_all1, claimdetail4)
claims_all1 <- rbind(claims_all1, claimdetail5)
claims_all1 <- rbind(claims_all1, claimdetail6)
claims_all1 <- rbind(claims_all1, claimdetail7)
claims_all1 <- rbind(claims_all1, claimdetail8)
claims_all1 <- rbind(claims_all1, claimdetail9)
claims_all1 <- rbind(claims_all1, claimdetail10)

claims_all1$PRINCIPAL_DIAG <- gsub(".","",claims_all1$PRINCIPAL_DIAG, fixed = TRUE)

claims_all1$CL_DATE_OF_SERVICE_BEG <- as.Date(as.character(claims_all1$CL_DATE_OF_SERVICE_BEG))
claims_all1$CL_DATE_OF_SERVICE_END <- as.Date(as.character(claims_all1$CL_DATE_OF_SERVICE_END))

claims_all2 <- sqldf ("select c.*, s.source from claims_all1 c, source_flag s
                      where c.CLAIM_NO = s.CLAIM_NO")


ggplot(claims_all2, aes(x=factor(source), y= SCORE, fill =factor(source) ))+
  geom_boxplot(alpha=0.4) +
  stat_summary(fun.y=mean, geom="point", shape=20, size=5, color = "red", fill="red")+
  theme(legend.position = "none")+
  scale_fill_brewer(palette = "Set3")+
  labs(title = "Score by Source", x = "source", y = "SCORE")


mem1b <- sqldf("select distinct PAT_MEMBER_NO,source from claims_all2")
mem2b <- sqldf("select source, count(source) as cnt from mem1b group by source" )



 



# 
# 
# # rename columns
# CCS_lookup$ICD9_CODE <- CCS_lookup$X.ICD.10.CM.CODE.
# CCS_lookup$CCS_DX <- CCS_lookup$X.CCS.CATEGORY.
# CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
# CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
# 
# 
# CCS_dupes <- sqldf("select DISTINCT d.*,  c.CCS_DX
#                         from claims_all1 d left join CCS_lookup c on d.PRINCIPAL_DIAG = c.ICD9_CODE
#                         order by d.CLAIM_NO ")
# 
# dupes_cpt_cnt <- sqldf("select PAT_MEMBER_NO, CCS_DX, CPT, count(CPT) as cpt_cnt from CCS_dupes
#                        group by  PAT_MEMBER_NO, CCS_DX, CPT")
# 
#  
# # time span
# 
# CCS_dupes_time <- CCS_dupes %>%
#   arrange( PAT_MEMBER_NO, CL_DATE_OF_SERVICE_BEG) %>%
#   group_by(  PAT_MEMBER_NO) %>%
#   dplyr::mutate(diff =  CL_DATE_OF_SERVICE_BEG - lag(CL_DATE_OF_SERVICE_END),
#                 days_between_encounter = as.numeric(diff, units = 'days'))
# 
# 
# CCS_dupes_time$days_between_encounter <- ifelse(is.na(CCS_dupes_time$days_between_encounter),
#                                               0, CCS_dupes_time$days_between_encounter + 1)
# 
# names(CCS_dupes_time)[45] <- "days_between_encounters"
# 
# 
# 
# time1_dup <- CCS_dupes_time %>%
#   arrange(PAT_MEMBER_NO,  CCS_DX, CPT ) %>%
#   group_by( PAT_MEMBER_NO,  CCS_DX, CPT) %>%
#   dplyr::summarize(dupe_median_time = median(days_between_encounters, na.rm=TRUE))
# 
# 
# names(time1_dup)[4] <- "dupe_median_times"
# 
# dupes_cpt_cnt2 <- sqldf("select d.*, t.dupe_median_times from dupes_cpt_cnt d, time1_dup t
#                       where d.PAT_MEMBER_NO = t.PAT_MEMBER_NO
#                       and d.CCS_DX = t.CCS_DX
#                       and d.CPT = t.CPT")
# 
# 
# baseline_CPT_counts <-  read.csv("baseline_CPT_counts.csv", sep = "\t",  quote = "\"", header = TRUE)
# 
# 
# dupes_cpt_cnt3 <- sqldf("select d.*, t.mean_cpt_cnt_member, t.median_cpt_cnt_member,
#                         t.mean_time, t.median_time from dupes_cpt_cnt2 d, baseline_CPT_counts t
#                       where d.CCS_DX = t.CCS_DX
#                         and d.CPT = t.CPT")
# 
# dupes_cpt_cnt3$CPT_Count_to_Baseline_Diff <- dupes_cpt_cnt3$cpt_cnt - dupes_cpt_cnt3$median_cpt_cnt_member
# dupes_cpt_cnt3$Median_Days_between_Claim_Diff <- dupes_cpt_cnt3$dupe_median_times - dupes_cpt_cnt3$median_time
# 
# dupes_cpt_cnt4 <- sqldf ("select distinct d.*, a.score from dupes_cpt_cnt3 d, dupe_all1 a
#                          where d.PAT_MEMBER_NO = a.PAT_MEMBER_NO" )
# 
# 
# names(CCS_lookup)[4] <- "CCS_Description"
# 
# CCS_lookup2 <- sqldf("select distinct CCS_DX,CCS_Description from CCS_lookup")
# 
# 
# dupes_cpt_cnt5 <- sqldf ("select distinct d.PAT_MEMBER_NO,d.Score,  c.CCS_Description, d.CPT,
#                          d.cpt_cnt as Count_CPT_Codes, d.median_cpt_cnt_member as Median_Baseline_Count,
#                          d.CPT_Count_to_Baseline_Diff, d.dupe_median_times as Median_Days_Between_Encounters,
#                          d.median_time as Baseline_Median_Days_Between_Encounters, d.Median_Days_between_Claim_Diff
#                          from dupes_cpt_cnt4 d, CCS_lookup2 c
#                          where d.CCS_DX = c.CCS_DX
#                          and d.CPT_Count_to_Baseline_Diff > 0
#                          order by d.CPT_Count_to_Baseline_Diff desc")
# 
# 
# 
# # claim hits
# 
# claim_all_hits <- sqldf("select c.* from claims_all1 c, dupes_cpt_cnt5 d
#                         where c.PAT_MEMBER_NO = d.PAT_MEMBER_NO")
# 


write.table(claim_all_hits, file = "claims_4_26.csv",
            row.names = FALSE, sep ="\t")

write.table(dupes_cpt_cnt5, file = "possible_dupes_4_26.csv",
            row.names = FALSE, sep ="\t")



