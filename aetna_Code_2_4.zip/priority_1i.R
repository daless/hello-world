#try different normailzation
# normalize before gower


# 
#
# neural network with no target ? CCS, elixhouser diseases

setwd("~/aetna")


library(comorbidity)
library(RODBC)
library(sqldf)
#library(dplyr)
library(tidyverse)
library(dummies)
library(SOMbrero)
library(kohonen)
library(broom)
library(cluster)

library(SOMbrero)
library(kohonen)

library(C50)

#library(h2o)
#h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)

# scp analytic_data2020_0_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp FIPS_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp USDA.txt dless1@apsrd9425:/home/dless1/aetna


# connection: dbswp0625
# database: RacerResearch
# schema: dbo
# view: vwAetnaTradMemClaimCoverage



conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)



base1 <- sqlQuery(
  conn,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,

CLM.AMT_COB_PAID,


CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,

MEM.member_ID,MEM.MEMBER_NO, MEM.DATE_EFFECTIVE,
CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
as cd_SUBCATEGORY, CS.STATUS_CODE, cs.amt_of_refund as Amount_refund,cs.case_id
FROM dbo.CLAIM CLM  with (nolock)
INNER JOIN dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
INNER JOIN dbo.CASE_DATA CD  with (nolock)
ON CS.CASE_ID = CD.CASE_ID
INNER JOIN dbo.STATUS_CODE SC  with (nolock)
ON CS.STATUS_CODE = SC.STATUS_CODE
INNER JOIN dbo.SPECIAL_FIELDS SF  with (nolock)
ON CLM.CLAIM_ID = SF.ID
WHERE CS.HDS_LOB_ID = 2
AND CD.SUBCATEGORY = 10

AND CS.STATUS_CODE IN (2,50,55)
AND CLM.PROJECT_ID = 222
AND IsValidSSN = 1
and CLM.FEED_ID between 150 and 209
")

#base1 <- data.frame(r_index = row.names(base1), base1)


mem_enroll_date <- sqldf("select MEMBER_NO, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE from base1

               group by MEMBER_NO")


base1 <- sqldf("select b.*, m.max_DATE_EFFECTIVE from base1 b left join mem_enroll_date m
               on b.MEMBER_NO = m.MEMBER_NO
               group by b.CLAIM_ID")



# base1$Days_of_service <- difftime("2021-1-1",base1$DATE_OF_SERVICE_END ,
#                                                   units = c("days")) 
# 
# base1$Days_of_service <- as.integer(base1$Days_of_service)
# 
# Days_of_service <= 365

base1 <- sqldf(
  "select DISTINCT *
FROM base1
WHERE  PATIENT_AGE >= 18 and PATIENT_AGE <=64
and AMT_PAID >0
  ")


# convert to date format

base1$enroll_date <-as.POSIXct(base1$max_DATE_EFFECTIVE, origin="1970-01-01")
base1$admit_date <-as.POSIXct(base1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
base1$member_months <-(difftime(base1$admit_date , base1$enroll_date, units = "days"  ))/30.42
base1a <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base1
                             group by PATIENT_ID")



summary(base1
        )


DX_claim  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.CLAIM CLM  with (nolock)
  INNER JOIN DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
  where CLM.PROJECT_ID = 222
  AND  DX.ORDER_IN_CLAIM <= 5
  AND CS.STATUS_CODE IN (2,50,55)
  and CLM.FEED_ID >= 150
 and CLM.FEED_ID between 150 and 209


  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)


cl_id <- sqldf("select distinct CLAIM_ID from base1 ")


DX_claim <- sqldf("select d.* from DX_claim d, cl_id c
                  where d.CLAIM_ID = c.CLAIM_ID")




non_refund_members <-  sqlQuery(
  conn,
  "select DISTINCT
CLM.PATIENT_ID,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
MEM.DATE_EFFECTIVE,
CLM.DATE_OF_SERVICE_BEG
FROM dbo.CLAIM CLM  with (nolock)
INNER JOIN dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
INNER JOIN dbo.CLAIM_STATUS CS  with (nolock)
ON CLM.CLAIM_ID = CS.CLAIM_ID
AND CLM.PROJECT_ID = CS.PROJECT_ID
INNER JOIN dbo.CASE_DATA CD  with (nolock)
ON CS.CASE_ID = CD.CASE_ID
INNER JOIN dbo.STATUS_CODE SC  with (nolock)
ON CS.STATUS_CODE = SC.STATUS_CODE
INNER JOIN dbo.SPECIAL_FIELDS SF  with (nolock)
ON CLM.CLAIM_ID = SF.ID
WHERE CS.HDS_LOB_ID = 2
AND CD.SUBCATEGORY = 10
AND CS.STATUS_CODE !='2'
  or CS.STATUS_CODE !='50'
  or CS.STATUS_CODE !='55'
AND CLM.PROJECT_ID != 222
AND IsValidSSN = 1
and CLM.FEED_ID >= 150
  and CLM.FEED_ID <= 209
AND CLM.PATIENT_AGE < 65
AND CLM.PATIENT_AGE > 18
and ISNULL(CLM.AMT_PAID, 0) > 0")


non_refund_members0 <- sqldf("select PATIENT_ID, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE from non_refund_members group by PATIENT_ID")
non_refund_members1 <- sqldf("select n.*,m.max_DATE_EFFECTIVE from non_refund_members0 m,  non_refund_members n
                             where m.PATIENT_ID= n.PATIENT_ID")

# convert to date format
non_refund_members1$enroll_date <-as.POSIXct(non_refund_members1$max_DATE_EFFECTIVE, origin="1970-01-01")
non_refund_members1$admit_date <-as.POSIXct(non_refund_members1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
non_refund_members1$member_months <-(difftime(non_refund_members1$admit_date , non_refund_members1$enroll_date, units = "days"  ))/30.42
non_refund_members2 <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from non_refund_members1
                             group by PATIENT_ID")



refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as ref_cnt, avg(first_mm) as mean_mm from
base1a  group by INS_GROUP_ID order by ref_cnt desc" )


  
non_refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as non_ref_cnt, avg(first_mm) as non_mean_mm from
non_refund_members2  group by INS_GROUP_ID order by non_ref_cnt desc" )

groupid_ratio <- sqldf("select r.*, n.non_ref_cnt,n.non_mean_mm   from non_refund_members_cnt n, 
                       refund_members_cnt r where r.INS_GROUP_ID = n.INS_GROUP_ID")

groupid_ratio$groupid_refund_rate <- (groupid_ratio$ref_cnt / groupid_ratio$non_ref_cnt) *100000

# a positive number means that the refunds were newer members
groupid_ratio$member_month_delta <- as.numeric(groupid_ratio$non_mean_mm -  groupid_ratio$mean_mm)

base2 <- sqldf("select b.*, g.groupid_refund_rate, g.member_month_delta from base1 b , groupid_ratio g
               where b.INS_GROUP_ID = g.INS_GROUP_ID", method = "name_class")


base2$ratio_billed_to_paid<-(base2$AMT_BILLED + 1 )/(base2$AMT_PAID +1 )
base2$ratio_allowed_to_paid<-(base2$AMT_ALLOWED +1 ) /(base2$AMT_PAID +1)

base2$PLACE_OF_SERVICE<- ifelse(is.na(base2$PLACE_OF_SERVICE), 0, 
                                base2$PLACE_OF_SERVICE)

base2$BILL_TYPE<- ifelse(base2$BILL_TYPE == '', "0", base1$BILL_TYPE)

# base2$INS_GROUP_ID <- as.factor(as.character(base2$INS_GROUP_ID ))
# base2$PRODUCT_LINE_ID <- as.factor(as.character(base2$PRODUCT_LINE_ID ))

# distance_factors <- sqldf("select groupid_refund_rate,ratio_billed_to_paid,
# ratio_allowed_to_paid
#   from base2  ")
# 
# distance_factors <- as.data.frame(scale(distance_factors))
# distance_factors <- cbind(distance_factors,base2$PRODUCT_LINE_ID)
# # rename
# names(distance_factors)[4] <- "PRODUCT_LINE_ID"
# 
# gower_dist <- daisy(distance_factors,
#                     metric = "gower",
#                     stand = FALSE)
# 
# 
# gower_dist_df <- as.data.frame(as.matrix((gower_dist)))
# 
# 
# summary(gower_dist )
# 
# distance_factors <- sqldf("select groupid_refund_rate,ratio_billed_to_paid,
# ratio_allowed_to_paid, PRODUCT_LINE_ID
#   from base2  ")
# 
# gower_mat <- as.matrix(gower_dist)
# # Output most similar pair
# distance_factors[
#   which(gower_mat == min(gower_mat[gower_mat != min(gower_mat)]),
#         arr.ind = TRUE)[1, ], ]
# 
# 
# # Output most dissimilar pair
# distance_factors[
#   which(gower_mat == max(gower_mat[gower_mat != max(gower_mat)]),
#         arr.ind = TRUE)[1, ], ]

# 
# # Calculate silhouette width for many k using PAM
# sil_width <- c(NA)
# for(i in 2:10){
#   
#   pam_fit <- pam(gower_dist,
#                  diss = TRUE,
#                  k = i)
#   
#   sil_width[i] <- pam_fit$silinfo$avg.width
#   
# }
# 
# sil_width <- as.data.frame(sil_width )
# 
# # 3 clusters
# 
# pam_fit <- pam(gower_dist, diss = TRUE, k = 3)
# 
# pam_results <- distance_factors %>%
#   dplyr::select(PRODUCT_LINE_ID)%>%
#   mutate(cluster = pam_fit$clustering) %>%
#   group_by(cluster) %>%
#   do(the_summary = summary(.))
# pam_results$the_summary
# 
# distance_factors[pam_fit$medoids, ]
# 
# 
# # Plot sihouette width (higher is better)
# plot(1:10, sil_width,
#      xlab = "Number of clusters",
#      ylab = "Silhouette Width")
# lines(1:10, sil_width)




DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")


elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")


base3 <- sqldf("select b.*, e.wscore_vw as elixhauser from elixhauser_scores e, base2 b
               where b.CLAIM_ID = e.CLAIM_ID")


base3 <- sqldf("select b.*, e.wscore as charlson from charlson_scores e, base3 b
               where b.CLAIM_ID = e.CLAIM_ID
               and member_month_delta !=''")

base3$member_month_delta <- as.integer(base3$member_month_delta)

saveRDS(base3, file="base3_priority.Rda")
write.csv(base3, file = "base3_priority.csv")


SOM_inputs <- sqldf("select PATIENT_AGE,groupid_refund_rate, ratio_billed_to_paid, ratio_allowed_to_paid,  charlson,elixhauser,
member_month_delta
                    from base3
                    ")





distance0_scale <- scale(SOM_inputs)
som2 <- trainSOM(x.data = distance0_scale, dimension = c(10,10), nb.save = 10, maxit = 500,
                 scaling = "none")

#plot(som2, what = "obs", type = "hitmap")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=5)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)


targ <- cbind(base3,som_diste)

# #rename
names(targ)[53] <- 'SOM_CLUSTER'

targ$SOM_CLUSTER <- as.factor(as.character(targ$SOM_CLUSTER))



base4 <- sqldf("select SOM_CLUSTER,
 PATIENT_GENDER,PLACE_OF_SERVICE,BILL_TYPE,PRODUCT_LINE_ID
from targ")


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)

base4$BILL_TYPE<- ifelse(is.na(base4$BILL_TYPE), 0, 
                                base4$BILL_TYPE)

base4$PATIENT_GENDER <- as.factor(base4$PATIENT_GENDER)

base4$BILL_TYPE <- as.factor(base4$BILL_TYPE)
base4$PLACE_OF_SERVICE<-as.factor(base4$PLACE_OF_SERVICE)

  
#base4$INS_GROUP_ID <- as.factor(as.character(base4$INS_GROUP_ID ))
base4$PRODUCT_LINE_ID <- as.factor(as.character(base4$PRODUCT_LINE_ID ))

colnames(base4)[colSums(is.na(base4)) > 0]

gower_dist <- daisy(base4,
                    metric = "gower",
                    stand = TRUE)


gower_dist_df <- as.data.frame(as.matrix((gower_dist)))


summary(gower_dist )


gower_mat <- as.matrix(gower_dist)
# Output most similar pair
base4[
  which(gower_mat == min(gower_mat[gower_mat != min(gower_mat)]),
        arr.ind = TRUE)[1, ], ]


# Output most dissimilar pair
targ[
  which(gower_mat == max(gower_mat[gower_mat != max(gower_mat)]),
        arr.ind = TRUE)[1, ], ]



# Calculate silhouette width for many k using PAM
sil_width <- c(NA)
for(i in 2:20){

  pam_fit <- pam(gower_dist,
                 diss = TRUE,
                 k = i)

  sil_width[i] <- pam_fit$silinfo$avg.width

}

sil_width <- as.data.frame(sil_width )

# 3 clusters

pam_fit <- pam(gower_dist, diss = TRUE, k = 5)

pam_results <- targ %>%
  dplyr::select(SOM_CLUSTER)%>%
  mutate(cluster = pam_fit$clustering) %>%
  group_by(cluster) %>%
  do(the_summary = summary(.))
pam_results$the_summary


sum29<- sqldf("select * from targ where SOM_CLUSTER IN(81) ")


sum3<- sqldf("select * from targ where SOM_CLUSTER IN(61) ")


summary(sum29)
summary(sum3)





####################################################################

# sqrt of ratios

base_sqrt <- base3

base_sqrt <- data.frame(r_index = row.names(base_sqrt), base_sqrt)
id <- sqldf("select r_index from base_sqrt ")
base_sqrt$r_index <- NULL


cluster_inputs <- base_sqrt

cluster_inputs$PATIENT_AGE <- sqrt(cluster_inputs$PATIENT_AGE)
cluster_inputs$groupid_refund_rate <- sqrt(cluster_inputs$groupid_refund_rate)
cluster_inputs$ratio_billed_to_paid <- sqrt(cluster_inputs$ratio_billed_to_paid)
cluster_inputs$ratio_allowed_to_paid <- sqrt(cluster_inputs$ratio_allowed_to_paid)

cluster_inputs$charlson <- scale(cluster_inputs$charlson)
cluster_inputs$elixhauser <- scale(cluster_inputs$elixhauser)
cluster_inputs$member_month_delta <- scale(cluster_inputs$member_month_delta)

distance0_scale <- sqldf("select PATIENT_AGE,groupid_refund_rate, ratio_billed_to_paid, ratio_allowed_to_paid,  charlson,elixhauser,
member_month_delta
                    from cluster_inputs
                    ")

som2 <- trainSOM(x.data = distance0_scale, dimension = c(4,5), nb.save = 10, maxit = 500,
                 scaling = "none")

#plot(som2, what = "obs", type = "hitmap")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=5)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)


targ <- cbind(cluster_inputs,som_diste)

# #rename
names(targ)[53] <- 'SOM_CLUSTER'

targ$SOM_CLUSTER <- as.factor(as.character(targ$SOM_CLUSTER))



base4 <- sqldf("select PATIENT_AGE,groupid_refund_rate, ratio_billed_to_paid, ratio_allowed_to_paid,  charlson,elixhauser,
member_month_delta,
 PATIENT_GENDER,PLACE_OF_SERVICE,BILL_TYPE,PRODUCT_LINE_ID
from targ")


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)

base4$BILL_TYPE<- ifelse(is.na(base4$BILL_TYPE), 0, 
                         base4$BILL_TYPE)

base4$PATIENT_GENDER <- as.factor(base4$PATIENT_GENDER)

base4$BILL_TYPE <- as.factor(base4$BILL_TYPE)
base4$PLACE_OF_SERVICE<-as.factor(base4$PLACE_OF_SERVICE)


#base4$INS_GROUP_ID <- as.factor(as.character(base4$INS_GROUP_ID ))
base4$PRODUCT_LINE_ID <- as.factor(as.character(base4$PRODUCT_LINE_ID ))

base4$charlson <- as.numeric(as.character(base4$charlson))
base4$elixhauser <-  as.numeric(as.character(base4$elixhauser))
base4$member_month_delta <-  as.numeric(as.character(base4$member_month_delta))



colnames(base4)[colSums(is.na(base4)) > 0]

gower_dist <- daisy(base4,
                    metric = "gower",
                    stand = TRUE)


gower_dist_df <- as.data.frame(as.matrix((gower_dist)))


summary(gower_dist )


gower_mat <- as.matrix(gower_dist)
# Output most similar pair
base4[
  which(gower_mat == min(gower_mat[gower_mat != min(gower_mat)]),
        arr.ind = TRUE)[1, ], ]


# Output most dissimilar pair
targ[
  which(gower_mat == max(gower_mat[gower_mat != max(gower_mat)]),
        arr.ind = TRUE)[1, ], ]



# Calculate silhouette width for many k using PAM
sil_width <- c(NA)
for(i in 2:20){
  
  pam_fit <- pam(gower_dist,
                 diss = TRUE,
                 k = i)
  
  sil_width[i] <- pam_fit$silinfo$avg.width
  
}

sil_width <- as.data.frame(sil_width )

# 3 clusters

pam_fit <- pam(gower_dist, diss = TRUE, k = 4)

pam_results <- targ %>%
  
  mutate(cluster = pam_fit$clustering) %>%
  group_by(cluster) %>%
  do(the_summary = summary(.))
pam_results$the_summary


sum29<- sqldf("select * from targ where SOM_CLUSTER IN(5) ")


sum3<- sqldf("select * from targ where SOM_CLUSTER IN(20) ")


summary(sum29)
summary(sum3)



# camila
library(klaR)
library(kamila)
library(cluster)
library(psych)

catVarsFac <- c(names(Filter(is.factor,base4)))

number_list <- c(names(Filter(is.numeric,base4)))
number_match <- match(number_list, names(base4))
number_match <- base4[,number_match]

conInd <- colnames(number_match)


# 
# 
# rangeStandardize <- function(x) {
#   (x - min(x)) / diff(range(x))
# }
# 
# 
# L1Dist <- function(v1, v2) {
#   sum(abs(v1 - v2))
# }
# matchingDist <- function(v1, v2) {
#   sum(as.integer(v1) != as.integer(v2))
# }
# 
# 
# # pam function wrapper
# 
# pamix <- function(connData, catData, conWeight, nclust, ...) {
#   conData <- as.data.frame(conVars)
#   catData <- as.data.frame(catVarsFac)
#   distmat <- daisy(x= cbind(conData, catData), metric = "gower",
#                    weights = rep(c(conWeight, 1 - conWeight),
#                                  times = c(ncol(conData), ncol(catData))))
#   clustRes <- pam(x = distMat, k = nclust, diss = TRUE, ...)
#   return(list(cluster = clustRes$clustering,
#               conCenters = conData[clustRes$id.med, , drop = FALSE],
#               catCenters = catData[clustRes$id.med, , drop = FALSE]))
# }


set.seed(77)
conVars <- base4[,conInd]
#conVars <- data.frame(scale(conVars))
#conVars <- as.data.frame(lapply(conVars, rangeStandardize))

catVarsFac[] <- lapply(catVarsFac, factor)
#catVarsDum <- dummyCodeFactorDf(catVarsFac)

# colnames(par4)[colSums(is.na(par4)) > 0]
# colnames(conVars)[colSums(is.na(conVars)) > 0]
# gmsResHw <- gmsClust(conVars,catVarsDum, nclust = 4 )
# gmsResLloyd <- gmsClust(conVars,catVarsDum, nclust = 4 ,
#                         algorithm = "Lloyd", searchDensity = 10)



factor_list3 <- c(names(Filter(is.factor,base4)))
fact_match3 <- match(factor_list3, names(base4))
catVarsFac <- base4[,fact_match3]

# kamRes <- kamila(conVars, catVarsFac, numClust = 4, numInit = 10,
#                 maxIter = 50)

#colnames(conVars)[colSums(is.na(conVars)) > 0]
#colnames(catVarsFac)[colSums(is.na(catVarsFac)) > 0]

kamRes2 <- kamila(conVars, catVarsFac, numClust = 2 : 10, numInit = 10,
                  calcNumClust = "ps", numPredStrCvRun = 10, predStrThresh = 0.5,  maxIter = 50)


kam_membership<- as.data.frame(kamRes2$finalMemb)
number_clusters <- as.data.frame(kamRes2$nClust$bestNClust)
N_clusters = kamRes2$nClust$bestNClust
cluster_strength <- as.data.frame(kamRes2$nClust$avgPredStr)

plotDatKam <- cbind(id,conVars, catVarsFac, Cluster = factor(kamRes2$finalMemb) )


# remove standardized continuous data and reload orignial data
# this makes rules easier to implament

plotDatKam <- plotDatKam[,!colnames(plotDatKam) %in% conInd]
conVars <- base_sqrt[,conInd]
plotDatKam <- cbind(plotDatKam ,conVars )

som_output <-sqldf("select SOM_CLUSTER from targ")

plotDatKam <- cbind(plotDatKam ,som_output )


table(plotDatKam$SOM_CLUSTER, plotDatKam$Cluster)

plotDatKam$r_index <- NULL
Cluster_descriptives_sqrt <- as.data.frame(describeBy(plotDatKam,
                                               group = list(plotDatKam$Cluster), 
                                               mat=TRUE))

SOM_descriptives_sqrt <- as.data.frame(describeBy(plotDatKam,
                                                 group = list(plotDatKam$SOM_CLUSTER), 
                                                 mat=TRUE))




plotDatKam$SOM_cluster_flag <- ifelse(plotDatKam$Cluster == 5 & plotDatKam$SOM_CLUSTER == 5,1,0)

SOM_results <- plotDatKam %>%
  
  mutate(cluster = plotDatKam$SOM_cluster_flag) %>%
  group_by(SOM_cluster_flag) %>%
  do(the_summary = summary(.))
SOM_results$the_summary

saveRDS(plotDatKam, file="plotDatKam_sqrt.Rda")
write.csv(plotDatKam, file = "plotDatKam_sqrt.csv")


write.csv(Cluster_descriptives_sqrt, file = "Cluster_descriptives_sqrt.csv")
write.csv(SOM_descriptives_sqrt, file = "SOM_descriptives_sqrt.csv")

#LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


# log transofrmation



base_log <- base3

base_log <- data.frame(r_index = row.names(base_log), base_log)
id <- sqldf("select r_index from base_log ")
base_log$r_index <- NULL


cluster_inputs <- base_log

cluster_inputs$PATIENT_AGE <- log10(cluster_inputs$PATIENT_AGE)
cluster_inputs$groupid_refund_rate <- log10(cluster_inputs$groupid_refund_rate)
cluster_inputs$ratio_billed_to_paid <- log10(cluster_inputs$ratio_billed_to_paid)
cluster_inputs$ratio_allowed_to_paid <- log10(cluster_inputs$ratio_allowed_to_paid)

cluster_inputs$charlson <- scale(cluster_inputs$charlson)
cluster_inputs$elixhauser <- scale(cluster_inputs$elixhauser)
cluster_inputs$member_month_delta <- scale(cluster_inputs$member_month_delta)

distance0_scale <- sqldf("select PATIENT_AGE,groupid_refund_rate, ratio_billed_to_paid, ratio_allowed_to_paid,  charlson,elixhauser,
member_month_delta
                    from cluster_inputs
                    ")

som2 <- trainSOM(x.data = distance0_scale, dimension = c(4,5), nb.save = 10, maxit = 500,
                 scaling = "none")


table(som2$clustering)


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=5)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)


targ <- cbind(cluster_inputs,som_diste)

# #rename
names(targ)[53] <- 'SOM_CLUSTER'

targ$SOM_CLUSTER <- as.factor(as.character(targ$SOM_CLUSTER))



base4 <- sqldf("select PATIENT_AGE,groupid_refund_rate, ratio_billed_to_paid, ratio_allowed_to_paid,  charlson,elixhauser,
member_month_delta,
 PATIENT_GENDER,PLACE_OF_SERVICE,BILL_TYPE,PRODUCT_LINE_ID
from targ")


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)


base4$PLACE_OF_SERVICE<- ifelse(is.na(base4$PLACE_OF_SERVICE), 0, 
                                base4$PLACE_OF_SERVICE)

base4$BILL_TYPE<- ifelse(is.na(base4$BILL_TYPE), 0, 
                         base4$BILL_TYPE)

base4$PATIENT_GENDER <- as.factor(base4$PATIENT_GENDER)

base4$BILL_TYPE <- as.factor(base4$BILL_TYPE)
base4$PLACE_OF_SERVICE<-as.factor(base4$PLACE_OF_SERVICE)



base4$PRODUCT_LINE_ID <- as.factor(as.character(base4$PRODUCT_LINE_ID ))

base4$charlson <- as.numeric(as.character(base4$charlson))
base4$elixhauser <-  as.numeric(as.character(base4$elixhauser))
base4$member_month_delta <-  as.numeric(as.character(base4$member_month_delta))



colnames(base4)[colSums(is.na(base4)) > 0]

gower_dist <- daisy(base4,
                    metric = "gower",
                    stand = TRUE)


gower_dist_df <- as.data.frame(as.matrix((gower_dist)))
summary(gower_dist )
gower_mat <- as.matrix(gower_dist)

# Output most similar pair
base4[
  which(gower_mat == min(gower_mat[gower_mat != min(gower_mat)]),
        arr.ind = TRUE)[1, ], ]


# Output most dissimilar pair
targ[
  which(gower_mat == max(gower_mat[gower_mat != max(gower_mat)]),
        arr.ind = TRUE)[1, ], ]



# Calculate silhouette width for many k using PAM
sil_width <- c(NA)
for(i in 2:20){
  
  pam_fit <- pam(gower_dist,
                 diss = TRUE,
                 k = i)
  
  sil_width[i] <- pam_fit$silinfo$avg.width
  
}

sil_width <- as.data.frame(sil_width )

# 6 clusters

pam_fit <- pam(gower_dist, diss = TRUE, k = 6)

pam_results <- targ %>%
  
  mutate(cluster = pam_fit$clustering) %>%
  group_by(cluster) %>%
  do(the_summary = summary(.))
pam_results$the_summary
# 
# 
# sum29<- sqldf("select * from targ where SOM_CLUSTER IN(9) ")
# 
# 
# sum3<- sqldf("select * from targ where SOM_CLUSTER IN(20) ")
# 
# 
# summary(sum29)
# summary(sum3)



# camila
# library(klaR)
# library(kamila)
# library(cluster)
# library(psych)

catVarsFac <- c(names(Filter(is.factor,base4)))

number_list <- c(names(Filter(is.numeric,base4)))
number_match <- match(number_list, names(base4))
number_match <- base4[,number_match]

conInd <- colnames(number_match)



set.seed(77)
conVars <- base4[,conInd]

catVarsFac[] <- lapply(catVarsFac, factor)
#


factor_list3 <- c(names(Filter(is.factor,base4)))
fact_match3 <- match(factor_list3, names(base4))
catVarsFac <- base4[,fact_match3]



kamRes2 <- kamila(conVars, catVarsFac, numClust = 2 : 10, numInit = 10,
                  calcNumClust = "ps", numPredStrCvRun = 10, predStrThresh = 0.5,  maxIter = 50)


kam_membership<- as.data.frame(kamRes2$finalMemb)
number_clusters <- as.data.frame(kamRes2$nClust$bestNClust)
N_clusters = kamRes2$nClust$bestNClust
cluster_strength <- as.data.frame(kamRes2$nClust$avgPredStr)

plotDatKam <- cbind(id,conVars, catVarsFac, Cluster = factor(kamRes2$finalMemb) )


# remove standardized continuous data and reload orignial data
# this makes rules easier to implament

plotDatKam <- plotDatKam[,!colnames(plotDatKam) %in% conInd]
conVars <- base_log[,conInd]
plotDatKam <- cbind(plotDatKam ,conVars )

som_output <-sqldf("select SOM_CLUSTER from targ")

plotDatKam <- cbind(plotDatKam ,som_output )


table(plotDatKam$SOM_CLUSTER, plotDatKam$Cluster)




plotDatKam$r_index <- NULL
Cluster_descriptives_log10 <- as.data.frame(describeBy(plotDatKam,
                                                      group = list(plotDatKam$Cluster), 
                                                      mat=TRUE))

SOM_descriptives_log10 <- as.data.frame(describeBy(plotDatKam,
                                                  group = list(plotDatKam$SOM_CLUSTER), 
                                                  mat=TRUE))


saveRDS(plotDatKam, file="plotDatKam_log.Rda")
write.csv(plotDatKam, file = "plotDatKam_log.csv")


write.csv(Cluster_descriptives_log10, file = "Cluster_descriptives_log10.csv")
write.csv(SOM_descriptives_log10, file = "SOM_descriptives_log10.csv")


plotDatKam$SOM_cluster_flag <- ifelse(plotDatKam$Cluster == 5 & plotDatKam$SOM_CLUSTER == 20,1,0)

SOM_results <- plotDatKam %>%
  
  mutate(cluster = plotDatKam$SOM_cluster_flag) %>%
  group_by(SOM_cluster_flag) %>%
  do(the_summary = summary(.))
SOM_results$the_summary




# H2O anomaly ANOVA

plotDatKam$cluster_cat <- as.factor(paste(as.character(plotDatKam$SOM_CLUSTER), '-', 
                                          as.character(plotDatKam$Cluster)))


an1 <- plotDatKam
an1$SOM_CLUSTER <- NULL
an1$Cluster <-NULL



learnname <- colnames(an1) 

an1_h2o <- as.h2o(an1)

an1_h2o_dl <- h2o.deeplearning(x = learnname, training_frame = an1_h2o, autoencoder = TRUE, 
                               hidden = c(100,20,100), epochs = 100, stopping_tolerance = 1e-4, activation = "Tanh",
                               categorical_encoding = "AUTO",
                               seed = 77,
                               standardize= TRUE,
                               reproducible = TRUE)


an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)

an2 <- cbind(plotDatKam,an1_h2o_dl2)

# #rename
names(an2)[15] <- 'Anomaly_Score'


anomaly_descriptives <- mutate(an2, 
                              anom_rank = ntile(an2$Anomaly_Score, 10))



table(anomaly_descriptives$cluster_cat , anomaly_descriptives$anom)




an3 <- an2 %>%
  
  mutate(cluster = an2$cluster_cat) %>%
  group_by(cluster) %>%
  do(the_summary = summary(.))
an3sum<-an3$the_summary

an3 <- as.data.frame(describeBy(an2,
                                                   group = list(an2$cluster_cat), 
                                                   mat=TRUE))


an3_groupby <- sqldf("select cluster_cat, avg(Anomaly_Score) as mean_score_by_cluster_cat,
count(cluster_cat) as member_cnt, avg(groupid_refund_rate) as avg_groupid_refund_rate
                     from an2 group by cluster_cat")



anomaly_descriptives$SOM_cluster_flag <- ifelse(anomaly_descriptives$cluster_cat == '1 - 5' &
                                                  anomaly_descriptives$anom == 1,1,0)

SOM_results <- anomaly_descriptives %>%
  
  mutate(cluster = plotDatKam$SOM_cluster_flag) %>%
  group_by(SOM_cluster_flag) %>%
  do(the_summary = summary(.))
SOM_results$the_summary

# C5models for all cluster 5 SOm clusters

# 1-5
C5a <- anomaly_descriptives
C5a$Cluster <- NULL
C5a$SOM_CLUSTER <- NULL
C5a$Anomaly_Score <- NULL
C5a$anom_rank <- NULL


C5a$SOM_cluster_flag <- ifelse(C5a$cluster_cat == '1 - 5', 1,0)
C5a$SOM_cluster_flag <- as.factor(as.character(C5a$SOM_cluster_flag))
C5a$cluster_cat <- NULL


ruleC5_1_5 <- C5.0(SOM_cluster_flag ~., data = C5a , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_1_5 )



SOM_results <- C5a %>%
  
  mutate(cluster = C5a$SOM_cluster_flag) %>%
  group_by(SOM_cluster_flag) %>%
  do(the_summary = summary(.))
SOM_results$the_summary


#CCCCCCCCCCCCC

# 11-5
C5a <- anomaly_descriptives
C5a$Cluster <- NULL
C5a$SOM_CLUSTER <- NULL
C5a$Anomaly_Score <- NULL
C5a$anom_rank <- NULL


C5a$SOM_cluster_flag <- ifelse(C5a$cluster_cat == '11 - 5', 1,0)
C5a$SOM_cluster_flag <- as.factor(as.character(C5a$SOM_cluster_flag))
C5a$cluster_cat <- NULL


ruleC5_11_5 <- C5.0(SOM_cluster_flag ~., data = C5a , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_11_5 )



SOM_results <- C5a %>%
  
  mutate(cluster = C5a$SOM_cluster_flag) %>%
  group_by(SOM_cluster_flag) %>%
  do(the_summary = summary(.))
SOM_results$the_summary

#CCCCCCCCCCCCCCCCCCCCC


# 2-5
C5a <- anomaly_descriptives
C5a$Cluster <- NULL
C5a$SOM_CLUSTER <- NULL
C5a$Anomaly_Score <- NULL
C5a$anom_rank <- NULL


C5a$SOM_cluster_flag <- ifelse(C5a$cluster_cat == '2 - 5', 1,0)
C5a$SOM_cluster_flag <- as.factor(as.character(C5a$SOM_cluster_flag))
C5a$cluster_cat <- NULL


ruleC5_2_5 <- C5.0(SOM_cluster_flag ~., data = C5a , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_2_5 )



SOM_results <- C5a %>%
  
  mutate(cluster = C5a$SOM_cluster_flag) %>%
  group_by(SOM_cluster_flag) %>%
  do(the_summary = summary(.))
SOM_results$the_summary


############ccccc

# 6-5
C5a <- anomaly_descriptives
C5a$Cluster <- NULL
C5a$SOM_CLUSTER <- NULL
C5a$Anomaly_Score <- NULL
C5a$anom_rank <- NULL


C5a$SOM_cluster_flag <- ifelse(C5a$cluster_cat == '6 - 5', 1,0)
C5a$SOM_cluster_flag <- as.factor(as.character(C5a$SOM_cluster_flag))
C5a$cluster_cat <- NULL


ruleC5_6_5 <- C5.0(SOM_cluster_flag ~., data = C5a , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_6_5 )



SOM_results <- C5a %>%
  
  mutate(cluster = C5a$SOM_cluster_flag) %>%
  group_by(SOM_cluster_flag) %>%
  do(the_summary = summary(.))
SOM_results$the_summary



#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

# cluster 5 random forest

C5a <- anomaly_descriptives

C5a$SOM_CLUSTER <- NULL
C5a$Anomaly_Score <- NULL
C5a$anom_rank <- NULL
C5a$cluster_cat <- NULL

C5a$SOM_cluster_flag <- ifelse(C5a$Cluster  == 5, 1,0)
C5a$SOM_cluster_flag <- as.factor(as.character(C5a$SOM_cluster_flag))
C5a$Cluster <- NULL

C5a_h2o <- as.h2o(C5a)
y_ccs <- "SOM_cluster_flag"
x_ccs <- setdiff(names(C5a_h2o), y_ccs)

RF <- h2o.randomForest(x=x_ccs,
                              y = y_ccs,
                              training_frame = C5a_h2o,
                              ntrees = 50,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)

RF_var_import <- h2o.varimp(RF)



