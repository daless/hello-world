# V 4 uses 50k file to generate 100 top acure with anomoly detection



setwd("~/aetna")


library(comorbidity)
library(RODBC)
library(sqldf)
#library(dplyr)
library(tidyverse)
library(dummies)
library(SOMbrero)
library(kohonen)
library(broom)




# scp analytic_data2020_0_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp FIPS_tab.txt dless1@apsrd9425:/home/dless1/aetna
# scp USDA.txt dless1@apsrd9425:/home/dless1/aetna

county_hlth  <- read.csv("analytic_data2020_0_tab.txt", header=TRUE, sep="\t")
FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


# connection: dbswp0625
# database: RacerResearch
# schema: dbo
# view: vwAetnaTradMemClaimCoverage





#conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;DATABASE=RacerResearch;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
#)
conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)

# WORKS
unkmem <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.vwAetnaTradMemClaimCoverage  p  with (nolock)",
  max=50)
str(unkmem,list.len = ncol(unkmem))

# date clean up
v1224 <- sqlQuery(
  conn,
  "SELECT v.PAT_MEMBER_NO,
v.member_id_number,
v.member_rel_code,
v.member_sex,
v.member_state,
SUBSTRING(v.member_zip_code,1,5) as zipcode,
v.PAT_DATE_OF_BIRTH,
v.member_age,
v.Pat_Date_Effective,
v.Pat_Date_Expiration,
v.cumb_id,
v.is_subscriber,
v.CLAIM_ID,
v.CLAIM_NO,
v.COVERAGE_CODE,
v.GROUP_NAME,
v.PROC_CD,
v.C_DRG,
v.ICD_DX_CD_1,
v.ICD_DX_CD_2,
v.ICD_DX_CD_3,
v.ICD_DX_CD_4,
v.ICD_DX_CD_5,
v.ICD_DX_CD_6,
v.ICD_DX_CD_7,
v.ICD_DX_CD_8,
v.ICD_DX_CD_9,
v.ICD_DX_CD_10,
v.ICD_DX_CD_11,
v.ICD_DX_CD_12,
v.DATE_OF_SERVICE_BEG,
v.DATE_OF_SERVICE_END,
v.days_of_service,
v.REVENUE_CODE,
v.Place_Of_Service,
v.Line_Of_Business,
v.CL_ELIG_EVENT,
v.CL_ELIG_COV,
v.CL_COB_TYPE,
v.CL_COB_OTHER_PAID,
v.CL_COB_CODE,
v.COB_TYPE,
v.case_1224_hit,
v.case_17_hit,
v.case_18_hit,
v.case_25_hit,
v.case_568_hit,
v.case_815_hit,
v.case_829_hit,
v.case_1227_hit,
v.case_1334_hit,
v.coveragetype,
v.coveragestatus,
v.coveragestatusreason,
v.InsCoName,
v.EffectiveDate,
v.TermDate,
v.REL_TO_INS_ID
  from RacerResearch.DBO.vwAetnaTradMemClaimCoverage  v  with (nolock)
  where DATEDIFF(D,  v.Pat_Date_Effective, GETDATE()) < 365
  and V.member_age <65",
  max=50000)


v1224 <- data.frame(id = row.names(v1224), v1224)

dx_a <- sqldf("select v.id,
v.ICD_DX_CD_1,
v.ICD_DX_CD_2,
v.ICD_DX_CD_3,
v.ICD_DX_CD_4,
v.ICD_DX_CD_5,
v.ICD_DX_CD_6,
v.ICD_DX_CD_7,
v.ICD_DX_CD_8,
v.ICD_DX_CD_9,
v.ICD_DX_CD_10,
v.ICD_DX_CD_11,
v.ICD_DX_CD_12
from v1224 v")

dx_b <- dx_a %>%
  tidyr::pivot_longer(
    cols = starts_with("ICD"),
    names_to = "DX",
    values_to = "ICD10",
    names_prefix = "ICD_DX_CD_"
  )

dx_b <-drop_na(dx_b)

dx_b$ICD10<-as.character(dx_b$ICD10)
dx_b$ICD10<-gsub(".","",dx_b$ICD10,fixed=TRUE)


elixhauser_scores <- comorbidity(x=dx_b , id = "id",  code = "ICD10", icd = "icd10", score = "elixhauser")
elixhauser <- sqldf("select id, score as elixhouser_score from elixhauser_scores")

# add external data


v1224_b <- sqldf("select v.*, f.COUNTY from FIPS f, v1224 v
                 where v.zipcode = f.zip")

v1224_b <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from USDA f, v1224_b v
                 where v.COUNTY = f.FIPS")

# #rename
names(county_hlth)[3] <- 'long_fips'
names(county_hlth)[140] <- 'physician_rate'
names(county_hlth)[152] <- 'MH_providers'
names(county_hlth)[8] <- 'premature_death'
names(county_hlth)[397] <- 'diabetes_preval'
names(county_hlth)[477] <- 'ratio_PCP_other'


county_hlth2 <- sqldf("select long_fips,
physician_rate,
                       premature_death,
                       MH_providers,
                      diabetes_preval,
                      ratio_PCP_other
                      from county_hlth
                      where long_fips !='0' ")

v1224_b <- sqldf("select v.*, 
c.physician_rate,
                       c.premature_death,
                       c.MH_providers,
                      c.diabetes_preval,
                      c.ratio_PCP_other
                      from v1224_b v, county_hlth2 c
                 where v.COUNTY = c.long_fips")


saveRDS(v1224_b, file="v1224_b1yr_50K.Rda")
#v1224_b <- readRDS(file="v1224_b1yr_50K.Rda")
saveRDS(elixhauser, file="elixhauser_50K.Rda")
#elixhauser <- readRDS(file="elixhauser_50K.Rda")

#str(county_hlth,list.len = ncol(county_hlth))


# remove county splits

v1224_c <- sqldf("select * from v1224_b group by id")

str(v1224_c,list.len = ncol(v1224_c))
# case id 1224

# 12 hits out of 10,000
case1224 <- sqldf("select * from v1224_c where case_1224_hit = 1")


# get number of claims and total paid


conn_racer = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=RACER00222;UID=COBUnixToSQL;PWD=Q438IerK@u9D'
)

# get number of claims and total paid all effective last year and claims last year
bucks_clm_cnt <- sqlQuery(
  conn_racer,
  " select 
  MEM.MEMBER_NO,
  count(CLM.CLAIM_NO) as tot_claims,
  SUM(CLM.AMT_PAID) as tot_paid
FROM dbo.CLAIM CLM
INNER JOIN dbo.MEMBER MEM
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where  DATEDIFF(D,  MEM.DATE_EFFECTIVE, GETDATE()) < 365
and DATEDIFF(D,  CLM.DATE_OF_SERVICE_END, GETDATE()) < 365
group by MEM.MEMBER_NO")

#saveRDS(bucks_clm_cnt, file="bucks_clm_cnt.Rda")
#bucks_clm_cnt <- readRDS(file="bucks_clm_cnt.Rda")

v1224_d <- sqldf("select distinct v.*, m.tot_claims, m.tot_paid
                 from v1224_b v, bucks_clm_cnt m
                 where m.MEMBER_NO = v.PAT_MEMBER_NO")
str(v1224_d,list.len = ncol(v1224_d))

v1224_e <- sqldf("select *
                 from v1224_d group by id")

v1224_e <- sqldf("select v.*, e.elixhouser_score
                 from v1224_e v, elixhauser e
                 where v.id = e.id")

#str(v1224_e,list.len = ncol(v1224_e))


# prep for SOM
# add GROUP_NAME, insurance name into supervised coveragetype,coveragestatus,coveragestatusreason,

v1224_e <- sqldf("select member_age,
is_subscriber,
COVERAGE_CODE,
elixhouser_score,
days_of_service,
REVENUE_CODE,
Place_Of_Service,

Line_Of_Business,
CL_ELIG_EVENT,
CL_ELIG_COV,
CL_COB_TYPE,
CL_COB_CODE,
COB_TYPE,
case_1224_hit,
case_17_hit,
case_18_hit,
case_25_hit,
case_568_hit,
case_815_hit,
case_829_hit,
case_1227_hit,
case_1334_hit,
REL_TO_INS_ID,
USDA_urban_rural,
physician_rate,
premature_death,
MH_providers,
diabetes_preval,
ratio_PCP_other,
tot_claims,
tot_paid
from v1224_e 
where member_age <65")


v1224_e$COVERAGE_CODE <- as.numeric(as.character(v1224_e$COVERAGE_CODE))
v1224_e$Line_Of_Business <- as.numeric(as.character(v1224_e$Line_Of_Business))

v1224_e <- v1224_e %>%
  mutate_if(is.character, ~replace(., is.na(.),'0'))
v1224_e <- v1224_e %>%
  mutate_if(is.numeric, ~replace(., is.na(.),0))
v1224_e <- v1224_e %>%
  mutate_if(is.integer, ~replace(., is.na(.),0))






eligability_event <- sqldf("select CL_ELIG_EVENT from v1224_e")
eligability_event <- cbind(eligability_event, dummy(eligability_event$CL_ELIG_EVENT , sep= "_"))
eligability_event$CL_ELIG_EVENT <- NULL

cov <- sqldf("select CL_ELIG_COV  from v1224_e")
cov <- cbind(cov, dummy(cov$CL_ELIG_COV , sep= "_"))
cov$CL_ELIG_COV <- NULL

ctype <- sqldf("select CL_COB_TYPE  from v1224_e")
ctype <- cbind(ctype, dummy(ctype$CL_COB_TYPE , sep= "_"))
ctype$CL_COB_TYPE <- NULL

COB_CODE  <- sqldf("select CL_COB_CODE  from v1224_e")
COB_CODE <- cbind(COB_CODE, dummy(COB_CODE$CL_COB_CODE , sep= "_"))
COB_CODE$CL_COB_CODE <- NULL

# Type_Of_Service  <- sqldf("select Type_Of_Service  from v1224_e")
# Type_Of_Service <- cbind(COB_CODE, dummy(Type_Of_Service$Type_Of_Service , sep= "_"))
# Type_Of_Service$Type_Of_Service <- NULL




v1224_e <- cbind(v1224_e,ctype)
v1224_e <- cbind(v1224_e,cov)
v1224_e <- cbind(v1224_e,eligability_event)
v1224_e <- cbind(v1224_e,COB_CODE)
#v1224_e <- cbind(v1224_e,Type_Of_Service)

v1224_e$physician_rate <- as.numeric(as.character(v1224_e$physician_rate))
v1224_e$premature_death <- as.numeric(as.character(v1224_e$premature_death))
v1224_e$MH_providers <- as.numeric(as.character(v1224_e$MH_providers))
v1224_e$diabetes_preval <- as.numeric(as.character(v1224_e$diabetes_preval))
v1224_e$ratio_PCP_other <- as.numeric(as.character(v1224_e$ratio_PCP_other))

v1224_e$physician_rate <- ifelse(is.na(v1224_e$physician_rate), 0, v1224_e$physician_rate)
v1224_e$premature_death <- ifelse(is.na(v1224_e$premature_death), 0, v1224_e$premature_death)
v1224_e$MH_providers <- ifelse(is.na(v1224_e$MH_providers), 0, v1224_e$MH_providers)
v1224_e$diabetes_preval <- ifelse(is.na(v1224_e$diabetes_preval), 0, v1224_e$diabetes_preval)
v1224_e$ratio_PCP_other <- ifelse(is.na(v1224_e$ratio_PCP_other), 0, v1224_e$ratio_PCP_other)

v1224_e$CL_ELIG_EVENT <- NULL
v1224_e$CL_ELIG_COV <- NULL
v1224_e$CL_COB_TYPE <- NULL
v1224_e$CL_COB_CODE <- NULL
v1224_e$is_subscriber <- NULL
v1224_e$Type_Of_Service <- NULL
v1224_e$InsCoName <- NULL
v1224_e$EffectiveDate <- NULL
v1224_e$TermDate <- NULL

colnames(v1224_e)[colSums(is.na(v1224_e)) > 0]

targets <- v1224_e

v1224_e$case_1224_hit <- NULL
v1224_e$case_17_hit <- NULL
v1224_e$case_18_hit <- NULL
v1224_e$case_25_hit <- NULL
v1224_e$case_568_hit <- NULL
v1224_e$case_815_hit <- NULL
v1224_e$case_829_hit <- NULL
v1224_e$case_1227_hit <- NULL
v1224_e$case_1334_hit <- NULL

#str(v1224_e,list.len = ncol(v1224_e))

saveRDS(v1224_e, file="v1224_e_50K.Rda")
saveRDS(targets, file="targets_50K.Rda")

#v1224_e <- readRDS(file="v1224_e_50K.Rda")
#targets_50K <- readRDS(file="targets_50K.Rda")


# scale all numeric
v1224_f <- v1224_e %>% mutate_if(is.numeric, scale)


som2 <- trainSOM(x.data = v1224_f, dimension = c(8,9), nb.save = 10, maxit = 500,
                 scaling = "none")

#plot(som2, what = "obs", type = "hitmap")

table(som2$clustering)
#plot(som2, what = "obs", type = "hitmap")


out_grid <- som2$parameters$the.grid$coord
out_grid$sc <- som2$clustering

out_dist <- as.data.frame(protoDist(som2))

som_clusters_super <- superClass(som2, k=5)
summary(som_clusters_super)
table(som_clusters_super$cluster)

som_dist <- as.data.frame(som_clusters_super$som$prototypes)
som_diste <- as.data.frame(som_clusters_super$som$clustering)  ## cluster membership of SOM
som_dist <- as.data.frame(scale(som_dist))
som_dist <- data.frame(r_index = row.names(som_dist), som_dist)

# save SOM output
saveRDS(som_diste, file="tsom_diste_50K.Rda")



targ <- sqldf("select case_1224_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_1224_hit <- as.factor(as.character(targ$case_1224_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_1224_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_1224_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_1224_hit==0,0,1)
micro_cluster2$case_1224_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")

# cross tabs
# table 1 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_58)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_57)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_1)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_64)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_47)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_69)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_4)
table8


# library(psych)
# 
# v1224_e <- cbind(v1224_e, micro_cluster2$hits)
# 
# v1224_e$hits <- as.factor(as.character(v1224_e$hits))
# 
# view_descriptives <- as.data.frame(describeBy(v1224_e,
#                                               group = list(v1224_e$hits),
#                                                mat=TRUE))


summary(v1224_e)


library(C50)

C5_v1224_e <- v1224_e
C5_v1224_e <- cbind(micro_cluster2$micro_cluster_1,C5_v1224_e )
C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_1'


ruleC5 <- C5.0(micro_cluster_1 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_1 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )

#write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)



#case_17_hit


targ <- sqldf("select case_17_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_17_hit <- as.factor(as.character(targ$case_17_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_17_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_17_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_17_hit==0,0,1)
micro_cluster2$case_17_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# 64 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_64)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_14)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_43)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_37)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_44)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_1)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_52)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_17_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_64,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_64'


ruleC5 <- C5.0(micro_cluster_64 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_64 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )

#write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)





#case_18_hit


targ <- sqldf("select case_18_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_18_hit <- as.factor(as.character(targ$case_18_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_18_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_18_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_18_hit==0,0,1)
micro_cluster2$case_18_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# 64 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_9)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_64)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_21)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_1)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_28)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_38)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_5)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_18_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_64,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_64'


ruleC5 <- C5.0(micro_cluster_64 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_64 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )

#write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)


# case_25_hit

targ <- sqldf("select case_25_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_25_hit <- as.factor(as.character(targ$case_25_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_25_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_25_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_25_hit==0,0,1)
micro_cluster2$case_25_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# 30 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_30)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_21)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_60)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_1)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_64)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_29)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_41)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_18)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_30_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_30,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_30'


ruleC5 <- C5.0(micro_cluster_30 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_30 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )

#write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)



# case_568_hit


targ <- sqldf("select case_568_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_568_hit <- as.factor(as.character(targ$case_568_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_568_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_568_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_568_hit==0,0,1)
micro_cluster2$case_568_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# 43 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_43)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_44)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_3)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_52)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_65)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_4)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_2)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_43_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_43,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_43'


ruleC5 <- C5.0(micro_cluster_43 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_43 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )

#write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)





#case_815_hit === all = 0



targ <- sqldf("select case_815_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_815_hit <- as.factor(as.character(targ$case_815_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_815_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_815_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_815_hit==0,0,1)
micro_cluster2$case_815_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# 43 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_43)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_44)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_3)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_52)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_65)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_4)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_2)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_43_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_43,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_43'


ruleC5 <- C5.0(micro_cluster_43 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_43 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )

#write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)


# case_829_hit



targ <- sqldf("select case_829_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_829_hit <- as.factor(as.character(targ$case_829_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_829_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_829_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_829_hit==0,0,1)
micro_cluster2$case_829_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# 1 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_1)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_5)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_3)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_64)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_19)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_9)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_68)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_1_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_1,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_1'


ruleC5 <- C5.0(micro_cluster_1 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_1 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )

#write(capture.output(summary(ruleC5)),"C5_by_cluster_outpt_full.txt", append=TRUE)




#@ case_1227_hit all 0s


targ <- sqldf("select case_1227_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_1227_hit <- as.factor(as.character(targ$case_1227_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_1227_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_1227_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_1227_hit==0,0,1)
micro_cluster2$case_1227_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# all 0s

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_1)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_5)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_3)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_64)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_19)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_9)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_68)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_1_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_1,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_1'


ruleC5 <- C5.0(micro_cluster_1 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_1 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )





#@ case_1334_hit 


targ <- sqldf("select case_1334_hit from  targets")
targ <- cbind(targ,som_diste)

# #rename
names(targ)[2] <- 'SOM_CLUSTER'
targ$case_1334_hit <- as.factor(as.character(targ$case_1334_hit))
targ$SOM_CLUSTER  <- as.factor(as.character(targ$SOM_CLUSTER))

micro_cluster  <- sqldf("select SOM_CLUSTER  from targ")
micro_cluster <- cbind(micro_cluster, dummy(micro_cluster$SOM_CLUSTER , sep= "_"))
micro_cluster$SOM_CLUSTER <- NULL

col_names <- names(micro_cluster)
micro_cluster[,col_names] <- lapply(micro_cluster[,col_names], factor)
micro_cluster2 <- cbind(targ$case_1334_hit, micro_cluster)
names(micro_cluster2)[1] <- 'case_1334_hit'
micro_cluster2$hits<-ifelse(micro_cluster2$case_1334_hit==0,0,1)
micro_cluster2$case_1334_hit <- NULL

chi_results <- lapply(micro_cluster2[-length(micro_cluster2)],
                      function(x) chisq.test(table(x, micro_cluster2$hits)))

chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )
#
# get clusters with chi p < 0.05

chi_results2 <- cbind(SOM_CLUSTER = rownames(chi_results2), chi_results2)


SOM_sig_clusters <- sqldf("select SOM_CLUSTER, chi_results2 as p 
                          from chi_results2 where chi_results2 < 0.05
                          order by chi_results2 asc")


# 72 best

table1 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_72)
table1
table2 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_1)
table2
table3 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_40)
table3
table4 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_64)
table4
table5 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_5)
table5
table6 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_63)
table6
table7 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_28)
table7
table8 <- table(micro_cluster2$hits, micro_cluster2$micro_cluster_14)
table8






# # C5 rule
# ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, winnow = TRUE, bands = 5)
# #sink('treeC5_tree_boost.txt')
# summary(ruleC5_boost )
# sink()
# 
# predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
# table(predict_rulec5_boost,test_auto_ml$target )
# summary(predict_rulec5_boost)




#library(C50)

targ <- sqldf("select case_1334_hit from  targets")
targ <- cbind(targ,som_diste)

#str(v1224_e,list.len = ncol(v1224_e))

C5_v1224_e <- v1224_e

C5_v1224_e <- cbind(micro_cluster2$micro_cluster_1,C5_v1224_e )
#C5_v1224_e$case_1224_hit <- NULL

names(C5_v1224_e)[1] <- 'micro_cluster_72'


ruleC5 <- C5.0(micro_cluster_72 ~., data = C5_v1224_e , rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5 )

ruleC5_boost <- C5.0(micro_cluster_72 ~., data = C5_v1224_e , 
                     trials = 5, rules = TRUE, winnow = TRUE, bands = 5)
summary(ruleC5_boost )




#ooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo

# create output test file


v1224_b <- readRDS(file="v1224_b1yr_50K.Rda")
elixhauser <- readRDS(file="elixhauser_50K.Rda")
bucks_clm_cnt <- readRDS(file="bucks_clm_cnt.Rda")


v1224_c <- sqldf("select * from v1224_b group by id")

v1224_d <- sqldf("select distinct v.*, m.tot_claims, m.tot_paid
                 from v1224_b v, bucks_clm_cnt m
                 where m.MEMBER_NO = v.PAT_MEMBER_NO")
str(v1224_d,list.len = ncol(v1224_d))

v1224_e <- sqldf("select *
                 from v1224_d group by id")

v1224_e <- sqldf("select v.*, e.elixhouser_score
                 from v1224_e v, elixhauser e
                 where v.id = e.id")


str(v1224_e,list.len = ncol(v1224_e))

# high cost high acuity

test_file1 <- sqldf("select distinct PAT_MEMBER_NO,
 member_id_number,
 tot_claims,
 tot_paid,
 elixhouser_score from v1224_e
                    where  tot_claims > 30
                    and elixhouser_score >=2
                    group by  member_id_number ")

write.table(test_file1, file = "test_file1.csv",
            row.names = FALSE, sep ="\t")

#scp dless1@apsrd9425:/home/dless1/aetna/test_file1.csv /H/My_Doccuments


#and p.post_OPTUM_LEAKAGE_FLAG='1'





dbswp0625.RACERRESEARCH.dbo.vwAetnaMembersUnique