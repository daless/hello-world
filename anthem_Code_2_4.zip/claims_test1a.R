


library(RODBC)
#conn = odbcDriverConnect(
#  'DRIVER={ODBCSQLSvr};SERVER=dbswp0628.aimhealth.com;DATABASE=RACER01044;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
#)


#works
conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0624.aimhealth.com;DATABASE=RACER00946;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)



library(sqldf)
library(dplyr)



member_claim_inv_test  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 65
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  order by CLM.PATIENT_ID desc",
  max = 100
)



# WHERE CS.HDS_LOB_ID = 2 # COB cases
# AND CD.SUBCATEGORY = 10 #  Medicare cases
# AND CS.STATUS_CODE IN (1,50) # Closed cases
# AND CLM.FEED_ID = 65 #####################   May Inventory Only   >>>>>>>>>>>>>>>>>>>>>  change
# MEMBER_ID=3584398
# AND CLM.PROJECT_ID = 946



Inventory_HITS_test <- sqlQuery(
  conn,
  " SELECT
  b.CLAIM_ID,
  b.CASE_ID, b.HDS_LOB_ID, b.STATUS_CODE, c.SUBCATEGORY, c.NAME, b.DATE_UPDATED
  FROM
  dbo.CLAIM_STATUS b
  LEFT OUTER JOIN
  dbo.Case_data c ON
  b.CASE_ID=c.CASE_ID
 AND b.HDS_LOB_ID = 2
  AND c.SUBCATEGORY = 10
 AND b.STATUS_CODE IN (0,-1) 
  ", max=100
)


# LOS
member_claim_inv_test$Days_of_service <- difftime(member_claim_inv_test$DATE_OF_SERVICE_END , 
                                                  member_claim_inv_test$DATE_OF_SERVICE_BEG,
                                                  units = c("days")) 

# removes 0 days of service
# look at CCS of long LOS to confirm not OB/GYN
member_claim_inv_test$Days_of_service <- member_claim_inv_test$Days_of_service + 1
# remove decimals from princiapl dx code
member_claim_inv_test$Principal_Dx <- as.character(member_claim_inv_test$Principal_Dx)
member_claim_inv_test[] <- lapply(member_claim_inv_test, function(x) sub("[.]","",x))



