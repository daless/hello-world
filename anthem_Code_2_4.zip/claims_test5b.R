
# V2 uses feed i1 69-73 which is march '17 - july '17
# testing with 100 records from each feed
# V 4 code target logic
#V5 final exclusions , case id exclusions
# 5b using 3 months of data



setwd("~/anthem")

library(RODBC)
#conn = odbcDriverConnect(
#  'DRIVER={ODBCSQLSvr};SERVER=dbswp0628.aimhealth.com;DATABASE=RACER01044;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
#)


#works
conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0624.aimhealth.com;DATABASE=RACER00946;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)



library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(tcltk)
#library(smbinning)
library(DMwR)
library(randomForest)
library(data.table)
library(discretization)
library(ggplot2)
library(dataMaid)
library(e1071)
library(C50)
library(lubridate)
library(h2o)
h2o.init()

# table listing in db
#table_listing <- as.data.frame(sqlTables(conn))






member_claim_inv_test <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.PRODUCT_LINE_ID,
  CLM.LINE_OF_BUSINESS_ID,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  CLM.PROVIDER_ID,
  SF.FIELD19,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  INNER JOIN dbo.SPECIAL_FIELDS SF
  ON CLM.CLAIM_ID = SF.ID
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (0,-1)
  AND CLM.FEED_ID IN (71,72,73)
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  AND CS.CASE_ID NOT IN (29, 628, 713, 815, 829, 1224, 1011, 1338)
  order by CLM.PATIENT_ID desc"
)



#  

# WHERE CS.HDS_LOB_ID = 2 # COB cases
# AND CD.SUBCATEGORY = 10 #  Medicare cases
# AND CS.STATUS_CODE IN (1,50) # Closed cases
# AND CLM.FEED_ID = 65 #####################   May Inventory Only   >>>>>>>>>>>>>>>>>>>>>  change
# MEMBER_ID=3584398
# AND CLM.PROJECT_ID = 946

claim_line <- sqlColumns(
  conn, "dbo.CLAIM_LINE"  )

MemberCoverage<- sqlColumns(
  conn, "dbo.MemberCoverage"  )

MemberCoverageHistory<- sqlColumns(
  conn, "dbo.MemberCoverageHistory"  )
Member<- sqlColumns(
  conn, "dbo.Member"  )

MemberStatus<- sqlColumns(
  conn, "dbo.MemberStatus"  )

ICD9 <- sqlColumns(
  conn, "dbo.ICD9"  )

junk<- sqlColumns(
  conn, "FEED"  )





# 
# member_list <- sqlQuery(
#   conn,
#   " select c.MemberCoverageID, c.MemberID, c.EffectiveDate,
#   c.TermDate, h.CoverageStatusID, c.DateUpdated
#   from dbo.MemberCoverage as c, dbo.MemberCoverageHistory as h
#   where c.MemberCoverageID = h.MemberCoverageID
#   and h.CoverageStatusID IN (3,4,7)
# order by c.MemberID
#   "
# )

member_list <- sqlQuery(
  conn,
  " select DISTINCT cm.MemberCoverageID, cm.MemberID, cm.EffectiveDate,
  cm.TermDate, hx.CoverageStatusID, cm.DateUpdated
  from dbo.MemberCoverage cm, dbo.MEMBER m, dbo.MemberCoverageHistory hx,
  dbo.CLAIM CLM, dbo.CLAIM_STATUS CS, dbo.CASE_DATA CD,
  dbo.STATUS_CODE SC
  where cm.MemberCoverageID = hx.MemberCoverageID
  and CLM.PATIENT_ID = m.MEMBER_ID
  and CLM.PATIENT_ID = cm.MemberID
  and CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  AND CS.CASE_ID = CD.CASE_ID
  AND CS.STATUS_CODE = SC.STATUS_CODE
  AND CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (0,-1)
  AND CLM.FEED_ID IN (71,72,73)
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  AND  hx.CoverageStatusID IN (3,4,7)
  order by cm.MemberID, cm.EffectiveDate desc
  "
)

feed <- sqlQuery(
  conn, "SELECT * from FEED where  PROJECT_ID = 946 and FEED_ID IN (71,72,73)")



dep <- sqldf("select * from  member_list where CoverageStatusID = 3")
dep$DateUpdated <- (as.Date(dep$DateUpdated))


last_date <- (as.Date((max(feed$DATE_UPDATED))))
first_date <- (as.Date(min(feed$DATE_UPDATED)))
feed <- seq(first_date, last_date , by="days")
dep <- subset(dep,DateUpdated %in% feed )
dep <- sqldf("select distinct MemberID as MemberIDx from dep")



member_final <- sqldf("select distinct MemberID as MemberIDx from member_list ")

# join member list to claims

member_claim_inv_test <- sqldf("SELECT c.* from member_claim_inv_test c,
             member_final m  where c.member_ID = m.MemberIDx")




# group number exclusions
excl_grp<-  sqlQuery(
  conn, "select distinct Exclusion from ExclusionsGroupNumber where ProjectID  = 946" )

member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_grp e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

# provider exclusions

excl_p<-  sqlQuery(
  conn, "select distinct Exclusion from ExclusionsProviderNumber where ProjectID  = 946" )
member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_p e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

# special field exclusion
excl_s<-  sqlQuery(
  conn, "select DISTINCT Exclusion from ExclusionsSpecialFields where ProjectID  = 946" )
member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_s e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

# product line exclusions
excl_i<-  sqlQuery(
  conn, "select DISTINCT Exclusion from ExclusionsProductLine where ProjectID  = 946" )
member_claim_inv_test  <- sqldf("SELECT DISTINCT c.*, e.Exclusion from member_claim_inv_test c
                                left join excl_i e on c.INS_GROUP_ID = e.Exclusion")

member_claim_inv_test <- member_claim_inv_test[is.na(member_claim_inv_test$Exclusion),]
member_claim_inv_test$Exclusion <- NULL

rm(excl_grp,excl_p,excl_s, excl_i )




#rm(member_list)
# DX codes

DX_test  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE DX.FEED_ID IN (71,72,73)
  AND CLM.PROJECT_ID = 946
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc"
)

clm_id <- sqldf("select distinct CLAIM_ID from  member_claim_inv_test")

DX_test  <- sqldf("SELECT DISTINCT d.* from DX_test d INNER JOIN clm_id as m 
                  ON d.CLAIM_ID =m.CLAIM_ID")



# LOS
member_claim_inv_test$Days_of_service <- difftime(member_claim_inv_test$DATE_OF_SERVICE_END , 
                                                  member_claim_inv_test$DATE_OF_SERVICE_BEG,
                                                  units = c("days")) 

# removes 0 days of service
# remove positive skew of LOS
member_claim_inv_test$Days_of_service <- round(sqrt(as.integer(member_claim_inv_test$Days_of_service + 1)))
# remove decimals from princiapl dx code
member_claim_inv_test$Principal_Dx <- as.character(member_claim_inv_test$Principal_Dx)
member_claim_inv_test$Principal_Dx <- gsub(".","",member_claim_inv_test$Principal_Dx, fixed = TRUE)

# change bill type code NA to 0
member_claim_inv_test$BILL_TYPE <- ifelse(is.na(member_claim_inv_test$BILL_TYPE), 0, member_claim_inv_test$BILL_TYPE)
member_claim_inv_test$BILL_TYPE <- as.factor(member_claim_inv_test$BILL_TYPE)

# place of service
member_claim_inv_test$PLACE_OF_SERVICE<- ifelse(is.na(member_claim_inv_test$PLACE_OF_SERVICE), 0, 
                                                member_claim_inv_test$PLACE_OF_SERVICE)
member_claim_inv_test$PLACE_OF_SERVICE<- as.factor(member_claim_inv_test$PLACE_OF_SERVICE)

#### EXPORT CSV member_claim_inv_test here
write.table(member_claim_inv_test, file = "member_claim_inv_test_3mo.csv",
          row.names = FALSE, sep ="\t")

write.table(DX_test, file = "DX_test_3mo.csv",
            row.names = FALSE, sep ="\t")





# remove decimals from diagnosis codes
DX_test$ICD9_CODE <- as.character(DX_test$ICD9_CODE)
DX_test$ICD9_CODE <- gsub(".","",DX_test$ICD9_CODE, fixed = TRUE)


# comorbidity where ICD9_TYPE = 'DIAG10'
DX__diag_test <- sqldf("select distinct * from DX_test where ICD9_TYPE = 'DIAG10' order by CLAIM_ID, ICD9_CODE  ")
charlson_scores <- comorbidity(x=DX__diag_test, id = "CLAIM_ID",  code = "ICD9_CODE", score = "charlson_icd10")

write.table(charlson_scores, file = "charlson_scores_3mo.csv",
            row.names = FALSE, sep ="\t")

elixhauser_scores <- comorbidity(x=DX__diag_test, id = "CLAIM_ID", code = "ICD9_CODE", score = "elixhauser_icd10")

write.table(elixhauser_scores, file = "elixhauser_scores_3mo.csv",
            row.names = FALSE, sep ="\t")

#  CCS DX
CCS_lookup <- read.csv("ccs_dx_icd10cm_2018_1.csv", sep = ",",  quote = "\"", header = TRUE)
# rename columns
CCS_lookup$ICD9_CODE <- CCS_lookup$X.ICD.10.CM.CODE.
CCS_lookup$CCS_DX <- CCS_lookup$X.CCS.CATEGORY.
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))

# build CCS dx table
CCS_Codes_test <- sqldf("select DISTINCT d.CLAIM_ID, d.ICD9_CODE, d.ORDER_IN_CLAIM, c.CCS_DX
                        from DX_test d left join CCS_lookup c on d.ICD9_CODE = c.ICD9_CODE
                        order by d.CLAIM_ID , d.ORDER_IN_CLAIM")
CCS_Codes_test$CCS_DX <- ifelse(is.na(CCS_Codes_test$CCS_DX), 0, CCS_Codes_test$CCS_DX)

CCS_Codes_test$CCS_DX <-as.factor(CCS_Codes_test$CCS_DX)


# make dummies, transpose then 1 record per client id
CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_DX from CCS_Codes_test order by CLAIM_ID")

CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_DX , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test", "CCS_",  colnames(CCS_Dummy_test)))
# group by client id
CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy3_test <- lapply(CCS_Dummy3_test, factor)
CCS_Dummy3_test <- as.data.frame(CCS_Dummy3_test)
CCS_Dummy3_test$CLAIM_ID <- as.numeric(as.character(CCS_Dummy3_test$CLAIM_ID))
CCS_Dummy3_test$CCS__0 <- NULL

#str(CCS_Dummy3_test, list.len=ncol(CCS_Dummy3_test))
#rm(CCS_Dummy2_test,CCS_Dummy_test,CCS_Codes_test )




# CCS procedures
CCS_lookup_procedure <- read.csv("pc_icd10pcs_2018.csv", sep = ",",  quote = "\"", header = TRUE)
#str(CCS_lookup_procedure)
# rename procedure code
CCS_lookup_procedure$Procedure_Code <- CCS_lookup_procedure$X.ICD.10.CM.CODE.
CCS_lookup_procedure$Procedure_CCS <- CCS_lookup_procedure$X.PROCEDURE.CLASS.

# have to run twice to remove left and right apostrophies
CCS_lookup_procedure[] <- lapply(CCS_lookup_procedure, function(x) sub("[']","",x))
CCS_lookup_procedure[] <- lapply(CCS_lookup_procedure, function(x) sub("[']","",x))


# map DX codes to CCS
DX_proc_test <- sqldf("select * from DX_test where ICD9_TYPE = 'PROC10' order by CLAIM_ID, ICD9_CODE  ")


# build CCS proc table
Proc_CCS_test <- sqldf("select DISTINCT d.CLAIM_ID, d.ICD9_CODE, d.ORDER_IN_CLAIM, c.Procedure_CCS
                        from DX_proc_test d left join CCS_lookup_procedure c on d.ICD9_CODE = c.Procedure_Code
                        order by d.CLAIM_ID , d.ORDER_IN_CLAIM")
Proc_CCS_test$Procedure_CCS <- ifelse(is.na(Proc_CCS_test$Procedure_CCS), 0, Proc_CCS_test$Procedure_CCS)

Proc_CCS_test$Procedure_CCS <-as.factor(Proc_CCS_test$Procedure_CCS)
Proc_CCS_test<- as.data.frame(Proc_CCS_test )


# make dummies, transpose then 1 record per client id
CCS_Proc_Dummy_test <- sqldf("select CLAIM_ID, Procedure_CCS from Proc_CCS_test order by CLAIM_ID")

CCS_Proc_Dummy_test <- cbind(CCS_Proc_Dummy_test, dummy(CCS_Proc_Dummy_test$Procedure_CCS , sep= "_"))
# replace with CCS
colnames(CCS_Proc_Dummy_test) <- (gsub("Procedure_CCS", "CCS_Proc_",  colnames(CCS_Proc_Dummy_test)))
# group by client id
CCS_Proc_Dummy2_test <- CCS_Proc_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

#temporaty id to character
CCS_Proc_Dummy2_test$CLAIM_ID <- as.character(CCS_Proc_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Proc_Dummy3_test <- CCS_Proc_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)
CCS_Proc_Dummy3_test <- lapply(CCS_Proc_Dummy3_test, factor) 
CCS_Proc_Dummy3_test <- as.data.frame(CCS_Proc_Dummy3_test)
CCS_Proc_Dummy3_test$CLAIM_ID <- as.numeric(as.character(CCS_Proc_Dummy3_test$CLAIM_ID))

#str(CCS_Proc_Dummy3_test, list.len=ncol(CCS_Proc_Dummy3_test))
#rm(CCS_Proc_Dummy2_test, CCS_Proc_Dummy_test, Proc_CCS_test, DX_test)




# POS
POS <- sqldf("select DISTINCT CLAIM_ID, PLACE_OF_SERVICE as POS from member_claim_inv_test")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS2 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS2$CLAIM_ID <- as.character(POS2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS3 <- POS2 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS3 <- lapply(POS3, factor) 
POS3 <- as.data.frame(POS3)
POS3$CLAIM_ID <- as.numeric(as.character((POS3$CLAIM_ID)))
POS3$POS <- NULL

#str(POS3, list.len=ncol(POS3))
#rm(POS2, POS)



# DX codes for nephrology related codes and ALS
# from nccd cdc data
icd_10 <- c("A1811",	"A5275",	"B520",	"C641",	"C642",	"C649",	"C689",	"D4100",	"D4101",
            "D4102",	"D4110",	"D4111",	"D4112",	"D4120",	"D4121",	"D4122",	"D593",	
            "E0821",	"E0822",	"E0829",	"E0921",	"E0922",	"E1065",	"E1121",	"E1122",
            "E1129",	"E1165",	"E11321",	"E113211",	"E113212",	"E113213",	"E113219",
            "E748",	"I120",	"I129",	"I130",	"I1311",	"I132",	"K767",	"M1030",	"M1031",
            "M3214",	"M3215",	"N131",	"N131",	"N132",	"N1330",	"N1339",	"N150",	"N158",
            "N159",	"N16",	"N181",	"N182",	"N183",	"N184",	"N185",	"N188",	"N189",	"N19",
            "N261",	"N269",	"O10411",	"O10412",	"O10413",	"O10419",	"O9089",	"Q6102",	"R944",
            "N010",	"N011",	"N012",	"N013",	"N014",	"N015",	"N016",	"N017",	"N018",	"N019",	
            "N020",	"N021",	"N022",	"N023",	"N024",	"N025",	"N026",	"N027",	"N028",	"N029",	
            "N030",	"N031",	"N032",	"N033",	"N034",	"N035",	"N036",	"N037",	"N038",	"N039",	
            "N040",	"N041",	"N042",	"N043",	"N044",	"N045",	"N046",	"N047",	"N048",	"N049",	
            "N050",	"N051",	"N052",	"N053",	"N054",	"N055",	"N056",	"N057",	"N058",	"N059",	
            "N060",	"N061",	"N062",	"N063",	"N064",	"N065",	"N066",	"N067",	"N068",	"N069",
            "N070",	"N071",	"N072",	"N073",	"N074",	"N075",	"N076",	"N077",	"N078",	"N079",
            "N08",	"D3000",	"D3001",	"D3002",	"D3010",	"D3011",	"D3012",	"D3020",	
            "D3021",	"D3022",	"D303",	"D304",	"D308",	"D309",	"N140",	"N141",	"N142",
            "N143",	"N144",	"N170",	"N171",	"N172",	"N178",	"N179",	"N250",	"N251",	"N2581",
            "N2589",	"N259",	"O1200",	"O1201",	"O1202",	"O1203",	"O1204",	"O1205",
            "O1210",	"O1211",	"O1212",	"O1213",	"O1214",	"O1215",	"O1220",	"O1221",
            "O1222",	"O1223",	"O1224",	"O1225",	"O26831",	"O26832",	"O26833",	"O26839",
            "Q6111",	"Q6119",	"Q612",	"Q613",	"Q614",	"Q615",	"Q618",	"Q260",	"Q261",	"Q262",
            "Q263",	"E1322",	"E1329",	"E1021",	"E1022",	"G1221")
ICD9_CODE_neph <- data.frame(icd_10)
icd_neph <- ICD9_CODE_neph

neph_test <- sqldf("select DISTINCT d.CLAIM_ID, d.ICD9_CODE, d.ORDER_IN_CLAIM, c.icd_10 as ICD9_CODE_neph
                        from DX_test d left join icd_neph c on d.ICD9_CODE = c.icd_10
                        order by d.CLAIM_ID , d.ORDER_IN_CLAIM")
neph_test$ICD9_CODE_neph[is.na(neph_test$ICD9_CODE_neph )] <- 0
neph_test$ICD9_CODE_neph <- ifelse(neph_test$ICD9_CODE_neph == 0,0,1)
neph_test$ICD9_CODE_neph <- as.numeric(neph_test$ICD9_CODE_neph)
neph_test <- sqldf("select DISTINCT CLAIM_ID, ICD9_CODE_neph from neph_test")


# group by client id
neph_test2 <- neph_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
neph_test2$CLAIM_ID <- as.character(neph_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
neph_test3 <- neph_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)
neph_test3 <- lapply(neph_test3, factor) 
neph_test3 <- as.data.frame(neph_test3)
neph_test3$CLAIM_ID <- as.numeric(as.character(neph_test3$CLAIM_ID))

rm(icd_10, ICD9_CODE_neph, icd_neph, neph_test, neph_test2)
table(neph_test3$ICD9_CODE_neph)




# create study table of single record per encounter
# this will be post adjudication

member_claim_inv_test <- member_claim_inv_test [order(member_claim_inv_test$CLAIM_ID), ]


##############################
# build study table at the encounter - claim level
# with real data confirm no missing comorbidity or dx  CCS codes

base_table1 <- sqldf("SELECT DISTINCT CLAIM_ID, FEED_ID, PATIENT_AGE, PATIENT_GENDER, BILL_TYPE,
                     member_ID,  
                     sqrt(AMT_ALLOWED / AMT_PAID) as ratio_allowed_to_paid ,
                     Days_of_service from member_claim_inv_test")

# add comorbidities
base_table2 <- sqldf("SELECT DISTINCT b.*, c.wscore as Charlson_score from base_table1 b left join charlson_scores c
                     on b.CLAIM_ID = c.CLAIM_ID")

base_table2 <- sqldf("SELECT DISTINCT b.*, c.wscore as Elixhauser_score from base_table2 b left join elixhauser_scores c
                     on b.CLAIM_ID = c.CLAIM_ID")


base_table2$Charlson_score <-  ifelse(is.na(base_table2$Charlson_score),1,base_table2$Charlson_score)
base_table2$Elixhauser_score <-  ifelse(is.na(base_table2$Elixhauser_score),1,base_table2$Elixhauser_score)
base_table2$CLAIM_ID <- as.numeric(base_table2$CLAIM_ID )

str(base_table2, list.len=ncol(base_table2))

# CCS dx
CCS_Dummy3_test$CLAIM_IDx <- CCS_Dummy3_test$CLAIM_ID
CCS_Dummy3_test$CLAIM_ID <- NULL
str(CCS_Dummy3_test, list.len=ncol(CCS_Dummy3_test))
base_table3 <- sqldf("SELECT DISTINCT b.*, c.* from base_table2 b left join CCS_Dummy3_test c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table3$CLAIM_IDx <- NULL
CCS_Dummy3_test$CLAIM_ID <- CCS_Dummy3_test$CLAIM_IDx
CCS_Dummy3_test$CLAIM_IDx <- NULL
str(base_table3, list.len=ncol(base_table3))



# CCS proc
# CCS_Proc_Dummy3_test$CLAIM_IDx <- CCS_Proc_Dummy3_test$CLAIM_ID
# CCS_Proc_Dummy3_test$CLAIM_ID <- NULL
# 
# 
# base_table4 <- sqldf("SELECT DISTINCT b.*, c.* from base_table3 b left join CCS_Proc_Dummy3_test c
#                      on b.CLAIM_ID = c.CLAIM_IDx")
# 
# 
# 
# #str(CCS_Proc_Dummy3_test, list.len=ncol(CCS_Proc_Dummy3_test))
# base_table4$CLAIM_IDx <- NULL
# CCS_Proc_Dummy3_test$CLAIM_ID <- CCS_Proc_Dummy3_test$CLAIM_IDx
# CCS_Proc_Dummy3_test$CLAIM_IDx  <- NULL
#str(base_table4, list.len=ncol(base_table4))

# POS -- v3 not using procedure code grouper
POS3$CLAIM_IDx <- POS3$CLAIM_ID
POS3$CLAIM_ID <- NULL
base_table5 <- sqldf("SELECT DISTINCT b.*, c.* from base_table3 b left join POS3 c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table5$CLAIM_IDx <- NULL
POS3$CLAIM_ID <- POS3$CLAIM_IDx

base_table5[is.na(base_table5)] <- 0
#str(base_table5, list.len=ncol(base_table5))



# neph als dx for targets for ccs feature extraction
neph_test3$CLAIM_IDx <- neph_test3$CLAIM_ID
neph_test3$CLAIM_ID <- NULL
base_table6 <- sqldf("SELECT DISTINCT b.*, c.* from base_table5 b left join neph_test3 c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table6$CLAIM_IDx <- NULL
base_table6$target_neph <- as.factor(base_table6$ICD9_CODE_neph)
base_table6$target_neph <- as.factor(base_table6$target_neph)
# replace NA with 0
base_table6$target_neph[is.na(base_table6$target_neph )] <- 0
base_table6$ICD9_CODE_neph <- NULL
table(base_table6$target_neph)
prop.table(table(base_table6$target_neph))

# target from meber file with CoverageStatusID  = 3
#dep <- sqldf("select distinct MemberID as MemberIDx from dep")
base_table6 <- sqldf ("SELECT DISTINCT b.*, dep.MemberIDx from base_table6 b
left join dep ON b.member_ID = dep.MemberIDx")
base_table6$target<- as.factor(ifelse(!is.na(base_table6$MemberIDx),1,0))



#str(base_table6, list.len=ncol(base_table6))
# feture reduction - CCS
base_table6$CCS__99 <- NULL
base_table6$CCS__158 <- NULL
base_table6$CCS__81 <- NULL 
base_table6$CCS__NA <- NULL
base_table6$CCS__157 <- NULL
base_table6$CCS__0 <- NULL
base_table6$MemberIDx  <- NULL
# for testing of dummy target remove CCS that are in target
str(base_table6, list.len=ncol(base_table6))

idx <- sample(seq(1,2), size = nrow(base_table6), replace = TRUE, prob = c(0.6, 0.4))
train <- base_table6[idx == 1,]
test <- base_table6[idx == 2,]



# SMOTE

#ncols <- ncol(train)
#train <- cbind(train[2:ncols], train[1])


prop.table(table(base_table6$target))


table(train$target)
prop.table(table(train$target))





# find ratio of 0 to 1 and use that as a starting point for over

# dived controls by cases to get ratio and tweak numbers to get close to 50/50
train_SMOTE <- SMOTE(target ~ . , train, k=5, perc.over = 1600,
                                 perc.under = 106)
ncols <- ncol(train_SMOTE)
train_SMOTE<- cbind(train_SMOTE[ncols],train_SMOTE[1:ncols-1])
table(train_SMOTE$target)

prop.table(table(train_SMOTE$target))

# same number but lowers controls by a bunch
# train_SMOTE <- SMOTE(target ~ . , train, k=5, perc.over = 100,
#                      perc.under = 200)
# table(train_SMOTE$target)
# table(train_SMOTE$target)
# prop.table(table(train_SMOTE$target))


# random forest for CCS list reduction
str(train, list.len=ncol(train))
train %>% select(CLAIM_ID:POS_99, target)
str(train, list.len=ncol(train))


CCS_list <- train_SMOTE %>% dplyr:: select (starts_with("CCS__"))
t_var <- sqldf("select target_neph from train_SMOTE")
CCS_list2 <- cbind(t_var,CCS_list)

# feature reduction using random forest
# take top 15 based upon gini index

# change target to target_neph 
CCS_list3 <- randomForest(target_neph ~. , data = CCS_list2, importance=T, ntree=500, nfolds = 5 )
varImpPlot(CCS_list3, sort = T, main = "Variable Importance", n.var = 15)
CCS_list3_import <- as.data.frame(importance(CCS_list3))
setDT(CCS_list3_import, keep.rownames = TRUE)
CCS_list3_import <- sqldf("select rn as CCS, MeanDecreaseGini
                          from CCS_list3_import order by MeanDecreaseGini desc")

# top 15 comrobidites
CCS_list3_import <- CCS_list3_import %>%
  filter(rank(desc(MeanDecreaseGini)) <= 15)

# get CCS comorbid list
j1 <- cbind(CCS_list3_import, dummy(CCS_list3_import$CCS , sep= "_"))
colnames(j1) <- (gsub("CCS_list3_import_", "",  colnames(j1)))
j1$CCS <- NULL
j1$MeanDecreaseGini <- NULL

neph_names <- colnames(j1)

# keep neph comordities
neph_match <- match(neph_names, names(CCS_list2))
neph_match <- CCS_list2[,neph_match]

# remove CCS from base data
no_ccs <- train_SMOTE [,!grepl("^CCS",names(train_SMOTE ))]
train_SMOTE <- cbind(no_ccs, neph_match)
train_SMOTE$CLAIM_ID.1 <- NULL

# binning using chiM
#PATIENT_AGE_colnum <- grep("PATIENT_AGE", colnames(train_SMOTE))
#j <- (  value(PATIENT_AGE_colnum,  train_SMOTE, alpha=0.05))
#j$cuts
#j$disc

# normalize patient age
train_SMOTE$PATIENT_AGE_norm <- (train_SMOTE$PATIENT_AGE - mean(train_SMOTE$PATIENT_AGE)) / sd(train_SMOTE$PATIENT_AGE)
train_SMOTE$PATIENT_AGE <- NULL

str(train_SMOTE, list.len=ncol(train_SMOTE))
# make datmaid codebook
# Instructions to open:  do file open rmd file; use Knit to render as an HTML doc
makeDataReport(train_SMOTE, vol="1", render = TRUE, 
               replace = TRUE, openResult = TRUE, codebook = TRUE,
               reportTitle = "Training Data - Report")

makeCodebook(train_SMOTE, vol="1",  
               replace = TRUE, render = TRUE,openResult = TRUE,
               reportTitle = "Training Data - Codebook")

# repeat for test data
#ttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt
test_SMOTE <- SMOTE(target ~ . , test, k=5, perc.over = 100,
                     perc.under = 200)
table(test_SMOTE$target)
table(test_SMOTE$target)
prop.table(table(test_SMOTE$target))

CCS_list <- test_SMOTE %>% dplyr:: select (starts_with("CCS__"))
t_var <- sqldf("select target from test_SMOTE")
CCS_list2 <- cbind(t_var,CCS_list)

# change target to target_neph 
CCS_list3 <- randomForest(target ~. , data = CCS_list2, importance=T, ntree=500 )
varImpPlot(CCS_list3, sort = T, main = "Variable Importance", n.var = 15)
CCS_list3_import <- as.data.frame(importance(CCS_list3))
setDT(CCS_list3_import, keep.rownames = TRUE)
CCS_list3_import <- sqldf("select rn as CCS, MeanDecreaseGini
                          from CCS_list3_import order by MeanDecreaseGini desc")

# top 15 comrobidites
CCS_list3_import <- CCS_list3_import %>%
  filter(rank(desc(MeanDecreaseGini)) <= 15)

# get CCS comorbid list
j1 <- cbind(CCS_list3_import, dummy(CCS_list3_import$CCS , sep= "_"))
colnames(j1) <- (gsub("CCS_list3_import_", "",  colnames(j1)))
j1$CCS <- NULL
j1$MeanDecreaseGini <- NULL

neph_names <- colnames(j1)

# keep neph comordities
neph_match <- match(neph_names, names(CCS_list2))
neph_match <- CCS_list2[,neph_match]

# remove CCS from base data
no_ccs <- test_SMOTE [,!grepl("^CCS",names(test_SMOTE ))]
test_SMOTE <- cbind(no_ccs, neph_match)
test_SMOTE$CLAIM_ID.1 <- NULL

# binning using chiM
#PATIENT_AGE_colnum <- grep("PATIENT_AGE", colnames(test_SMOTE))
#j <- (  value(PATIENT_AGE_colnum,  test_SMOTE, alpha=0.05))
#j$cuts
#j$disc

# normalize patient age
test_SMOTE$PATIENT_AGE_norm <- (test_SMOTE$PATIENT_AGE - mean(test_SMOTE$PATIENT_AGE)) / sd(test_SMOTE$PATIENT_AGE)
test_SMOTE$PATIENT_AGE <- NULL

str(test_SMOTE, list.len=ncol(test_SMOTE))

#makeCodebook(test_SMOTE, vol = "1", reportTitle = "Test Data", output='html', replace=TRUE)
makeCodebook(test_SMOTE, vol="1",  
             replace = TRUE, render = TRUE,openResult = TRUE,
             reportTitle = "Testing Data - Codebook")


# auto ML
train_auto_ml <- train_SMOTE
train_auto_ml$member_ID <- NULL
train_auto_ml$CLAIM_ID <- NULL
train_auto_ml$FEED_ID <- NULL

test_auto_ml <- test_SMOTE
test_auto_ml$member_ID <- NULL
test_auto_ml$CLAIM_ID <- NULL
test_auto_ml$FEED_ID <- NULL



#feature_exclusions <- c("member_ID","CLAIM_ID", "FEED_ID" )
#features <- setdiff(colnames(train_SMOTE),feature_exclusions)
feature_exclusions <- c("target" )
features <- setdiff(colnames(train_auto_ml),feature_exclusions)

#features <- c(features)
y <- c("target")
x <- colnames(train_auto_ml)


# C5
treeC5_boost <- C5.0(target ~., data = train_auto_ml, trials = 10)
predict_c5_boost <- predict(treeC5_boost, test_auto_ml)
table(predict_c5_boost,test_auto_ml$target )

# C5 rule set boosted
ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, trials = 10)
predict_rule_c5_boost <- predict(ruleC5_boost, test_auto_ml)
table(ruleC5_boost,test_auto_ml$target )


# SVM
model_svm <- svm(target ~., data = train_auto_ml)







train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "target"
x <- setdiff(names(train), y)

# 
# 
# nfolds = 10
# 
# 
# aml <- h2o.automl( x = x, y =y,
#                    training_frame = train,
#                    validation_frame = test,
#                    leaderboard_frame = test,
#                    nfolds,
#                    seed = 77,
#                    stopping_rounds =5,
#                    stopping_tolerance = 1e-4,
#                    stopping_metric = "AUC",
#                    max_runtime_secs = 300)
# lb <- aml@leaderboard
# lb

# GBM

response <- "target"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)

train <- as.h2o(train_auto_ml)
gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10)
h2o.varimp(gbm)


# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 10000,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 100
)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
h2o.varimp(gbm2)

# gbm using hper parameter search
hyper_params = list(max_depth = seq(1,29,2))

grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = list(strategy = "Cartesian"),
  algorithm = "gbm",
  grid_id = "depth_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 10000,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  stopping_rounds =5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10
  )
grid
# sort grid models be creasing AUC
sortedGrid <- h2o.getGrid("depth_grid", sort_by="auc", decreasing = TRUE)
sortedGrid

# find the range of max_depth for the top 5 models
topDepths = sortedGrid@summary_table$max_depth[1:5]
minDepth = min(as.numeric(topDepths))
maxDepth = max(as.numeric(topDepths))
minDepth
maxDepth

####################################################################
# make new hyperparameters list from the above reults - need to chang for each run based upon above
# SLOW TO RUN
hyper_params = list(
  max_depth = seq(minDepth, maxDepth, 1),
  sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate_per_tree = seq(0.2, 1, 0.01),
  col_sample_rate_change_per_level = seq(0.9, 1.1, 0.01),
  min_rows = 2^seq(0, log2(nrow(train)) - 1, 1),
  nbins = 2^seq(4, 10, 1),
  nbins_cats = 2^seq(4, 12, 1),
  min_split_improvement = c(0, 1e-8, 1e-6, 1e-4),
  histogram_type = c("UniformAdaptive", "QuantilesGlobal", "RoundRobin")
  
)

search_criteria = list(
  
  strategy = "RandomDiscrete",
  max_runtime_secs = 36000,
  max_models = 100,
  seed = 77,
  stopping_rounds = 5,
  stopping_metric = "AUC",
  stopping_tolerance = 1e-3
)


grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = search_criteria,
  algorithm = "gbm",
  grid_id = "final_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 10000,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  max_runtime_secs = 36000,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10,
  seed = 77
)

# sort grid models by AUC
sortedGrid <- h2o.getGrid("final_grid", sort_by = "auc", decreasing = TRUE)
sortedGrid
h2o.varimp(grid)
###################################################

#  insert validation data here
# also here is where 3 1 month hold out production tests are run
###### in example this is Model Inspection and Final Test Scoring on git hub page





# stacked ensemble model
# random forest and GBM

nfolds <- 10

# max and min rows based upon above max and min depth
# experiment with fold_assignment "AUTO", "Random", "Modulo", "Stratified"

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 500,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 500,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)



ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id))

# compare to base learner performance
perf <- h2o.performance(ensemble, newdata = test)
#perf


perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test))
ensemble_auc_test <- h2o.auc(perf)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
#pred_ensemble


# ENSEMBLE WITH GRID SEARCH
# use parameters from grid search above
#SLOW TO RUN


gbm_grid_ensemble <- h2o.grid(
  algorithm = "gbm",
  grid_id = "gbm_grid_binomial",
  x = x,
  y = y,
  training_frame = train,
  ntrees = 500,
  seed = 77,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  hyper_params = hyper_params,
  search_criteria = search_criteria)



ensemble2 <- h2o.stackedEnsemble(
  x = x,
  y = y,
  training_frame = train,
  model_id = "ensemble_gbm_grid_binomial",
  base_models = gbm_grid_ensemble@model_ids
)

perf_grid_ensemble <- h2o.performance(ensemble2, newdata = test)

# compare to base learner performance on test setwd
getauc <- function(mm) h2o.auc(h2o.performance(h2o.getModel(mm), newdata = test))
base_leaner_aucs2 <- sapply(gbm_grid_ensemble@model_ids, getauc)
baselearner_best_auc_test2 <- max(base_leaner_aucs2)
ensemble_auc_test2 <- h2o.auc(perf)
print(sprintf("Best Base-learner Test AUC GRID:  %s", baselearner_best_auc_test2))
print(sprintf("Ensemble Test AUC GRID:  %s", ensemble_auc_test2))







# list of features for unspervised learning
# features to exclude
#feature_exclusions <- c("member_ID","CLAIM_ID", "FEED_ID", "target" )
#features <- setdiff(colnames(train_SMOTE),feature_exclusions)

train_unsupervised <-train_SMOTE
train_unsupervised$member_ID <- NULL
train_unsupervised$CLAIM_ID <- NULL
train_unsupervised$FEED_ID <- NULL
train_unsupervised$target <- NULL
features <- colnames(train_unsupervised)
train_unsupervised <- as.h2o(train_SMOTE)

# convert to h2o data frame

test_unsupervised <-test_SMOTE
test_unsupervised$member_ID <- NULL
test_unsupervised$CLAIM_ID <- NULL
test_unsupervised$FEED_ID <- NULL
test_unsupervised$target <- NULL
test_unsupervised <- as.h2o(test_SMOTE)

model_nn <- h2o.deeplearning(x = features,
                             training_frame = train_unsupervised,
                             autoencoder = TRUE,
                             reproducible = TRUE,
                             ignore_const_cols = FALSE,
                             seed = 77,
                             hidden = c(10, 2, 10),
                             epochs = 100,
                             activation = "Tanh")


#h2o.saveModel(model_nn, path = "model_nn", force =TRUE)
#"/home/dless1/anthem/model_nn/DeepLearning_model_R_1522846633706_178818"
model_nn

# convert to autoencoded representation using test data
# 40 features
test_autoenc <- h2o.predict(model_nn, test_unsupervised)
  
  
  
train_features <- h2o.predict(model_nn, train_unsupervised, layer = 2) %>%
  as.data.frame() %>%
  mutate(Class = as.vector(train_unsupervised[, 40]))

#ggplot(train_features, aes(x = DF.L2.C1, y = DF.L2.C2, color = Class)) +
 # geom_point(alpha = 0.1)
train_features <- h2o.predict(model_nn, train_unsupervised, layer = 2) %>%

# third hidden layer
train_features <- h2o.predict(model_nn, train_unsupervised, layer = 3) %>%
  as.data.frame() %>%
  mutate(Class = as.vector(train_unsupervised[, 40])) %>%
  as.h2o()

#features_dim <- setdiff(colnames(train_SMOTE),feature_exclusions)

model_nn_dim <- h2o.deeplearning(x = features,
                                 y=response,
                                 training_frame = train_unsupervised,
                                 reproducible = TRUE,
                                 ignore_const_cols = FALSE,
                                 seed = 77,
                                 hidden = c(10, 2, 10),
                                 epochs = 100,
                                 activation = "Tanh")

#h2o.saveModel(model_nn_dim, path = "model_nn_dim", force =TRUE)
model_nn_dim


test_dim <- h2o.deepfeatures(model_nn, test_unsupervised, layer = 3)

layer3 <- h2o.predict(model_nn_dim, test_unsupervised) %>%
  as.data.frame() %>%
  mutate(actual = as.vector(test_unsupervised[,40])) %>%
  group_by(actual, predict) %>%
  summarise(n =n()) %>%
  mutate(freq = n/ sum(n))



# anomoly
anomaly <- h2o.anomaly(model_nn, test_unsupervised) %>%
  as.data.frame() %>%
  tibble::rownames_to_column() %>%
  mutate(Class = as.vector(test[,40]))

# with real data see if this is factor not a number

anomaly$Class <- as.factor(as.integer(anomaly$Class))

mean_mse <- anomaly %>%
  group_by(Class) %>%
  summarise(mean = mean(Reconstruction.MSE))




# plot anaomoaly

ggplot(anomaly, aes(x = as.numeric(rowname), y = Reconstruction.MSE, color = as.factor(Class))) +
  geom_point(alpha = 0.3) +
  geom_hline(data = mean_mse, aes(yintercept = mean, color = Class)) +
  scale_color_brewer(palette = "Set1") +
  labs(x = "instance number",
       color = "Class")

# change with real data
anomaly <- anomaly %>%
  mutate(outlier = ifelse(Reconstruction.MSE > 0.02, "outlier", "no_outlier"))

anomaly %>%
  group_by(Class, outlier) %>%
  summarise(n = n()) %>%
  mutate(freq = n / sum(n))
