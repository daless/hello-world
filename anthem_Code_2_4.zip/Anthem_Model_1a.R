


#feature_exclusions <- c("member_ID","CLAIM_ID", "FEED_ID" )
#features <- setdiff(colnames(train_SMOTE),feature_exclusions)
feature_exclusions <- c("target" )
features <- setdiff(colnames(train_auto_ml),feature_exclusions)

#features <- c(features)
y <- c("target")
x <- colnames(train_auto_ml)


# C5
treeC5_boost <- C5.0(target ~., data = train_auto_ml, trials = 10)
predict_c5_boost <- predict(treeC5_boost, test_auto_ml)
table(predict_c5_boost,test_auto_ml$target )
summary(predict_c5_boost )

# C5 rule
ruleC5_boost <- C5.0(target ~., data = train_auto_ml, rules = TRUE, trials = 30)
predict_rulec5_boost <- predict(ruleC5_boost, test_auto_ml)
table(predict_rulec5_boost,test_auto_ml$target )
summary(predict_rulec5_boost)

# SVM

# SVM using caret package

# number = number of cross validations , method = "repeatedcv" means repeated cross-validation repeat crossvlidation 3 times
trctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 3, savePredictions = 'final')
set.seed(77)
svm_Linear <- train(target ~., data = train_auto_ml, method = "svmLinear",
                    trControl=trctrl,
                    tuneLength = 10)
svm_Linear

test_pred <- predict(svm_Linear, newdata = test_auto_ml)
test_pred
confusionMatrix(test_pred, test_auto_ml$target)
confusionMatrix(reference = test_auto_ml$target, data= test_pred, mode='everything')



# test_pred2 <- performance(test_pred, "auc")
# test_pred2 
# test_pred2 <- performance(test_pred2, "tpr", "fpr")
# # plot ROC
# plot(test_pred2 , col = "green",lwd=1.5)

# adaboost
model_adaboost <- train(target ~., data = train_auto_ml, method = "adaboost",
                        trControl=trctrl)
model_adaboost				 


# xgboost
set.seed(77)
model_xgbDART <- train(target ~., data = train_auto_ml, method = "xgbDART",
                       trControl=trctrl, tuneLength = 5)
model_xgbDART				



# not tested
plot(roc(predictor = modelObject$pred$CLASSNAME, response = modelObject$pred$obs))


# SVM linear with grid search
grid <- expand.grid(C = c(0,0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2,5))
set.seed(77)
svm_Linear_Grid <- train(target ~., data = train_auto_ml, method = "svmLinear",
                         trControl=trctrl,
                         tuneGrid = grid,
                         tuneLength = 10)

svm_Linear_Grid
plot(svm_Linear_Grid)

test_pred_grid <- predict(svm_Linear_Grid, newdata = test_auto_ml)
test_pred_grid


confusionMatrix(test_pred_grid,test_auto_ml$target )
varImp(svm_Linear_Grid$finalModel)

# SVM with non linear kernel
set.seed(77)

svm_Radial <- train(target ~., data = train_auto_ml, method = "svmRadial", trControl=trctrl, tuneLength = 10)

svm_Radial
plot(svm_Radial)

test_pred_Radial <- predict(svm_Radial, newdata = test_auto_ml)
confusionMatrix(test_pred_Radial, test_auto_ml$target )




# SVM radial
# check wrapping
grid_radial <- expand.grid(sigma = c(0,0.01, 0.02, 0.025, 0.03, 0.04, 0.05,
                                     0.06, 0.07,0.08, 0.09, 0.1, 0.25, 0.5, 0.75,0.9),
                           C = c(0,0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 1, 1.5, 2,5))
set.seed(77)

svm_Radial_Grid <- train(target ~., data = train_auto_ml, method = "svmRadial",
                         trControl=trctrl,
                         tuneGrid = grid_radial,
                         tuneLength = 10)

svm_Radial_Grid

plot(svm_Radial_Grid)

test_pred_Radial_Grid <- predict(svm_Radial_Grid, newdata = test_auto_ml)

confusionMatrix(test_pred_Radial_Grid, test_auto_ml$target )

# use resample to compare models
resample1 <- resample(list(ADABOOST = model_adaboost, XGBDART = model_xgbDART, SVM = svm_Linear_Grid))
scales <- list(x=list(relation="free"), y=list(relation="free"))
# boxplot

bwplot(resample1, scales=scales)
                      
resample2 <- resample(list(ADABOOST = model_adaboost, XGBDART = model_xgbDART, SVM = svm_Radial))
bwplot(resample2, scales=scales)
                                            
resample3 <- resample(list(ADABOOST = model_adaboost, XGBDART = model_xgbDART, SVM = svm_Radial_Grid))
bwplot(resample3, scales=scales)




################################################################################

# H2o Models

# how to get h2o help
#args(h2o.deeplearning)
#help(h2o.deeplearning)
#example(h2odeeplearning)



train <- as.h2o(train_auto_ml)
test <- as.h2o(test_auto_ml)

y <- "target"
x <- setdiff(names(train), y)

# GBM

# if models do not take long to run add reproducible = TRUE,

response <- "target"
train_auto_ml[[response]] <- as.factor(train_auto_ml[[response]])
predictors <- setdiff(colnames(train_auto_ml),response)

train <- as.h2o(train_auto_ml)
gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10)
h2o.varimp(gbm)

# as dataframe - if works put st end of all models
head(as.data.frame(h2o.varimp(gbm)))

# AUC if works add to all models
#h2o.auc(gbm,valid=TRUE)

summary(gbm)
gbm@model$validation_metrics
h2o.confusionMatrix(gbm,valid=TRUE)
h2o.hit_ratio_table(rf1,valid = T)[1,2]
