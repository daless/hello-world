
# V2 uses feed i1 69-73 which is march '17 - july '17
# testing with 100 records from each feed


setwd("~/anthem")

library(RODBC)
#conn = odbcDriverConnect(
#  'DRIVER={ODBCSQLSvr};SERVER=dbswp0628.aimhealth.com;DATABASE=RACER01044;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
#)


#works
conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=dbswp0624.aimhealth.com;DATABASE=RACER00946;UID=COBUnixToSQL;PWD=COBUn!xT0Sql'
)



library(sqldf)
library(dplyr)
library(comorbidity)
library(dummies)
library(smbinning)

# table listing in db
#table_listing <- as.data.frame(sqlTables(conn))




#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# change to CLM.FEED_ID IN(59,58,57,56,55) for feed ids instead of a table for each
# repeat for dx codes as well

member_claim_inv_69  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 69
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  order by CLM.PATIENT_ID desc",
  max = 1000
)

member_claim_inv_70  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 70
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  order by CLM.PATIENT_ID desc",
  max = 1000
)

member_claim_inv_71  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 71
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  order by CLM.PATIENT_ID desc",
  max = 1000
)

member_claim_inv_72  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 72
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  order by CLM.PATIENT_ID desc",
  max = 1000
)

member_claim_inv_73  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  CLM.FEED_ID,
  CLM.PROJECT_ID,
  CLM.PATIENT_ID,
  CLM.PATIENT_AGE,
  CLM.PATIENT_DOB,
  CLM.PATIENT_GENDER,
  CLM.DATE_OF_SERVICE_BEG,
  CLM.DATE_OF_SERVICE_END,
  CLM.DATE_ADMITTED,
  CLM.DATE_DISCHARGED,
  CLM.SUBSCRIBER_ID,
  CLM.SUBSCRIBER_AGE,
  CLM.SUBSCRIBER_DOB,
  CLM.BILL_TYPE,
  CLM.AMT_BILLED,
  CLM.AMT_ALLOWED,
  CLM.AMT_COPAY,
  CLM.AMT_DEDUCTIBLE,
  CLM.AMT_COINSURANCE,
  CLM.AMT_DISALLOWED,
  CLM.AMT_COB_PAID,
  CLM.AMT_DISCOUNT,
  CLM.AMT_COVERED,
  CLM.AMT_NOT_COVERED,
  CLM.AMT_PAID,
  CLM.DATE_PAID,
  CLM.ADJ_CLAIM_FLAG,
  CLM.PRINCIPAL_DIAG as Principal_Dx,
  CLM.PLACE_OF_SERVICE,
  CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
  CLM.ROWID,
  CLM.INS_GROUP_ID,
  CLM.GROUP_SIZE,
  CLM.DATE_CREATED AS CLM_DATE_CREATED,
  CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
  MEM.member_ID, CS.CLAIM_ID as cs_CLAIM_ID, CS.HDS_LOB_ID as cs_HDS_LOB_ID, CD.SUBCATEGORY
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 73
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  order by CLM.PATIENT_ID desc",
  max = 1000
)

member_claim_inv_test <- rbind(member_claim_inv_73, member_claim_inv_72, member_claim_inv_70, member_claim_inv_69)
rm(member_claim_inv_73, member_claim_inv_72, member_claim_inv_70, member_claim_inv_69)



# WHERE CS.HDS_LOB_ID = 2 # COB cases
# AND CD.SUBCATEGORY = 10 #  Medicare cases
# AND CS.STATUS_CODE IN (1,50) # Closed cases
# AND CLM.FEED_ID = 65 #####################   May Inventory Only   >>>>>>>>>>>>>>>>>>>>>  change
# MEMBER_ID=3584398
# AND CLM.PROJECT_ID = 946

claim_line <- sqlColumns(
  conn, "dbo.CLAIM_LINE"  )

ICD9 <- sqlColumns(
  conn, "dbo.ICD9"  )

junk<- sqlColumns(
  conn, "FEED"  )


feed <- sqlQuery(
  conn, "SELECT * from FEED where  PROJECT_ID = 946")

# CLAIM_ID = 3584398
Inventory_HITS_test <- sqlQuery(
  conn,
  " SELECT
  b.CLAIM_ID,
  b.CASE_ID, b.HDS_LOB_ID, b.STATUS_CODE, c.SUBCATEGORY, c.NAME, b.DATE_UPDATED
  FROM
  dbo.CLAIM_STATUS b
  LEFT OUTER JOIN
  dbo.Case_data c ON
  b.CASE_ID=c.CASE_ID
 AND b.HDS_LOB_ID = 2
  AND c.SUBCATEGORY = 10
 AND b.STATUS_CODE IN (0,-1) 
  ", max=100
)



# DX codes
DX_69  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 69
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc",
  max = 1000
)

DX_70  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 70
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc",
  max = 1000
)

DX_71  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 71
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc",
  max = 1000
)

DX_72  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 72
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc",
  max = 1000
)

DX_73  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  as cd_SUBCATEGORY, CS.STATUS_CODE
  FROM dbo.CLAIM CLM
  INNER JOIN dbo.MEMBER MEM
  ON CLM.PATIENT_ID = MEM.MEMBER_ID
  INNER JOIN dbo.CLAIM_STATUS CS
  ON CLM.CLAIM_ID = CS.CLAIM_ID
  AND CLM.PROJECT_ID = CS.PROJECT_ID
  INNER JOIN dbo.CASE_DATA CD
  ON CS.CASE_ID = CD.CASE_ID
  INNER JOIN dbo.STATUS_CODE SC
  ON CS.STATUS_CODE = SC.STATUS_CODE
  INNER JOIN dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CS.HDS_LOB_ID = 2
  AND CD.SUBCATEGORY = 10
  AND CS.STATUS_CODE IN (1,50)
  AND CLM.FEED_ID = 73
  AND CLM.PROJECT_ID = 946
  AND IsValidSSN = 1
  AND CLM.PATIENT_AGE < 65
  AND CLM.PATIENT_AGE > 18
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc",
  max = 1000
)

DX_test <- rbind(DX_69, DX_70, DX_71, DX_72, DX_73)
rm(DX_69, DX_70, DX_71, DX_72, DX_73)


# LOS
member_claim_inv_test$Days_of_service <- difftime(member_claim_inv_test$DATE_OF_SERVICE_END , 
                                                  member_claim_inv_test$DATE_OF_SERVICE_BEG,
                                                  units = c("days")) 

# removes 0 days of service
# remove positive skew of LOS
member_claim_inv_test$Days_of_service <- round(sqrt(as.integer(member_claim_inv_test$Days_of_service + 1)))
# remove decimals from princiapl dx code
member_claim_inv_test$Principal_Dx <- as.character(member_claim_inv_test$Principal_Dx)
member_claim_inv_test$Principal_Dx <- gsub(".","",member_claim_inv_test$Principal_Dx, fixed = TRUE)

# change bill type code NA to 0
member_claim_inv_test$BILL_TYPE <- ifelse(is.na(member_claim_inv_test$BILL_TYPE), 0, member_claim_inv_test$BILL_TYPE)
member_claim_inv_test$BILL_TYPE <- as.factor(member_claim_inv_test$BILL_TYPE)

# remove decimals from diagnosis codes
DX_test$ICD9_CODE <- as.character(DX_test$ICD9_CODE)
DX_test$ICD9_CODE <- gsub(".","",DX_test$ICD9_CODE, fixed = TRUE)


# comorbidity where ICD9_TYPE = 'DIAG10'
DX__diag_test <- sqldf("select * from DX_test where ICD9_TYPE = 'DIAG10' order by CLAIM_ID, ICD9_CODE  ")
charlson_scores <- comorbidity(x=DX__diag_test, id = "CLAIM_ID",  code = "ICD9_CODE", score = "charlson_icd10")
elixhauser_scores <- comorbidity(x=DX__diag_test, id = "CLAIM_ID", code = "ICD9_CODE", score = "elixhauser_icd10")


#  CCS DX
CCS_lookup <- read.csv("ccs_dx_icd10cm_2018_1.csv", sep = ",",  quote = "\"", header = TRUE)
# rename columns
CCS_lookup$ICD9_CODE <- CCS_lookup$X.ICD.10.CM.CODE.
CCS_lookup$CCS_DX <- CCS_lookup$X.CCS.CATEGORY.
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))
CCS_lookup[] <- lapply(CCS_lookup, function(x) sub("[']","",x))

# build CCS dx table
CCS_Codes_test <- sqldf("select DISTINCT d.CLAIM_ID, d.ICD9_CODE, d.ORDER_IN_CLAIM, c.CCS_DX
                        from DX_test d left join CCS_lookup c on d.ICD9_CODE = c.ICD9_CODE
                        order by d.CLAIM_ID , d.ORDER_IN_CLAIM")
CCS_Codes_test$CCS_DX <-as.factor(CCS_Codes_test$CCS_DX)



# make dummies, transpose then 1 record per client id
CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_DX from CCS_Codes_test order by CLAIM_ID")

CCS_Dummy_test <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_DX , sep= "_"))
# replace with CCS
colnames(CCS_Dummy_test) <- (gsub("CCS_Dummy_test", "CCS_",  colnames(CCS_Dummy_test)))
# group by client id
CCS_Dummy2_test <- CCS_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
CCS_Dummy2_test$CLAIM_ID <- as.character(CCS_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy3_test <- CCS_Dummy2_test %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)
CCS_Dummy3_test$CLAIM_ID <- as.numeric(CCS_Dummy3_test$CLAIM_ID)
#rm(CCS_Dummy2_test,CCS_Dummy_test,CCS_Codes_test )


# CCS procedures
CCS_lookup_procedure <- read.csv("pc_icd10pcs_2018.csv", sep = ",",  quote = "\"", header = TRUE)
#str(CCS_lookup_procedure)
# rename procedure code
CCS_lookup_procedure$Procedure_Code <- CCS_lookup_procedure$X.ICD.10.CM.CODE.
CCS_lookup_procedure$Procedure_CCS <- CCS_lookup_procedure$X.PROCEDURE.CLASS.

# have to run twice to remove left and right apostrophies
CCS_lookup_procedure[] <- lapply(CCS_lookup_procedure, function(x) sub("[']","",x))
CCS_lookup_procedure[] <- lapply(CCS_lookup_procedure, function(x) sub("[']","",x))


# map DX codes to CCS
DX_proc_test <- sqldf("select * from DX_test where ICD9_TYPE = 'PROC10' order by CLAIM_ID, ICD9_CODE  ")


# build CCS proc table
Proc_CCS_test <- sqldf("select DISTINCT d.CLAIM_ID, d.ICD9_CODE, d.ORDER_IN_CLAIM, c.Procedure_CCS
                        from DX_proc_test d left join CCS_lookup_procedure c on d.ICD9_CODE = c.Procedure_Code
                        order by d.CLAIM_ID , d.ORDER_IN_CLAIM")
Proc_CCS_test$Procedure_CCS <-as.factor(Proc_CCS_test$Procedure_CCS)



# make dummies, transpose then 1 record per client id
CCS_Proc_Dummy_test <- sqldf("select CLAIM_ID, Procedure_CCS from Proc_CCS_test order by CLAIM_ID")

CCS_Proc_Dummy_test <- cbind(CCS_Proc_Dummy_test, dummy(CCS_Proc_Dummy_test$Procedure_CCS , sep= "_"))
# replace with CCS
colnames(CCS_Proc_Dummy_test) <- (gsub("Procedure_CCS", "CCS_Proc_",  colnames(CCS_Proc_Dummy_test)))
# group by client id
CCS_Proc_Dummy2_test <- CCS_Proc_Dummy_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

#temporaty id to character
CCS_Proc_Dummy2_test$CLAIM_ID <- as.character(CCS_Proc_Dummy2_test$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Proc_Dummy3_test <- CCS_Proc_Dummy2_test %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)
CCS_Proc_Dummy3_test$CLAIM_ID <- as.numeric(CCS_Proc_Dummy3_test$CLAIM_ID)

#rm(CCS_Proc_Dummy2_test, CCS_Proc_Dummy_test, Proc_CCS_test, DX_test)

# POS

POS <- sqldf("select DISTINCT CLAIM_ID, PLACE_OF_SERVICE as POS from member_claim_inv_test")
POS <- cbind(POS, dummy(POS$POS , sep= "_"))

# group by client id
POS2 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS2$CLAIM_ID <- as.character(POS2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS3 <- POS2 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)
POS3$CLAIM_ID <- as.numeric(POS3$CLAIM_ID)
#rm(POS2, POS)


# create study table of single record per encounter
# this will be post adjudication

member_claim_inv_test <- member_claim_inv_test [order(member_claim_inv_test$CLAIM_ID), ]


##############################
# build study table at the encounter - claim level
# with real data confirm no missing comorbidity or dx  CCS codes

base_table1 <- sqldf("SELECT DISTINCT CLAIM_ID, FEED_ID, PATIENT_AGE, PATIENT_GENDER, BILL_TYPE,
                     member_ID,  
                     sqrt(AMT_ALLOWED / AMT_PAID) as ratio_allowed_to_paid ,
                     Days_of_service from member_claim_inv_test")

# add comorbidities
base_table2 <- sqldf("SELECT DISTINCT b.*, c.wscore as Charlson_score from base_table1 b left join charlson_scores c
                     on b.CLAIM_ID = c.CLAIM_ID")

base_table2 <- sqldf("SELECT DISTINCT b.*, c.wscore as Elixhauser_score from base_table2 b left join elixhauser_scores c
                     on b.CLAIM_ID = c.CLAIM_ID")

# CCS dx
CCS_Dummy3_test$CLAIM_IDx <- CCS_Dummy3_test$CLAIM_ID
CCS_Dummy3_test$CLAIM_ID <- NULL
base_table3 <- sqldf("SELECT DISTINCT b.*, c.* from base_table2 b left join CCS_Dummy3_test c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table3$CLAIM_IDx <- NULL
CCS_Dummy3_test$CLAIM_ID <- CCS_Dummy3_test$CLAIM_IDx
CCS_Dummy3_test$CLAIM_IDx <- NULL

# CCS proc
CCS_Proc_Dummy3_test$CLAIM_IDx <- CCS_Proc_Dummy3_test$CLAIM_ID
CCS_Proc_Dummy3_test$CLAIM_ID <- NULL
base_table4 <- sqldf("SELECT DISTINCT b.*, c.* from base_table3 b left join CCS_Proc_Dummy3_test c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table4$CLAIM_IDx <- NULL
CCS_Proc_Dummy3_test$CLAIM_ID <- CCS_Proc_Dummy3_test$CLAIM_IDx
CCS_Proc_Dummy3_test$CLAIM_IDx  <- NULL

# POS
POS3$CLAIM_IDx <- POS3$CLAIM_ID
POS3$CLAIM_ID <- NULL
base_table5 <- sqldf("SELECT DISTINCT b.*, c.* from base_table4 b left join POS3 c
                     on b.CLAIM_ID = c.CLAIM_IDx")
base_table5$CLAIM_IDx <- NULL
POS3$CLAIM_ID <- POS3$CLAIM_IDx

# for testing remove missing CCS
base_table5 <- na.omit(base_table4)

#rm(base_table1, base_table2, base_table3, base_table4)

# dummy target for testing
base_table5$target <- ifelse(base_table5$CCS__110 == 1,
                             1,0)


