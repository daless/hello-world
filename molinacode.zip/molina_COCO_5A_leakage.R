

# V1O_leakage rests the target for feture reduction for OCE to leakage
# V1A based up FL blue


#scp betos20.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_family_level.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_level1.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_level2.txt dless1@apsrd9425:/home/dless1/molina


#V3 refund model inv 1/0

# V4 changed feed ids to 271-322 - lates safari create date was 5 months from current run date
# feed 322 is march 2021 which was the latest invloiced in 3/21

# V5 used and cs.date_updated between '06-01-2019' and '05-31-2021' instead of feeds
# V5b pre process with anomaly


setwd("~/molina")

# files restore
# claims <- readRDS( file="claims.Rda")
# claims_invoiced <- readRDS( file="claims_invoiced.Rda")
# claims <- readRDS( file="claims.Rda")
# FIPS2 <- readRDS( file="FIPS2.Rda")
# DX_claim <- readRDS( file="DX_claim.Rda")
# Leakage_test3 <- readRDS( file="Leakage_test3.Rda")
# charlson_scores <- readRDS( file="charlson_scores.Rda")
# elixhauser_scores <- readRDS( file="elixhauser_scores.Rda")
# CCS_Dummy_test3 <- readRDS( file="CCS_Dummy_test3.Rda")
# POS2 <- readRDS( file="POS2.Rda")
# CPT2 <- readRDS( file="CPT2.Rda")
# PROV_TYPE2 <- readRDS( file="PROV_TYPE2.Rda")
# AHRQ_1 <- readRDS(file="AHRQ_1.Rda")
# base1 <- readRDS(file="base1.Rda")
# base2 <- readRDS(file="base2.Rda")
# claims_OVP_invoiced <- readRDS(file = "claims_OVP_invoiced.Rda")
# base2_saffari <- readRDS(file = "base2_saffari.Rda")

library(comorbidity)
library(RODBC)
library(sqldf)
library(dplyr)


library(dummies)
# #library(tcltk)
# #library(smbinning)
# library(DMwR)
# library(randomForest)
# library(data.table)
# library(discretization)
# library(ggplot2)
# #library(dataMaid)
# #library(e1071)
# ##library(C51)
# library(lubridate)
# library(caret)
# library(h2o)
# library(ROCR)
# #library(pROC)
# library(h2o)
# h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)

conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;DATABASE=racer01272;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')
conn2 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=Dbswp0809.aimhealth.com;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')


feeds <- sqlQuery( conn1, "select max(feed_id) as mx from  racer01272.dbo.claim (nolock) where feed_id != 999 ")

feedspaid <- sqlQuery( conn1, "select max(DATE_PAID) as mx from dmfeed01272.dbo.fd_molina_clm_v2 where feed_id != 999 ")

feedspaid2 <- sqlQuery( conn1, "select max(DATE_PAID) as mx from racer01272.dbo.claim  where feed_id != 999 ")


feedspp <- sqlQuery( conn1, "select max(feed_id) as mx from dmfeed01272.dbo.fd_molina_clm_v2 where feed_id != 999 ")



# last feed for invoiced is 295 
# use 281 -292 for model and 293-95 for OSOD

data_OVP <- sqlQuery(
  conn1,
  "select
distinct
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and cs.current_status = 1
and clm.amt_paid > 0
and cs.date_updated between '06-01-2019' and '05-31-2021'
and cs.current_status = 1
and clm.amt_paid > 0

and cs.status_code in (2,50)")

# originaly
#AND DATEDIFF(D,  clm.DATE_PAID, GETDATE()) >= 30
#AND DATEDIFF(D,  clm.DATE_PAID, GETDATE()) <= 100 
#and cs.date_created between '01-01-2019' and '02-28-2021' 
#AND DATEDIFF(D,  cs.date_created, GETDATE()) >= 120
#AND DATEDIFF(D,  cs.date_created, GETDATE()) <= 850

Unique_OVP_claimids <- sqldf("select distinct CLAIM_id from  data_OVP")


data_NOVP <-  sqlQuery(
  conn1,
  "select
distinct
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and cs.current_status = 1
and clm.amt_paid > 0
and cs.date_updated between '06-01-2019' and '05-31-2021'
  and  ( cs.status_code in (1,20) 
  and cs.reason_code in (13,14,16,17,19,22,24,31,71)) ")

# originally  and cs.date_updated between '01-01-2019' and '02-28-2021'
#AND DATEDIFF(D,  cs.date_created, GETDATE()) >= 120
#AND DATEDIFF(D,  cs.date_created, GETDATE()) <= 850

Unique_NOVP_claimids <- sqldf("select distinct CLAIM_id from  data_NOVP")
data_OVP$OVP <- 1
data_NOVP$OVP <- 0


claims<-rbind(data_OVP,data_NOVP)
saveRDS(claims, file="claims.Rda")
#claims<- readRDS(file="claims.Rda")

Unique_claimids <- sqldf("select distinct CLAIM_id from  claims")
Unique_claimnos <- sqldf("select distinct CLAIM_no from  claims")

##pulling only invoiced claims from safari
Safari<-sqlQuery(conn2,"select distinct claimNO, Provider,ProviderTaxid,
AdjustedSubmittedAmt,EstimatedCommission,
NetSubmittedAmt,ProviderState,
ProviderARStatus, Insurer,caseNbr,
SafariLoaddate, WrittenBy 
from biw_analytics.dbo.dailysafaristatusupdate s with (nolock)
inner join biw_racer.dbo.casedata cd with (nolock)
on s.casenbr=cd.caseid
where Insurer='Molina Healthcare Inc'
                 and cd.hdslobid=3 
                 and ProviderARStatus='INV'")

InvClaims<-Safari
## creating label for Invoiced modeling
InvClaims$INV <- 1

##QA testing
Unique_Invclaimids <- sqldf("select distinct CLAIMNO from  InvClaims")

Unique_claims_inv<-sqldf("select * from Unique_claimnos uc inner join Unique_Invclaimids ui
                         on uc.CLAIM_NO=ui.claimNO")

claims_invoiced <- sqldf("select * from claims clm left join InvClaims inv
                         on clm.CLAIM_NO=inv.claimNO")

saveRDS(claims_invoiced, file="claims_invoiced.Rda")
#claims_invoiced <- readRDS(file="claims_invoiced.Rda")
sqldf("select count(distinct claim_id) from claims_invoiced where OVP=0")
#37730
sqldf("select count(distinct claim_id) from claims_invoiced where OVP=1")
#11859

sqldf("select count(distinct claim_id) from claims_invoiced where INV=1")
#4698

## The test below should confirm that if a claim is  an overpayment iy might or might not have a INV label=1

sqldf("select count(distinct claim_id) from claims_invoiced where OVP=1 and INV=1")
#4698
sqldf("select count(distinct claim_id) from claims_invoiced where OVP=0 and INV=1")
#1

## The test below should confirm that if a claim is not an overpayment it should definitely have INV label=0

NOP_invoiced<-sqldf("select distinct claim_id,claim_no from claims_invoiced where OVP=0 and INV=1")
#1
## creating a label for non-invoiced claim
claims_invoiced$INV <- ifelse(is.na(claims_invoiced$INV), 0, claims_invoiced$INV)

# creating a dataset with claims information to build a model for claims which were refunded.
#here the labels would be invoiced vs non-invoiced

claims_OVP_invoiced<-claims_invoiced%>%filter(OVP==1)

saveRDS(claims_OVP_invoiced, file="claims_OVP_invoiced.Rda")


# checking the proportionality of INV label to make sure to cross check with the recovery rate
prop.table(table(claims_OVP_invoiced$INV))

#0         1 
#0.5483772 0.4516228 

claims_invoiced_<-sqldf("select distinct claim_id,claim_no,claim_feed_id,OVP,INV from claims_invoiced")
saveRDS(claims_invoiced_, file="claims_invoiced_.Rda")


## This shows that FLBL has about 36% of recoverability from the detected overpaid claims
#sqlDrop(conn1,'dbo.FLBL_CoCO_claims_invoiced2019')
#sqlSave(conn1,claims_invoiced_,tablename="dbo.FLBL_CoCO_claims_invoiced2019",rownames=FALSE)

#max_feed <-  sqlQuery(
#  conn1," select max(FEED_ID) as mx from dbo.CLAIM CLM where FEED_ID != 999")


# 3 feeds for OSOD 1 feeds for analysis

##Pulling Dx codes

DX_claim_non  <- sqlQuery(
  conn1,
  " select
DISTINCT CLM.CLAIM_ID,
DX.ICD9_CODE,
DX.PROJECT_ID,
DX.ICD9_TYPE,
DX.ADMITTING_CODE,
DX.PRINCIPAL_CODE,
DX.ORDER_IN_CLAIM,
DX.CLAIM_LINE_ID,
DX.FEED_ID
FROM  dbo.CLAIM CLM   with (nolock)
INNER JOIN dbo.ICD9 DX  with (nolock)
ON CLM.CLAIM_ID = DX.CLAIM_ID


inner join racer01272.dbo.claim_status cs with (nolock)
on CLM.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = CLM.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = CLM.claim_id
and pv_clm.claim_no = CLM.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id

and CLM.FEED_ID=DX.FEED_ID
where DX.ORDER_IN_CLAIM <= 4

and cs.hds_lob_id = 3
and cs.current_status = 1
and clm.amt_paid > 0 
and cs.date_updated between '06-01-2019' and '05-31-2021'
and  ( cs.status_code in (1,20) 
       and cs.reason_code in (13,14,16,17,19,22,24,31,71)) 
order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc")


DX_claim_ok  <- sqlQuery(
  conn1,
  " select
DISTINCT CLM.CLAIM_ID,
DX.ICD9_CODE,
DX.PROJECT_ID,
DX.ICD9_TYPE,
DX.ADMITTING_CODE,
DX.PRINCIPAL_CODE,
DX.ORDER_IN_CLAIM,
DX.CLAIM_LINE_ID,
DX.FEED_ID
FROM  dbo.CLAIM CLM   with (nolock)
INNER JOIN dbo.ICD9 DX  with (nolock)
ON CLM.CLAIM_ID = DX.CLAIM_ID


inner join racer01272.dbo.claim_status cs with (nolock)
on CLM.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = CLM.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = CLM.claim_id
and pv_clm.claim_no = CLM.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id

and CLM.FEED_ID=DX.FEED_ID
where DX.ORDER_IN_CLAIM <= 4
and cs.hds_lob_id = 3
and cs.current_status = 1
and clm.amt_paid > 0
and cs.date_updated between '06-01-2019' and '05-31-2021'
and  cs.status_code in (2,50) 
order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc")


DX_claim <- rbind(DX_claim_ok, DX_claim_non)


saveRDS(DX_claim, file="DX_claim.Rda")

rm(DX_claim_ok)
rm(DX_claim_non)

DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)
DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

#charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson",mc.cores=0)
#elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser",mc.cores=0)

detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

saveRDS(charlson_scores, file="charlson_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
#  elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")


#####
# AHRQ comorbidities
library(icd)

AHRQ_1 <- icd_comorbid_ahrq(DX_claimids_Diag, visit_name = 'CLAIM_ID', icd_name = 'ICD9_CODE', return_df = TRUE,
                            return_binary = FALSE)

AHRQ_1$CLAIM_ID <- as.character(AHRQ_1$CLAIM_ID)
cols <- sapply(AHRQ_1, is.logical)

AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.numeric)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.character)
AHRQ_1$CLAIM_ID <- as.integer(AHRQ_1$CLAIM_ID)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.factor)
colnames(AHRQ_1) <- paste("AHRQ", colnames(AHRQ_1), sep = "_")
AHRQ_1$CLAIM_IDx <- AHRQ_1$AHRQ_CLAIM_ID
AHRQ_1$AHRQ_CLAIM_ID <- NULL

saveRDS(AHRQ_1, file="AHRQ_1.Rda")









####CCS categories


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)



# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category, c.multi_desc 
from DX_claim d left join CCS c on d.ICD9_CODE = c.ICD10_Code
order by d.CLAIM_ID")

#DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), '0', DX_CCS$CCS_Category)
DX_CCS$multi_desc  <- ifelse(is.na(DX_CCS$multi_desc ), 'missing', DX_CCS$multi_desc )

#DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
DX_CCS$multi_desc <-as.factor(DX_CCS$multi_desc)

### One hot encoding of CCS variables #####

#CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from DX_CCS order by CLAIM_ID")




## Making a wide table
#CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc, sep= "_"))

#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))


saveRDS(CCS_Dummy_test3, file="CCS_Dummy_test3.Rda")

##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID, claim_place_of_service as POS from claims_invoiced")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor)
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
saveRDS(POS2, file="POS2.Rda")

icd10codes<-sqldf('select distinct ICD10_CODE from DX_claim')



icd10codes_leakage<-sqldf("select * from icd10codes where    ICD10_CODE in(
'R62.50', 'Z51.0', 'I10', 'F80.9', 'Z51.11', 'N18.6', 'E11.9', 'F82', 'R62.0', 'R69', 'F84.0', 'M54.5', 'R07.89', 'R07.9', 'F80.2', 'R10.9', 'N39.0', 'R11.2',
'O99.89', 'M54.2', 'G80.9', 'M54.9', 'C61', 'F03.90', 'M43.6', 'R51', 'F10.129', 'K52.9', 'J44.1', 'S01.01XA', 'S01.81XA', 'G30.9', 'J44.9', 'R55', 'F80.0', 'G47.33',
'M19.90', 'A41.9', 'R45.851', 'J06.9', 'O26.891', 'R27.8', 'G54.0', 'R56.9', 'F32.9', 'M62.81', 'E86.0', 'E11.621', 'G40.909', 'R26.9', 'F33.2', 'M25.561', 'F80.1',
'C53.9', 'R10.13', 'I50.9', 'S09.90XA', 'A41.89', 'Z00.129', 'O20.0', 'R29.898', 'Z51.12', 'R53.1', 'O26.893', 'R41.82', 'E11.8', 'J18.9', 'B34.9', 'O26.892',
'I63.9', 'F33.9', 'F31.9', 'O34.211', 'M06.9', 'R11.10', 'F41.9', 'R05', 'K59.00', 'Q90.9', 'R10.31', 'O60.03', 'O20.9', 'M25.562', 'Z20.2', 'F10.10', 'Z51.89',
'F20.9', 'E87.6', 'K29.00', 'R47.9', 'G35', 'C10.8', 'E11.65', 'O21.9', 'M62.830', 'R42', 'J45.909', 'C16.8', 'G89.29', 'K35.80', 'C34.92', 'J45.901', 'F79',
'E11.3513', 'O03.9', 'R26.89', 'L03.116', 'J20.9', 'S61.216D', 'N10', 'K02.9', 'R06.02', 'K85.90', 'G43.909', 'I61.9', 'N17.9', 'J40', 'R50.9', 'M15.0', 'R10.84',
'F11.20', 'M86.9', 'F84.9')")

icd10codes_leakage$ICD10_CODE<-as.character(icd10codes_leakage$ICD10_CODE)
icd10codes_leakage$icd10_leakage<-gsub(".","",icd10codes_leakage$ICD10_CODE,fixed=TRUE)


DX_leakage <- sqldf("select DISTINCT d.*,  c.icd10_leakage as ICD10_CODE_Leakage from
DX_claim d left join icd10codes_leakage c on d.ICD9_CODE = c.icd10_leakage
order by d.CLAIM_ID ")

##setting up Leakage codes to be 1
DX_leakage$ICD10_CODE_Leakage[is.na(DX_leakage$ICD10_CODE_Leakage)]<-0
DX_leakage$ICD10_CODE_Leakage<-ifelse(DX_leakage$ICD10_CODE_Leakage==0,0,1)
DX_leakage$ICD10_CODE_Leakage <- as.numeric(DX_leakage$ICD10_CODE_Leakage)
Leakage_test <- sqldf("select DISTINCT CLAIM_ID, ICD10_CODE_Leakage from DX_leakage")

# group by client id
Leakage_test2 <- Leakage_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
Leakage_test2$CLAIM_ID <- as.character(Leakage_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Leakage_test3 <- Leakage_test2 %>% mutate_if(is.numeric,
                                             function(x) case_when(
                                               x >= 1 ~ 1,
                                               x == 0 ~ 0
                                             )
)
Leakage_test3 <- lapply(Leakage_test3, factor)
Leakage_test3 <- as.data.frame(Leakage_test3)
Leakage_test3$CLAIM_ID <- as.numeric(as.character(Leakage_test3$CLAIM_ID))



saveRDS(Leakage_test3, file="Leakage_test3.Rda")


table(Leakage_test$ICD10_CODE_Leakage)
prop.table(table(Leakage_test$ICD10_CODE_Leakage))








BETOS<-read.csv("betos20.txt", header=TRUE, sep="\t")


CPT <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID, OVP,  CLAIM_LINE_CPT as CPT from claims_invoiced
             where CPT != 'NA'")


CPT <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from CPT b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")


CPT$ICD10_CODE_Leakage <- ifelse(is.na(CPT$ICD10_CODE_Leakage), 0, 
                                 CPT$ICD10_CODE_Leakage)


#CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c inner JOIN BETOS b
#             ON c.CPT = b.HCPCS")


CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c LEFT JOIN BETOS b
             ON c.CPT = b.HCPCS")

CPT_OVP <- sqldf("select distinct claim_ID, ICD10_CODE_Leakage from CPT")
# for orphan betos, use CPT

CPT$BETOS_20 <-  ifelse(is.na(CPT$BETOS_20),CPT$CPT,CPT$BETOS_20)

CPT_b <- sqldf("select distinct CLAIM_ID, BETOS_20 from CPT")
CPT_b$BETOS_20 <- as.factor(CPT_b$BETOS_20)

CPT_b <- cbind(CPT_b, dummy(CPT_b$BETOS_20, sep= "_"))

#replace with betos
colnames(CPT_b)<-gsub("CPT_b","BETOS_20",colnames(CPT_b))

CPT_b$BETOS_20 <- NULL



# temp make id character
CPT$CLAIM_ID <- as.character(CPT$CLAIM_ID)

# group by client id
CPT1 <- CPT_b %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor)
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character(CPT2$CLAIM_ID))





CPT2 <- cbind(CPT_OVP$ICD10_CODE_Leakage,CPT2)
# #rename
names(CPT2)[1] <- 'ICD10_CODE_Leakage'

saveRDS(CPT2, file="CPT2.Rda")

CPT2$ICD10_CODE_Leakage <- as.factor(as.character(CPT2$ICD10_CODE_Leakage))
CPT2$CLAIM_ID <- NULL

library(randomForest)
library(psych)

set.seed(77)



rf_CPT1 <- randomForest(ICD10_CODE_Leakage~. ,data=CPT2, ntree=100)

rf_CPT1_importance <- as.data.frame(importance(rf_CPT1))

rf_CPT1_importance <- data.frame(CPT = row.names(rf_CPT1_importance), rf_CPT1_importance)

rf_CPT1_importance_tile <- mutate(rf_CPT1_importance, 
                                  tiles = ntile(rf_CPT1_importance$MeanDecreaseGini, 50))

rf_CPT1_importance <- sqldf("select * from rf_CPT1_importance_tile where tiles = 50")







####### Configuring Provider city#########


FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


claims_invoiced$ZIP <-  ifelse(is.na(claims_invoiced$ZIPCODE),claims_invoiced$ALTERNATE_ZIPCODE,claims_invoiced$ZIPCODE)
claims_invoiced$ZIP <-  ifelse(is.na(claims_invoiced$ZIP),'missing',claims_invoiced$ZIP)


claims_invoiced$zip5 <- substr(claims_invoiced$ZIP,1,5)

claims_invoiced2 <- claims_invoiced

claims_invoiced2 <- data.frame(r_index = row.names(claims_invoiced2), claims_invoiced2)

claims_invoiced2 <- sqldf("select v.*, f.COUNTY from   claims_invoiced2 v left join FIPS f
                 ON v.zip5 = f.zip group by v.r_index
                          " )

claims_invoiced2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from claims_invoiced2 v left join USDA f
ON  v.COUNTY = f.FIPS  group by v.r_index")

claims_invoiced2$COUNTY <-  ifelse(is.na(claims_invoiced2$COUNTY),'missing',claims_invoiced2$COUNTY)
claims_invoiced2$USDA_urban_rural <- ifelse(is.na(claims_invoiced2$USDA_urban_rural),0,claims_invoiced2$USDA_urban_rural)



# use FIPS instead
FIPS <- sqldf("select DISTINCT claim_id as CLAIM_ID,  COUNTY from claims_invoiced2")

FIPS <- cbind(FIPS, dummy(FIPS$COUNTY , sep= "_"))

FIPS$FIPS_missing <- NULL

# group by client id
FIPS1 <- FIPS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
FIPS1$CLAIM_ID <- as.character(FIPS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
FIPS2 <- FIPS1 %>% mutate_if(is.numeric,
                             function(x) case_when(
                               x >= 1 ~ 1,
                               x == 0 ~ 0
                             )
)

FIPS2 <- lapply(FIPS2, factor)
FIPS2<- as.data.frame(FIPS2)
FIPS2$CLAIM_ID <- as.numeric(as.character((FIPS2$CLAIM_ID)))
FIPS2$COUNTY <- NULL
saveRDS(FIPS2, file="FIPS2.Rda")


###### Configuring Provider Type#######
PROV_TYPE <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID,  pv_provider_speciality as PROV_TYPE from claims_invoiced")

PROV_TYPE <- cbind(PROV_TYPE, dummy(PROV_TYPE$PROV_TYPE , sep= "_"))

PROV_TYPE$CLAIM_ID <- as.character(PROV_TYPE$CLAIM_ID)
# group by client id
PROV_TYPE1 <- PROV_TYPE %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
PROV_TYPE1$CLAIM_ID <- as.character(PROV_TYPE1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_TYPE2 <- PROV_TYPE1 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_TYPE2 <- lapply(PROV_TYPE2, factor)
PROV_TYPE2 <- as.data.frame(PROV_TYPE2)
PROV_TYPE2$CLAIM_ID <- as.numeric(as.character((PROV_TYPE2$CLAIM_ID)))
PROV_TYPE2$PROV_TYPE <- NULL

saveRDS(PROV_TYPE2, file="PROV_TYPE2.Rda")


####  creating new features

# use scale / normalize library here
library(BBmisc)

claims_invoiced$ratio_billed_to_paid<-claims_invoiced$claim_amt_billed /claims_invoiced$claim_amt_paid
claims_invoiced$ratio_billed_to_paid <- normalize(claims_invoiced$ratio_billed_to_paid, method="range", range=c(0,1))


#claims_invoiced$ratio_billed_to_paid<-claims_invoiced$claim_line_amt_billed /claims_invoiced$claim_line_amt_paid

# allowed all missing

#claims_invoiced$ratio_allowed_to_paid<-claims_invoiced$claim_amt_allowed/claims_invoiced$claim_amt_paid
#claims_invoiced$PATIENT_AGE_NORM <- scale(claims_invoiced$claim_patient_age)
claims_invoiced$PATIENT_AGE_NORM <- normalize(claims_invoiced$claim_patient_age, method="range", range=c(0,1))

#claims_invoiced$PATIENT_AGE_NORM <- as.numeric(claims_invoiced$PATIENT_AGE_NORM)

claims_invoiced$Days_of_service <- difftime(claims_invoiced$claim_date_of_service_end ,
                                            claims_invoiced$claim_date_of_service_beg,
                                            units = c("days"))

claims_invoiced$Days_of_service <- as.numeric(claims_invoiced$Days_of_service)

claims_invoiced$Days_of_service <-  normalize(claims_invoiced$Days_of_service, method="range", range=c(0,1))

makeDataReport(claims_invoiced, vol="1", render = FALSE,
               replace = TRUE, openResult = FALSE, codebook = TRUE,
               reportTitle = "claims_invoiced - Report")





# remove positive skew of LOS
#claims_invoiced$Days_of_service <- round(sqrt(as.integer(claims_invoiced$Days_of_service + 1)))
# remove decimals from princiapl dx code
claims_invoiced$claim_principal_diag <- as.character(claims_invoiced$claim_principal_diag)
claims_invoiced$claim_principal_diag <- gsub(".","",claims_invoiced$claim_principal_diag, fixed = TRUE)

saveRDS(claims_invoiced, file="claims_invoiced.Rda")
####### Creating a target variable for Leakage to perform dimensional reduction############


claims_invoiced<-claims_invoiced[order(claims_invoiced$claim_id),]
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
#Merging with cormorbidities

# if clim is OVP = 1 and OVP = 0 force to be overpoayment

ovpfix <- sqldf ("select distinct CLAIM_ID, OVP from  claims_invoiced")

ovpfix  <- sqldf ("select CLAIM_ID, OVP, count(CLAIM_ID) as cnt from  ovpfix  group by   CLAIM_ID having cnt  > 1")

claims_invoiced$OVP <- as.factor(claims_invoiced$OVP)
claims_invoiced <- sqldf("select c.*, o.cnt from claims_invoiced c left join ovpfix o
                         ON c.CLAIM_ID = o.CLAIM_ID
                         ")
claims_invoiced$cnt <-  ifelse(is.na(claims_invoiced$cnt),0,claims_invoiced$cnt)

claims_invoiced$OVP2 <- claims_invoiced$OVP
claims_invoiced$OVP2 <- ifelse(claims_invoiced$cnt == 2 ,1,claims_invoiced$OVP2)
claims_invoiced$OVP <- claims_invoiced$OVP2

claims_invoiced$cnt <- NULL
claims_invoiced$OVP2  <- NULL

count_claim_ids <- sqldf("select distinct claim_id from claims_invoiced")



base1 <- sqldf("select distinct claim_id , claim_no, OVP, PATIENT_AGE_NORM,
Days_of_service, ratio_billed_to_paid , 
               claim_patient_gender
               from claims_invoiced ")

charlson_scores$CLAIM_ID <- as.numeric(charlson_scores$CLAIM_ID )



base1 <-sqldf("select distinct b.*, c.wscore as Charlson_score from  base1 b
             left join charlson_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

# lekage dx flag


base1 <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from base1 b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")

base1$ICD10_CODE_Leakage <- ifelse(is.na(base1$ICD10_CODE_Leakage), 0, 
                                   base1$ICD10_CODE_Leakage)


base1$Charlson_score <-  ifelse(is.na(base1$Charlson_score),1,base1$Charlson_score)


elixhauser_scores$CLAIM_ID<-as.numeric(elixhauser_scores$CLAIM_ID)

base1 <-sqldf("select distinct b.*, c.score as elix_score from  base1 b
             left join elixhauser_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

base1$elix_score <-  ifelse(is.na(base1$elix_score),0,base1$elix_score)

base1 <-sqldf("select distinct b.*, c.* from  base1 b
             left join AHRQ_1 c
             on b.claim_id = c.CLAIM_IDx", method = "name_class")

base1$CLAIM_IDx <- NULL


base1 <- mutate_at(base1, vars(starts_with("AHRQ_")),
                   ~replace(., is.na(.), 0))






### Merging with CCS
# CCS dx
CCS_Dummy_test3$CLAIM_IDx <- CCS_Dummy_test3$CLAIM_ID

CCS_Dummy_test3$CLAIM_ID <- NULL

base1<- sqldf("SELECT DISTINCT b.*, c.* from base1 b left join CCS_Dummy_test3 c
                               on b.CLAIM_ID = c.CLAIM_IDx")




base1 <- mutate_at(base1, vars(starts_with("CCS_")),
                   ~replace(., is.na(.), 0))

base1$CLAIM_IDx <- NULL


##### Merging with POS
# POS2$CLAIM_IDx <- POS2$CLAIM_ID
# base1 <- base1%>%left_join(POS2,by=c("claim_id"="CLAIM_IDx"))
# 
# 
# base1 <- mutate_at(base1, vars(starts_with("POS_")),
#                    ~replace(., is.na(.), 0))


# for larger merges use targeted feature reduction




POS2$CLAIM_IDx <- POS2$CLAIM_ID
POS2$CLAIM_ID <- NULL

rf_pos1 <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, POS2 p
                 where b.CLAIM_ID = p.CLAIM_IDx")

rf_pos1$claim_id <- NULL
rf_pos1$CLAIM_IDx <- NULL
rf_pos1$POS_NA <- NULL


rf_pos1$ICD10_CODE_Leakage <- as.factor(rf_pos1$ICD10_CODE_Leakage)

rf_pos1 <- randomForest(ICD10_CODE_Leakage~. ,data=rf_pos1, ntree=500)

rf_pos1_importance <- as.data.frame(importance(rf_pos1))

rf_pos1_importance <- data.frame(POS = row.names(rf_pos1_importance), rf_pos1_importance)

rf_pos1_importance_tile <- mutate(rf_pos1_importance, 
                 tiles = ntile(rf_pos1_importance$MeanDecreaseGini, 4))

rf_pos1_importance <- sqldf("select * from rf_pos1_importance_tile where tiles = 4")


# rf_pos1_importance <-rf_pos1_importance_tile %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 10)

saveRDS(rf_pos1_importance, file="rf_pos1_importance.Rda")



POS_match <- POS2[, names(POS2) %in% rf_pos1_importance$POS]
base1 <- cbind(base1, POS_match)


base1 <- mutate_at(base1, vars(starts_with("POS_")),
                   ~replace(., is.na(.), 0))



#################################### Feature reduction of CPT variables#####

# CPT2$CLAIM_IDx <- CPT2$CLAIM_ID
# CPT2$CLAIM_ID <- NULL
# 
# rf_CPT1 <- sqldf("select b.CLAIM_ID, b.OVP, p.* from base1 b, CPT2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_CPT1$claim_id <- NULL
# rf_CPT1$CLAIM_IDx <- NULL
# rf_CPT1$CPT2_NA <- NULL
# 
# 
# set.seed(77)
# 
# rf_CPT1$OVP <- as.factor(rf_CPT1$OVP)
# 
# rf_CPT1 <- randomForest(OVP~. ,data=rf_CPT1, ntree=500)
# 
# rf_CPT1_importance <- as.data.frame(importance(rf_CPT1))
# 
# rf_CPT1_importance <- data.frame(CPT = row.names(rf_CPT1_importance), rf_CPT1_importance)
# 
# rf_CPT1_importance_tile <- mutate(rf_CPT1_importance, 
#                                   tiles = ntile(rf_CPT1_importance$MeanDecreaseGini, 4))
# 
# rf_CPT1_importance <- sqldf("select * from rf_CPT1_importance_tile where tiles = 4")



# rf_CPT1_importance <-rf_CPT1_importance %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 20)

saveRDS(rf_CPT1_importance, file="rf_CPT1_importance.Rda")



CPT2_match <- CPT2[, names(CPT2) %in% rf_CPT1_importance$CPT]

CPT2_match <- cbind(CPT1$CLAIM_ID, CPT2_match)
names(CPT2_match)[1] <- 'CLAIM_IDx'

base1<- sqldf("select b.*, c.* from base1 b left join CPT2_match c
               on b.CLAIM_ID = c.CLAIM_IDx")

base1 <- mutate_at(base1, vars(starts_with("BETOS_")),
                   ~replace(., is.na(.), 0))

base1$CLAIM_IDx <- NULL


##################################################  FIPS

FIPS2$CLAIM_IDx <- FIPS2$CLAIM_ID
FIPS2$CLAIM_ID <- NULL

rf_FIPS <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, FIPS2 p
                 where b.CLAIM_ID = p.CLAIM_IDx")

rf_FIPS$claim_id <- NULL
rf_FIPS$CLAIM_IDx <- NULL
rf_FIPS$CPT2_NA <- NULL


set.seed(77)

rf_FIPS$ICD10_CODE_Leakage <- as.factor(rf_FIPS$ICD10_CODE_Leakage)

rf_FIPS <- randomForest(ICD10_CODE_Leakage~. ,data=rf_FIPS, ntree=500)

rf_FIPS_importance <- as.data.frame(importance(rf_FIPS))

rf_FIPS_importance <- data.frame(FIPS = row.names(rf_FIPS_importance), rf_FIPS_importance)


rf_FIPS_importance_tile <- mutate(rf_FIPS_importance, 
                                  tiles = ntile(rf_FIPS_importance$MeanDecreaseGini, 4))

rf_FIPS_importance <- sqldf("select * from rf_FIPS_importance_tile where tiles = 4")


# rf_FIPS_importance <-rf_FIPS_importance %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 20)

saveRDS(rf_FIPS_importance, file="rf_FIPS_importance.Rda")


FIPS_match <- FIPS2[, names(FIPS2) %in% rf_FIPS_importance$FIPS]
base1 <- cbind(base1, FIPS_match)


base1 <- mutate_at(base1, vars(starts_with("FIPS_")),
                   ~replace(., is.na(.), 0))





##############################################################################################

# provider type targeted feature reduction
PROV_TYPE2$CLAIM_IDx <- PROV_TYPE2$CLAIM_ID
PROV_TYPE2$CLAIM_ID <- NULL

rf_PROV_TYPE <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, PROV_TYPE2 p
                 where b.CLAIM_ID = p.CLAIM_IDx")

rf_PROV_TYPE$claim_id <- NULL
rf_PROV_TYPE$CLAIM_IDx <- NULL
rf_PROV_TYPE$CPT2_NA <- NULL


set.seed(77)

rf_PROV_TYPE$ICD10_CODE_Leakage <- as.factor(rf_PROV_TYPE$ICD10_CODE_Leakage)

rf_PROV_TYPE <- randomForest(ICD10_CODE_Leakage ~. ,data=rf_PROV_TYPE, ntree=500)

rf_PROV_TYPE_importance <- as.data.frame(importance(rf_PROV_TYPE))

rf_PROV_TYPE_importance <- data.frame(PROV_TYPE = row.names(rf_PROV_TYPE_importance), rf_PROV_TYPE_importance)


rf_PROV_TYPE_importance_tile <- mutate(rf_PROV_TYPE_importance, 
                                  tiles = ntile(rf_PROV_TYPE_importance$MeanDecreaseGini, 4))

rf_PROV_TYPE_importance <- sqldf("select * from rf_PROV_TYPE_importance_tile where tiles = 4")



# rf_PROV_TYPE_importance <-rf_PROV_TYPE_importance %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 20)

saveRDS(rf_PROV_TYPE_importance, file="rf_PROV_TYPE_importance.Rda")

PROV_TYPE_match <- PROV_TYPE2[, names(PROV_TYPE2) %in% rf_PROV_TYPE_importance$PROV_TYPE]
base1 <- cbind(base1, PROV_TYPE_match)


base1 <- mutate_at(base1, vars(starts_with("PROV_TYPE_")),
                   ~replace(., is.na(.), 0))








# remove missings
base1$claim_patient_gender<- ifelse(is.na(base1$claim_patient_gender), 'X', 
                                    base1$claim_patient_gender)


base2 <- sqldf("select * from base1 where PATIENT_AGE_NORM IS NOT NULL")

base2 <- lapply(base2, factor)

base2$claim_id  <- as.numeric(as.character(base2$claim_id))
base2$claim_no  <- NULL
base2$PATIENT_AGE_NORM  <- as.numeric(as.character(base2$PATIENT_AGE_NORM))
base2$Days_of_service  <- as.numeric(as.character(base2$Days_of_service))
base2$ratio_billed_to_paid  <- as.numeric(as.character(base2$ratio_billed_to_paid))
base2$Charlson_score  <- as.numeric(as.character(base2$Charlson_score))
base2$elix_score  <- as.numeric(as.character(base2$elix_score))
base2 <- as.data.frame(base2)
base2$PROV_TYPE_NA <-  NULL
base2$CCS_missing <- NULL


saveRDS(base1, file="base1_leakage.Rda")
saveRDS(base2, file="base2_leakage.Rda")


inv_id <- sqldf("select distinct claim_id, INV from claims_OVP_invoiced")

base2_saffari <- sqldf("select b.*, i.INV from base2 b, inv_id i
                       where b.claim_id = i.claim_id")

saveRDS(base2_saffari, file="base2_saffari.Rda")
# base2_saffari<- readRDS(file="base2_saffari.Rda")

library(dataMaid)

# make datmaid codebook
# Instructions to open:  do file open rmd file; use Knit to render as an HTML doc
makeDataReport(base2, vol="1", render = FALSE,
               replace = TRUE, openResult = FALSE, codebook = TRUE,
               reportTitle = "Model Data - Report")

foo
# base2_leakage<- readRDS(file="base2_leakage.Rda")

# base2_saffari<- readRDS(file="base2_saffari.Rda")


base3 <- base2

base3$claim_id<-NULL

idx <- sample(seq(1,2), size = nrow(base3), replace = TRUE, prob = c(0.7, 0.3))
train <- base3[idx == 1,]
test <- base3[idx == 2,]



library(h2o)
#h2o.init()
h2o.init(port=54333)

train <- as.h2o(train)
test<-as.h2o(test)
y <- "OVP"
x <- setdiff(names(train), y)
predictors <- setdiff(names(train), y)
response <- "OVP"

gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10)
h2o.varimp(gbm)
summary(gbm)



gbm_2a <- h2o.gbm(x= predictors, y=response, training_frame = train, validation_frame = test, nfolds = 10)
summary(gbm_2a)




# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 10
)

summary(gbm2)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
head(as.data.frame(h2o.varimp(gbm2)),n=10)


rf_h2o_1<- h2o.randomForest(x=x,
                           y = y,
                           training_frame = train,
                           validation_frame = test,
                           ntrees = 100,
                           nfolds = 10,
                           sample_rate = 0.85,
                           fold_assignment = "Modulo",
                           keep_cross_validation_predictions = TRUE,
                           stopping_tolerance = 1e-2,
                           stopping_rounds = 2,
                           seed = 77)


summary(rf_h2o_1)
rf1_var_import <-h2o.varimp(rf_h2o_1)

nfolds <- 10
rf_2 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         ntrees = 500,
                         nfolds = nfolds,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)
summary(rf_2)




rf_3 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         validation_frame = test,
                         ntrees = 500,
                         nfolds = nfolds,
                         nbins = 50,
                         balance_classes = TRUE,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)



summary(rf_3)




# xgboost

nfolds <- 10
xgboost <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 200,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost)
head(as.data.frame(h2o.varimp(xgboost)),n=10)


xgboost500 <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 500,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost500)
head(as.data.frame(h2o.varimp(xgboost500)),n=10)




nfolds <- 5
xgboost700 <- h2o.xgboost(x=x,
                          y = y,
                          training_frame = train,
                          validation_frame = test,
                          ntrees = 700,
                          nfolds = nfolds,
                          fold_assignment = "Modulo",
                          keep_cross_validation_predictions = TRUE,
                          max_depth = 3,
                          min_rows = 2,
                          learn_rate =0.2,
                          seed = 77)

summary(xgboost700)
head(as.data.frame(h2o.varimp(xgboost700)),n=10)

#h2o.saveModel(xgboost700, path = "xgboost", force =TRUE)
#  1/12/22 OVP
#  /home/dless1/molina/xgboost/XGBoost_model_R_1642019750772_1156"



# ##########
# # h2o ensemble
# 
# stacked ensemble model
# random forest and GBM



# max and min rows based upon above max and min depth
# experiment with fold_assignment "AUTO", "Random", "Modulo", "Stratified"

nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 500,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 500,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)


solo_xgboost700 <- h2o.xgboost(x=x,
                          y = y,
                          training_frame = train,
                          ntrees = 700,
                          nfolds = nfolds,
                          fold_assignment = "Modulo",
                          keep_cross_validation_predictions = TRUE,
                          max_depth = 3,
                          min_rows = 2,
                          learn_rate =0.2,
                          seed = 77)


solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id, solo_xgboost700l@model_id))





perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_xgboost700 <-  h2o.performance(solo_xgboost700, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_xgboost700),
                                 h2o.auc(perf_solo_solo_dl))

ensemble_auc_test <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
pred_ensemble
summary(pred_ensemble)




#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR



# recovery model
saff1 <- base2_saffari
saff1$ claim_id <- NULL
saff1$OVP <- NULL
saff1$INV <- as.factor(as.character(saff1$INV))


library(dataMaid)

# make datmaid codebook
# Instructions to open:  do file open rmd file; use Knit to render as an HTML doc
makeDataReport(saff1, vol="1", render = FALSE,
               replace = TRUE, openResult = FALSE, codebook = TRUE,
               reportTitle = "Model Data - Report")




idx <- sample(seq(1,2), size = nrow(saff1), replace = TRUE, prob = c(0.7, 0.3))
train <- saff1[idx == 1,]
test <- saff1[idx == 2,]

train <- as.h2o(train)
test<-as.h2o(test)
y <- "INV"
x <- setdiff(names(train), y)
predictors <- setdiff(names(train), y)
response <- "INV"

gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10)
h2o.varimp(gbm)
summary(gbm)



gbm_2a <- h2o.gbm(x= predictors, y=response, training_frame = train, validation_frame = test, nfolds = 10)
summary(gbm_2a)




# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 10
)

summary(gbm2)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
head(as.data.frame(h2o.varimp(gbm2)),n=10)


rf_h2o_1<- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            validation_frame = test,
                            ntrees = 100,
                            nfolds = 10,
                            sample_rate = 0.85,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            stopping_tolerance = 1e-2,
                            stopping_rounds = 2,
                            seed = 77)


summary(rf_h2o_1)
rf1_var_import <-h2o.varimp(rf_h2o_1)

nfolds <- 10
rf_2 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         ntrees = 500,
                         nfolds = nfolds,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)
summary(rf_2)




rf_3 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         validation_frame = test,
                         ntrees = 500,
                         nfolds = nfolds,
                         nbins = 50,
                         balance_classes = TRUE,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)



summary(rf_3)




# xgboost

nfolds <- 10
xgboost <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 200,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost)
head(as.data.frame(h2o.varimp(xgboost)),n=10)


xgboost500 <- h2o.xgboost(x=x,
                          y = y,
                          training_frame = train,
                          validation_frame = test,
                          ntrees = 500,
                          nfolds = nfolds,
                          fold_assignment = "Modulo",
                          keep_cross_validation_predictions = TRUE,
                          max_depth = 3,
                          min_rows = 2,
                          learn_rate =0.2,
                          seed = 77)

summary(xgboost500)
head(as.data.frame(h2o.varimp(xgboost500)),n=10)

#h2o.saveModel(xgboost500, path = "xgboost", force =TRUE)
# best recvoered INV 1/0 model
#  "/home/dless1/molina/xgboost/XGBoost_model_R_1629222360940_6970"



nfolds <- 5
xgboost700 <- h2o.xgboost(x=x,
                          y = y,
                          training_frame = train,
                          validation_frame = test,
                          ntrees = 700,
                          nfolds = nfolds,
                          fold_assignment = "Modulo",
                          keep_cross_validation_predictions = TRUE,
                          max_depth = 3,
                          min_rows = 2,
                          learn_rate =0.2,
                          seed = 77)

summary(xgboost700)
head(as.data.frame(h2o.varimp(xgboost700)),n=10)

#h2o.saveModel(xgboost700, path = "xgboost", force =TRUE)
# best recvoered INV 1/0 model
# model 1/12/22 safari
# ""/home/dless1/molina/xgboost/XGBoost_model_R_1642019750772_4328"


# ##########
# # h2o ensemble
# 
# stacked ensemble model
# random forest and GBM



# max and min rows based upon above max and min depth
# experiment with fold_assignment "AUTO", "Random", "Modulo", "Stratified"

nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 500,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 500,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)


solo_xgboost700 <- h2o.xgboost(x=x,
                               y = y,
                               training_frame = train,
                               ntrees = 700,
                               nfolds = nfolds,
                               fold_assignment = "Modulo",
                               keep_cross_validation_predictions = TRUE,
                               max_depth = 3,
                               min_rows = 2,
                               learn_rate =0.2,
                               seed = 77)


solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id, solo_xgboost700l@model_id))





perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_xgboost700 <-  h2o.performance(solo_xgboost700, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_xgboost700),
                                 h2o.auc(perf_solo_solo_dl))

ensemble_auc_test <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
pred_ensemble
summary(pred_ensemble)














h2o.performance(rf_FLBL,newdata=test)
h2o.confusionMatrix(rf_FLBL,newdata=test,threshold=0.4)
#AUC-0.79, percision=0.52 and recall=0.26
healthnet_list3_var_import <-h2o.varimp(rf_FLBL)
#h2o.varimp_plot(rf_FLBL)

healthnet_list3_import <-healthnet_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
healthnet_list3_import$healthnet <- healthnet_list3_import$variable
healthnet_Top25<-as.data.frame(healthnet_list3_import$healthnet)
write.csv(healthnet_Top25,file="FLBLRF_Top25_04072021_v1.csv")
h2o.saveModel(rf_FLBL, path = getwd(), force =TRUE)
### XG Boost
rf_xgboost<- h2o.xgboost(x=x,
                         y = y,
                         training_frame = train,
                        
                         ntrees = 100,
                         nfolds = 10,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         keep_cross_validation_predictions = TRUE,
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         seed = 77)








h2o.performance(rf_xgboost,newdata=test)
h2o.confusionMatrix(rf_xgboost,newdata=test,threshold=0.4)
#AUC-0.82, percision=0.59 and recall=0.33
rf_xgboost_var_import <-h2o.varimp(rf_xgboost)
#h2o.varimp_plot(rf_healthnet)





FLBL_list3_var_import <-FLBL_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
FLBL_list3_var_import$FLBL <- FLBL_list3_var_import$variable
FLBL_Top25<-as.data.frame(FLBL_list3_var_import$FLBL)
write.csv(FLBL_Top25,file="FLBLXgBoost_Top25_04072021_v1.csv")
h2o.saveModel(rf_xgboost, path = getwd(), force =TRUE)

#### Building the recoverability model
base_table7a<-base_table6%>%select (claim_id,NORM_LINE_AMT_PAID,NORM_LINE_AMT_BILLED,Days_of_service,ratio_billed_to_paid,ratio_allowed_to_paid,PATIENT_AGE_NORM,wscore,wscore_ahrq,starts_with("CCS_"),starts_with("POS_"),starts_with("PROV_CITY_"),starts_with("PROV_TYPE_"),starts_with("CPT_"),OVP,INV)
base_table7b<-base_table7a%>%filter(OVP==1)
prop.table(table(base_table7b$INV))

## The test below should confirm that if a claim is  an overpayment iy might or might not have a INV label=1
sqldf("select count(distinct claim_id) from base_table7a where OVP=1 and INV=1")
sqldf("select count(distinct claim_id) from base_table7a where OVP=0 and INV=1")
## The test below should confirm that if a claim is not an overpayment it should definitely have INV label=0


base_table7b$NORM_LINE_AMT_PAID<-as.numeric(base_table7b$NORM_LINE_AMT_PAID)
base_table7b$NORM_LINE_AMT_BILLED<-as.numeric(base_table7b$NORM_LINE_AMT_BILLED)

##### Need to revise here based on the leakage feature reduction###
base_table8a<-sqldf("select
claim_id,
max(NORM_LINE_AMT_PAID) as  NORM_LINE_AMT_PAID,
max(NORM_LINE_AMT_BILLED) as  NORM_LINE_AMT_BILLED,
max(Days_of_service) as  Days_of_service,
max(ratio_billed_to_paid) as  ratio_billed_to_paid,
max(ratio_allowed_to_paid) as  ratio_allowed_to_paid,
max(PATIENT_AGE_NORM) as  PATIENT_AGE_NORM,
max(wscore) as  charlson_score,
max(wscore_ahrq) as  elixhauser_score,
MAX(CCS_45) AS CCS_45,
MAX(CCS_98) AS CCS_98,
MAX(CCS_158) AS CCS_158,
MAX(CCS_138) AS CCS_138,
MAX(CCS_101) AS CCS_101,
MAX(CCS_102) AS CCS_102,
MAX(CCS_53) AS CCS_53,
MAX(CCS_106) AS CCS_106,
MAX(CCS_157) AS CCS_157,
MAX(CCS_251) AS CCS_251,
MAX(CCS_42) AS CCS_42,
MAX(CCS_99) AS CCS_99,
MAX(CCS_59) AS CCS_59,
MAX(CCS_159) AS CCS_159,
MAX(CCS_217) AS CCS_217,
MAX(CCS_161) AS CCS_161,
MAX(CCS_49) AS CCS_49,
MAX(CCS_250) AS CCS_250,
MAX(CCS_24) AS CCS_24,
MAX(CCS_2) AS CCS_2,
MAX(CCS_19) AS CCS_19,
MAX(CCS_84) AS CCS_84,
MAX(CCS_46) AS CCS_46,
MAX(CCS_245) AS CCS_245,
MAX(CCS_29) AS CCS_29,
MAX(POS_65) AS POS_65,
MAX(POS_23) AS POS_23,
MAX(POS_11) AS POS_11,
MAX(POS_22) AS POS_22,
MAX(POS_21) AS POS_21,
MAX(CPT_96417) AS CPT_96417,
MAX(CPT_96375) AS CPT_96375,
MAX(CPT_J1644) AS CPT_J1644,
MAX(CPT_80053) AS CPT_80053,
MAX(CPT_96413) AS CPT_96413,
MAX(CPT_36415) AS CPT_36415,
MAX(CPT_A4657) AS CPT_A4657,
MAX(CPT_83690) AS CPT_83690,
MAX(CPT_J2505) AS CPT_J2505,
MAX(PROV_TYPE_RADIOLOGY) AS PROV_TYPE_RADIOLOGY,
MAX(PROV_TYPE_NEUROLOGY) AS PROV_TYPE_NEUROLOGY,
MAX(PROV_TYPE_SPECIALTY_PHARMACIES) AS PROV_TYPE_SPECIALTY_PHARMACIES,
MAX(PROV_TYPE_PLASTICSURGERY) AS PROV_TYPE_PLASTICSURGERY,
MAX(PROV_CITY_TAMPA) AS PROV_CITY_TAMPA,
MAX(PROV_CITY_ORLANDO) AS PROV_CITY_ORLANDO,
MAX(PROV_CITY_MIAMI) AS PROV_CITY_MIAMI,
MAX(PROV_CITY_PLANTATION) AS PROV_CITY_PLANTATION,
MAX(PROV_CITY_JACKSONVILLE) AS PROV_CITY_JACKSONVILLE,
MAX(PROV_CITY_WESTPALMBEACH) AS PROV_CITY_WESTPALMBEACH,
MAX(PROV_CITY_ATLANTIS) AS PROV_CITY_ATLANTIS,
MAX(PROV_CITY_PENSACOLA) AS PROV_CITY_PENSACOLA,
MAX(PROV_CITY_MARGATE) AS PROV_CITY_MARGATE,
INV
from base_table7b
group by claim_id,INV")

base_table8a$claim_id<-NULL
base_table8a$INV<-as.factor(base_table8a$INV)
base_table8a$ratio_billed_to_paid <-  ifelse(base_table8a$ratio_billed_to_paid==Inf,1,base_table8a$ratio_billed_to_paid)
idx <- sample(seq(1,2), size = nrow(base_table8a), replace = TRUE, prob = c(0.7, 0.3))
train_inv <- base_table8a[idx == 1,]
test_inv <- base_table8a[idx == 2,]

train_inv <- as.h2o(train_inv)
test_inv<-as.h2o(test_inv)
y_inv <- "INV"
x_inv <- setdiff(names(train_inv), y_inv)

rf_FLBL_inv<- h2o.randomForest(x=x_inv,
                               y = y_inv,
                               training_frame = train_inv,
                               validation_frame = test_inv,
                               ntrees = 100,
                               nfolds = 10,
                               sample_rate = 0.85,
                               fold_assignment = "Modulo",
                               keep_cross_validation_predictions = TRUE,
                               stopping_tolerance = 1e-2,
                               stopping_rounds = 2,
                               seed = 77)








h2o.performance(rf_FLBL_inv,newdata=test_inv)
h2o.confusionMatrix(rf_FLBL_inv,newdata=test_inv,threshold=0.4)
#AUC-0.79, percision=0.52 and recall=0.26
FLBLINV_list3_var_import <-h2o.varimp(rf_FLBL_inv)
#h2o.varimp_plot(rf_FLBL)

FLBLINV_list3_var_import<-FLBLINV_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
FLBLINV_list3_var_import$FLBL_INV <- FLBLINV_list3_var_import$variable
FLBLINV_Top25<-as.data.frame(FLBLINV_list3_var_import$FLBL_INV)
write.csv(healthnet_Top25,file="FLBLRFINV_Top25_04072021_v1.csv")
h2o.saveModel(rf_FLBLINV, path = getwd(), force =TRUE)
### XG Boost
FLBLINV_xgboost<- h2o.xgboost(x=x_inv,
                              y = y_inv,
                              training_frame = train_inv,
                              validation_frame = test_inv,
                              ntrees = 100,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              keep_cross_validation_predictions = TRUE,
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)








h2o.performance(FLBLINV_xgboost,newdata=test_inv)
h2o.confusionMatrix(FLBLINV_xgboost,newdata=test_inv,threshold=0.4)


#AUC-0.82, percision=0.59 and recall=0.33
FLBL_list3_var_import <-h2o.varimp(rf_xgboost)
#h2o.varimp_plot(rf_healthnet)




FLBL_list3_var_import <-FLBL_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
FLBL_list3_var_import$FLBL <- FLBL_list3_var_import$variable
FLBL_Top25<-as.data.frame(FLBL_list3_var_import$FLBL)
write.csv(FLBL_Top25,file="FLBLXgBoost_Top25_04072021_v1.csv")
h2o.saveModel(rf_xgboost, path = getwd(), force =TRUE)



