
# 4A leakge_prod removed dmfeed01272.dbo.fd_molina_clm_v2 pv_clm from claims query - drg and claim type not used in modeling

# V1O_leakage rests the target for feture reduction for OCE to leakage
# V1A based up FL blue


#scp betos20.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_family_level.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_level1.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_level2.txt dless1@apsrd9425:/home/dless1/molina

# 5B  "/home/dless1/molina/ensemble/ensemble_binomial"


# 2b go back in 100 day chunks each output file is a different name
#by batch number
# 1: 30-130, 2: 131-160, 3: 161-190 4: 191 - 220 5: 221 - 250  6: 251 - 280 7: 281-310 8: 311-340 9: 341-365

# V2d work off of feeds feeds are weekly


setwd("~/molina")

# files restore
# claims <- readRDS( file="claims.Rda")
# claims <- readRDS( file="claims.Rda")
# claims <- readRDS( file="claims.Rda")
# FIPS2 <- readRDS( file="FIPS2.Rda")
# DX_claim <- readRDS( file="DX_claim.Rda")
# Leakage_test3 <- readRDS( file="Leakage_test3.Rda")
# charlson_scores <- readRDS( file="charlson_scores.Rda")
# elixhauser_scores <- readRDS( file="elixhauser_scores.Rda")
# CCS_Dummy_test3 <- readRDS( file="CCS_Dummy_test3.Rda")
# POS2 <- readRDS( file="POS2.Rda")
# CPT2 <- readRDS( file="CPT2.Rda")
# PROV_TYPE2 <- readRDS( file="PROV_TYPE2.Rda")
# AHRQ_1 <- readRDS(file="AHRQ_1.Rda")
# base1 <- readRDS(file="base1.Rda")
# base2 <- readRDS(file="base2.Rda")

# claims <- readRDS( file="claims_prod.Rda")
# #FIPS2 <- readRDS( file="FIPS2_prod.Rda")
# DX_claim <- readRDS( file="DX_claim.Rda")
# Leakage_test3 <- readRDS( file="Leakage_test3.Rda")
# charlson_scores <- readRDS( file="charlson_scores_prod.Rda")
# elixhauser_scores <- readRDS( file="elixhauser_scores_prod.Rda")
#  CCS_Dummy_test3 <- readRDS( file="CCS_Dummy_test3_prod.Rda")
# POS2 <- readRDS( file="POS2_prod.Rda")
# # CPT2 <- readRDS( file="CPT2_prod.Rda")
# PROV_TYPE2 <- readRDS( file="PROV_TYPE2_prod.Rda")
#  AHRQ_1 <- readRDS(file="AHRQ_1_prod.Rda")
# base1 <- readRDS(file="base1_prod.Rda")
# base2 <- readRDS(file="base2_prod.Rda")

library(comorbidity)
library(RODBC)
library(sqldf)
library(dplyr)


library(dummies)
# #library(tcltk)
# #library(smbinning)
# library(DMwR)
# library(randomForest)
# library(data.table)
# library(discretization)
# library(ggplot2)
# #library(dataMaid)
# #library(e1071)
# ##library(C51)
# library(lubridate)
# library(caret)
# library(h2o)
# library(ROCR)
# #library(pROC)
# library(h2o)
# h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)
#library(h2oEnsemble)

conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;DATABASE=racer01272;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')
conn2 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=Dbswp0809.aimhealth.com;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')


# feeds <- sqlQuery( conn1, "select max(feed_id) as mx from  racer01272.dbo.claim (nolock) where feed_id != 999 ")
# 
# feedspaid <- sqlQuery( conn1, "select max(DATE_PAID) as mx from dmfeed01272.dbo.fd_molina_clm_v2 where feed_id != 999 ")
# 
# feedspaid2 <- sqlQuery( conn1, "select max(DATE_PAID) as mx from racer01272.dbo.claim  where feed_id != 999 ")
# 
# 
# feedspp <- sqlQuery( conn1, "select max(feed_id) as mx from dmfeed01272.dbo.fd_molina_clm_v2 where feed_id != 999 ")
# 
# funk<- sqlTables(
#   conn1  )
# member_table <- sqlQuery( conn1, " select * from racer01272.dbo.MEMBER (nolock)",max=10  ) 
# 

# last feed for invoiced is 295 
# use 281 -292 for model and 293-95 for OSOD

claims <- sqlQuery(
  conn1,
  "select
distinct
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE,
MEM.LAST_NAME
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
INNER JOIN racer01272.dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and clm.amt_paid > 0
and cs.status_code in (0,-1)
and cs.current_status = 1
and clm.amt_paid > 0
AND clm.feed_id = 375")

saveRDS(claims, file="claims_prod.Rda")
# claims<- readRDS(file="claims_prod.Rda")


##Pulling Dx codes

DX_claim  <- sqlQuery(
  conn1,
  " select
DISTINCT CLM.CLAIM_ID,
DX.ICD9_CODE,
DX.PROJECT_ID,
DX.ICD9_TYPE,
DX.ADMITTING_CODE,
DX.PRINCIPAL_CODE,
DX.ORDER_IN_CLAIM,
DX.CLAIM_LINE_ID,
DX.FEED_ID
FROM  dbo.CLAIM CLM   with (nolock)
INNER JOIN dbo.ICD9 DX  with (nolock)
ON CLM.CLAIM_ID = DX.CLAIM_ID
where DX.ORDER_IN_CLAIM <= 4 
AND clm.feed_id = 375
order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc")


saveRDS(DX_claim, file="DX_claim_prod.Rda")

DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)
DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

#charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson",mc.cores=0)
#elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser",mc.cores=0)

detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

saveRDS(charlson_scores, file="charlson_scores_prod.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

saveRDS(elixhauser_scores, file="elixhauser_scores_prod.Rda")
#  elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")


#####
# AHRQ comorbidities
library(icd)

AHRQ_1 <- icd_comorbid_ahrq(DX_claimids_Diag, visit_name = 'CLAIM_ID', icd_name = 'ICD9_CODE', return_df = TRUE,
                            return_binary = FALSE)

AHRQ_1$CLAIM_ID <- as.character(AHRQ_1$CLAIM_ID)
cols <- sapply(AHRQ_1, is.logical)

AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.numeric)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.character)
AHRQ_1$CLAIM_ID <- as.integer(AHRQ_1$CLAIM_ID)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.factor)
colnames(AHRQ_1) <- paste("AHRQ", colnames(AHRQ_1), sep = "_")
AHRQ_1$CLAIM_IDx <- AHRQ_1$AHRQ_CLAIM_ID
AHRQ_1$AHRQ_CLAIM_ID <- NULL

saveRDS(AHRQ_1, file="AHRQ_1_prod.Rda")









####CCS categories


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)



# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category, c.multi_desc 
from DX_claim d left join CCS c on d.ICD9_CODE = c.ICD10_Code
order by d.CLAIM_ID")

#DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), '0', DX_CCS$CCS_Category)
DX_CCS$multi_desc  <- ifelse(is.na(DX_CCS$multi_desc ), 'missing', DX_CCS$multi_desc )

#DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
DX_CCS$multi_desc <-as.factor(DX_CCS$multi_desc)

### One hot encoding of CCS variables #####

#CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from DX_CCS order by CLAIM_ID")




## Making a wide table
#CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc, sep= "_"))

#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))


saveRDS(CCS_Dummy_test3, file="CCS_Dummy_test3_prod.Rda")

##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID, claim_place_of_service as POS from claims")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor)
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
saveRDS(POS2, file="POS2_prod.Rda")

icd10codes<-sqldf('select distinct ICD10_CODE from DX_claim')



icd10codes_leakage<-sqldf("select * from icd10codes where    ICD10_CODE in(
'R62.50', 'Z51.0', 'I10', 'F80.9', 'Z51.11', 'N18.6', 'E11.9', 'F82', 'R62.0', 'R69', 'F84.0', 'M54.5', 'R07.89', 'R07.9', 'F80.2', 'R10.9', 'N39.0', 'R11.2',
'O99.89', 'M54.2', 'G80.9', 'M54.9', 'C61', 'F03.90', 'M43.6', 'R51', 'F10.129', 'K52.9', 'J44.1', 'S01.01XA', 'S01.81XA', 'G30.9', 'J44.9', 'R55', 'F80.0', 'G47.33',
'M19.90', 'A41.9', 'R45.851', 'J06.9', 'O26.891', 'R27.8', 'G54.0', 'R56.9', 'F32.9', 'M62.81', 'E86.0', 'E11.621', 'G40.909', 'R26.9', 'F33.2', 'M25.561', 'F80.1',
'C53.9', 'R10.13', 'I50.9', 'S09.90XA', 'A41.89', 'Z00.129', 'O20.0', 'R29.898', 'Z51.12', 'R53.1', 'O26.893', 'R41.82', 'E11.8', 'J18.9', 'B34.9', 'O26.892',
'I63.9', 'F33.9', 'F31.9', 'O34.211', 'M06.9', 'R11.10', 'F41.9', 'R05', 'K59.00', 'Q90.9', 'R10.31', 'O60.03', 'O20.9', 'M25.562', 'Z20.2', 'F10.10', 'Z51.89',
'F20.9', 'E87.6', 'K29.00', 'R47.9', 'G35', 'C10.8', 'E11.65', 'O21.9', 'M62.830', 'R42', 'J45.909', 'C16.8', 'G89.29', 'K35.80', 'C34.92', 'J45.901', 'F79',
'E11.3513', 'O03.9', 'R26.89', 'L03.116', 'J20.9', 'S61.216D', 'N10', 'K02.9', 'R06.02', 'K85.90', 'G43.909', 'I61.9', 'N17.9', 'J40', 'R50.9', 'M15.0', 'R10.84',
'F11.20', 'M86.9', 'F84.9')")

icd10codes_leakage$ICD10_CODE<-as.character(icd10codes_leakage$ICD10_CODE)
icd10codes_leakage$icd10_leakage<-gsub(".","",icd10codes_leakage$ICD10_CODE,fixed=TRUE)


DX_leakage <- sqldf("select DISTINCT d.*,  c.icd10_leakage as ICD10_CODE_Leakage from
DX_claim d left join icd10codes_leakage c on d.ICD9_CODE = c.icd10_leakage
order by d.CLAIM_ID ")

##setting up Leakage codes to be 1
DX_leakage$ICD10_CODE_Leakage[is.na(DX_leakage$ICD10_CODE_Leakage)]<-0
DX_leakage$ICD10_CODE_Leakage<-ifelse(DX_leakage$ICD10_CODE_Leakage==0,0,1)
DX_leakage$ICD10_CODE_Leakage <- as.numeric(DX_leakage$ICD10_CODE_Leakage)
Leakage_test <- sqldf("select DISTINCT CLAIM_ID, ICD10_CODE_Leakage from DX_leakage")

# group by client id
Leakage_test2 <- Leakage_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
Leakage_test2$CLAIM_ID <- as.character(Leakage_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Leakage_test3 <- Leakage_test2 %>% mutate_if(is.numeric,
                                             function(x) case_when(
                                               x >= 1 ~ 1,
                                               x == 0 ~ 0
                                             )
)
Leakage_test3 <- lapply(Leakage_test3, factor)
Leakage_test3 <- as.data.frame(Leakage_test3)
Leakage_test3$CLAIM_ID <- as.numeric(as.character(Leakage_test3$CLAIM_ID))



saveRDS(Leakage_test3, file="Leakage_test3_prod.Rda")


table(Leakage_test$ICD10_CODE_Leakage)
prop.table(table(Leakage_test$ICD10_CODE_Leakage))








BETOS<-read.csv("betos20.txt", header=TRUE, sep="\t")


CPT <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID,  CLAIM_LINE_CPT as CPT from claims
             where CPT != 'NA'")


CPT <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from CPT b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")


CPT$ICD10_CODE_Leakage <- ifelse(is.na(CPT$ICD10_CODE_Leakage), 0, 
                                 CPT$ICD10_CODE_Leakage)


#CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c inner JOIN BETOS b
#             ON c.CPT = b.HCPCS")


CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c LEFT JOIN BETOS b
             ON c.CPT = b.HCPCS")

CPT_OVP <- sqldf("select distinct claim_ID, ICD10_CODE_Leakage from CPT")
# for orphan betos, use CPT

CPT$BETOS_20 <-  ifelse(is.na(CPT$BETOS_20),CPT$CPT,CPT$BETOS_20)

CPT_b <- sqldf("select distinct CLAIM_ID, BETOS_20 from CPT")
CPT_b$BETOS_20 <- as.factor(CPT_b$BETOS_20)

CPT_b <- cbind(CPT_b, dummy(CPT_b$BETOS_20, sep= "_"))

#replace with betos
colnames(CPT_b)<-gsub("CPT_b","BETOS_20",colnames(CPT_b))

CPT_b$BETOS_20 <- NULL



# temp make id character
CPT$CLAIM_ID <- as.character(CPT$CLAIM_ID)


# new loop by to split CPT into columns split 10 ways
###############################################################


pid <- as.data.frame(CPT_b[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'



CPT_b$CLAIM_ID <- NULL

cpt_test2 <- split.default(CPT_b, gl(ncol(CPT_b)/10, 10))

number_data_frames <- as.integer(length(cpt_test2))




hcpc1 <- cpt_test2[[1]]
hcpc1 <- cbind(pid,hcpc1)
CPT1 <- hcpc1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  hcpc <- cpt_test2[[i]]
  hcpc <- cbind(pid,hcpc)
  
  hcpc3 <- hcpc %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(hcpc3)[1] <- 'CLAIM_IDx'
  
  CPT1<- cbind( CPT1,  hcpc3)
  CPT1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}


rm(cpt_test2)






# group by client id
#CPT1 <- CPT_b %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor)
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character(CPT2$CLAIM_ID))





CPT2 <- cbind(CPT_OVP$ICD10_CODE_Leakage,CPT2)
# #rename
names(CPT2)[1] <- 'ICD10_CODE_Leakage'

saveRDS(CPT2, file="CPT2_prod.Rda")

CPT2$ICD10_CODE_Leakage <- as.factor(as.character(CPT2$ICD10_CODE_Leakage))
#CPT2$CLAIM_ID <- NULL
rm(CPT1)
rm(CPT_b)


####### Configuring Provider city#########


FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


claims$ZIP <-  ifelse(is.na(claims$ZIPCODE),claims$ALTERNATE_ZIPCODE,claims$ZIPCODE)
claims$ZIP <-  ifelse(is.na(claims$ZIP),'missing',claims$ZIP)


claims$zip5 <- substr(claims$ZIP,1,5)

claims2 <- claims

claims2 <- data.frame(r_index = row.names(claims2), claims2)

claims2 <- sqldf("select v.*, f.COUNTY from   claims2 v left join FIPS f
                 ON v.zip5 = f.zip group by v.r_index
                          " )

claims2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from claims2 v left join USDA f
ON  v.COUNTY = f.FIPS  group by v.r_index")

claims2$COUNTY <-  ifelse(is.na(claims2$COUNTY),'missing',claims2$COUNTY)
claims2$USDA_urban_rural <- ifelse(is.na(claims2$USDA_urban_rural),0,claims2$USDA_urban_rural)



# use FIPS instead
FIPS <- sqldf("select DISTINCT claim_id as CLAIM_ID,  COUNTY from claims2")

FIPS <- cbind(FIPS, dummy(FIPS$COUNTY , sep= "_"))

FIPS$FIPS_missing <- NULL



# new group by methodology
pid <- as.data.frame(FIPS[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'


FIPS$CLAIM_ID <- NULL

fips_test2 <- split.default(FIPS, gl(ncol(FIPS)/10, 10))

number_data_frames <- as.integer(length(fips_test2))

###############################################################

county1 <- fips_test2[[1]]
county1 <- cbind(pid,county1)
FIPS1 <- county1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  county <- fips_test2[[i]]
  county <- cbind(pid,county)
  
  county3 <- county %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(county3)[1] <- 'CLAIM_IDx'
  
  FIPS1 <- cbind( FIPS1,  county3)
  FIPS1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}

rm(fips_test2)





# group by client id
#FIPS1 <- FIPS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
FIPS1$CLAIM_ID <- as.character(FIPS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
FIPS2 <- FIPS1 %>% mutate_if(is.numeric,
                             function(x) case_when(
                               x >= 1 ~ 1,
                               x == 0 ~ 0
                             )
)

FIPS2 <- lapply(FIPS2, factor)
FIPS2<- as.data.frame(FIPS2)
FIPS2$CLAIM_ID <- as.numeric(as.character((FIPS2$CLAIM_ID)))
FIPS2$COUNTY <- NULL
saveRDS(FIPS2, file="FIPS2_prod.Rda")


###### Configuring Provider Type#######
PROV_TYPE <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID,  pv_provider_speciality as PROV_TYPE from claims")

PROV_TYPE <- cbind(PROV_TYPE, dummy(PROV_TYPE$PROV_TYPE , sep= "_"))

PROV_TYPE$CLAIM_ID <- as.character(PROV_TYPE$CLAIM_ID)
# group by client id
PROV_TYPE1 <- PROV_TYPE %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
PROV_TYPE1$CLAIM_ID <- as.character(PROV_TYPE1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_TYPE2 <- PROV_TYPE1 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_TYPE2 <- lapply(PROV_TYPE2, factor)
PROV_TYPE2 <- as.data.frame(PROV_TYPE2)
PROV_TYPE2$CLAIM_ID <- as.numeric(as.character((PROV_TYPE2$CLAIM_ID)))
PROV_TYPE2$PROV_TYPE <- NULL

saveRDS(PROV_TYPE2, file="PROV_TYPE2_prod.Rda")


####  creating new features

# use scale / normalize library here
library(BBmisc)

claims$ratio_billed_to_paid<-claims$claim_amt_billed /claims$claim_amt_paid
claims$ratio_billed_to_paid <- normalize(claims$ratio_billed_to_paid, method="range", range=c(0,1))


claims$PATIENT_AGE_NORM <- normalize(claims$claim_patient_age, method="range", range=c(0,1))

claims$Days_of_service <- difftime(claims$claim_date_of_service_end ,
                                            claims$claim_date_of_service_beg,
                                            units = c("days"))

claims$Days_of_service <- as.numeric(claims$Days_of_service)

claims$Days_of_service <-  normalize(claims$Days_of_service, method="range", range=c(0,1))

# makeDataReport(claims, vol="1", render = FALSE,
#                replace = TRUE, openResult = FALSE, codebook = TRUE,
#                reportTitle = "claims - Report")




claims$claim_principal_diag <- as.character(claims$claim_principal_diag)
claims$claim_principal_diag <- gsub(".","",claims$claim_principal_diag, fixed = TRUE)

saveRDS(claims, file="claims_prod.Rda")
#  claims <- readRDS( file="claims_prod.Rda")
####### Creating a target variable for Leakage to perform dimensional reduction############


claims<-claims[order(claims$claim_id),]
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
#Merging with cormorbidities

count_claim_ids <- sqldf("select distinct claim_id from claims")



base1 <- sqldf("select distinct claim_id , claim_no, PATIENT_AGE_NORM,
Days_of_service, ratio_billed_to_paid , 
               claim_patient_gender
               from claims ")

charlson_scores$CLAIM_ID <- as.numeric(charlson_scores$CLAIM_ID )



base1 <-sqldf("select distinct b.*, c.wscore as Charlson_score from  base1 b
             left join charlson_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

# lekage dx flag


base1 <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from base1 b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")

base1$ICD10_CODE_Leakage <- ifelse(is.na(base1$ICD10_CODE_Leakage), 0, 
                                   base1$ICD10_CODE_Leakage)


base1$Charlson_score <-  ifelse(is.na(base1$Charlson_score),1,base1$Charlson_score)


elixhauser_scores$CLAIM_ID<-as.numeric(elixhauser_scores$CLAIM_ID)

base1 <-sqldf("select distinct b.*, c.score as elix_score from  base1 b
             left join elixhauser_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

base1$elix_score <-  ifelse(is.na(base1$elix_score),0,base1$elix_score)

#########################################################################################

# match fields to model featrues


old_model<- readRDS(file="base2.Rda")

# extract the column names
field1 <- old_model %>% select(starts_with("AHRQ"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- AHRQ_1[, names(AHRQ_1) %in% field12$mycol]


AHRQ_2 <- cbind(AHRQ_1$CLAIM_ID,field13 )
names(AHRQ_2)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join AHRQ_2 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")


base1$CLAIM_IDx <- NULL


base1 <- mutate_at(base1, vars(starts_with("AHRQ_")),
                   ~replace(., is.na(.), 0))


# extract the column names
field1 <- old_model %>% select(starts_with("CCS"))


### Merging with CCS
# CCS dx
# chould have 23 fields
CCS_Dummy_test3$CLAIM_IDx <- CCS_Dummy_test3$CLAIM_ID

CCS_Dummy_test3$CLAIM_ID <- NULL

base1<- sqldf("SELECT DISTINCT b.*, c.* from base1 b left join CCS_Dummy_test3 c
                               on b.CLAIM_ID = c.CLAIM_IDx")




base1 <- mutate_at(base1, vars(starts_with("CCS_")),
                   ~replace(., is.na(.), 0))

base1$CLAIM_IDx <- NULL


##### Merging with POS

# extract the column names
field1 <- old_model %>% select(starts_with("POS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- POS2[, names(POS2) %in% field12$mycol]


POS3 <- cbind(POS2$CLAIM_ID,field13 )
names(POS3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join POS3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("POS_")),
                   ~replace(., is.na(.), 0))


# POS2$CLAIM_IDx <- POS2$CLAIM_ID
# POS2$CLAIM_ID <- NULL
# 
# rf_pos1 <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, POS2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_pos1$claim_id <- NULL
# rf_pos1$CLAIM_IDx <- NULL
# rf_pos1$POS_NA <- NULL
# 
# 
# rf_pos1$ICD10_CODE_Leakage <- as.factor(rf_pos1$ICD10_CODE_Leakage)
# 
# rf_pos1 <- randomForest(ICD10_CODE_Leakage~. ,data=rf_pos1, ntree=500)
# 
# rf_pos1_importance <- as.data.frame(importance(rf_pos1))
# 
# rf_pos1_importance <- data.frame(POS = row.names(rf_pos1_importance), rf_pos1_importance)
# 
# rf_pos1_importance_tile <- mutate(rf_pos1_importance, 
#                  tiles = ntile(rf_pos1_importance$MeanDecreaseGini, 4))
# 
# rf_pos1_importance <- sqldf("select * from rf_pos1_importance_tile where tiles = 4")
# 
# 
# # rf_pos1_importance <-rf_pos1_importance_tile %>%
# #   filter(rank(desc(MeanDecreaseGini)) <= 10)
# 
# saveRDS(rf_pos1_importance, file="rf_pos1_importance_prod.Rda")
# 
# 
# 
# POS_match <- POS2[, names(POS2) %in% rf_pos1_importance$POS]
# base1 <- cbind(base1, POS_match)
# 
# 
# base1 <- mutate_at(base1, vars(starts_with("POS_")),
#                    ~replace(., is.na(.), 0))


# get only the columns that are in the original base 2


# CPT

# extract the column names
field1 <- old_model %>% select(starts_with("BETOS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- CPT2[, names(CPT2) %in% field12$mycol]


CPT3 <- cbind(CPT2$CLAIM_ID,field13 )
names(CPT3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join CPT3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("BETOS_")),
                   ~replace(., is.na(.), 0))
















#################################### Feature reduction of CPT variables#####

# CPT2$CLAIM_IDx <- CPT2$CLAIM_ID
# CPT2$CLAIM_ID <- NULL
# 
# rf_CPT1 <- sqldf("select b.CLAIM_ID, b.OVP, p.* from base1 b, CPT2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_CPT1$claim_id <- NULL
# rf_CPT1$CLAIM_IDx <- NULL
# rf_CPT1$CPT2_NA <- NULL
# 
# 
# set.seed(77)
# 
# rf_CPT1$OVP <- as.factor(rf_CPT1$OVP)
# 
# rf_CPT1 <- randomForest(OVP~. ,data=rf_CPT1, ntree=500)
# 
# rf_CPT1_importance <- as.data.frame(importance(rf_CPT1))
# 
# rf_CPT1_importance <- data.frame(CPT = row.names(rf_CPT1_importance), rf_CPT1_importance)
# 
# rf_CPT1_importance_tile <- mutate(rf_CPT1_importance, 
#                                   tiles = ntile(rf_CPT1_importance$MeanDecreaseGini, 4))
# 
# rf_CPT1_importance <- sqldf("select * from rf_CPT1_importance_tile where tiles = 4")



# rf_CPT1_importance <-rf_CPT1_importance %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 20)

#saveRDS(rf_CPT1_importance, file="rf_CPT1_importance_prod.Rda")



# CPT2_match <- CPT2[, names(CPT2) %in% rf_CPT1_importance$CPT]
# 
# CPT2_match <- cbind(CPT1$CLAIM_ID, CPT2_match)
# names(CPT2_match)[1] <- 'CLAIM_IDx'
# 
# base1<- sqldf("select b.*, c.* from base1 b left join CPT2_match c
#                on b.CLAIM_ID = c.CLAIM_IDx")
# 
# base1 <- mutate_at(base1, vars(starts_with("BETOS_")),
#                    ~replace(., is.na(.), 0))
# 
# base1$CLAIM_IDx <- NULL


##################################################  FIPS


# extract the column names
field1 <- old_model %>% select(starts_with("FIPS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- FIPS2[, names(FIPS2) %in% field12$mycol]


FIPS3 <- cbind(FIPS2$CLAIM_ID,field13 )
names(FIPS3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join FIPS3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("FIPS_")),
                   ~replace(., is.na(.), 0))




# FIPS2$CLAIM_IDx <- FIPS2$CLAIM_ID
# FIPS2$CLAIM_ID <- NULL
# 
# rf_FIPS <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, FIPS2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_FIPS$claim_id <- NULL
# rf_FIPS$CLAIM_IDx <- NULL
# rf_FIPS$CPT2_NA <- NULL
# 
# 
# set.seed(77)
# 
# rf_FIPS$ICD10_CODE_Leakage <- as.factor(rf_FIPS$ICD10_CODE_Leakage)
# 
# rf_FIPS <- randomForest(ICD10_CODE_Leakage~. ,data=rf_FIPS, ntree=500)
# 
# rf_FIPS_importance <- as.data.frame(importance(rf_FIPS))
# 
# rf_FIPS_importance <- data.frame(FIPS = row.names(rf_FIPS_importance), rf_FIPS_importance)
# 
# 
# rf_FIPS_importance_tile <- mutate(rf_FIPS_importance, 
#                                   tiles = ntile(rf_FIPS_importance$MeanDecreaseGini, 4))
# 
# rf_FIPS_importance <- sqldf("select * from rf_FIPS_importance_tile where tiles = 4")
# 
# 
# # rf_FIPS_importance <-rf_FIPS_importance %>%
# #   filter(rank(desc(MeanDecreaseGini)) <= 20)
# 
# saveRDS(rf_FIPS_importance, file="rf_FIPS_importance_prod.Rda")
# 
# 
# FIPS_match <- FIPS2[, names(FIPS2) %in% rf_FIPS_importance$FIPS]
# base1 <- cbind(base1, FIPS_match)
# 
# 
# base1 <- mutate_at(base1, vars(starts_with("FIPS_")),
#                    ~replace(., is.na(.), 0))





##############################################################################################



# extract the column names
field1 <- old_model %>% select(starts_with("PROV_TYPE"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- PROV_TYPE2[, names(PROV_TYPE2) %in% field12$mycol]


PROV_TYPE3 <- cbind(PROV_TYPE2$CLAIM_ID,field13 )
names(PROV_TYPE3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join PROV_TYPE3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("PROV_TYPE_")),
                   ~replace(., is.na(.), 0))

# 
# # provider type targeted feature reduction
# PROV_TYPE2$CLAIM_IDx <- PROV_TYPE2$CLAIM_ID
# PROV_TYPE2$CLAIM_ID <- NULL
# 
# rf_PROV_TYPE <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, PROV_TYPE2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_PROV_TYPE$claim_id <- NULL
# rf_PROV_TYPE$CLAIM_IDx <- NULL
# rf_PROV_TYPE$CPT2_NA <- NULL
# 
# 
# set.seed(77)
# 
# rf_PROV_TYPE$ICD10_CODE_Leakage <- as.factor(rf_PROV_TYPE$ICD10_CODE_Leakage)
# 
# rf_PROV_TYPE <- randomForest(ICD10_CODE_Leakage ~. ,data=rf_PROV_TYPE, ntree=500)
# 
# rf_PROV_TYPE_importance <- as.data.frame(importance(rf_PROV_TYPE))
# 
# rf_PROV_TYPE_importance <- data.frame(PROV_TYPE = row.names(rf_PROV_TYPE_importance), rf_PROV_TYPE_importance)
# 
# 
# rf_PROV_TYPE_importance_tile <- mutate(rf_PROV_TYPE_importance, 
#                                   tiles = ntile(rf_PROV_TYPE_importance$MeanDecreaseGini, 4))
# 
# rf_PROV_TYPE_importance <- sqldf("select * from rf_PROV_TYPE_importance_tile where tiles = 4")
# 
# 
# 
# # rf_PROV_TYPE_importance <-rf_PROV_TYPE_importance %>%
# #   filter(rank(desc(MeanDecreaseGini)) <= 20)
# 
# saveRDS(rf_PROV_TYPE_importance, file="rf_PROV_TYPE_importance_prod.Rda")
# 
# PROV_TYPE_match <- PROV_TYPE2[, names(PROV_TYPE2) %in% rf_PROV_TYPE_importance$PROV_TYPE]
# base1 <- cbind(base1, PROV_TYPE_match)
# 
# 
# base1 <- mutate_at(base1, vars(starts_with("PROV_TYPE_")),
#                    ~replace(., is.na(.), 0))








# remove missings
base1$claim_patient_gender<- ifelse(is.na(base1$claim_patient_gender), 'X', 
                                    base1$claim_patient_gender)


base2 <- sqldf("select * from base1 where PATIENT_AGE_NORM IS NOT NULL")

base2 <- lapply(base2, factor)

base2$claim_id  <- as.numeric(as.character(base2$claim_id))
base2$claim_no  <- NULL
base2$PATIENT_AGE_NORM  <- as.numeric(as.character(base2$PATIENT_AGE_NORM))
base2$Days_of_service  <- as.numeric(as.character(base2$Days_of_service))
base2$ratio_billed_to_paid  <- as.numeric(as.character(base2$ratio_billed_to_paid))
base2$Charlson_score  <- as.numeric(as.character(base2$Charlson_score))
base2$elix_score  <- as.numeric(as.character(base2$elix_score))
base2 <- as.data.frame(base2)
base2$PROV_TYPE_NA <-  NULL
base2$CCS_missing <- NULL



empty_old_model <- sqldf("select * from old_model where CLAIM_ID = 2")

empty_old_model

#library(gtools)
#base3 <- smartbind(empty_old_model, base2)

base3 <- rbind(
  data.frame(c(empty_old_model, sapply(setdiff(names(base2), names(empty_old_model)), function(x) NA))),
  data.frame(c(base2, sapply(setdiff(names(empty_old_model), names(base2)), function(x) NA)))
)

base3[is.na(base3)] <- 0


saveRDS(base1, file="base1_leakage_prod.Rda")
saveRDS(base2, file="base2_leakage_prod.Rda")
saveRDS(base3, file="base3_leakage_prod.Rda")

# base1 <- readRDS(file="base1_leakage_prod.Rda")
#base2 <- readRDS(file="base2_leakage_prod.Rda")

# base3 <- readRDS(file="base3_leakage_prod.Rda")


# model development
# inv_id <- sqldf("select distinct claim_id, INV from claims_OVP_invoiced")
# 
# base2_saffari <- sqldf("select b.*, i.INV from base3 b, inv_id i
#                        where b.claim_id = i.claim_id")
# 
# saveRDS(base2_saffari, file="base2_saffari_prod.Rda")
# 





# library(dataMaid)
# 
# # make datmaid codebook
# # Instructions to open:  do file open rmd file; use Knit to render as an HTML doc
# makeDataReport(base3, vol="1", render = FALSE,
#                replace = TRUE, openResult = FALSE, codebook = TRUE,
#                reportTitle = "Model Data - Report")
# 


library(h2o)
#h2o.init()
h2o.init(port=54333)
library(h2oEnsemble)


base3$claim_id<-NULL

# V5B leakage 2/1/21
rf_95<- h2o.loadModel("/home/dless1/molina/ensemble/ensemble_binomial5")

# gbm model bckup if ensemble does not work 2/1/21
#rf_95<- h2o.loadModel("/home/dless1/molina/gbm/GBM_model_R_1643730457276_1")

data_to_score <- as.h2o(base3)



pred <- h2o.predict(object = rf_95, newdata = data_to_score)


pred_df <- as.data.frame(pred )

my_threshold <- .5
pred_df[,"predict"] <- pred_df[,"p0"] >= my_threshold

#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


# recovery model


base2_saffari <- readRDS(file = "base2_saffari.Rda")


saff1 <- sqldf("select * from base2_saffari where claim_id = 7")


# recovery model

saff1$ claim_id <- NULL
saff1$OVP <- NULL
saff1$INV <-NULL


saff2<-  data.frame(c(base2, sapply(setdiff(names(saff1), names(base2)), function(x) NA)))

saff2[is.na(saff2)] <- 0

xg_saffari<- h2o.loadModel("/home/dless1/molina/xgboost/XGBoost_model_R_1629222360940_6970")

data_to_score_jungle <- as.h2o(saff2)

pred_jungle <- h2o.predict(object =xg_saffari, newdata = data_to_score_jungle)



# make output files

cl_ids <- base1 %>%
  select(claim_id) 

claim_probabilities <- cbind(cl_ids,pred_df )
claim_probabilities <- sqldf("select distinct d.CLAIM_ID, d.CLAIM_FEED_ID, d.claim_amt_paid,
 c.p0 as P0_overpayment,c.p1  as P1_Overpayment , d.LAST_NAME as member_last_name, DATE_PAID
                               from claim_probabilities c, claims d
                               where d.CLAIM_ID = c.CLAIM_ID ")


claim_probabilities$DATE_PAID <- as.POSIXct(claim_probabilities$DATE_PAID, origin="1970-01-01")
claim_probabilities$days_from_paid_date <- (difftime(Sys.Date(), claim_probabilities$DATE_PAID, units = "days"  ))

claim_probabilities$DATE_PAID <- NULL
claim_probabilities$days_from_paid_date <- as.numeric(claim_probabilities$days_from_paid_date)
# add safari

pred_df_jungle <- as.data.frame(pred_jungle )

pred_df_jungle <- cbind(cl_ids,pred_df_jungle )

claim_probabilities <- sqldf("select p.*, s.p0 as P0_recoverability, p1 as P1_recoverability
                             from claim_probabilities p left join pred_df_jungle s
                             ON p.CLAIM_ID = s.CLAIM_ID")

claim_probabilities$P0_recoverability<- ifelse(is.na(claim_probabilities$P0_recoverability), 0, 
                                               claim_probabilities$P0_recoverability)

claim_probabilities$P1_recoverability<- ifelse(is.na(claim_probabilities$P1_recoverability), 0, 
                                               claim_probabilities$P1_recoverability)

claims_to_investigate_claims<-sqldf("select Claim_id, claim_feed_id,claim_amt_paid,P0_overpayment,P1_Overpayment,P0_recoverability,
P1_recoverability,days_from_paid_date,member_last_name

                                    from claim_probabilities 
                                    order by P1_Overpayment desc")


#order by p1 desc")

# conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
#                          UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')
# 
# sqlSave(conn1,claims_to_investigate_claims,tablename="dbo.molina_feed_364",rownames=FALSE)
# 

#saveRDS(claims_to_investigate_claims, file="claims_to_investigate_claims_feed364.Rda")

conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
                         UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')

sqlSave(conn1,claims_to_investigate_claims,tablename="dbo.molina_feed_375",rownames=FALSE)




h2o.shutdown(prompt  = FALSE)















idx <- sample(seq(1,2), size = nrow(base3), replace = TRUE, prob = c(0.7, 0.3))
train <- base3[idx == 1,]
test <- base3[idx == 2,]

train <- as.h2o(train)
test<-as.h2o(test)
y <- "OVP"
x <- setdiff(names(train), y)
predictors <- setdiff(names(train), y)
response <- "OVP"

gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10)
h2o.varimp(gbm)
summary(gbm)



gbm_2a <- h2o.gbm(x= predictors, y=response, training_frame = train, validation_frame = test, nfolds = 10)
summary(gbm_2a)




# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 10
)

summary(gbm2)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
head(as.data.frame(h2o.varimp(gbm2)),n=10)


rf_h2o_1<- h2o.randomForest(x=x,
                           y = y,
                           training_frame = train,
                           validation_frame = test,
                           ntrees = 100,
                           nfolds = 10,
                           sample_rate = 0.85,
                           fold_assignment = "Modulo",
                           keep_cross_validation_predictions = TRUE,
                           stopping_tolerance = 1e-2,
                           stopping_rounds = 2,
                           seed = 77)


summary(rf_h2o_1)
rf1_var_import <-h2o.varimp(rf_h2o_1)

nfolds <- 10
rf_2 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         ntrees = 500,
                         nfolds = nfolds,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)
summary(rf_2)




rf_3 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         validation_frame = test,
                         ntrees = 500,
                         nfolds = nfolds,
                         nbins = 50,
                         balance_classes = TRUE,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)



summary(rf_3)




# xgboost

nfolds <- 10
xgboost <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 200,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost)
head(as.data.frame(h2o.varimp(xgboost)),n=10)


xgboost500 <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 500,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost500)
head(as.data.frame(h2o.varimp(xgboost500)),n=10)

#h2o.saveModel(xgboost500, path = "xgboost", force =TRUE)
#  "/home/dless1/molina/xgboost/XGBoost_model_R_1628262053429_7942"



nfolds <- 5
xgboost700 <- h2o.xgboost(x=x,
                          y = y,
                          training_frame = train,
                          validation_frame = test,
                          ntrees = 700,
                          nfolds = nfolds,
                          fold_assignment = "Modulo",
                          keep_cross_validation_predictions = TRUE,
                          max_depth = 3,
                          min_rows = 2,
                          learn_rate =0.2,
                          seed = 77)

summary(xgboost700)
head(as.data.frame(h2o.varimp(xgboost700)),n=10)



# ##########
# # h2o ensemble
# 
# stacked ensemble model
# random forest and GBM



# max and min rows based upon above max and min depth
# experiment with fold_assignment "AUTO", "Random", "Modulo", "Stratified"

nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 500,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 500,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)


solo_xgboost700 <- h2o.xgboost(x=x,
                          y = y,
                          training_frame = train,
                          ntrees = 700,
                          nfolds = nfolds,
                          fold_assignment = "Modulo",
                          keep_cross_validation_predictions = TRUE,
                          max_depth = 3,
                          min_rows = 2,
                          learn_rate =0.2,
                          seed = 77)


solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id, solo_xgboost700l@model_id))





perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_xgboost700 <-  h2o.performance(solo_xgboost700, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_xgboost700),
                                 h2o.auc(perf_solo_solo_dl))

ensemble_auc_test <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
pred_ensemble
summary(pred_ensemble)




















h2o.performance(rf_FLBL,newdata=test)
h2o.confusionMatrix(rf_FLBL,newdata=test,threshold=0.4)
#AUC-0.79, percision=0.52 and recall=0.26
healthnet_list3_var_import <-h2o.varimp(rf_FLBL)
#h2o.varimp_plot(rf_FLBL)

healthnet_list3_import <-healthnet_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
healthnet_list3_import$healthnet <- healthnet_list3_import$variable
healthnet_Top25<-as.data.frame(healthnet_list3_import$healthnet)
write.csv(healthnet_Top25,file="FLBLRF_Top25_04072021_v1.csv")
h2o.saveModel(rf_FLBL, path = getwd(), force =TRUE)
### XG Boost
rf_xgboost<- h2o.xgboost(x=x,
                         y = y,
                         training_frame = train,
                        
                         ntrees = 100,
                         nfolds = 10,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         keep_cross_validation_predictions = TRUE,
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         seed = 77)








h2o.performance(rf_xgboost,newdata=test)
h2o.confusionMatrix(rf_xgboost,newdata=test,threshold=0.4)
#AUC-0.82, percision=0.59 and recall=0.33
rf_xgboost_var_import <-h2o.varimp(rf_xgboost)
#h2o.varimp_plot(rf_healthnet)





FLBL_list3_var_import <-FLBL_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
FLBL_list3_var_import$FLBL <- FLBL_list3_var_import$variable
FLBL_Top25<-as.data.frame(FLBL_list3_var_import$FLBL)
write.csv(FLBL_Top25,file="FLBLXgBoost_Top25_04072021_v1.csv")
h2o.saveModel(rf_xgboost, path = getwd(), force =TRUE)

#### Building the recoverability model
base_table7a<-base_table6%>%select (claim_id,NORM_LINE_AMT_PAID,NORM_LINE_AMT_BILLED,Days_of_service,ratio_billed_to_paid,ratio_allowed_to_paid,PATIENT_AGE_NORM,wscore,wscore_ahrq,starts_with("CCS_"),starts_with("POS_"),starts_with("PROV_CITY_"),starts_with("PROV_TYPE_"),starts_with("CPT_"),OVP,INV)
base_table7b<-base_table7a%>%filter(OVP==1)
prop.table(table(base_table7b$INV))

## The test below should confirm that if a claim is  an overpayment iy might or might not have a INV label=1
sqldf("select count(distinct claim_id) from base_table7a where OVP=1 and INV=1")
sqldf("select count(distinct claim_id) from base_table7a where OVP=0 and INV=1")
## The test below should confirm that if a claim is not an overpayment it should definitely have INV label=0


base_table7b$NORM_LINE_AMT_PAID<-as.numeric(base_table7b$NORM_LINE_AMT_PAID)
base_table7b$NORM_LINE_AMT_BILLED<-as.numeric(base_table7b$NORM_LINE_AMT_BILLED)

##### Need to revise here based on the leakage feature reduction###
base_table8a<-sqldf("select
claim_id,
max(NORM_LINE_AMT_PAID) as  NORM_LINE_AMT_PAID,
max(NORM_LINE_AMT_BILLED) as  NORM_LINE_AMT_BILLED,
max(Days_of_service) as  Days_of_service,
max(ratio_billed_to_paid) as  ratio_billed_to_paid,
max(ratio_allowed_to_paid) as  ratio_allowed_to_paid,
max(PATIENT_AGE_NORM) as  PATIENT_AGE_NORM,
max(wscore) as  charlson_score,
max(wscore_ahrq) as  elixhauser_score,
MAX(CCS_45) AS CCS_45,
MAX(CCS_98) AS CCS_98,
MAX(CCS_158) AS CCS_158,
MAX(CCS_138) AS CCS_138,
MAX(CCS_101) AS CCS_101,
MAX(CCS_102) AS CCS_102,
MAX(CCS_53) AS CCS_53,
MAX(CCS_106) AS CCS_106,
MAX(CCS_157) AS CCS_157,
MAX(CCS_251) AS CCS_251,
MAX(CCS_42) AS CCS_42,
MAX(CCS_99) AS CCS_99,
MAX(CCS_59) AS CCS_59,
MAX(CCS_159) AS CCS_159,
MAX(CCS_217) AS CCS_217,
MAX(CCS_161) AS CCS_161,
MAX(CCS_49) AS CCS_49,
MAX(CCS_250) AS CCS_250,
MAX(CCS_24) AS CCS_24,
MAX(CCS_2) AS CCS_2,
MAX(CCS_19) AS CCS_19,
MAX(CCS_84) AS CCS_84,
MAX(CCS_46) AS CCS_46,
MAX(CCS_245) AS CCS_245,
MAX(CCS_29) AS CCS_29,
MAX(POS_65) AS POS_65,
MAX(POS_23) AS POS_23,
MAX(POS_11) AS POS_11,
MAX(POS_22) AS POS_22,
MAX(POS_21) AS POS_21,
MAX(CPT_96417) AS CPT_96417,
MAX(CPT_96375) AS CPT_96375,
MAX(CPT_J1644) AS CPT_J1644,
MAX(CPT_80053) AS CPT_80053,
MAX(CPT_96413) AS CPT_96413,
MAX(CPT_36415) AS CPT_36415,
MAX(CPT_A4657) AS CPT_A4657,
MAX(CPT_83690) AS CPT_83690,
MAX(CPT_J2505) AS CPT_J2505,
MAX(PROV_TYPE_RADIOLOGY) AS PROV_TYPE_RADIOLOGY,
MAX(PROV_TYPE_NEUROLOGY) AS PROV_TYPE_NEUROLOGY,
MAX(PROV_TYPE_SPECIALTY_PHARMACIES) AS PROV_TYPE_SPECIALTY_PHARMACIES,
MAX(PROV_TYPE_PLASTICSURGERY) AS PROV_TYPE_PLASTICSURGERY,
MAX(PROV_CITY_TAMPA) AS PROV_CITY_TAMPA,
MAX(PROV_CITY_ORLANDO) AS PROV_CITY_ORLANDO,
MAX(PROV_CITY_MIAMI) AS PROV_CITY_MIAMI,
MAX(PROV_CITY_PLANTATION) AS PROV_CITY_PLANTATION,
MAX(PROV_CITY_JACKSONVILLE) AS PROV_CITY_JACKSONVILLE,
MAX(PROV_CITY_WESTPALMBEACH) AS PROV_CITY_WESTPALMBEACH,
MAX(PROV_CITY_ATLANTIS) AS PROV_CITY_ATLANTIS,
MAX(PROV_CITY_PENSACOLA) AS PROV_CITY_PENSACOLA,
MAX(PROV_CITY_MARGATE) AS PROV_CITY_MARGATE,
INV
from base_table7b
group by claim_id,INV")

base_table8a$claim_id<-NULL
base_table8a$INV<-as.factor(base_table8a$INV)
base_table8a$ratio_billed_to_paid <-  ifelse(base_table8a$ratio_billed_to_paid==Inf,1,base_table8a$ratio_billed_to_paid)
idx <- sample(seq(1,2), size = nrow(base_table8a), replace = TRUE, prob = c(0.7, 0.3))
train_inv <- base_table8a[idx == 1,]
test_inv <- base_table8a[idx == 2,]

train_inv <- as.h2o(train_inv)
test_inv<-as.h2o(test_inv)
y_inv <- "INV"
x_inv <- setdiff(names(train_inv), y_inv)

rf_FLBL_inv<- h2o.randomForest(x=x_inv,
                               y = y_inv,
                               training_frame = train_inv,
                               validation_frame = test_inv,
                               ntrees = 100,
                               nfolds = 10,
                               sample_rate = 0.85,
                               fold_assignment = "Modulo",
                               keep_cross_validation_predictions = TRUE,
                               stopping_tolerance = 1e-2,
                               stopping_rounds = 2,
                               seed = 77)








h2o.performance(rf_FLBL_inv,newdata=test_inv)
h2o.confusionMatrix(rf_FLBL_inv,newdata=test_inv,threshold=0.4)
#AUC-0.79, percision=0.52 and recall=0.26
FLBLINV_list3_var_import <-h2o.varimp(rf_FLBL_inv)
#h2o.varimp_plot(rf_FLBL)

FLBLINV_list3_var_import<-FLBLINV_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
FLBLINV_list3_var_import$FLBL_INV <- FLBLINV_list3_var_import$variable
FLBLINV_Top25<-as.data.frame(FLBLINV_list3_var_import$FLBL_INV)
write.csv(healthnet_Top25,file="FLBLRFINV_Top25_04072021_v1.csv")
h2o.saveModel(rf_FLBLINV, path = getwd(), force =TRUE)
### XG Boost
FLBLINV_xgboost<- h2o.xgboost(x=x_inv,
                              y = y_inv,
                              training_frame = train_inv,
                              validation_frame = test_inv,
                              ntrees = 100,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              keep_cross_validation_predictions = TRUE,
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)








h2o.performance(FLBLINV_xgboost,newdata=test_inv)
h2o.confusionMatrix(FLBLINV_xgboost,newdata=test_inv,threshold=0.4)


#AUC-0.82, percision=0.59 and recall=0.33
FLBL_list3_var_import <-h2o.varimp(rf_xgboost)
#h2o.varimp_plot(rf_healthnet)




FLBL_list3_var_import <-FLBL_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
FLBL_list3_var_import$FLBL <- FLBL_list3_var_import$variable
FLBL_Top25<-as.data.frame(FLBL_list3_var_import$FLBL)
write.csv(FLBL_Top25,file="FLBLXgBoost_Top25_04072021_v1.csv")
h2o.saveModel(rf_xgboost, path = getwd(), force =TRUE)



