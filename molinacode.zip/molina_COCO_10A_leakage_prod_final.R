

setwd("~/molina")


library(comorbidity)
library(RODBC)
library(sqldf)
library(dplyr)
library(tidyverse)

library(dummies)


conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;DATABASE=racer01272;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')

claims <- sqlQuery(
  conn1,
  "select
distinct
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,clm.INS_GROUP_ID
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE,
MEM.LAST_NAME
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
INNER JOIN racer01272.dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and clm.amt_paid > 0
and cs.status_code in (0,-1)
and cs.current_status = 1
and clm.amt_paid > 0
AND clm.feed_id = 371")


saveRDS(claims, file="claims_prod.Rda")



##Pulling Dx codes

DX_claim  <- sqlQuery(
  conn1,
  " select
DISTINCT CLM.CLAIM_ID,
DX.ICD9_CODE,
DX.PROJECT_ID,
DX.ICD9_TYPE,
DX.ADMITTING_CODE,
DX.PRINCIPAL_CODE,
DX.ORDER_IN_CLAIM,
DX.CLAIM_LINE_ID,
DX.FEED_ID
FROM  dbo.CLAIM CLM   with (nolock)
INNER JOIN dbo.ICD9 DX  with (nolock)
ON CLM.CLAIM_ID = DX.CLAIM_ID
where DX.ORDER_IN_CLAIM <= 4 
AND clm.feed_id = 371
order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc")


saveRDS(DX_claim, file="DX_claim_prod.Rda")

DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)
DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

saveRDS(charlson_scores, file="charlson_scores_prod.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

saveRDS(elixhauser_scores, file="elixhauser_scores_prod.Rda")
#  elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")


#####
# AHRQ comorbidities
library(icd)

AHRQ_1 <- icd_comorbid_ahrq(DX_claimids_Diag, visit_name = 'CLAIM_ID', icd_name = 'ICD9_CODE', return_df = TRUE,
                            return_binary = FALSE)

AHRQ_1$CLAIM_ID <- as.character(AHRQ_1$CLAIM_ID)
cols <- sapply(AHRQ_1, is.logical)

AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.numeric)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.character)
AHRQ_1$CLAIM_ID <- as.integer(AHRQ_1$CLAIM_ID)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.factor)
colnames(AHRQ_1) <- paste("AHRQ", colnames(AHRQ_1), sep = "_")
AHRQ_1$CLAIM_IDx <- AHRQ_1$AHRQ_CLAIM_ID
AHRQ_1$AHRQ_CLAIM_ID <- NULL

saveRDS(AHRQ_1, file="AHRQ_1_prod.Rda")


####CCS categories


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)



# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category, c.multi_desc 
from DX_claim d left join CCS c on d.ICD9_CODE = c.ICD10_Code
order by d.CLAIM_ID")

#DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), '0', DX_CCS$CCS_Category)
DX_CCS$multi_desc  <- ifelse(is.na(DX_CCS$multi_desc ), 'missing', DX_CCS$multi_desc )

#DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
DX_CCS$multi_desc <-as.factor(DX_CCS$multi_desc)

### One hot encoding of CCS variables #####

#CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from DX_CCS order by CLAIM_ID")




## Making a wide table

CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc, sep= "_"))

#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))


saveRDS(CCS_Dummy_test3, file="CCS_Dummy_test3_prod.Rda")

##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID, claim_place_of_service as POS from claims")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor)
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
saveRDS(POS2, file="POS2_prod.Rda")

icd10codes<-sqldf('select distinct ICD10_CODE from DX_claim')


conn_cpt          =  odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=aimdb06.aimhealth.com;DATABASE=racerresearch;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')

ICD10<-sqlQuery(conn_cpt,"select * from dbo.ICD10_Descriptions")
#####Leakage query

leakage_codes=sqlQuery(conn1,"select  leakage.PRINCIPAL_DIAG,count(leakage.PRINCIPAL_DIAG) as count
from racerresearch.dbo.PARS leakage with (nolock)
inner join racer01272.dbo.claim clm
on leakage.claim_no=clm.claim_no
inner join racer01272.dbo.claim_status cs
on cs.claim_id=clm.claim_id
where leakage.PROJECT_ID=1272 and leakage.POST_Optum_leakage_flag='1' and cs.hds_lob_id=3
group by leakage.PRINCIPAL_DIAG")


leakage_codes$ICD10_DIAG<-leakage_codes$PRINCIPAL_DIAG
leakage_codes$PRINCIPAL_DIAG<-gsub(".","",leakage_codes$PRINCIPAL_DIAG,fixed=TRUE)

matches <- c("Unspecified","unspecified", "uncomplicated","not specified","Other")

leakage_code_description<-sqldf("select a.*,b.count, b.ICD10_DIAG from ICD10 a 
                                inner join leakage_codes b on a.ICD10Code=b.PRINCIPAL_DIAG")
##leakge_code_test<-leakage_code_description%>%filter( !grepl('Unspecified|unspecified|uncomplicated|not specified', Description))%>%filter(count>=1000)%>%arrange(desc(count))

leakge_code_test<-leakage_code_description%>%filter( !grepl(paste(matches, collapse = "|"),
                                                            Description))%>%filter(count>=200)%>%arrange(desc(count))



DX_leakage <- sqldf("select DISTINCT d.*,  c.ICD10_DIAG as ICD10_CODE_Leakage from
DX_claim d left join leakge_code_test c on d.ICD10_CODE = c.ICD10_DIAG
order by d.CLAIM_ID ")

##setting up Leakage codes to be 1
DX_leakage$ICD10_CODE_Leakage[is.na(DX_leakage$ICD10_CODE_Leakage)]<-0
DX_leakage$ICD10_CODE_Leakage<-ifelse(DX_leakage$ICD10_CODE_Leakage==0,0,1)
DX_leakage$ICD10_CODE_Leakage <- as.numeric(DX_leakage$ICD10_CODE_Leakage)
Leakage_test <- sqldf("select DISTINCT CLAIM_ID, ICD10_CODE_Leakage from DX_leakage")

# group by client id
Leakage_test2 <- Leakage_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
Leakage_test2$CLAIM_ID <- as.character(Leakage_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Leakage_test3 <- Leakage_test2 %>% mutate_if(is.numeric,
                                             function(x) case_when(
                                               x >= 1 ~ 1,
                                               x == 0 ~ 0
                                             )
)
Leakage_test3 <- lapply(Leakage_test3, factor)
Leakage_test3 <- as.data.frame(Leakage_test3)
Leakage_test3$CLAIM_ID <- as.numeric(as.character(Leakage_test3$CLAIM_ID))



saveRDS(Leakage_test3, file="Leakage_test3.Rda")

table(Leakage_test$ICD10_CODE_Leakage)
prop.table(table(Leakage_test$ICD10_CODE_Leakage))








BETOS<-read.csv("betos20.txt", header=TRUE, sep="\t")


CPT <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID,  CLAIM_LINE_CPT as CPT from claims
             where CPT != 'NA'")


CPT <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from CPT b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")


CPT$ICD10_CODE_Leakage <- ifelse(is.na(CPT$ICD10_CODE_Leakage), 0, 
                                 CPT$ICD10_CODE_Leakage)




CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c LEFT JOIN BETOS b
             ON c.CPT = b.HCPCS")

CPT_OVP <- sqldf("select distinct claim_ID, ICD10_CODE_Leakage from CPT")
# for orphan betos, use CPT

CPT$BETOS_20 <-  ifelse(is.na(CPT$BETOS_20),CPT$CPT,CPT$BETOS_20)

CPT_b <- sqldf("select distinct CLAIM_ID, BETOS_20 from CPT")
CPT_b$BETOS_20 <- as.factor(CPT_b$BETOS_20)

CPT_b <- cbind(CPT_b, dummy(CPT_b$BETOS_20, sep= "_"))

#replace with betos
colnames(CPT_b)<-gsub("CPT_b","BETOS_20",colnames(CPT_b))

CPT_b$BETOS_20 <- NULL



# temp make id character
CPT$CLAIM_ID <- as.character(CPT$CLAIM_ID)


# new loop by to split CPT into columns split 10 ways
###############################################################


pid <- as.data.frame(CPT_b[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'



CPT_b$CLAIM_ID <- NULL

cpt_test2 <- split.default(CPT_b, gl(ncol(CPT_b)/10, 10))

number_data_frames <- as.integer(length(cpt_test2))




hcpc1 <- cpt_test2[[1]]
hcpc1 <- cbind(pid,hcpc1)
CPT1 <- hcpc1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  hcpc <- cpt_test2[[i]]
  hcpc <- cbind(pid,hcpc)
  
  hcpc3 <- hcpc %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(hcpc3)[1] <- 'CLAIM_IDx'
  
  CPT1<- cbind( CPT1,  hcpc3)
  CPT1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}


rm(cpt_test2)






# group by client id


CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor)
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character(CPT2$CLAIM_ID))





CPT2 <- cbind(CPT_OVP$ICD10_CODE_Leakage,CPT2)
# #rename
names(CPT2)[1] <- 'ICD10_CODE_Leakage'

saveRDS(CPT2, file="CPT2_prod.Rda")

CPT2$ICD10_CODE_Leakage <- as.factor(as.character(CPT2$ICD10_CODE_Leakage))
#CPT2$CLAIM_ID <- NULL
rm(CPT1)
rm(CPT_b)


####### Configuring Provider city#########


FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


claims$ZIP <-  ifelse(is.na(claims$ZIPCODE),claims$ALTERNATE_ZIPCODE,claims$ZIPCODE)
claims$ZIP <-  ifelse(is.na(claims$ZIP),'missing',claims$ZIP)


claims$zip5 <- substr(claims$ZIP,1,5)

claims2 <- claims

claims2 <- data.frame(r_index = row.names(claims2), claims2)

claims2 <- sqldf("select v.*, f.COUNTY from   claims2 v left join FIPS f
                 ON v.zip5 = f.zip group by v.r_index
                          " )

claims2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from claims2 v left join USDA f
ON  v.COUNTY = f.FIPS  group by v.r_index")

claims2$COUNTY <-  ifelse(is.na(claims2$COUNTY),'missing',claims2$COUNTY)
claims2$USDA_urban_rural <- ifelse(is.na(claims2$USDA_urban_rural),0,claims2$USDA_urban_rural)



# use FIPS instead
FIPS <- sqldf("select DISTINCT claim_id as CLAIM_ID,  COUNTY from claims2")

FIPS <- cbind(FIPS, dummy(FIPS$COUNTY , sep= "_"))

FIPS$FIPS_missing <- NULL



# new group by methodology
pid <- as.data.frame(FIPS[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'


FIPS$CLAIM_ID <- NULL

fips_test2 <- split.default(FIPS, gl(ncol(FIPS)/10, 10))

number_data_frames <- as.integer(length(fips_test2))

###############################################################

county1 <- fips_test2[[1]]
county1 <- cbind(pid,county1)
FIPS1 <- county1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  county <- fips_test2[[i]]
  county <- cbind(pid,county)
  
  county3 <- county %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(county3)[1] <- 'CLAIM_IDx'
  
  FIPS1 <- cbind( FIPS1,  county3)
  FIPS1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}

rm(fips_test2)





# group by client id


# temp make id character
FIPS1$CLAIM_ID <- as.character(FIPS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
FIPS2 <- FIPS1 %>% mutate_if(is.numeric,
                             function(x) case_when(
                               x >= 1 ~ 1,
                               x == 0 ~ 0
                             )
)

FIPS2 <- lapply(FIPS2, factor)
FIPS2<- as.data.frame(FIPS2)
FIPS2$CLAIM_ID <- as.numeric(as.character((FIPS2$CLAIM_ID)))
FIPS2$COUNTY <- NULL
saveRDS(FIPS2, file="FIPS2_prod.Rda")


###### Configuring Provider Type#######
PROV_TYPE <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID,  pv_provider_speciality as PROV_TYPE from claims")

PROV_TYPE <- cbind(PROV_TYPE, dummy(PROV_TYPE$PROV_TYPE , sep= "_"))

PROV_TYPE$CLAIM_ID <- as.character(PROV_TYPE$CLAIM_ID)
# group by client id
PROV_TYPE1 <- PROV_TYPE %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
PROV_TYPE1$CLAIM_ID <- as.character(PROV_TYPE1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_TYPE2 <- PROV_TYPE1 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_TYPE2 <- lapply(PROV_TYPE2, factor)
PROV_TYPE2 <- as.data.frame(PROV_TYPE2)
PROV_TYPE2$CLAIM_ID <- as.numeric(as.character((PROV_TYPE2$CLAIM_ID)))
PROV_TYPE2$PROV_TYPE <- NULL

saveRDS(PROV_TYPE2, file="PROV_TYPE2_prod.Rda")


####  creating new features

# use scale / normalize library here
library(BBmisc)

claims$ratio_billed_to_paid<-claims$claim_amt_billed /claims$claim_amt_paid
claims$ratio_billed_to_paid <- normalize(claims$ratio_billed_to_paid, method="range", range=c(0,1))


claims$PATIENT_AGE_NORM <- normalize(claims$claim_patient_age, method="range", range=c(0,1))

claims$Days_of_service <- difftime(claims$claim_date_of_service_end ,
                                            claims$claim_date_of_service_beg,
                                            units = c("days"))

claims$Days_of_service <- as.numeric(claims$Days_of_service)

claims$Days_of_service <-  normalize(claims$Days_of_service, method="range", range=c(0,1))

# makeDataReport(claims, vol="1", render = FALSE,
#                replace = TRUE, openResult = FALSE, codebook = TRUE,
#                reportTitle = "claims - Report")




claims$claim_principal_diag <- as.character(claims$claim_principal_diag)
claims$claim_principal_diag <- gsub(".","",claims$claim_principal_diag, fixed = TRUE)

saveRDS(claims, file="claims_prod.Rda")
#  claims <- readRDS( file="claims_prod.Rda")
####### Creating a target variable for Leakage to perform dimensional reduction############


claims<-claims[order(claims$claim_id),]
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
#Merging with cormorbidities

count_claim_ids <- sqldf("select distinct claim_id from claims")



base1 <- sqldf("select distinct claim_id , claim_no, PATIENT_AGE_NORM,
Days_of_service, ratio_billed_to_paid , 
               claim_patient_gender
               from claims ")

charlson_scores$CLAIM_ID <- as.numeric(charlson_scores$CLAIM_ID )



base1 <-sqldf("select distinct b.*, c.wscore as Charlson_score from  base1 b
             left join charlson_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

# lekage dx flag


base1 <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from base1 b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")

base1$ICD10_CODE_Leakage <- ifelse(is.na(base1$ICD10_CODE_Leakage), 0, 
                                   base1$ICD10_CODE_Leakage)


base1$Charlson_score <-  ifelse(is.na(base1$Charlson_score),1,base1$Charlson_score)


elixhauser_scores$CLAIM_ID<-as.numeric(elixhauser_scores$CLAIM_ID)

base1 <-sqldf("select distinct b.*, c.score as elix_score from  base1 b
             left join elixhauser_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

base1$elix_score <-  ifelse(is.na(base1$elix_score),0,base1$elix_score)



insur <- sqldf("select distinct CLAIM_ID as CLAIM_IDx, INS_GROUP_ID from claims")

insur$INS_GROUP_ID <- as.factor(insur$INS_GROUP_ID)
insur$INS_GROUP_ID <- fct_lump(insur$INS_GROUP_ID, n=10)


base1 <-sqldf("select distinct b.*, c.INS_GROUP_ID from  base1 b, insur c
             where  b.claim_id = c.CLAIM_IDx", method = "name_class")

#########################################################################################

# match fields to model featrues


old_model<- readRDS(file="base2.Rda")



# extract the column names
field1 <- old_model %>% select(starts_with("AHRQ"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- AHRQ_1[, names(AHRQ_1) %in% field12$mycol]


AHRQ_2 <- cbind(AHRQ_1$CLAIM_ID,field13 )
names(AHRQ_2)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join AHRQ_2 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")


base1$CLAIM_IDx <- NULL


base1 <- mutate_at(base1, vars(starts_with("AHRQ_")),
                   ~replace(., is.na(.), 0))


# extract the column names
field1 <- old_model %>% select(starts_with("CCS"))


### Merging with CCS
# CCS dx
# chould have 23 fields
CCS_Dummy_test3$CLAIM_IDx <- CCS_Dummy_test3$CLAIM_ID

CCS_Dummy_test3$CLAIM_ID <- NULL

base1<- sqldf("SELECT DISTINCT b.*, c.* from base1 b left join CCS_Dummy_test3 c
                               on b.CLAIM_ID = c.CLAIM_IDx")




base1 <- mutate_at(base1, vars(starts_with("CCS_")),
                   ~replace(., is.na(.), 0))

base1$CLAIM_IDx <- NULL


##### Merging with POS

# extract the column names
field1 <- old_model %>% select(starts_with("POS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- POS2[, names(POS2) %in% field12$mycol]


POS3 <- cbind(POS2$CLAIM_ID,field13 )
names(POS3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join POS3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("POS_")),
                   ~replace(., is.na(.), 0))




# CPT

# extract the column names
field1 <- old_model %>% select(starts_with("BETOS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- CPT2[, names(CPT2) %in% field12$mycol]


CPT3 <- cbind(CPT2$CLAIM_ID,field13 )
names(CPT3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join CPT3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("BETOS_")),
                   ~replace(., is.na(.), 0))




#################################### Feature reduction of CPT variables#####



##################################################  FIPS


# extract the column names
field1 <- old_model %>% select(starts_with("FIPS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- FIPS2[, names(FIPS2) %in% field12$mycol]


FIPS3 <- cbind(FIPS2$CLAIM_ID,field13 )
names(FIPS3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join FIPS3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("FIPS_")),
                   ~replace(., is.na(.), 0))




##############################################################################################



# extract the column names
field1 <- old_model %>% select(starts_with("PROV_TYPE"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- PROV_TYPE2[, names(PROV_TYPE2) %in% field12$mycol]


PROV_TYPE3 <- cbind(PROV_TYPE2$CLAIM_ID,field13 )
names(PROV_TYPE3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join PROV_TYPE3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("PROV_TYPE_")),
                   ~replace(., is.na(.), 0))



# remove missings
base1$claim_patient_gender<- ifelse(is.na(base1$claim_patient_gender), 'X', 
                                    base1$claim_patient_gender)


base2 <- sqldf("select * from base1 where PATIENT_AGE_NORM IS NOT NULL")

base2 <- lapply(base2, factor)

base2$claim_id  <- as.numeric(as.character(base2$claim_id))
base2$claim_no  <- NULL
base2$PATIENT_AGE_NORM  <- as.numeric(as.character(base2$PATIENT_AGE_NORM))
base2$Days_of_service  <- as.numeric(as.character(base2$Days_of_service))
base2$ratio_billed_to_paid  <- as.numeric(as.character(base2$ratio_billed_to_paid))
base2$Charlson_score  <- as.numeric(as.character(base2$Charlson_score))
base2$elix_score  <- as.numeric(as.character(base2$elix_score))
base2 <- as.data.frame(base2)
base2$PROV_TYPE_NA <-  NULL
base2$CCS_missing <- NULL



empty_old_model <- sqldf("select * from old_model where CLAIM_ID = 2")

empty_old_model

#library(gtools)
#base3 <- smartbind(empty_old_model, base2)

base3 <- rbind(
  data.frame(c(empty_old_model, sapply(setdiff(names(base2), names(empty_old_model)), function(x) NA))),
  data.frame(c(base2, sapply(setdiff(names(empty_old_model), names(base2)), function(x) NA)))
)

base3[is.na(base3)] <- 0


saveRDS(base1, file="base1_leakage_prod.Rda")
saveRDS(base2, file="base2_leakage_prod.Rda")
saveRDS(base3, file="base3_leakage_prod.Rda")




library(h2o)
h2o.init(port=54333)
library(h2oEnsemble)


base3$claim_id<-NULL

 rf_95<- h2o.loadModel("/home/dless1/molina/ensemble/ensemble_binomial6")

data_to_score <- as.h2o(base3)


pred <- h2o.predict(rf_95, data_to_score)
pred <- h2o.predict(object = rf_95, newdata = data_to_score)


pred_df <- as.data.frame(pred )

my_threshold <- .5
pred_df[,"predict"] <- pred_df[,"p0"] >= my_threshold



#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


# recovery model


base2_saffari <- readRDS(file = "base2_saffari.Rda")


saff1 <- sqldf("select * from base2_saffari where claim_id = 7")


# recovery model

saff1$ claim_id <- NULL
saff1$OVP <- NULL
saff1$INV <-NULL


saff2<-  data.frame(c(base2, sapply(setdiff(names(saff1), names(base2)), function(x) NA)))

saff2[is.na(saff2)] <- 0

xg_saffari<- h2o.loadModel("/home/dless1/molina/xgboost/XGBoost_model_R_1629222360940_6970")

data_to_score_jungle <- as.h2o(saff2)

pred_jungle <- h2o.predict(object =xg_saffari, newdata = data_to_score_jungle)



# make output files

cl_ids <- base1 %>%
  select(claim_id) 

claim_probabilities <- cbind(cl_ids,pred_df )
claim_probabilities <- sqldf("select distinct d.CLAIM_ID, d.CLAIM_FEED_ID, d.claim_amt_paid,
 c.p0 as P0_overpayment,c.p1  as P1_Overpayment , d.LAST_NAME as member_last_name, DATE_PAID
                               from claim_probabilities c, claims d
                               where d.CLAIM_ID = c.CLAIM_ID ")


claim_probabilities$DATE_PAID <- as.POSIXct(claim_probabilities$DATE_PAID, origin="1970-01-01")
claim_probabilities$days_from_paid_date <- (difftime(Sys.Date(), claim_probabilities$DATE_PAID, units = "days"  ))

claim_probabilities$DATE_PAID <- NULL
claim_probabilities$days_from_paid_date <- as.numeric(claim_probabilities$days_from_paid_date)
# add safari

pred_df_jungle <- as.data.frame(pred_jungle )

pred_df_jungle <- cbind(cl_ids,pred_df_jungle )

claim_probabilities <- sqldf("select p.*, s.p0 as P0_recoverability, p1 as P1_recoverability
                             from claim_probabilities p left join pred_df_jungle s
                             ON p.CLAIM_ID = s.CLAIM_ID")

claim_probabilities$P0_recoverability<- ifelse(is.na(claim_probabilities$P0_recoverability), 0, 
                                               claim_probabilities$P0_recoverability)

claim_probabilities$P1_recoverability<- ifelse(is.na(claim_probabilities$P1_recoverability), 0, 
                                               claim_probabilities$P1_recoverability)

claims_to_investigate_claims<-sqldf("select Claim_id, claim_feed_id,claim_amt_paid,P0_overpayment,P1_Overpayment,P0_recoverability,
P1_recoverability,days_from_paid_date,member_last_name

                                    from claim_probabilities 
                                    order by P1_Overpayment desc")



conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
                         UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')

sqlSave(conn1,claims_to_investigate_claims ,tablename="dbo.molina_feed_371",rownames=FALSE)




h2o.shutdown(prompt  = FALSE)

