
# 4A leakge_prod removed dmfeed01272.dbo.fd_molina_clm_v2 pv_clm from claims query - drg and claim type not used in modeling

# V1O_leakage rests the target for feture reduction for OCE to leakage
# V1A based up FL blue


#scp betos20.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_family_level.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_level1.txt dless1@apsrd9425:/home/dless1/molina
#scp betos_level2.txt dless1@apsrd9425:/home/dless1/molina




# 2b go back in 100 day chunks each output file is a different name
#by batch number
# 1: 30-130, 2: 131-160, 3: 161-190 4: 191 - 220 5: 221 - 250  6: 251 - 280 7: 281-310 8: 311-340 9: 341-365

# V2d work off of feeds feeds are weekly


setwd("~/molina")

# files restore
# claims <- readRDS( file="claims.Rda")
# claims <- readRDS( file="claims.Rda")
# claims <- readRDS( file="claims.Rda")
# FIPS2 <- readRDS( file="FIPS2.Rda")
# DX_claim <- readRDS( file="DX_claim.Rda")
# Leakage_test3 <- readRDS( file="Leakage_test3.Rda")
# charlson_scores <- readRDS( file="charlson_scores.Rda")
# elixhauser_scores <- readRDS( file="elixhauser_scores.Rda")
# CCS_Dummy_test3 <- readRDS( file="CCS_Dummy_test3.Rda")
# POS2 <- readRDS( file="POS2.Rda")
# CPT2 <- readRDS( file="CPT2.Rda")
# PROV_TYPE2 <- readRDS( file="PROV_TYPE2.Rda")
# AHRQ_1 <- readRDS(file="AHRQ_1.Rda")
# base1 <- readRDS(file="base1.Rda")
# base2 <- readRDS(file="base2.Rda")

# claims <- readRDS( file="claims_prod.Rda")
# #FIPS2 <- readRDS( file="FIPS2_prod.Rda")
# DX_claim <- readRDS( file="DX_claim.Rda")
# Leakage_test3 <- readRDS( file="Leakage_test3.Rda")
# charlson_scores <- readRDS( file="charlson_scores_prod.Rda")
# elixhauser_scores <- readRDS( file="elixhauser_scores_prod.Rda")
#  CCS_Dummy_test3 <- readRDS( file="CCS_Dummy_test3_prod.Rda")
# POS2 <- readRDS( file="POS2_prod.Rda")
# # CPT2 <- readRDS( file="CPT2_prod.Rda")
# PROV_TYPE2 <- readRDS( file="PROV_TYPE2_prod.Rda")
#  AHRQ_1 <- readRDS(file="AHRQ_1_prod.Rda")
# base1 <- readRDS(file="base1_prod.Rda")
# base2 <- readRDS(file="base2_prod.Rda")

library(comorbidity)
library(RODBC)
library(sqldf)
library(dplyr)


library(dummies)
# #library(tcltk)
# #library(smbinning)
# library(DMwR)
# library(randomForest)
# library(data.table)
# library(discretization)
# library(ggplot2)
# #library(dataMaid)
# #library(e1071)
# ##library(C51)
# library(lubridate)
# library(caret)
# library(h2o)
# library(ROCR)
# #library(pROC)
# library(h2o)
# h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)

conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;DATABASE=racer01272;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')
conn2 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=Dbswp0809.aimhealth.com;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')


# feeds <- sqlQuery( conn1, "select max(feed_id) as mx from  racer01272.dbo.claim (nolock) where feed_id != 999 ")
# 
# feedspaid <- sqlQuery( conn1, "select max(DATE_PAID) as mx from dmfeed01272.dbo.fd_molina_clm_v2 where feed_id != 999 ")
# 
# feedspaid2 <- sqlQuery( conn1, "select max(DATE_PAID) as mx from racer01272.dbo.claim  where feed_id != 999 ")
# 
# 
# feedspp <- sqlQuery( conn1, "select max(feed_id) as mx from dmfeed01272.dbo.fd_molina_clm_v2 where feed_id != 999 ")
# 
# funk<- sqlTables(
#   conn1  )
# member_table <- sqlQuery( conn1, " select * from racer01272.dbo.MEMBER (nolock)",max=10  ) 
# 

# last feed for invoiced is 295 
# use 281 -292 for model and 293-95 for OSOD

claims <- sqlQuery(
  conn1,
  "select
distinct
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE,
MEM.LAST_NAME
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
INNER JOIN racer01272.dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and clm.amt_paid > 0

and cs.current_status = 1
and clm.amt_paid > 0
AND clm.feed_id = 356")

# removed and cs.status_code in (0,-1)

saveRDS(claims, file="claims_prod.Rda")
# claims<- readRDS(file="claims_prod.Rda")


##Pulling Dx codes

DX_claim  <- sqlQuery(
  conn1,
  " select
DISTINCT CLM.CLAIM_ID,
DX.ICD9_CODE,
DX.PROJECT_ID,
DX.ICD9_TYPE,
DX.ADMITTING_CODE,
DX.PRINCIPAL_CODE,
DX.ORDER_IN_CLAIM,
DX.CLAIM_LINE_ID,
DX.FEED_ID
FROM  dbo.CLAIM CLM   with (nolock)
INNER JOIN dbo.ICD9 DX  with (nolock)
ON CLM.CLAIM_ID = DX.CLAIM_ID
where DX.ORDER_IN_CLAIM <= 4 
AND clm.feed_id = 356
order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc")


saveRDS(DX_claim, file="DX_claim_prod.Rda")

DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)
DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

#charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson",mc.cores=0)
#elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser",mc.cores=0)

detach("package:tidyr", unload = TRUE)
detach("package:psych", unload = TRUE)

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

saveRDS(charlson_scores, file="charlson_scores_prod.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

saveRDS(elixhauser_scores, file="elixhauser_scores_prod.Rda")
#  elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")


#####
# AHRQ comorbidities
library(icd)

AHRQ_1 <- icd_comorbid_ahrq(DX_claimids_Diag, visit_name = 'CLAIM_ID', icd_name = 'ICD9_CODE', return_df = TRUE,
                            return_binary = FALSE)

AHRQ_1$CLAIM_ID <- as.character(AHRQ_1$CLAIM_ID)
cols <- sapply(AHRQ_1, is.logical)

AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.numeric)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.character)
AHRQ_1$CLAIM_ID <- as.integer(AHRQ_1$CLAIM_ID)
AHRQ_1[,cols] <- lapply(AHRQ_1[,cols], as.factor)
colnames(AHRQ_1) <- paste("AHRQ", colnames(AHRQ_1), sep = "_")
AHRQ_1$CLAIM_IDx <- AHRQ_1$AHRQ_CLAIM_ID
AHRQ_1$AHRQ_CLAIM_ID <- NULL

saveRDS(AHRQ_1, file="AHRQ_1_prod.Rda")









####CCS categories


CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
names(CCS)[2]<-"CCS_Category_Description"
names(CCS)[3]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)

CCS$multi_desc <- substr(CCS$CCS_Category,1,3)



# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category, c.multi_desc 
from DX_claim d left join CCS c on d.ICD9_CODE = c.ICD10_Code
order by d.CLAIM_ID")

#DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), '0', DX_CCS$CCS_Category)
DX_CCS$multi_desc  <- ifelse(is.na(DX_CCS$multi_desc ), 'missing', DX_CCS$multi_desc )

#DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
DX_CCS$multi_desc <-as.factor(DX_CCS$multi_desc)

### One hot encoding of CCS variables #####

#CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
CCS_Dummy_test <- sqldf("select distinct CLAIM_ID, multi_desc from DX_CCS order by CLAIM_ID")




## Making a wide table
#CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$multi_desc, sep= "_"))

#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))


saveRDS(CCS_Dummy_test3, file="CCS_Dummy_test3_prod.Rda")

##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID, claim_place_of_service as POS from claims")

POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor)
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
saveRDS(POS2, file="POS2_prod.Rda")

icd10codes<-sqldf('select distinct ICD10_CODE from DX_claim')



icd10codes_leakage<-sqldf("select * from icd10codes where    ICD10_CODE in(
'R62.50', 'Z51.0', 'I10', 'F80.9', 'Z51.11', 'N18.6', 'E11.9', 'F82', 'R62.0', 'R69', 'F84.0', 'M54.5', 'R07.89', 'R07.9', 'F80.2', 'R10.9', 'N39.0', 'R11.2',
'O99.89', 'M54.2', 'G80.9', 'M54.9', 'C61', 'F03.90', 'M43.6', 'R51', 'F10.129', 'K52.9', 'J44.1', 'S01.01XA', 'S01.81XA', 'G30.9', 'J44.9', 'R55', 'F80.0', 'G47.33',
'M19.90', 'A41.9', 'R45.851', 'J06.9', 'O26.891', 'R27.8', 'G54.0', 'R56.9', 'F32.9', 'M62.81', 'E86.0', 'E11.621', 'G40.909', 'R26.9', 'F33.2', 'M25.561', 'F80.1',
'C53.9', 'R10.13', 'I50.9', 'S09.90XA', 'A41.89', 'Z00.129', 'O20.0', 'R29.898', 'Z51.12', 'R53.1', 'O26.893', 'R41.82', 'E11.8', 'J18.9', 'B34.9', 'O26.892',
'I63.9', 'F33.9', 'F31.9', 'O34.211', 'M06.9', 'R11.10', 'F41.9', 'R05', 'K59.00', 'Q90.9', 'R10.31', 'O60.03', 'O20.9', 'M25.562', 'Z20.2', 'F10.10', 'Z51.89',
'F20.9', 'E87.6', 'K29.00', 'R47.9', 'G35', 'C10.8', 'E11.65', 'O21.9', 'M62.830', 'R42', 'J45.909', 'C16.8', 'G89.29', 'K35.80', 'C34.92', 'J45.901', 'F79',
'E11.3513', 'O03.9', 'R26.89', 'L03.116', 'J20.9', 'S61.216D', 'N10', 'K02.9', 'R06.02', 'K85.90', 'G43.909', 'I61.9', 'N17.9', 'J40', 'R50.9', 'M15.0', 'R10.84',
'F11.20', 'M86.9', 'F84.9')")

icd10codes_leakage$ICD10_CODE<-as.character(icd10codes_leakage$ICD10_CODE)
icd10codes_leakage$icd10_leakage<-gsub(".","",icd10codes_leakage$ICD10_CODE,fixed=TRUE)


DX_leakage <- sqldf("select DISTINCT d.*,  c.icd10_leakage as ICD10_CODE_Leakage from
DX_claim d left join icd10codes_leakage c on d.ICD9_CODE = c.icd10_leakage
order by d.CLAIM_ID ")

##setting up Leakage codes to be 1
DX_leakage$ICD10_CODE_Leakage[is.na(DX_leakage$ICD10_CODE_Leakage)]<-0
DX_leakage$ICD10_CODE_Leakage<-ifelse(DX_leakage$ICD10_CODE_Leakage==0,0,1)
DX_leakage$ICD10_CODE_Leakage <- as.numeric(DX_leakage$ICD10_CODE_Leakage)
Leakage_test <- sqldf("select DISTINCT CLAIM_ID, ICD10_CODE_Leakage from DX_leakage")

# group by client id
Leakage_test2 <- Leakage_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
Leakage_test2$CLAIM_ID <- as.character(Leakage_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Leakage_test3 <- Leakage_test2 %>% mutate_if(is.numeric,
                                             function(x) case_when(
                                               x >= 1 ~ 1,
                                               x == 0 ~ 0
                                             )
)
Leakage_test3 <- lapply(Leakage_test3, factor)
Leakage_test3 <- as.data.frame(Leakage_test3)
Leakage_test3$CLAIM_ID <- as.numeric(as.character(Leakage_test3$CLAIM_ID))



saveRDS(Leakage_test3, file="Leakage_test3_prod.Rda")


table(Leakage_test$ICD10_CODE_Leakage)
prop.table(table(Leakage_test$ICD10_CODE_Leakage))








BETOS<-read.csv("betos20.txt", header=TRUE, sep="\t")


CPT <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID,  CLAIM_LINE_CPT as CPT from claims
             where CPT != 'NA'")


CPT <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from CPT b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")


CPT$ICD10_CODE_Leakage <- ifelse(is.na(CPT$ICD10_CODE_Leakage), 0, 
                                 CPT$ICD10_CODE_Leakage)


#CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c inner JOIN BETOS b
#             ON c.CPT = b.HCPCS")


CPT <- sqldf("select distinct c.*, b.BETOS_20, b.BETOS_20_label from CPT c LEFT JOIN BETOS b
             ON c.CPT = b.HCPCS")

CPT_OVP <- sqldf("select distinct claim_ID, ICD10_CODE_Leakage from CPT")
# for orphan betos, use CPT

CPT$BETOS_20 <-  ifelse(is.na(CPT$BETOS_20),CPT$CPT,CPT$BETOS_20)

CPT_b <- sqldf("select distinct CLAIM_ID, BETOS_20 from CPT")
CPT_b$BETOS_20 <- as.factor(CPT_b$BETOS_20)

CPT_b <- cbind(CPT_b, dummy(CPT_b$BETOS_20, sep= "_"))

#replace with betos
colnames(CPT_b)<-gsub("CPT_b","BETOS_20",colnames(CPT_b))

CPT_b$BETOS_20 <- NULL



# temp make id character
CPT$CLAIM_ID <- as.character(CPT$CLAIM_ID)


# new loop by to split CPT into columns split 10 ways
###############################################################


pid <- as.data.frame(CPT_b[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'



CPT_b$CLAIM_ID <- NULL

cpt_test2 <- split.default(CPT_b, gl(ncol(CPT_b)/10, 10))

number_data_frames <- as.integer(length(cpt_test2))




hcpc1 <- cpt_test2[[1]]
hcpc1 <- cbind(pid,hcpc1)
CPT1 <- hcpc1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  hcpc <- cpt_test2[[i]]
  hcpc <- cbind(pid,hcpc)
  
  hcpc3 <- hcpc %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(hcpc3)[1] <- 'CLAIM_IDx'
  
  CPT1<- cbind( CPT1,  hcpc3)
  CPT1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}


rm(cpt_test2)






# group by client id
#CPT1 <- CPT_b %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor)
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character(CPT2$CLAIM_ID))





CPT2 <- cbind(CPT_OVP$ICD10_CODE_Leakage,CPT2)
# #rename
names(CPT2)[1] <- 'ICD10_CODE_Leakage'

saveRDS(CPT2, file="CPT2_prod.Rda")

CPT2$ICD10_CODE_Leakage <- as.factor(as.character(CPT2$ICD10_CODE_Leakage))
#CPT2$CLAIM_ID <- NULL
rm(CPT1)
rm(CPT_b)


####### Configuring Provider city#########


FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


claims$ZIP <-  ifelse(is.na(claims$ZIPCODE),claims$ALTERNATE_ZIPCODE,claims$ZIPCODE)
claims$ZIP <-  ifelse(is.na(claims$ZIP),'missing',claims$ZIP)


claims$zip5 <- substr(claims$ZIP,1,5)

claims2 <- claims

claims2 <- data.frame(r_index = row.names(claims2), claims2)

claims2 <- sqldf("select v.*, f.COUNTY from   claims2 v left join FIPS f
                 ON v.zip5 = f.zip group by v.r_index
                          " )

claims2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from claims2 v left join USDA f
ON  v.COUNTY = f.FIPS  group by v.r_index")

claims2$COUNTY <-  ifelse(is.na(claims2$COUNTY),'missing',claims2$COUNTY)
claims2$USDA_urban_rural <- ifelse(is.na(claims2$USDA_urban_rural),0,claims2$USDA_urban_rural)



# use FIPS instead
FIPS <- sqldf("select DISTINCT claim_id as CLAIM_ID,  COUNTY from claims2")

FIPS <- cbind(FIPS, dummy(FIPS$COUNTY , sep= "_"))

FIPS$FIPS_missing <- NULL



# new group by methodology
pid <- as.data.frame(FIPS[,1])

#rename

names(pid)[1] <- 'CLAIM_ID'


FIPS$CLAIM_ID <- NULL

fips_test2 <- split.default(FIPS, gl(ncol(FIPS)/10, 10))

number_data_frames <- as.integer(length(fips_test2))

###############################################################

county1 <- fips_test2[[1]]
county1 <- cbind(pid,county1)
FIPS1 <- county1 %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)



#while (i <= number_data_frames)

i <- 2
while (i <= number_data_frames)
{
  county <- fips_test2[[i]]
  county <- cbind(pid,county)
  
  county3 <- county %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)
  names(county3)[1] <- 'CLAIM_IDx'
  
  FIPS1 <- cbind( FIPS1,  county3)
  FIPS1$CLAIM_IDx <- NULL
  
  
  i <- i+1
  
}

rm(fips_test2)





# group by client id
#FIPS1 <- FIPS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
FIPS1$CLAIM_ID <- as.character(FIPS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
FIPS2 <- FIPS1 %>% mutate_if(is.numeric,
                             function(x) case_when(
                               x >= 1 ~ 1,
                               x == 0 ~ 0
                             )
)

FIPS2 <- lapply(FIPS2, factor)
FIPS2<- as.data.frame(FIPS2)
FIPS2$CLAIM_ID <- as.numeric(as.character((FIPS2$CLAIM_ID)))
FIPS2$COUNTY <- NULL
saveRDS(FIPS2, file="FIPS2_prod.Rda")


###### Configuring Provider Type#######
PROV_TYPE <- sqldf("select DISTINCT CLAIM_ID as CLAIM_ID,  pv_provider_speciality as PROV_TYPE from claims")

PROV_TYPE <- cbind(PROV_TYPE, dummy(PROV_TYPE$PROV_TYPE , sep= "_"))

PROV_TYPE$CLAIM_ID <- as.character(PROV_TYPE$CLAIM_ID)
# group by client id
PROV_TYPE1 <- PROV_TYPE %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
PROV_TYPE1$CLAIM_ID <- as.character(PROV_TYPE1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_TYPE2 <- PROV_TYPE1 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_TYPE2 <- lapply(PROV_TYPE2, factor)
PROV_TYPE2 <- as.data.frame(PROV_TYPE2)
PROV_TYPE2$CLAIM_ID <- as.numeric(as.character((PROV_TYPE2$CLAIM_ID)))
PROV_TYPE2$PROV_TYPE <- NULL

saveRDS(PROV_TYPE2, file="PROV_TYPE2_prod.Rda")


####  creating new features

# use scale / normalize library here
library(BBmisc)

claims$ratio_billed_to_paid<-claims$claim_amt_billed /claims$claim_amt_paid
claims$ratio_billed_to_paid <- normalize(claims$ratio_billed_to_paid, method="range", range=c(0,1))


claims$PATIENT_AGE_NORM <- normalize(claims$claim_patient_age, method="range", range=c(0,1))

claims$Days_of_service <- difftime(claims$claim_date_of_service_end ,
                                            claims$claim_date_of_service_beg,
                                            units = c("days"))

claims$Days_of_service <- as.numeric(claims$Days_of_service)

claims$Days_of_service <-  normalize(claims$Days_of_service, method="range", range=c(0,1))

# makeDataReport(claims, vol="1", render = FALSE,
#                replace = TRUE, openResult = FALSE, codebook = TRUE,
#                reportTitle = "claims - Report")




claims$claim_principal_diag <- as.character(claims$claim_principal_diag)
claims$claim_principal_diag <- gsub(".","",claims$claim_principal_diag, fixed = TRUE)

saveRDS(claims, file="claims_prod.Rda")
#  claims <- readRDS( file="claims_prod.Rda")
####### Creating a target variable for Leakage to perform dimensional reduction############


claims<-claims[order(claims$claim_id),]
attr(charlson_scores, "label") <- NULL
attr(elixhauser_scores, "label") <- NULL
#Merging with cormorbidities

count_claim_ids <- sqldf("select distinct claim_id from claims")



base1 <- sqldf("select distinct claim_id , claim_no, PATIENT_AGE_NORM,
Days_of_service, ratio_billed_to_paid , 
               claim_patient_gender
               from claims ")

charlson_scores$CLAIM_ID <- as.numeric(charlson_scores$CLAIM_ID )



base1 <-sqldf("select distinct b.*, c.wscore as Charlson_score from  base1 b
             left join charlson_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

# lekage dx flag


base1 <- sqldf("select b.*, p.ICD10_CODE_Leakage 
from base1 b left join Leakage_test3 p
on b.CLAIM_ID = p.CLAIM_ID")

base1$ICD10_CODE_Leakage <- ifelse(is.na(base1$ICD10_CODE_Leakage), 0, 
                                   base1$ICD10_CODE_Leakage)


base1$Charlson_score <-  ifelse(is.na(base1$Charlson_score),1,base1$Charlson_score)


elixhauser_scores$CLAIM_ID<-as.numeric(elixhauser_scores$CLAIM_ID)

base1 <-sqldf("select distinct b.*, c.score as elix_score from  base1 b
             left join elixhauser_scores c
             on b.claim_id = c.CLAIM_ID", method = "name_class")

base1$elix_score <-  ifelse(is.na(base1$elix_score),0,base1$elix_score)

#########################################################################################

# match fields to model featrues


old_model<- readRDS(file="base2.Rda")

# extract the column names
field1 <- old_model %>% select(starts_with("AHRQ"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- AHRQ_1[, names(AHRQ_1) %in% field12$mycol]

AHRQ_2 <- cbind(AHRQ_1$CLAIM_ID,field13 )
names(AHRQ_2)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join AHRQ_2 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")


base1$CLAIM_IDx <- NULL


base1 <- mutate_at(base1, vars(starts_with("AHRQ_")),
                   ~replace(., is.na(.), 0))


# extract the column names
field1 <- old_model %>% select(starts_with("CCS"))


### Merging with CCS
# CCS dx
# chould have 23 fields
CCS_Dummy_test3$CLAIM_IDx <- CCS_Dummy_test3$CLAIM_ID

CCS_Dummy_test3$CLAIM_ID <- NULL

base1<- sqldf("SELECT DISTINCT b.*, c.* from base1 b left join CCS_Dummy_test3 c
                               on b.CLAIM_ID = c.CLAIM_IDx")




base1 <- mutate_at(base1, vars(starts_with("CCS_")),
                   ~replace(., is.na(.), 0))

base1$CLAIM_IDx <- NULL


##### Merging with POS

# extract the column names
field1 <- old_model %>% select(starts_with("POS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- POS2[, names(POS2) %in% field12$mycol]


POS3 <- cbind(POS2$CLAIM_ID,field13 )
names(POS3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join POS3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("POS_")),
                   ~replace(., is.na(.), 0))


# POS2$CLAIM_IDx <- POS2$CLAIM_ID
# POS2$CLAIM_ID <- NULL
# 
# rf_pos1 <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, POS2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_pos1$claim_id <- NULL
# rf_pos1$CLAIM_IDx <- NULL
# rf_pos1$POS_NA <- NULL
# 
# 
# rf_pos1$ICD10_CODE_Leakage <- as.factor(rf_pos1$ICD10_CODE_Leakage)
# 
# rf_pos1 <- randomForest(ICD10_CODE_Leakage~. ,data=rf_pos1, ntree=500)
# 
# rf_pos1_importance <- as.data.frame(importance(rf_pos1))
# 
# rf_pos1_importance <- data.frame(POS = row.names(rf_pos1_importance), rf_pos1_importance)
# 
# rf_pos1_importance_tile <- mutate(rf_pos1_importance, 
#                  tiles = ntile(rf_pos1_importance$MeanDecreaseGini, 4))
# 
# rf_pos1_importance <- sqldf("select * from rf_pos1_importance_tile where tiles = 4")
# 
# 
# # rf_pos1_importance <-rf_pos1_importance_tile %>%
# #   filter(rank(desc(MeanDecreaseGini)) <= 10)
# 
# saveRDS(rf_pos1_importance, file="rf_pos1_importance_prod.Rda")
# 
# 
# 
# POS_match <- POS2[, names(POS2) %in% rf_pos1_importance$POS]
# base1 <- cbind(base1, POS_match)
# 
# 
# base1 <- mutate_at(base1, vars(starts_with("POS_")),
#                    ~replace(., is.na(.), 0))


# get only the columns that are in the original base 2


# CPT

# extract the column names
field1 <- old_model %>% select(starts_with("BETOS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- CPT2[, names(CPT2) %in% field12$mycol]


CPT3 <- cbind(CPT2$CLAIM_ID,field13 )
names(CPT3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join CPT3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("BETOS_")),
                   ~replace(., is.na(.), 0))
















#################################### Feature reduction of CPT variables#####

# CPT2$CLAIM_IDx <- CPT2$CLAIM_ID
# CPT2$CLAIM_ID <- NULL
# 
# rf_CPT1 <- sqldf("select b.CLAIM_ID, b.OVP, p.* from base1 b, CPT2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_CPT1$claim_id <- NULL
# rf_CPT1$CLAIM_IDx <- NULL
# rf_CPT1$CPT2_NA <- NULL
# 
# 
# set.seed(77)
# 
# rf_CPT1$OVP <- as.factor(rf_CPT1$OVP)
# 
# rf_CPT1 <- randomForest(OVP~. ,data=rf_CPT1, ntree=500)
# 
# rf_CPT1_importance <- as.data.frame(importance(rf_CPT1))
# 
# rf_CPT1_importance <- data.frame(CPT = row.names(rf_CPT1_importance), rf_CPT1_importance)
# 
# rf_CPT1_importance_tile <- mutate(rf_CPT1_importance, 
#                                   tiles = ntile(rf_CPT1_importance$MeanDecreaseGini, 4))
# 
# rf_CPT1_importance <- sqldf("select * from rf_CPT1_importance_tile where tiles = 4")



# rf_CPT1_importance <-rf_CPT1_importance %>%
#   filter(rank(desc(MeanDecreaseGini)) <= 20)

#saveRDS(rf_CPT1_importance, file="rf_CPT1_importance_prod.Rda")



# CPT2_match <- CPT2[, names(CPT2) %in% rf_CPT1_importance$CPT]
# 
# CPT2_match <- cbind(CPT1$CLAIM_ID, CPT2_match)
# names(CPT2_match)[1] <- 'CLAIM_IDx'
# 
# base1<- sqldf("select b.*, c.* from base1 b left join CPT2_match c
#                on b.CLAIM_ID = c.CLAIM_IDx")
# 
# base1 <- mutate_at(base1, vars(starts_with("BETOS_")),
#                    ~replace(., is.na(.), 0))
# 
# base1$CLAIM_IDx <- NULL


##################################################  FIPS


# extract the column names
field1 <- old_model %>% select(starts_with("FIPS"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- FIPS2[, names(FIPS2) %in% field12$mycol]


FIPS3 <- cbind(FIPS2$CLAIM_ID,field13 )
names(FIPS3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join FIPS3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("FIPS_")),
                   ~replace(., is.na(.), 0))




# FIPS2$CLAIM_IDx <- FIPS2$CLAIM_ID
# FIPS2$CLAIM_ID <- NULL
# 
# rf_FIPS <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, FIPS2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_FIPS$claim_id <- NULL
# rf_FIPS$CLAIM_IDx <- NULL
# rf_FIPS$CPT2_NA <- NULL
# 
# 
# set.seed(77)
# 
# rf_FIPS$ICD10_CODE_Leakage <- as.factor(rf_FIPS$ICD10_CODE_Leakage)
# 
# rf_FIPS <- randomForest(ICD10_CODE_Leakage~. ,data=rf_FIPS, ntree=500)
# 
# rf_FIPS_importance <- as.data.frame(importance(rf_FIPS))
# 
# rf_FIPS_importance <- data.frame(FIPS = row.names(rf_FIPS_importance), rf_FIPS_importance)
# 
# 
# rf_FIPS_importance_tile <- mutate(rf_FIPS_importance, 
#                                   tiles = ntile(rf_FIPS_importance$MeanDecreaseGini, 4))
# 
# rf_FIPS_importance <- sqldf("select * from rf_FIPS_importance_tile where tiles = 4")
# 
# 
# # rf_FIPS_importance <-rf_FIPS_importance %>%
# #   filter(rank(desc(MeanDecreaseGini)) <= 20)
# 
# saveRDS(rf_FIPS_importance, file="rf_FIPS_importance_prod.Rda")
# 
# 
# FIPS_match <- FIPS2[, names(FIPS2) %in% rf_FIPS_importance$FIPS]
# base1 <- cbind(base1, FIPS_match)
# 
# 
# base1 <- mutate_at(base1, vars(starts_with("FIPS_")),
#                    ~replace(., is.na(.), 0))





##############################################################################################



# extract the column names
field1 <- old_model %>% select(starts_with("PROV_TYPE"))

#convert the column names to a df
field12 <- as.data.frame(colnames(field1))
names(field12)[1] <- 'mycol'


# get only the columns that are in the original base 2
field13<- PROV_TYPE2[, names(PROV_TYPE2) %in% field12$mycol]


PROV_TYPE3 <- cbind(PROV_TYPE2$CLAIM_ID,field13 )
names(PROV_TYPE3)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select b.*, a.* from base1 b left join PROV_TYPE3 a
               on b.CLAIM_ID = a.CLAIM_IDx ", method = "name_class")

base1$CLAIM_IDx <- NULL
base1 <- mutate_at(base1, vars(starts_with("PROV_TYPE_")),
                   ~replace(., is.na(.), 0))

# 
# # provider type targeted feature reduction
# PROV_TYPE2$CLAIM_IDx <- PROV_TYPE2$CLAIM_ID
# PROV_TYPE2$CLAIM_ID <- NULL
# 
# rf_PROV_TYPE <- sqldf("select b.CLAIM_ID, b.ICD10_CODE_Leakage, p.* from base1 b, PROV_TYPE2 p
#                  where b.CLAIM_ID = p.CLAIM_IDx")
# 
# rf_PROV_TYPE$claim_id <- NULL
# rf_PROV_TYPE$CLAIM_IDx <- NULL
# rf_PROV_TYPE$CPT2_NA <- NULL
# 
# 
# set.seed(77)
# 
# rf_PROV_TYPE$ICD10_CODE_Leakage <- as.factor(rf_PROV_TYPE$ICD10_CODE_Leakage)
# 
# rf_PROV_TYPE <- randomForest(ICD10_CODE_Leakage ~. ,data=rf_PROV_TYPE, ntree=500)
# 
# rf_PROV_TYPE_importance <- as.data.frame(importance(rf_PROV_TYPE))
# 
# rf_PROV_TYPE_importance <- data.frame(PROV_TYPE = row.names(rf_PROV_TYPE_importance), rf_PROV_TYPE_importance)
# 
# 
# rf_PROV_TYPE_importance_tile <- mutate(rf_PROV_TYPE_importance, 
#                                   tiles = ntile(rf_PROV_TYPE_importance$MeanDecreaseGini, 4))
# 
# rf_PROV_TYPE_importance <- sqldf("select * from rf_PROV_TYPE_importance_tile where tiles = 4")
# 
# 
# 
# # rf_PROV_TYPE_importance <-rf_PROV_TYPE_importance %>%
# #   filter(rank(desc(MeanDecreaseGini)) <= 20)
# 
# saveRDS(rf_PROV_TYPE_importance, file="rf_PROV_TYPE_importance_prod.Rda")
# 
# PROV_TYPE_match <- PROV_TYPE2[, names(PROV_TYPE2) %in% rf_PROV_TYPE_importance$PROV_TYPE]
# base1 <- cbind(base1, PROV_TYPE_match)
# 
# 
# base1 <- mutate_at(base1, vars(starts_with("PROV_TYPE_")),
#                    ~replace(., is.na(.), 0))








# remove missings
base1$claim_patient_gender<- ifelse(is.na(base1$claim_patient_gender), 'X', 
                                    base1$claim_patient_gender)


base2 <- sqldf("select * from base1 where PATIENT_AGE_NORM IS NOT NULL")

base2 <- lapply(base2, factor)

base2$claim_id  <- as.numeric(as.character(base2$claim_id))
base2$claim_no  <- NULL
base2$PATIENT_AGE_NORM  <- as.numeric(as.character(base2$PATIENT_AGE_NORM))
base2$Days_of_service  <- as.numeric(as.character(base2$Days_of_service))
base2$ratio_billed_to_paid  <- as.numeric(as.character(base2$ratio_billed_to_paid))
base2$Charlson_score  <- as.numeric(as.character(base2$Charlson_score))
base2$elix_score  <- as.numeric(as.character(base2$elix_score))
base2 <- as.data.frame(base2)
base2$PROV_TYPE_NA <-  NULL
base2$CCS_missing <- NULL



empty_old_model <- sqldf("select * from old_model where CLAIM_ID = 2")

empty_old_model

#library(gtools)
#base3 <- smartbind(empty_old_model, base2)

base3 <- rbind(
  data.frame(c(empty_old_model, sapply(setdiff(names(base2), names(empty_old_model)), function(x) NA))),
  data.frame(c(base2, sapply(setdiff(names(empty_old_model), names(base2)), function(x) NA)))
)

base3[is.na(base3)] <- 0


saveRDS(base1, file="base1_leakage_prod.Rda")
saveRDS(base2, file="base2_leakage_prod.Rda")
saveRDS(base3, file="base3_leakage_prod.Rda")

# base3 <- readRDS(file="base3_leakage_prod.Rda")
#base3_distinct<- sqldf("select distinct * from base3")
base3<- sqldf("select distinct * from base3 where PATIENT_AGE_NORM <= .386")
base3_distinct<- sqldf("select distinct * from base3 where PATIENT_AGE_NORM <= .386")

# base1 <- readRDS(file="base1_leakage_prod.Rda")
#base2 <- readRDS(file="base2_leakage_prod.Rda")




# model development
# inv_id <- sqldf("select distinct claim_id, INV from claims_OVP_invoiced")
# 
# base2_saffari <- sqldf("select b.*, i.INV from base3 b, inv_id i
#                        where b.claim_id = i.claim_id")
# 
# saveRDS(base2_saffari, file="base2_saffari_prod.Rda")
# 





# library(dataMaid)
# 
# # make datmaid codebook
# # Instructions to open:  do file open rmd file; use Knit to render as an HTML doc
# makeDataReport(base3, vol="1", render = FALSE,
#                replace = TRUE, openResult = FALSE, codebook = TRUE,
#                reportTitle = "Model Data - Report")
# 

#base3<- sqldf("select distinct * from base3 where PATIENT_AGE_NORM <= .386")

library(h2o)
#h2o.init()
h2o.init(port=54333)

base3$claim_id<-NULL

# 1/14/22
#rf_95<- h2o.loadModel("/home/dless1/molina/gbm/GBM_model_R_1642178978036_11610")

# parsomonious
rf_95<- h2o.loadModel("/home/dless1/molina/gbm/GBM_model_R_1643144523935_47")


data_to_score <- as.h2o(base3)



pred <- h2o.predict(object = rf_95, newdata = data_to_score)


pred_df <- as.data.frame(pred )

my_threshold <- .5
pred_df[,"predict"] <- pred_df[,"p0"] >= my_threshold

#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


# recovery model


base2_saffari <- readRDS(file = "base2_saffari.Rda")


saff1 <- sqldf("select * from base2_saffari where claim_id = 7")


# recovery model

saff1$ claim_id <- NULL
saff1$OVP <- NULL
saff1$INV <-NULL


saff2<-  data.frame(c(base2, sapply(setdiff(names(saff1), names(base2)), function(x) NA)))

saff2[is.na(saff2)] <- 0

# 1/14/22
xg_saffari<- h2o.loadModel("/home/dless1/molina/gbm/GBM_model_R_1642178978036_12790")

data_to_score_jungle <- as.h2o(saff2)

pred_jungle <- h2o.predict(object =xg_saffari, newdata = data_to_score_jungle)



# make output files

cl_ids <- base3_distinct %>%
  select(claim_id) 

claim_probabilities <- cbind(cl_ids,pred_df )
claim_probabilities <- sqldf("select distinct d.CLAIM_ID, d.CLAIM_FEED_ID, d.claim_amt_paid,
 c.p0 as P0_overpayment,c.p1  as P1_Overpayment , d.LAST_NAME as member_last_name, DATE_PAID
                               from claim_probabilities c, claims d
                               where d.CLAIM_ID = c.CLAIM_ID ")


claim_probabilities$DATE_PAID <- as.POSIXct(claim_probabilities$DATE_PAID, origin="1970-01-01")
claim_probabilities$days_from_paid_date <- (difftime(Sys.Date(), claim_probabilities$DATE_PAID, units = "days"  ))

claim_probabilities$DATE_PAID <- NULL
claim_probabilities$days_from_paid_date <- as.numeric(claim_probabilities$days_from_paid_date)
# add safari

pred_df_jungle <- as.data.frame(pred_jungle )

pred_df_jungle <- cbind(pid,pred_df_jungle )

claim_probabilities <- sqldf("select p.*, s.p0 as P0_recoverability, p1 as P1_recoverability
                             from claim_probabilities p left join pred_df_jungle s
                             ON p.CLAIM_ID = s.CLAIM_ID")

claim_probabilities$P0_recoverability<- ifelse(is.na(claim_probabilities$P0_recoverability), 0, 
                                               claim_probabilities$P0_recoverability)

claim_probabilities$P1_recoverability<- ifelse(is.na(claim_probabilities$P1_recoverability), 0, 
                                               claim_probabilities$P1_recoverability)

claims_to_investigate_claims<-sqldf("select Claim_id, claim_feed_id,claim_amt_paid,P0_overpayment,P1_Overpayment,P0_recoverability,
P1_recoverability,days_from_paid_date,member_last_name

                                    from claim_probabilities 
                                    order by P1_Overpayment desc")


#order by p1 desc")

# conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
#                          UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')
# 
# sqlSave(conn1,claims_to_investigate_claims,tablename="dbo.molina_feed_359",rownames=FALSE)
# 


# 
# conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
#                          UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')
# 
# sqlSave(conn1,claims_to_investigate_claims,tablename="dbo.mmolina_feed_362_unfiltered",rownames=FALSE)
# 



h2o.shutdown(prompt  = FALSE)



#################################################


# scored data


data_OVP <- sqlQuery(
  conn1,
  "select
distinct
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and cs.current_status = 1
and clm.amt_paid > 0

and cs.current_status = 1
and clm.amt_paid > 0

and cs.status_code in (2,50)")

# originaly
#AND DATEDIFF(D,  clm.DATE_PAID, GETDATE()) >= 30
#AND DATEDIFF(D,  clm.DATE_PAID, GETDATE()) <= 100 
#and cs.date_created between '01-01-2019' and '02-28-2021' 
#AND DATEDIFF(D,  cs.date_created, GETDATE()) >= 120
#AND DATEDIFF(D,  cs.date_created, GETDATE()) <= 850

Unique_OVP_claimids <- sqldf("select distinct CLAIM_id from  data_OVP")


data_NOVP <-  sqlQuery(
  conn1,
  "select
distinct
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and cs.current_status = 1
and clm.amt_paid > 0

  and  ( cs.status_code in (1,20) 
  and cs.reason_code in (13,14,16,17,19,22,24,31,71)) ")

# originally  and cs.date_updated between '01-01-2019' and '02-28-2021'
#AND DATEDIFF(D,  cs.date_created, GETDATE()) >= 120
#AND DATEDIFF(D,  cs.date_created, GETDATE()) <= 850

Unique_NOVP_claimids <- sqldf("select distinct CLAIM_id from  data_NOVP")
data_OVP$OVP <- 1
data_NOVP$OVP <- 0




scorred_claims<-rbind(data_OVP,data_NOVP)



scr <- sqldf("select distinct claim_id, OVP from scorred_claims")

#183
scr2 <- sqldf("select distinct c.*, s.OVP from claim_probabilities c,scorred_claims s
where c.claim_id = s.claim_id")

saveRDS(scorred_claims, file="scorred_claims.Rda")
saveRDS(claims_to_investigate_claims, file="claims_to_investigate_claims356.Rda")
saveRDS(scr2, file="scr2.Rda")

claim_probabilities$claim_id <- as.integer(claim_probabilities$claim_id)
#  scorred_claims <- readRDS( file="scorred_claims.Rda")
#  claims_to_investigate_claims <- readRDS( file="claims_to_investigate_claims356.Rda")
#  scr2 <- readRDS( file="scr2.Rda")


# 180
test_positive5 <- sqldf("select * from  scr2 where P1_Overpayment < 0.5")
#20
true_positive5 <- sqldf("select * from  scr2 where P1_Overpayment < 0.5 and OVP = 1")

#22
true_positive <- sqldf("select * from  scr2 where  OVP = 1")


#19
test_positive7 <- sqldf("select * from  scr2 where P1_Overpayment < 0.3")
# 
#2
true_positive7 <- sqldf("select  * from  test_positive7
                        where OVP = 1
                        ")

#96
test_positive8 <- sqldf("select * from  scr2 where P1_Overpayment < 0.2")
true_positive8 <- sqldf("select  * from  test_positive8
                        where OVP = 1
                        ")
#0
test_positive9 <- sqldf("select * from  scr2 where P1_Overpayment < 0.1")
#22
true_positive <- sqldf("select * from  scr2 where  OVP = 1")




#0
true_positive8 <- sqldf("select  * from  test_positive8
                        where OVP = 1
                        ")
#0
true_positive9 <- sqldf("select  * from  test_positive9
                        where OVP = 1
                        ")
#DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD


test_positive5 <- sqldf("select * from  scr2 where P1_Overpayment < 0.5")

test_positive5$P5 <- ifelse(test_positive5$P1_Overpayment < 0.5, 1,0)

test_positive5$P2 <- ifelse(test_positive5$P1_Overpayment < 0.2, 1,0)

test_positive5$P1 <- ifelse(test_positive5$P1_Overpayment < 0.1, 1,0)


test_positive8 <- sqldf("select * from  test_positive5 where P1_Overpayment < 0.2")
prop.table(table(test_positive8$P2))

mytable <- table(test_positive5$P5, test_positive5$OVP)
ftable(mytable)

mytable <- table(test_positive5$P2, test_positive5$OVP)
ftable(mytable)

mytable <- table(test_positive5$P1, test_positive5$OVP)
ftable(mytable)





Safari<-sqlQuery(conn2,"select distinct  claimNO, Provider,ProviderTaxid,
AdjustedSubmittedAmt,EstimatedCommission,
NetSubmittedAmt,ProviderState,
ProviderARStatus, Insurer,caseNbr,
SafariLoaddate, WrittenBy 
from biw_analytics.dbo.dailysafaristatusupdate s with (nolock)
inner join biw_racer.dbo.casedata cd with (nolock)
on s.casenbr=cd.caseid
where Insurer='Molina Healthcare Inc'
                 and cd.hdslobid=3 
                 and ProviderARStatus='INV'")

InvClaims<-Safari
## creating label for Invoiced modeling
InvClaims$INV <- 1


sid <- sqldf("select * from claims where claim_id = 213746939")
sid <- sqldf("select * from data_OVP where claim_id = 213746939")



zclaims <- sqlQuery(
  conn1,
  "select
distinct
 cs.status_code,
 cs.reason_code ,
 cs.current_status,
clm.claim_id
,clm.claim_no
,clm.DATE_PAID
,clm.amt_allowed as claim_amt_allowed
,clm.amt_paid as claim_amt_paid
,clm.feed_id as claim_feed_id
,clm.patient_age as claim_patient_age
,clm.patient_gender as claim_patient_gender
,clm.place_of_service as claim_place_of_service
,clm.principal_diag as claim_principal_diag
,clm.date_of_service_beg as claim_date_of_service_beg
,clm.date_of_service_end as claim_date_of_service_end
,clm.provider_id as claim_provider_id
,clm.amt_billed as claim_amt_billed
,cl.revenue_code as claim_line_revenue_code
,cl.amt_billed as claim_line_amt_billed
,cl.amt_paid as claim_line_amt_paid
,cl.cpt as claim_line_cpt
,cl.cpt_modifier as claim_line_cpt_modifier
,cl.amt_allowed as claim_line_amt_allowed
,pv_prov.provider_number
,pv_prov.provider_specialty_1 as pv_provider_speciality
,pv_prov.CITY as pv_provider_city
,pv_prov.provider_first_name as pv_prov_first_name
,pv_prov.provider_last_name as pv_prov_last_name
,pv_prov.tax_id
,pv_clm.drg
,pv_clm.claim_type,
pv_prov.ZIPCODE,
pv_prov.ALTERNATE_ZIPCODE,
MEM.LAST_NAME
from racer01272.dbo.claim clm with (nolock)
inner join racer01272.dbo.claim_status cs with (nolock)
on clm.claim_id=cs.claim_id
inner join racer01272.dbo.claim_line cl with (nolock) on
cl.claim_id = clm.claim_id
inner join  racer01272.dbo.status_code sc with (nolock) on
cs.status_code = sc.status_code
INNER JOIN racer01272.dbo.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
inner join dmfeed01272.dbo.fd_molina_clm_v2 pv_clm with (nolock)
on pv_clm.claim_id = clm.claim_id
and pv_clm.claim_no = clm.claim_no
and pv_clm.feed_id = clm.feed_id
left join dmfeed01272.dbo.fd_molina_prov pv_prov with (nolock)
on pv_prov.provider_no = pv_clm.provider_no
and pv_clm.feed_id = pv_prov.feed_id
where cs.hds_lob_id = 3 -- contract
and clm.amt_paid > 0
AND clm.feed_id = 356
  AND clm.claim_id =213746939")

#========================================================

conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
                         UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')



#RacerResearch.dbo.Molina_COCO_DSPROJ_CASE2336 ds (nolock)


revued <- sqlQuery(
  conn1,
  "select * from RacerResearch.dbo.Molina_COCO_DSPROJ_CASE2336 ds (nolock) ",
  max = 100)

# feed 356 largest number of records 36302

revued <- sqlQuery(
  conn1,
  "select feed_id, count(feed_id) as cnt from RacerResearch.dbo.Molina_COCO_DSPROJ_CASE2336 ds (nolock)
  group by feed_id
  order by cnt desc")

revued <- sqlQuery(
  conn1,
  "select * from RacerResearch.dbo.Molina_COCO_DSPROJ_CASE2336 ds (nolock)
  where feed_id = 356
   order by PROB_OVP asc")


revued <- sqlQuery(
  conn1,
  "select distinct * from RacerResearch.dbo.Molina_COCO_DSPROJ_CASE2336 ds (nolock)
  where feed_id = 356
   order by PROB_OVP asc")

CASE2336_scorred <- sqldf("select distinct s.claim_id as claim_id_score, r.*, 
                          s.P0_overpayment as P0_overpayment_score,
                          s.P1_Overpayment as P1_Overpayment_score,
                          s.P0_recoverability as P0_recoverability_score,
                          s.P1_recoverability as P1_recoverability_score
                          from claims_to_investigate_claims s left join revued r  on
                          s.claim_id = r.claim_id")




conn2 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;DATABASE=racer01272;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')

statuses <- sqlQuery(
  conn2,
  "select cs.* from racer01272.dbo.claim_status cs with  (nolock),
  racer01272.dbo.claim clm with (nolock)
  where cs.CLAIM_ID = clm.CLAIM_ID
  and clm.FEED_ID = 356
  and  Convert(DATE,cs.DATE_UPDATED) >'2021-09-23'
 ")

# funk <- statuses
# funk$DATE_UPDATED <- as.Date(funk$DATE_UPDATED)
# funk$DATE_UPDATED <- as.POSIXct(funk$DATE_UPDATED, origin="1970-01-01, format = '%Y-%m-%d")
# 
# junk <- sqldf("select * from funk where DATE_UPDATED >'2021-09-23'")

last_status <- sqldf("select CLAIM_ID, max(DATE_UPDATED) as last_date
                     from statuses group by CLAIM_ID")

statuses2 <- sqldf("select distinct s.* from statuses s, last_status l
                   where s.CLAIM_ID = l.CLAIM_ID
                   and s.DATE_UPDATED = l.last_date
                   order by s.DATE_UPDATED asc")


# statuses to CASE2336_scorred


CASE2336_scorred2 <- sqldf("select c.*,
                           s.STATUS_CODE ,
                           s.CURRENT_STATUS,
                           s.REASON_CODE
                           from CASE2336_scorred c, statuses2 s
                           where c.CLAIM_ID =s.CLAIM_ID 
                           and s.hds_lob_id=3
                            ")

Reviewed_OVP <- sqldf("select * from CASE2336_scorred2 where status_code in (2,50) and current_status=1")

Reviewed_nonOVP <- sqldf("select * from CASE2336_scorred2 where status_code in (1,20)
                         and reason_code in (13,14,16,17,19,22,24,31,71)")



# remove restriction of most recent


CASE2336_scorred2 <- sqldf("select c.*,
                           s.STATUS_CODE ,
                           s.CURRENT_STATUS,
                           s.REASON_CODE
                           from CASE2336_scorred c, statuses s
                           where c.CLAIM_ID =s.CLAIM_ID 
                           and s.hds_lob_id=3
                           and s.current_status=1 ")
# difference of one
Reviewed_OVP <- sqldf("select * from CASE2336_scorred2 where status_code in (2,50)")

Reviewed_nonOVP <- sqldf("select * from CASE2336_scorred2 where status_code in (1,20)
                         and reason_code in (13,14,16,17,19,22,24,31,71)")




#SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS\\


# pre process with SOM models
base3_distinct <- base3

library(h2o)
#h2o.init()
h2o.init(port=54333)

base3$claim_id<-NULL


# 1/21/22
# SOM mmebersjip
SOM_membership1<- h2o.loadModel( "/home/dless1/molina/gbm/GBM_model_R_1642684488221_2218")


# 1/14/22
#rf_95<- h2o.loadModel("/home/dless1/molina/gbm/GBM_model_R_1642178978036_11610")

# parsomonious
#rf_95<- h2o.loadModel("/home/dless1/molina/gbm/GBM_model_R_1642604997371_24")


data_to_score <- as.h2o(base3)



pred <- h2o.predict(object = SOM_membership1, newdata = data_to_score)


pred_df <- as.data.frame(pred )



# make output files

cl_ids <- base3_distinct %>%
  select(claim_id) 

SOM_probabilities <- cbind(cl_ids,pred_df )

# SOM_probabilities_P9 <- sqldf("select * from SOM_probabilities where p1 <= 0.018")
# 
# base3_SOM <- sqldf("select b.* from base3_distinct b,SOM_probabilities_P9 s
#                    where b.claim_id = s.claim_id")
# 
# base3_SOM$claim_id <- NULL


# 1/14/22
rf_95<- h2o.loadModel("/home/dless1/molina/gbm/GBM_model_R_1642178978036_11610")

data_to_score <- as.h2o(base3)

pred <- h2o.predict(object = rf_95, newdata = data_to_score)


pred_df <- as.data.frame(pred )



# make output files

cl_ids <-base3 %>%
  select(claim_id) 

base3_probabilities <- cbind(cl_ids,pred_df )


 #scorred_claims <- readRDS( file="scorred_claims.Rda")
#  claims_to_investigate_claims <- readRDS( file="claims_to_investigate_claims356.Rda")
#  scr2 <- readRDS( file="scr2.Rda")

 scr <- sqldf("select distinct claim_id, OVP from scorred_claims")
 scr$claim_id <- as.numeric( scr$claim_id)
 
 
 #183
 scr2 <- sqldf("select distinct c.*, s.OVP from base3_probabilities  c,scorred_claims s
where c.claim_id = s.claim_id") 
 
 scr3 <- sqldf("select s.*, m.p1 as p1_SOM from scr2 s, SOM_probabilities m
               where s.claim_id = m.claim_id")
 
 
 junk <- sqldf("select * from scr3 where p1 < .35")
 summary(junk)
 
 
 
 
 
 

# 180
test_positive5 <- sqldf("select * from  scr2 where p1 < 0.5")
#22
true_positive5 <- sqldf("select * from  scr2 where p1 < 0.5 and OVP = 1")

#22
true_positive <- sqldf("select * from  scr2 where  OVP = 1")


#113
test_positive7 <- sqldf("select * from  scr2 where p1 < 0.3")


#113
test_positive8 <- sqldf("select * from  scr2 where p1 < 0.2")

#13
test_positive9 <- sqldf("select * from  scr2 where p1 < 0.12")


#22
true_positive <- sqldf("select * from  scr2 where  OVP = 1")

# 
#2
true_positive7 <- sqldf("select  * from  test_positive7
                        where OVP = 1
                        ")


#0
true_positive8 <- sqldf("select  * from  test_positive8
                        where OVP = 1
                        ")
#0
true_positive9 <- sqldf("select  * from  test_positive9
                        where OVP = 1
                        ")