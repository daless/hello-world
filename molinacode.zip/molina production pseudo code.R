
# for molina prod to match the same base 2 column name

# for each group of variables like FIPS, POS, et

# extract the column names
junk <-base2 %>% select(starts_with("AHRQ"))

# convert the column names to a df
funk <- as.data.frame(colnames(junk))
names(funk)[1] <- 'mycol'
# get only the columns that are in the original base 2
junk2<- base2[, names(base2) %in% funk$mycol]

# repeat for each variable group
# if no match will need to add manually?



clmv1 <- sqlQuery( conn1, "select claim_id, feed_id from dmfeed01272.dbo.fd_molina_clm where
                   feed_id = 295 ", max=200)



clmv2 <- sqlQuery( conn1, "select CLAIM_ID, feed_id from dmfeed01272.dbo.fd_molina_clm_v2 where
                   feed_id = 341 ", max=20)


clmv2 <- sqlQuery( conn1, "select * from dmfeed01272.dbo.fd_molina_clm_v2 where
                   feed_id = 341 ", max=20)


clmv0 <- sqlQuery( conn1, "select max(DATE_PAID) as mx from racer01272.dbo.claim with (nolock) where
                   feed_id = 340")



Safarix<-sqlQuery(conn2,"select s.*
from biw_analytics.dbo.dailysafaristatusupdate s with (nolock)
inner join biw_racer.dbo.casedata cd with (nolock)
on s.casenbr=cd.caseid
where Insurer='Molina Healthcare Inc'
                 and cd.hdslobid=3 
                 and ProviderARStatus='INV'",
                  max = 10)


ff <- sqlQuery(
  conn1,
  "select
distinct
clm.DATE_PAID,
clm.FEED_ID
from racer01272.dbo.claim clm with (nolock)
where DATEDIFF(D,  clm.DATE_PAID, GETDATE()) >= 150
AND DATEDIFF(D,  clm.DATE_PAID, GETDATE()) <= 190")


fff <- sqldf("select FEED_ID, count(FEED_ID) as cnt from ff group by FEED_ID order by cnt desc")


fins <- sqlQuery(conn2,"select distinct Insurer from biw_analytics.dbo.dailysafaristatusupdate")


Safariall<-sqlQuery(conn2,"select distinct claimNO, Provider,ProviderTaxid,
AdjustedSubmittedAmt,EstimatedCommission,
NetSubmittedAmt,ProviderState,
ProviderARStatus, Insurer,caseNbr,
SafariLoaddate, WrittenBy ,  cd.hdslobid
from biw_analytics.dbo.dailysafaristatusupdate s with (nolock)
inner join biw_racer.dbo.casedata cd with (nolock)
on s.casenbr=cd.caseid
where Insurer='Molina Healthcare Inc'
               
                 and ProviderARStatus='INV'")



Safariall<-sqlQuery(conn2,"select distinct claimNO, Provider,ProviderTaxid,
AdjustedSubmittedAmt,EstimatedCommission,
NetSubmittedAmt,ProviderState,
ProviderARStatus, Insurer,caseNbr,
SafariLoaddate, WrittenBy 
from biw_analytics.dbo.dailysafaristatusupdate s with (nolock)

where Insurer='Molina Healthcare Inc'
               
                 and ProviderARStatus='INV'")
