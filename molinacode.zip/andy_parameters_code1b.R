




setwd("~/molina")


library(tidyverse)
library(h2o)
library(h2oEnsemble)
# library(readxl)
# library(openxlsx)
# 
# dataPaths = c("/home/adang3/COCO/TrainResults/train_2022_01_05_08_32_04/")
# outPath = getwd() # <---- speficy this

h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)

metricsList = list()
getResult = function(mod,
                     id,
                     specs,
                     info
){
  
  train_res = h2o.performance(mod,newdata=train)
  test_res = h2o.performance(mod,newdata=test)
  osod_res = h2o.performance(mod,newdata=osod)
  
  AUC = tibble(`AUC_Train`=train_res@metrics$AUC,
               `AUC_Test`=test_res@metrics$AUC,
               `AUC_OSOD`=osod_res@metrics$AUC)
  
  AUC = AUC %>% mutate_if(is.double,as.character)
  if(!str_detect(id,'ENS')) {
    AUC[2:3,] = tibble(AUC_Train=c(NA,specs),AUC_Test=NA,AUC_OSOD=NA)
  } 
  
  varimp = h2o.varimp(mod) %>% as_tibble() %>% arrange(desc(relative_importance))
  
  # confusion matrices
  cm_osod_ls = list()
  
  thres_ = seq(0.2,0.7,0.05)

  
  for(i in seq_along(thres_)){
    cm_osod=as.data.frame(h2o.confusionMatrix(osod_res,threshold=thres_[i]))
    cm_osod$`Actual/Predicted`=c('0','1','Total')
    cm_osod=cm_osod %>% select(`Actual/Predicted`,everything()) 
    cm_osod=cm_osod[1:2,1:3]
    cm_osod$Threshold = c(thres_[i],NA)
    cm_osod_ls[[i]]=cm_osod
   
  }
  cm_osod = bind_rows(cm_osod_ls)
  
  
  thres = seq(0,1,0.05)
 
  # Train
  recall_v = NULL; precision_v = NULL
  for(i in thres){
    recall_v = c(recall_v,h2o.recall(train_res, thresholds=i)[[1]])
    precision_v = c(precision_v,h2o.precision(train_res, thresholds=i)[[1]])
  }
  metrics_train = data.frame(Threshold=thres,Recall_Train=recall_v,Precision_Train=precision_v)
  # Test
  recall_v = NULL; precision_v = NULL
  for(i in thres){
    recall_v = c(recall_v,h2o.recall(test_res, thresholds=i)[[1]])
    precision_v = c(precision_v,h2o.precision(test_res, thresholds=i)[[1]])
  }
  metrics_test = data.frame(Threshold=thres,Recall_Test=recall_v,Precision_Test=precision_v)
  # Osod
  recall_v = NULL; precision_v = NULL
  for(i in thres){
    recall_v = c(recall_v,h2o.recall(osod_res, thresholds=i)[[1]])
    precision_v = c(precision_v,h2o.precision(osod_res, thresholds=i)[[1]])
  }
  metrics_osod = data.frame(Threshold=thres,Recall_OSOD=recall_v,Precision_OSOD=precision_v)
  
  cm = cm_osod
  
  if(!str_detect(id,'ENS')) {
    AUC[4:nrow(cm),] = NA
  } else {
    AUC[2:nrow(cm),] = NA
  }
  
  metrics_test[(nrow(metrics_test)+1):nrow(cm),]=tibble(Threshold=NA,Recall_Test=NA,Precision_Test=NA)
  metrics_osod[(nrow(metrics_osod)+1):nrow(cm),]=tibble(Threshold=NA,Recall_Test=NA,Precision_Test=NA)
  
  # empty column dividers
  space = tibble(space=rep(NA,nrow(cm)))
  
  info[3:nrow(cm),] = NA
  
  (tmp = bind_cols(metrics_test,metrics_osod %>% select(-Threshold),space,AUC,space,cm,space,info))
  
  metricsList[[id]] <<- tmp
  
}



# dataPath = dataPaths[1]
# dateinfo = read_csv(paste0(dataPath,'date.csv'))
# write_csv(x=dateinfo,path=paste0(outPath,'date.csv'))
# 
# # load data
# load(paste0(dataPath,'OVP_Data.RData'))
# load(paste0(dataPath,'OSOD.RData'))
# ls()
# 
# 
# # training model (RF)
# train0=train
# test0=test
# osod0=osod_ovp

train <- readRDS( file="andy_train.Rda")
test <- readRDS( file="andy_test.Rda")
osod_ovp <- readRDS( file="andy_OSOD.Rda")

#saveRDS(train, file="andy_train.Rda")
#saveRDS(test, file="andy_test.Rda")
#saveRDS(base3, file="andy_OSOD.Rda")


dtrain = train %>% count(OVP) %>% rename(train=n) %>% mutate(train_perc = train/sum(train))
dtest = test %>% count(OVP) %>% rename(test=n) %>% mutate(test_perc = test/sum(test))
dosod = osod_ovp %>% count(OVP) %>% rename(osod=n) %>% mutate(osod_perc = osod/sum(osod))
info = dtrain %>% inner_join(dtest) %>% inner_join(dosod)

train = as.h2o(train)
test = as.h2o(test)
osod = as.h2o(osod_ovp)
y = "OVP"
x = setdiff(names(train),y)
y <- "OVP"
x <- setdiff(names(train), y)
predictors <- setdiff(names(train), y)
response <- "OVP"


# gbm4 = mod = h2o.gbm(
#   x = predictors,
#   y = response,
#   training_frame = train,
#   validation_frame = test,
#   ntrees = 500,
#   learn_rate = 0.01,
#   stopping_rounds = 5,
#   stopping_tolerance = 1e-4,
#   balance_classes = TRUE,
#   sample_rate = 0.8,
#   col_sample_rate = 0.8,
#   seed = 77,
#   model_id = id,
#   score_tree_interval = 10
# )
# 
# summary(gbm4)
# head(as.data.frame(h2o.varimp(gbm4)),n=20)


nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  
  distribution = "bernoulli",
  ntrees = 500,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

summary(solo_gbm)


solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 500,
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 500,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)


solo_xgboost700 <- h2o.xgboost(x=x,
                               y = y,
                               training_frame = train,
                               ntrees = 700,
                               nfolds = nfolds,
                               fold_assignment = "Modulo",
                               keep_cross_validation_predictions = TRUE,
                               max_depth = 3,
                               min_rows = 2,
                               learn_rate =0.2,
                               seed = 77)



solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo", categorical_encoding = "AUTO",
                            standardize= TRUE, activation = "Tanh",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble  = mod = h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial6",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id))


specs = NULL
# specsName = names(mod@parameters)[!(names(mod@parameters)%in%
#                                       c('model_id','training_frame','validation_frame',
#                                         'keep_cross_validation_predictions','distribution','x','y'))]


id ="ensemble_binomial6"
model_id = id

specsName = names(mod@parameters)[!(names(mod@parameters)%in%
                                      c('model_id','training_frame','validation_frame',
                                        'x','y'))]

specsName = names(mod@parameters)[!(names(mod@parameters)%in%
                                      c('model_id','training_frame','validation_frame',
                                        'keep_cross_validation_predictions','distribution','x','y'))]


for(i in c(specsName)){specs = paste0(specs,paste0(i,':',mod@parameters[[i]],' '))}
metricsList <- getResult(mod,id,specs,info)

write.csv(metricsList, file = "andy_metricsList.csv")

#   scp dless1@apsrd9425:/home/dless1/molina/andy_metricsList.csv ~/Desktop


#write.xlsx(metricsList, file = paste0(outPath,"metricOut.xlsx"))

