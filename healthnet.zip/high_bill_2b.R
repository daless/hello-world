# this goes back 1 yesr
# pulls all docs with all 5 COT office visits
# compares to all docs
# finds chi sqaure an cramers V
# only 9 docs had all 5
# the test compares the doc ratios to all docs




setwd("~/healthnet")
library(comorbidity)
library(RODBC)
library(sqldf)
library(dplyr)
library(tidyr)
library(tidyverse)



library(RODBC)
conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')


# 
# docdb = sqlQuery(
#   conn,
#   "SELECT  * from RACER01132.DBO.PROVIDER with (nolock)",
#   max=50)
# docdb = sqlQuery(
#   conn,
#   "SELECT  * from DMFEED01132.DBO.FD_HNT_PROV with (nolock)",
#   max=50)




















#table listing in db
#table_listing <- as.data.frame(sqlTables(conn))
#write.csv(table_listing,file="racer_scehma.csv")

#claim_line <- sqlColumns(
#  conn, "dbo.CLAIM_LINE"  )


library(h2o)
# h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)
# h2o.init(port=54333)


data0 = sqlQuery(
  conn,
  "SELECT DISTINCT c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID                                                                                
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,c.CLAIM_NO as CLAIM_CLAIM_NO                                                                                
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID                                                                              
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
,PROV.PROVIDER_NO as FFD_HNT_PROV_PROVIDER_NO                                                        
,PROV.CITY as FD_HNT_PROV_CITY                                                                      
,PROV.PROV_NAME as FD_HNT_PROV_PROV_NAME                                                            
,PROV.PROVIDER_TYPE as FD_HNT_PROV_PROVIDER_TYPE                                                                                              
,PROV.NPI as FD_HNT_PROV_NPI
,PROV.PROVIDER_SPECIALTY_1
,cs.PROJECT_ID as CLAIM_STATUS_PROJECT_ID
,P.PROVIDER_ID as PROV_PROVIDER_ID
from dmfeed01132.dbo.FD_HNT_CLM dc
inner join RACER01132.DBO.CLAIM c
on dc.claim_no = c.claim_no
inner join racer01132.dbo.claim_Status cs                                                                        
on c.claim_id = cs.claim_id
INNER JOIN RACER01132.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
inner join racer01132.dbo.case_data cd                                                                          
on cd.case_id = cs.case_id  
inner join Racer01132.dbo.STATUS_CODE sc                                                                         
on sc.status_code = cs.status_code
INNER JOIN RACER01132.DBO.PROVIDER P                                                                             
ON P.PROVIDER_ID = C.PROVIDER_ID
INNER JOIN DMFEED01132.DBO.FD_HNT_PROV PROV                                                                      
ON (P.PROVIDER_NO = PROV.PROVIDER_NO AND PROV.FEED_ID = C.FEED_ID)
CROSS APPLY (SELECT TOP 1 * FROM  DMFEED01132.DBO.FD_HNT_MEM  MEM (NOLOCK)
WHERE MEM.PAT_MEMBER_NO = DC.SUB_MEMBER_NO  
AND MEM.FEED_ID > 10 ) M
LEFT join Racer01132.dbo.REASON_CODE rc                                                                          
on CS.REASON_CODE = RC.REASON_CODE
WHERE  DATEDIFF(D,  dc.DATE_OF_SERVICE_BEG, GETDATE()) < 365
and dc.CLAIM_ID IS NOT NULL 
and cs.PROJECT_ID = 01132
and c.CLAIM_ID IS NOT NULL
  and cl.CPT in ('99201',
  '99202',
  '99203',
  '99204',
  '99205' )
  ")


cpt_by_doc <- sqldf("select FFD_HNT_PROV_PROVIDER_NO as physician_id,
                    CLAIM_LINE_CPT as CPT, COUNT(CLAIM_LINE_CPT) as cnt
                    from data0 group by FFD_HNT_PROV_PROVIDER_NO, CLAIM_LINE_CPT ")


cpt_tot <- sqldf("select 
                    CLAIM_LINE_CPT as CPT_all, COUNT(CLAIM_LINE_CPT) as all_docs
                    from data0 group by  CLAIM_LINE_CPT ")



cpt_by_doc2_cnt <- sqldf("select physician_id, count(physician_id) as tcnt
                         from cpt_by_doc
                         group by physician_id
                         HAVING tcnt =5")


cpt_by_doc2 <- sqldf("select c.* from cpt_by_doc c, cpt_by_doc2_cnt t
where c.physician_id = t.physician_id")


cpt_by_doc2_cnt <- sqldf("select c.*, d.CPT_all, d.all_docs
                         from cpt_by_doc2 c, cpt_tot  d
                         where c.CPT = d.CPT_all")


#chi1 <- sqldf("select CPT, CPT_all from cpt_by_doc2_cnt where physician_id = '271346767A'")
#library(dplyr)
#library(lsr)

jid <- sqldf("select distinct physician_id from cpt_by_doc2_cnt")
dummy_col_names <- c(  "cnt", "all_docs", "chi_results2", "physician_id")

dummy_pull <- data.frame(matrix(ncol = 4, nrow = 1))
colnames(dummy_pull) <- dummy_col_names

for (i in rownames(jid))
{
  jid_loop <- jid[i, ]
  
  j_string <- paste0("select cnt, all_docs from cpt_by_doc2_cnt 
                     where physician_id ='",jid_loop,"'")
  
  chi1 <- sqldf(j_string)

chi_results <- lapply(chi1[-length(chi1)],
                      function(x) chisq.test(table(x, chi1$all_docs)))

V_results <- lapply(chi1[-length(chi1)],
                      function(x) cramersV(table(x, chi1$all_docs)))



chi_results2 <- unlist(sapply(chi_results, "[", "p.value"))

chi_results2 <- as.data.frame(chi_results2 )

cramr <- apply(chi1, 2, cramersV)
cramr_results <- as.data.frame(cramr )
cramr_resultsV <- as.data.frame(t(cramr_results))
cramr_resultsV <- cbind(cramr_resultsV,chi_results2)
cramr_resultsV$physician_id <- jid_loop

dummy_pull <- rbind(dummy_pull, cramr_resultsV)

}


final_output <- sqldf("select cnt as cramers1,all_docs as cramers2,
                      chi_results2 as chi_results,
                      physician_id from dummy_pull
                      where physician_id != ''")


write.csv(final_output, file = "unbundle_example.csv")
#scp dless1@apsrd9425:/home/dless1/healthnet/unbundle_example.csv /H/My_Doccuments

