
# original code adding FIPS codes, new CCS file and experimental feature reduction

setwd("~/healthnet")

library(RODBC)
library(sqldf)
library(dplyr)
library(tidyr)
library(tidyverse)



library(RODBC)
conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')



docdb = sqlQuery(
  conn,
  "SELECT  * from RACER01132.DBO.PROVIDER with (nolock)",
  max=50)
docdb = sqlQuery(
  conn,
  "SELECT  * from DMFEED01132.DBO.FD_HNT_PROV with (nolock)",
  max=50)




















#table listing in db
#table_listing <- as.data.frame(sqlTables(conn))
#write.csv(table_listing,file="racer_scehma.csv")

#claim_line <- sqlColumns(
#  conn, "dbo.CLAIM_LINE"  )



h2o.init(port=54333)
h2o.shutdown(prompt  = FALSE)
h2o.init(port=54333)


data0 = sqlQuery(
  conn,
  "SELECT DISTINCT c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID                                                                                
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,c.CLAIM_NO as CLAIM_CLAIM_NO                                                                                
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID                                                                              
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
,PROV.PROVIDER_NO as FFD_HNT_PROV_PROVIDER_NO                                                        
,PROV.CITY as FD_HNT_PROV_CITY                                                                      
,PROV.PROV_NAME as FD_HNT_PROV_PROV_NAME                                                            
,PROV.PROVIDER_TYPE as FD_HNT_PROV_PROVIDER_TYPE                                                                                              
,PROV.NPI as FD_HNT_PROV_NPI
,PROV.PROVIDER_SPECIALTY_1
,cs.PROJECT_ID as CLAIM_STATUS_PROJECT_ID
,P.PROVIDER_ID as PROV_PROVIDER_ID
from dmfeed01132.dbo.FD_HNT_CLM dc
inner join RACER01132.DBO.CLAIM c
on dc.claim_no = c.claim_no
inner join racer01132.dbo.claim_Status cs                                                                        
on c.claim_id = cs.claim_id
INNER JOIN RACER01132.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
inner join racer01132.dbo.case_data cd                                                                          
on cd.case_id = cs.case_id  
inner join Racer01132.dbo.STATUS_CODE sc                                                                         
on sc.status_code = cs.status_code
INNER JOIN RACER01132.DBO.PROVIDER P                                                                             
ON P.PROVIDER_ID = C.PROVIDER_ID
INNER JOIN DMFEED01132.DBO.FD_HNT_PROV PROV                                                                      
ON (P.PROVIDER_NO = PROV.PROVIDER_NO AND PROV.FEED_ID = C.FEED_ID)
CROSS APPLY (SELECT TOP 1 * FROM  DMFEED01132.DBO.FD_HNT_MEM  MEM (NOLOCK)
WHERE MEM.PAT_MEMBER_NO = DC.SUB_MEMBER_NO  
AND MEM.FEED_ID > 10 ) M
LEFT join Racer01132.dbo.REASON_CODE rc                                                                          
on CS.REASON_CODE = RC.REASON_CODE
WHERE  DATEDIFF(D,  dc.DATE_OF_SERVICE_BEG, GETDATE()) < 180
and dc.CLAIM_ID IS NOT NULL 
and cs.PROJECT_ID = 01132
and  M.LAST_NAME <> 'HN ASSOCIATE'
and c.CLAIM_ID IS NOT NULL
  and cl.CPT in ('96401',
  '99211',
  '99212',
  '99213',
  '99214',
  '99215',
  '99216',
  '99217',
  '99218',
  '99219',
  '99220',
  '99221',
  '99222',
  '99223',
  '99224',
  '99225'  )
  ")



docid <- sqldf("select PROV_PROVIDER_ID, count(PROV_PROVIDER_ID) as cnt from data0
               group by PROV_PROVIDER_ID order by cnt desc")



data1 = sqlQuery(
  conn,
  "SELECT                                                                  
c.CLAIM_NO as CLAIM_CLAIM_NO                                                                                
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID                                                                              
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
,PROV.PROVIDER_NO as FFD_HNT_PROV_PROVIDER_NO                                                        
,PROV.CITY as FD_HNT_PROV_CITY                                                                      
,PROV.PROV_NAME as FD_HNT_PROV_PROV_NAME                                                            
,PROV.PROVIDER_TYPE as FD_HNT_PROV_PROVIDER_TYPE                                                                                              
,PROV.NPI as FD_HNT_PROV_NPI 
,PROV.PROVIDER_SPECIALTY_1
,P.PROVIDER_ID
from dmfeed01132.dbo.FD_HNT_CLM dc
inner join RACER01132.DBO.CLAIM c
on dc.claim_no = c.claim_no
inner join racer01132.dbo.claim_Status cs                                                                        
on c.claim_id = cs.claim_id
INNER JOIN RACER01132.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
inner join racer01132.dbo.case_data cd                                                                          
on cd.case_id = cs.case_id  
inner join Racer01132.dbo.STATUS_CODE sc                                                                         
on sc.status_code = cs.status_code
INNER JOIN RACER01132.DBO.PROVIDER P                                                                             
ON P.PROVIDER_ID = C.PROVIDER_ID
INNER JOIN DMFEED01132.DBO.FD_HNT_PROV PROV                                                                      
ON (P.PROVIDER_NO = PROV.PROVIDER_NO AND PROV.FEED_ID = C.FEED_ID)
CROSS APPLY (SELECT TOP 1 * FROM  DMFEED01132.DBO.FD_HNT_MEM  MEM (NOLOCK)
WHERE MEM.PAT_MEMBER_NO = DC.SUB_MEMBER_NO  
AND MEM.FEED_ID > 10 ) M
LEFT join Racer01132.dbo.REASON_CODE rc                                                                          
on CS.REASON_CODE = RC.REASON_CODE
WHERE  DATEDIFF(D,  dc.DATE_OF_SERVICE_BEG, GETDATE()) < 180
and dc.CLAIM_ID IS NOT NULL 
and cs.PROJECT_ID = 01132
and  M.LAST_NAME <> 'HN ASSOCIATE'
and c.CLAIM_ID IS NOT NULL
  and P.PROVIDER_ID in('14570',
'4117423',
'351680',
'3581834',
'44980',
'142196',
'722575',
'610019',
'481738',
'100460',
'101113',
'101338',
'618594',
'4981205',
'67089',
'5012640',
'67304',
'375153',
'5112991',
'140644')")


library(arules)
library(arulesViz)
library(visNetwork)
library(igraph)

ap1 <- sqldf("select distinct CLAIM_CLAIM_NO  as CLAIM_ID, CLAIM_LINE_CPT as CPT from data1 order by CLAIM_CLAIM_NO ")







ap2 <- ddply(ap1, c("CLAIM_ID"),
             function(ap1)paste(ap1$CPT,
                                collapse = ','))

names(ap2)[2] <- "CPT"

ap3 <- ap2
ap3$CLAIM_ID <- NULL

write.csv(ap2, file = "ccs_transactions.csv")

txn <- read.transactions(file="ccs_transactions.csv", rm.duplicates = TRUE,
                         format="single", sep=",", cols=c("CLAIM_ID","CPT"))






























DX_claim  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM RACER01132.dbo.CLAIM CLM
  INNER JOIN RACER01132.dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  where CLM.PROJECT_ID = 1132
  AND  DX.ORDER_IN_CLAIM <= 4
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc"
)



claims_OP<-sqldf("select * from data0 where CLAIM_STATUS_STATUS_CODE in (50,14,2) and CLAM_STATUS_CURRENT_STATUS=1")
claims_OP$OVP=1
claims_NOP<-sqldf("select * from data0 where (CLAIM_STATUS_STATUS_CODE in (20) and CLAIM_STATUS_REASON_CODE in (13,14,16,17,19,22,24,27,31,39,71) and CLAM_STATUS_CURRENT_STATUS=1) or (CLAIM_STATUS_STATUS_CODE in (40,1) and CLAM_STATUS_CURRENT_STATUS=1) ")
claims_NOP$OVP=0
claims<-rbind(claims_OP,claims_NOP)
Unique_claimids <- sqldf("select distinct CLAIM_CLAIM_ID from  claims")
DX_claimids  <- sqldf("SELECT DISTINCT d.*,m.* from DX_claim d INNER JOIN Unique_claimids as m 
                  ON d.CLAIM_ID =m.CLAIM_CLAIM_ID")
DX_claimids$ICD9_CODE<-as.character(DX_claimids$ICD9_CODE)
DX_claimids$ICD10_CODE<-DX_claimids$ICD9_CODE
DX_claimids$ICD9_CODE<-gsub(".","",DX_claimids$ICD9_CODE,fixed=TRUE)
DX_claimids_Diag <- sqldf("select distinct * from DX_claimids where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")
elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")

claims$Days_of_service <- difftime(claims$CLAIM_DATE_OF_SERVICE_END , 
                                   claims$CLAIM_DATE_OF_SERVICE_BEG,
                                   units = c("days")) 

# remove positive skew of LOS
claims$Days_of_service <- round(sqrt(as.integer(claims$Days_of_service + 1)))
# remove decimals from princiapl dx code
claims$CLAIM_PRINCIPAL_DIAG <- as.character(claims$CLAIM_PRINCIPAL_DIAG)
claims$CLAIM_PRINCIPAL_DIAG <- gsub(".","",claims$CLAIM_PRINCIPAL_DIAG, fixed = TRUE)


# place of service
claims$PLACE_OF_SERVICE<- ifelse(is.na(claims$CLAIM_PLACE_OF_SERVICE), 0, 
                                 claims$CLAIM_PLACE_OF_SERVICE)
claims$PLACE_OF_SERVICE<- as.factor(claims$PLACE_OF_SERVICE)

##### CCS groupings##########

# CCS<-read.csv("ccs_dx_icd10cm_2018_1.csv")

CCS<-read.csv("ccs_dx_icd10cm_2019_1.csv")
#names(CCS)[1]<-"ICD10_Code"
#names(CCS)[2]<-"CCS_Category"
CCS$ICD10_Code<-as.character(CCS$ICD10_Code)
CCS$ICD10_Code<-gsub("'","",CCS$ICD10_Code,fixed=TRUE)
CCS$CCS_Category<-gsub("'","",CCS$CCS_Category,fixed=TRUE)
# build CCS dx table
DX_CCS <- sqldf("select DISTINCT d.*,  c.CCS_Category
 from DX_claimids d left join CCS c on d.ICD9_CODE = c.ICD10_Code
                        order by d.CLAIM_ID")
DX_CCS$CCS_Category <- ifelse(is.na(DX_CCS$CCS_Category), 0, DX_CCS$CCS_Category)

DX_CCS$CCS_Category <-as.factor(DX_CCS$CCS_Category)
### One hot encoding of CCS variables #####

CCS_Dummy_test <- sqldf("select CLAIM_ID, CCS_Category from DX_CCS order by CLAIM_ID")
## Making a wide table
CCS_Dummy_test1 <- cbind(CCS_Dummy_test, dummy(CCS_Dummy_test$CCS_Category, sep= "_"))
#replace with CCS
colnames(CCS_Dummy_test1)<-gsub("CCS_Dummy_test","CCS",colnames(CCS_Dummy_test1))
# CCS per Claim ID
CCS_Dummy_test2<-CCS_Dummy_test1%>%group_by(CLAIM_ID)%>%summarise_if(is.numeric,sum)


# temporarialy make claim id text
CCS_Dummy_test2$CLAIM_ID <- as.character(CCS_Dummy_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CCS_Dummy_test3 <- CCS_Dummy_test2 %>% mutate_if(is.numeric,
                                                 function(x) case_when(
                                                   x >= 1 ~ 1,
                                                   x == 0 ~ 0
                                                 )
)

CCS_Dummy_test3 <- lapply(CCS_Dummy_test3, factor)

CCS_Dummy_test3<-as.data.frame(CCS_Dummy_test3)

CCS_Dummy_test3$CLAIM_ID <- as.numeric(as.character(CCS_Dummy_test3$CLAIM_ID))

##### Configuring Place of service
POS <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID, CLAIM_PLACE_OF_SERVICE from claims")
names(POS)[2]<-"POS"
POS <- cbind(POS, dummy(POS$POS , sep= "_"))


# group by client id
POS1 <- POS %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
POS1$CLAIM_ID <- as.character(POS1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
POS2 <- POS1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

POS2 <- lapply(POS2, factor) 
POS2 <- as.data.frame(POS2)
POS2$CLAIM_ID <- as.numeric(as.character((POS2$CLAIM_ID)))
POS2$POS <- NULL
##### configuring Claim Line CPT###

CPT <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID,  CLAIM_LINE_CPT as CPT from claims")


CPT <- cbind(CPT, dummy(CPT$CPT , sep= "_"))


# group by client id
CPT1 <- CPT %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor) 
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character((CPT2$CLAIM_ID)))
CPT2$CPT <- NULL
####### Configuring Provider city#########
# PROV_CITY <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID,  FD_HNT_PROV_CITY as PROV_CITY from claims")
# 
# PROV_CITY <- cbind(PROV_CITY, dummy(PROV_CITY$PROV_CITY , sep= "_"))
# 
# 
# # group by client id
# PROV_CITY1 <- PROV_CITY %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)


# map FIPS to Zip code
fips_zips<-read.csv("FIPS.csv")

PROV_CITY <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID,  FD_HNT_PROV_CITY as PROV_CITY,
                  PROV_ZIP as ZIP from claims where  ZIP <> ''")
PROV_CITY$zip5 <- substr(PROV_CITY$ZIP, start =1, stop = 5)
PROV_fips <- sqldf("select DISTINCT p.*, f.FIPS from PROV_CITY p, fips_zips f where p.ZIP5 = f.ZIP" )
# force single zip to FIPS mapping
PROV_fips <- PROV_fips[!duplicated(PROV_fips$CLAIM_ID),]
PROV_fips <- cbind(PROV_fips, dummy(PROV_fips$FIPS , sep= "_"))


# temp make id character
#PROV_CITY1$CLAIM_ID <- as.character(PROV_CITY1$CLAIM_ID)
PROV_fips$CLAIM_ID <- as.character(PROV_fips$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_fips2 <- PROV_fips %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_fips2 <- lapply(PROV_fips2, factor) 
PROV_fips2 <- as.data.frame(PROV_fips2)
PROV_fips2$CLAIM_ID <- as.numeric(as.character((PROV_fips2$CLAIM_ID)))
PROV_fips2$FIPS <- NULL

###### Configuring Provider Type#######
PROV_TYPE <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID,  FD_HNT_PROV_PROVIDER_TYPE as PROV_TYPE from claims")

PROV_TYPE <- cbind(PROV_TYPE, dummy(PROV_TYPE$PROV_TYPE , sep= "_"))


# group by client id
PROV_TYPE1 <- PROV_TYPE %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
PROV_TYPE1$CLAIM_ID <- as.character(PROV_TYPE1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
PROV_TYPE2 <- PROV_TYPE1 %>% mutate_if(is.numeric,
                                       function(x) case_when(
                                         x >= 1 ~ 1,
                                         x == 0 ~ 0
                                       )
)

PROV_TYPE2 <- lapply(PROV_TYPE2, factor) 
PROV_TYPE2 <- as.data.frame(PROV_TYPE2)
PROV_TYPE2$CLAIM_ID <- as.numeric(as.character((PROV_TYPE2$CLAIM_ID)))
PROV_TYPE2$PROV_TYPE <- NULL


###Saved in a Rdata file

########Deriving new features#######3


claims$CLAIM_LINE_AMT_BILLED[is.na(claims$CLAIM_LINE_AMT_BILLED)] <-0
claims$CLAIM_AMT_ALLOWED[is.na(claims$claims$CLAIM_AMT_ALLOWED)] <-0
claims$claims$CLAIM_LINE_AMT_PAID[is.na(claims$claims$CLAIM_LINE_AMT_PAID)] <-0


claims$ratio_billed_to_paid<-(claims$CLAIM_LINE_AMT_BILLED + 1 )/(claims$CLAIM_LINE_AMT_PAID +1 )
claims$ratio_allowed_to_paid<-(claims$CLAIM_AMT_ALLOWED +1 ) /(claims$CLAIM_AMT_PAID +1)
claims$PATIENT_AGE_NORM <- scale(claims$CLAIM_PATIENT_AGE)
claims$PATIENT_AGE_NORM<-as.numeric(claims$PATIENT_AGE_NORM)
prop.table(table(claims$OVP))


####### Creating a target variable for Leakage to perform dimensional reduction############

icd10codes<-sqldf('select distinct ICD10_CODE from DX_claimids')


icd10codes_leakage<-sqldf("select * from icd10codes where    ICD10_CODE in 
(
'I10',
'N18.6',
'J44.9',
'N39.0',
'E11.9',
'A41.9',
'M54.5',
'J18.9',
'R07.9',
'J96.10',
'M54.2',
'Z12.31',
'G47.33',
'R07.89',
'R10.9',
'Z34.83',
'F03.90',
'J06.9',
'Z12.11',
'J44.1',
'I50.9',
'R51',
'M62.81',
'G30.9',
'Z00.129',
'Z23',
'H90.3',
'R13.10',
'R06.02',
'D64.9',
'Z01.419',
'G20',
'I25.10',
'R05',
'E86.0',
'E78.5',
'E11.65',
'G40.909',
'J02.9',
'Z51.89',
'Z30.49',
'Z51.11',
'R55',
'Z39.1',
'G93.40',
'J96.90',
'I67.9',
'R42',
'R56.9',
'E03.9',
'S09.90XA',
'S16.1XXA',
'R41.82',
'N17.9',
'M25.561',
'R10.13',
'F41.9',
'J96.00',
'I48.91',
'J96.01',
'I63.9',
'Z00.01',
'R53.83',
'K92.2',
'M25.512',
'J20.9',
'N31.9',
'R50.9',
'K52.9',
'R53.1',
'K21.9',
'C61',
'K02.9',
'Z01.818',
'M25.511',
'Z30.42',
'J45.901',
'M54.16',
'M25.562',
'Z34.03',
'M99.03',
'M54.9',
'R62.7',
'J45.909',
'K59.00',
'F32.9',
'K80.10',
'H25.11',
'Z43.1',
'O47.1',
'R45.851',
'H25.12',
'M54.12',
'G35',
'Z38.00',
'B34.9',
'Z45.2',
'Z0000',
'D50.9',
'M19.90',
'F03.91',
'R11.2',
'N18.9',
'R21',
'O34.211',
'M17.11',
'R00.2',
'Z30.2',
'Z30.41',
'L03.115',
'N20.0',
'J40',
'S39.012A',
'I69.90',
'E66.01',
'F29',
'R13.12',
'R19.7',
'E55.9',
'L03.116',
'M99.01',
'R06.00',
'R10.2',
'M81.0',
'R91.8',
'R10.84',
'I21.4',
'Z09',
'K29.70',
'R32',
'N32.81',
'I69.951',
'I48.0',
'K40.90',
'J96.12',
'Z34.80',
'B20',
'F20.9'
)"
)
icd10codes_leakage$ICD10_CODE<-as.character(icd10codes_leakage$ICD10_CODE)
icd10codes_leakage$icd10_leakage<-gsub(".","",icd10codes_leakage$ICD10_CODE,fixed=TRUE)


DX_leakage <- sqldf("select DISTINCT d.*,  c.icd10_leakage as ICD10_CODE_Leakage from 
DX_claimids d left join icd10codes_leakage c on d.ICD9_CODE = c.icd10_leakage
                   order by d.CLAIM_ID ")

##setting up Leakage codes to be 1 
DX_leakage$ICD10_CODE_Leakage[is.na(DX_leakage$ICD10_CODE_Leakage)]<-0
DX_leakage$ICD10_CODE_Leakage<-ifelse(DX_leakage$ICD10_CODE_Leakage==0,0,1)
DX_leakage$ICD10_CODE_Leakage <- as.numeric(DX_leakage$ICD10_CODE_Leakage)
Leakage_test <- sqldf("select DISTINCT CLAIM_ID, ICD10_CODE_Leakage from DX_leakage")

# group by client id
Leakage_test2 <- Leakage_test %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temporarialy make claim id text
Leakage_test2$CLAIM_ID <- as.character(Leakage_test2$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
Leakage_test3 <- Leakage_test2 %>% mutate_if(is.numeric,
                                             function(x) case_when(
                                               x >= 1 ~ 1,
                                               x == 0 ~ 0
                                             )
)
Leakage_test3 <- lapply(Leakage_test3, factor) 
Leakage_test3 <- as.data.frame(Leakage_test3)
Leakage_test3$CLAIM_ID <- as.numeric(as.character(Leakage_test3$CLAIM_ID))


table(Leakage_test$ICD10_CODE_Leakage)
prop.table(table(Leakage_test$ICD10_CODE_Leakage))

###################3
###################################
#Merging with cormorbidities

claims<-claims[order(claims$CLAIM_CLAIM_ID),]
#Merging with cormorbidities
claims_charlson <- sqldf("SELECT DISTINCT b.*, c.wscore as Charlson_score from DX_claimids b left join charlson_scores c
                   on b.CLAIM_ID = c.CLAIM_ID")
#charlson_scores$CLAIM_ID <- as.numeric(charlson_scores$CLAIM_ID )
claims_charlson$CLAIM_ID <- as.numeric(claims_charlson$CLAIM_ID )


claims_charlson <- claims%>%left_join(claims_charlson,by=c("CLAIM_CLAIM_ID" = "CLAIM_ID"))
claims_charlson$Charlson_score <-  ifelse(is.na(claims_charlson$Charlson_score),1,claims_charlson$Charlson_score)



##base_table2$Elixhauser_score <-  ifelse(is.na(base_table2$Elixhauser_score),1,base_table2$Elixhauser_score)

elixhauser_scores$CLAIM_ID<-as.numeric(elixhauser_scores$CLAIM_ID)

elixhauser_scores2 <- sqldf("select CLAIM_ID, wscore_ahrq from elixhauser_scores")




claims_charlson_elix <- claims_charlson%>% 
  left_join(elixhauser_scores2, by =c("CLAIM_CLAIM_ID"= "CLAIM_ID"))

claims_charlson_elix$wscore_ahrq <-  ifelse(is.na(claims_charlson_elix$wscore_ahrq),1,claims_charlson_elix$wscore_ahrq)
### Merging with CCS
# CCS dx

#claims_charlson_ccs <- sqldf("SELECT DISTINCT b.*, c.* from claims_charlson b inner join CCS_Dummy_test3 c
#                                on b.CLAIM_ID = c.CLAIM_IDx")
claims_charlson_elix_ccs <- claims_charlson_elix%>%inner_join(CCS_Dummy_test3,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))


##### Merging with POS
claims_charlson_elix_ccs_pos <- claims_charlson_elix_ccs%>%left_join(POS2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))


##### Merging with CPT

claims_charlson_elix_ccs_pos_cpt <- claims_charlson_elix_ccs_pos%>%left_join(CPT2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))
#Merging with leakage
claims_charlson_elix_ccs_pos_cpt_leakage <- claims_charlson_elix_ccs_pos_cpt%>%left_join(Leakage_test3,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))



# Merging with Provider City
#claims_charlson_elix_ccs_pos_cpt_leakage_city <-
#  claims_charlson_elix_ccs_pos_cpt_leakage%>%left_join(PROV_CITY2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))

claims_charlson_elix_ccs_pos_cpt_leakage_city <-
  claims_charlson_elix_ccs_pos_cpt_leakage%>%left_join(PROV_fips2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))


#merging with Provider Type 
claims_charlson_elix_ccs_pos_cpt_leakage_city_prov <- claims_charlson_elix_ccs_pos_cpt_leakage_city%>%left_join(PROV_TYPE2,by=c("CLAIM_CLAIM_ID"="CLAIM_ID"))



################ Creating the target variable ############
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<-claims_charlson_elix_ccs_pos_cpt_leakage_city_prov


claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage <- as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$ICD10_CODE_Leakage)
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage <- as.factor(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage)
# replace NA with 0
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage[is.na(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage )] <- 0
##base_table6$ICD9_CODE_neph <- NULL
table(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage)
prop.table(table(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix$target_leakage))
#claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE_NORM <- scale(claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE)
#claims_charlson_ccs_pos_ckd_elix$PATIENT_AGE<-NULL



#################################### Feature reduction of CCS variables#####

CCS_list <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix %>% dplyr:: select (starts_with("CCS_"))
t_var<-select(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,target_leakage)
##t_var <- sqldf("select target_leakage from claims_charlson_ccs_pos_cpt_leakage_city_prov_elix")
CCS_list2 <- cbind(t_var,CCS_list)
#h2o.init()

CCS_list2_h2o <- as.h2o(CCS_list2)
y_ccs <- "target_leakage"
x_ccs <- setdiff(names(CCS_list2_h2o), y_ccs)

CCS_list3 <- h2o.randomForest(x=x_ccs,
                              y = y_ccs,
                              training_frame = CCS_list2_h2o,
                              ntrees = 50,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)


CCS_list3_var_import <- h2o.varimp(CCS_list3)


# top 15 comrobidites
CCS_list3_import <-CCS_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
CCS_list3_import$CCS <- CCS_list3_import$variable
CCS_Top25<-as.data.frame(CCS_list3_import$CCS)
write.csv(CCS_Top25,file="CCS_Top25_Healthnetleakage_01072020_v1.csv")




#################################### Feature reduction of CCS variables#####

####Keeping the same CCS variables as the historic data#####
CCS_names_leakage<-read.csv("CCS_Top25_Healthnetleakage_01072020_v1.csv")
names(CCS_names_leakage)
CCS_leakage<-as.character(CCS_names_leakage$CCS_list3_import.CCS)
leakage_match<- match(CCS_leakage, names(CCS_list2))
leakage_match <- CCS_list2[,leakage_match]


# remove CCS from base data
##claims_charlson_ccs_pos_ckd_elix<-claims_member_leakage_dx_ckd_charlson_ccs_pos
no_ccs <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix[,!grepl("^CCS",names(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix ))]
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<- cbind(no_ccs, leakage_match)


#################################### Feature reduction of CPT variables#####

CPT_list <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix %>% dplyr:: select (starts_with("CPT_"))
cpt_var<-select(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,target_leakage)
##t_var <- sqldf("select target_leakage from claims_charlson_CPT_pos_cpt_leakage_city_prov_elix")
CPT_list2 <- cbind(cpt_var,CPT_list)
#h2o.init()
CPT_list2_h2o <- as.h2o(CPT_list2)
y_CPT <- "target_leakage"
x_CPT <- setdiff(names(CPT_list2_h2o), y_CPT)

CPT_list3 <- h2o.randomForest(x=x_CPT,
                              y = y_CPT,
                              training_frame = CPT_list2_h2o,
                              ntrees = 50,
                              nfolds = 10,
                              sample_rate = 0.85,
                              fold_assignment = "Modulo",
                              stopping_tolerance = 1e-2,
                              stopping_rounds = 2,
                              seed = 77)


CPT_list3_var_import <- h2o.varimp(CPT_list3)


# top 15 comrobidites
CPT_list3_import <-CPT_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 10)
CPT_list3_import$CPT <- CPT_list3_import$variable
CPT_Top10<-as.data.frame(CPT_list3_import$CPT)
write.csv(CPT_Top10,file="CPT_Top10_Healthnetleakage_01072020_v1.csv")




#################################### Feature reduction of CPT variables#####

####Keeping the same CPT variables as the historic data#####
CPT_names_leakage<-read.csv("CPT_Top10_Healthnetleakage_01072020_v1.csv")
names(CPT_names_leakage)
CPT_leakage<-as.character(CPT_names_leakage$CPT_list3_import.CPT)
leakage_match<- match(CPT_leakage, names(CPT_list2))
leakage_match <- CPT_list2[,leakage_match]


# remove CPT from base data
##claims_charlson_CPT_pos_ckd_elix<-claims_member_leakage_dx_ckd_charlson_CPT_pos
no_CPT <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix[,!grepl("^CPT",names(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix ))]
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<- cbind(no_CPT, leakage_match)

### Need to run from here 12/26
#################################### Feature reduction of Prov Type  variables#####

PROV_TYPE_list <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix %>% dplyr:: select (starts_with("PROV_TYPE_"))
PROV_TYPE_var<-select(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,target_leakage)
##t_var <- sqldf("select target_leakage from claims_charlson_PROV_TYPE_pos_PROV_TYPE_leakage_city_prov_elix")
PROV_TYPE_list2 <- cbind(PROV_TYPE_var,PROV_TYPE_list)
#h2o.init()
PROV_TYPE_list2_h2o <- as.h2o(PROV_TYPE_list2)
y_PROV_TYPE <- "target_leakage"
x_PROV_TYPE <- setdiff(names(PROV_TYPE_list2_h2o), y_PROV_TYPE)

PROV_TYPE_list3 <- h2o.randomForest(x=x_PROV_TYPE,
                                    y = y_PROV_TYPE,
                                    training_frame = PROV_TYPE_list2_h2o,
                                    ntrees = 50,
                                    nfolds = 10,
                                    sample_rate = 0.85,
                                    fold_assignment = "Modulo",
                                    stopping_tolerance = 1e-2,
                                    stopping_rounds = 2,
                                    seed = 77)


PROV_TYPE_list3_var_import <- h2o.varimp(PROV_TYPE_list3)


# top 15 comrobidites
PROV_TYPE_list3_import <-PROV_TYPE_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 10)
PROV_TYPE_list3_import$PROV_TYPE <- PROV_TYPE_list3_import$variable
PROV_TYPE_Top10<-as.data.frame(PROV_TYPE_list3_import$PROV_TYPE)
write.csv(PROV_TYPE_Top10,file="PROV_TYPE_Top10_Healthnetleakage_01072020_v1.csv")




#################################### Feature reduction of PROV_TYPE variables#####

####Keeping the same PROV_TYPE variables as the historic data#####
PROV_TYPE_names_leakage<-read.csv("PROV_TYPE_Top10_Healthnetleakage_01072020_v1.csv")
names(PROV_TYPE_names_leakage)
PROV_TYPE_leakage<-as.character(PROV_TYPE_names_leakage$PROV_TYPE_list3_import.PROV_TYPE)
leakage_match<- match(PROV_TYPE_leakage, names(PROV_TYPE_list2))
leakage_match <- PROV_TYPE_list2[,leakage_match]


# remove PROV_TYPE from base data
##claims_charlson_PROV_TYPE_pos_ckd_elix<-claims_member_leakage_dx_ckd_charlson_PROV_TYPE_pos
no_PROV_TYPE <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix[,!grepl("^PROV_TYPE",names(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix ))]
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<- cbind(no_PROV_TYPE, leakage_match)


#################################### Feature reduction of Prov City  variables#####
# 
# PROV_CITY_list <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix %>% dplyr:: select (starts_with("PROV_CITY_"))
# PROV_CITY_var<-select(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,target_leakage)
# ##t_var <- sqldf("select target_leakage from claims_charlson_PROV_CITY_pos_PROV_CITY_leakage_city_prov_elix")
# PROV_CITY_list2 <- cbind(PROV_CITY_var,PROV_CITY_list)
# h2o.init()
# PROV_CITY_list2_h2o <- as.h2o(PROV_CITY_list2)
# y_PROV_CITY <- "target_leakage"
# x_PROV_CITY <- setdiff(names(PROV_CITY_list2_h2o), y_PROV_CITY)
# 
# PROV_CITY_list3 <- h2o.randomForest(x=x_PROV_CITY,
#                                     y = y_PROV_CITY,
#                                     training_frame = PROV_CITY_list2_h2o,
#                                     ntrees = 50,
#                                     nfolds = 10,
#                                     sample_rate = 0.85,
#                                     fold_assignment = "Modulo",
#                                     stopping_tolerance = 1e-2,
#                                     stopping_rounds = 2,
#                                     seed = 77)
# 
# 
# PROV_CITY_list3_var_import <- h2o.varimp(PROV_CITY_list3)
# 
# 
# # top 15 comrobidites
# PROV_CITY_list3_import <-PROV_CITY_list3_var_import %>%
#   filter(rank(desc(relative_importance)) <= 10)
# PROV_CITY_list3_import$PROV_CITY <- PROV_CITY_list3_import$variable
# PROV_CITY_Top10<-as.data.frame(PROV_CITY_list3_import$PROV_CITY)
# write.csv(PROV_CITY_Top10,file="PROV_CITY_Top10_Healthnetleakage_01072020_v1.csv")







PROV_CITY_list <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix %>% dplyr:: select (starts_with("PROV_fips_"))
PROV_CITY_var<-select(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,target_leakage)
##t_var <- sqldf("select target_leakage from claims_charlson_PROV_CITY_pos_PROV_CITY_leakage_city_prov_elix")
PROV_CITY_list2 <- cbind(PROV_CITY_var,PROV_CITY_list)
#h2o.init()
PROV_CITY_list2_h2o <- as.h2o(PROV_CITY_list2)
y_PROV_CITY <- "target_leakage"
x_PROV_CITY <- setdiff(names(PROV_CITY_list2_h2o), y_PROV_CITY)

PROV_CITY_list3 <- h2o.randomForest(x=x_PROV_CITY,
                                    y = y_PROV_CITY,
                                    training_frame = PROV_CITY_list2_h2o,
                                    ntrees = 50,
                                    nfolds = 10,
                                    sample_rate = 0.85,
                                    fold_assignment = "Modulo",
                                    stopping_tolerance = 1e-2,
                                    stopping_rounds = 2,
                                    seed = 77)


PROV_CITY_list3_var_import <- h2o.varimp(PROV_CITY_list3)


# top 15 comrobidites
PROV_CITY_list3_import <-PROV_CITY_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 10)
PROV_CITY_list3_import$PROV_CITY <- PROV_CITY_list3_import$variable
PROV_CITY_Top10<-as.data.frame(PROV_CITY_list3_import$PROV_CITY)
write.csv(PROV_CITY_Top10,file="PROV_CITY_Top10_Healthnetleakage_01072020_v1.csv")
















#################################### Feature reduction of PROV_CITY variables#####

####Keeping the same PROV_CITY variables as the historic data#####
PROV_CITY_names_leakage<-read.csv("PROV_CITY_Top10_Healthnetleakage_01072020_v1.csv")
names(PROV_CITY_names_leakage)
PROV_CITY_leakage<-as.character(PROV_CITY_names_leakage$PROV_CITY_list3_import.PROV_CITY)
leakage_match<- match(PROV_CITY_leakage, names(PROV_CITY_list2))
leakage_match <- PROV_CITY_list2[,leakage_match]
leakage_match[is.na(leakage_match)] <- 0



# remove PROV_CITY from base data
##claims_charlson_PROV_CITY_pos_ckd_elix<-claims_member_leakage_dx_ckd_charlson_PROV_CITY_pos

#no_PROV_CITY <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix[,!grepl("^PROV_CITY",names(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix ))]
no_PROV_CITY <- claims_charlson_ccs_pos_cpt_leakage_city_prov_elix[,!grepl("^PROV_fips",names(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix ))]
claims_charlson_ccs_pos_cpt_leakage_city_prov_elix<- cbind(no_PROV_CITY, leakage_match)


str(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix,list.len = ncol(claims_charlson_ccs_pos_cpt_leakage_city_prov_elix))



######################
base_table6<-claims_charlson_ccs_pos_cpt_leakage_city_prov_elix
base_table6$NORM_LINE_AMT_PAID<-scale(base_table6$CLAIM_LINE_AMT_PAID)
base_table6$NORM_LINE_AMT_BILLED<-scale(base_table6$CLAIM_LINE_AMT_BILLED)
# base_table6$PROV_CITY <- NULL
# base_table6$ZIP <- NULL
# base_table6$zip5 <- NULL



str(base_table6,list.len = ncol(base_table6))



base_table7<-base_table6%>%select (CLAIM_CLAIM_ID,NORM_LINE_AMT_PAID,NORM_LINE_AMT_BILLED,
                                   Days_of_service,ratio_billed_to_paid,ratio_allowed_to_paid,PATIENT_AGE_NORM,
                                   Charlson_score, wscore_ahrq,starts_with("CCS_"),starts_with("POS_"),starts_with("PROV_fips_"),
                                   starts_with("PROV_TYPE_"),starts_with("CPT_"),OVP)
base_table7$NORM_LINE_AMT_PAID<-as.numeric(base_table7$NORM_LINE_AMT_PAID)
base_table7$NORM_LINE_AMT_BILLED<-as.numeric(base_table7$NORM_LINE_AMT_BILLED)
# names(base_table7) <- gsub(x = names(base_table7), pattern = "NORTH.HOLLYWOOD", replacement = "NORTH_HOLLYWOOD") 
# names(base_table7) <- gsub(x = names(base_table7), pattern = "SAN.JOSE", replacement = "SAN_JOSE") 
# names(base_table7) <- gsub(x = names(base_table7), pattern = "LOS.ANGELES", replacement = "LOS_ANGELES")
# names(base_table7) <- gsub(x = names(base_table7), pattern = "SAN.FRANCISCO", replacement = "SAN_FRANCISCO") 
##### Need to work here###

str(base_table7,list.len = ncol(base_table7))
colnames(base_table7)[colSums(is.na(base_table7)) > 0]

# get list of factors
# to do aggregation need to convert factors to numeric
factor_list <- c(names(Filter(is.factor,base_table7)))


base_table8 <- base_table7

# change factors to numeric
# 
base_table8<- base_table8 %>%
  mutate_if(is.factor, ~as.numeric(as.character(.)))

# aggregate with group by find max values

base_table8  <- base_table8 %>%
  group_by(CLAIM_CLAIM_ID,OVP) %>%
  summarise_all((funs(max)))


# change old factors back to factors
base_table8[factor_list] <- lapply(base_table8[factor_list], factor)


str(base_table8,list.len = ncol(base_table8))







base_table8$CLAIM_CLAIM_ID<-NULL
base_table8$OVP<-as.factor(base_table8$OVP)
#base_table8$ratio_billed_to_paid <-  ifelse(base_table8$ratio_billed_to_paid==Inf,1,base_table8$ratio_billed_to_paid)



#foo

idx <- sample(seq(1,2), size = nrow(base_table8), replace = TRUE, prob = c(0.7, 0.3))
train <- base_table8[idx == 1,]
test <- base_table8[idx == 2,]

train <- as.h2o(train)
test<-as.h2o(test)
y <- "OVP"
x <- setdiff(names(train), y)

rf_healthnet<- h2o.randomForest(x=x,
                                y = y,
                                training_frame = train,
                                validation_frame = test,
                                ntrees = 100,
                                nfolds = 10,
                                sample_rate = 0.85,
                                fold_assignment = "Modulo",
                                keep_cross_validation_predictions = TRUE,
                                stopping_tolerance = 1e-2,
                                stopping_rounds = 2,
                                seed = 77)








h2o.performance(rf_healthnet,newdata=test)
h2o.confusionMatrix(rf_healthnet,newdata=test)
healthnet_list3_var_import <-h2o.varimp(rf_healthnet)
h2o.varimp_plot(rf_healthnet)

healthnet_list3_import <-healthnet_list3_var_import %>%
  filter(rank(desc(relative_importance)) <= 25)
healthnet_list3_import$healthnet <- healthnet_list3_import$variable
healthnet_Top25<-as.data.frame(healthnet_list3_import$healthnet)
write.csv(healthnet_Top25,file="healthnet_Top25_01072020_v1.csv")
h2o.saveModel(rf_healthnet, path = getwd(), force =TRUE)

##### Non H2o version #################
idx <- sample(seq(1,2), size = nrow(base_table8), replace = TRUE, prob = c(0.7, 0.3))
train_rf <- base_table8[idx == 1,]
test_rf <- base_table8[idx == 2,]
colnames(base_table8)[colSums(is.na(base_table8)) > 0]
healthnet_randomF<-randomForest(OVP~.,data=train_rf,importance=TRUE)
save(healthnet_randomF,file="randomForest_healthnet.RData")
var.imp <- data.frame(importance(healthnet_randomF,
                                 type=2))
# make row names as columns
var.imp$Variables <- row.names(var.imp)
var.imp[order(var.imp$MeanDecreaseGini,decreasing = T),]
##h2o.saveModel(rf, path = "rf", force =TRUE)

predict_rf_healthnet <- predict(healthnet_randomF,test_rf)
confusionMatrix(data=predict_rf_healthnet,
                reference=test_rf$OVP,positive='1')





library("ROCR")
rf.pr = predict(healthnet_randomF,test_rf,type="prob")
pred<-as.data.frame(rf.pr)
names(pred)[1]<-"p0"
names(pred)[2]<-"p1"
pred$predict<-ifelse(pred$p1>0.5,1,0)

rf.pred = prediction(rf.pr, test_rf$OVP)
rf.perf = performance(rf.pred,"tpr","fpr")
rf.auc= performance(rf.pred,"auc")
plot(rf.perf,main="ROC Curve for Random Forest",col=1,lwd=2)
abline(a=0,b=1,lwd=2,lty=2,col="gray")
varImpPlot(healthnet_randomF)
AUC=rf.auc@y.values[[1]]











