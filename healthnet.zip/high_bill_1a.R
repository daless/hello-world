
# original code adding FIPS codes, new CCS file and experimental feature reduction

setwd("~/healthnet")
library(comorbidity)
library(RODBC)
library(sqldf)
library(dplyr)
library(tidyr)
library(tidyverse)



library(RODBC)
conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0625.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')


# 
# docdb = sqlQuery(
#   conn,
#   "SELECT  * from RACER01132.DBO.PROVIDER with (nolock)",
#   max=50)
# docdb = sqlQuery(
#   conn,
#   "SELECT  * from DMFEED01132.DBO.FD_HNT_PROV with (nolock)",
#   max=50)




















#table listing in db
#table_listing <- as.data.frame(sqlTables(conn))
#write.csv(table_listing,file="racer_scehma.csv")

#claim_line <- sqlColumns(
#  conn, "dbo.CLAIM_LINE"  )


library(h2o)
# h2o.init(port=54333)
# h2o.shutdown(prompt  = FALSE)
# h2o.init(port=54333)


data0 = sqlQuery(
  conn,
  "SELECT DISTINCT c.AMT_ALLOWED as CLAIM_AMT_ALLOWED                                                                                                                                             
,c.AMT_PAID as CLAIM_AMT_PAID                                                                                
,c.CLAIM_ID as CLAIM_CLAIM_ID                                                                                
,c.CLAIM_NO as CLAIM_CLAIM_NO                                                                                
,c.FEED_ID as CLAIM_FEED_ID                                                                                  
,c.PAR as CLAIM_PAR                                                                                          
,c.PATIENT_AGE as CLAIM_PATIENT_AGE                                                                          
,c.PATIENT_GENDER as CLAIM_PATIENT_GENDER                                                                    
,c.PLACE_OF_SERVICE as CLAIM_PLACE_OF_SERVICE                                                                
,c.PRINCIPAL_DIAG as CLAIM_PRINCIPAL_DIAG                                                                                                                                                              
,c.DATE_RECEIVED as CLAIM_DATE_RECEIVED                                                                      
,c.DATE_ENTERED as CLAIM_DATE_ENTERED                                                                        
,c.DATE_OF_SERVICE_BEG as CLAIM_DATE_OF_SERVICE_BEG                                                          
,c.DATE_OF_SERVICE_END as CLAIM_DATE_OF_SERVICE_END                                                          
,c.DATE_ADMITTED as CLAIM_DATE_ADMITTED                                                                      
,c.DATE_DISCHARGED as CLAIM_DATE_DISCHARGED                                                                  
,c.PROVIDER_ID as CLAIM_PROVIDER_ID                                                                          
,c.AMT_BILLED as CLAIM_AMT_BILLED                                                                            
,c.DATE_PAID as CLAIM_DATE_PAID                                                                              
,cl.REVENUE_CODE as CLAIM_LINE_REVENUE_CODE                                                                  
,cl.AMT_BILLED as CLAIM_LINE_AMT_BILLED                                                                                                                                   
,cl.AMT_PAID as CLAIM_LINE_AMT_PAID                                                                          
,cl.CPT as CLAIM_LINE_CPT                                                                                    
,cl.LINE_NO as CLAIM_LINE_LINE_NO                                                                            
,cl.CPT_MODIFIER as CLAIM_LINE_CPT_MODIFIER                                                                  
,cl.AMT_ALLOWED as CLAIM_LINE_AMT_ALLOWED                                                                    
,cl.DATE_PAID as CLAIM_LINE_DATE_PAID
,PROV.PROVIDER_NO as FFD_HNT_PROV_PROVIDER_NO                                                        
,PROV.CITY as FD_HNT_PROV_CITY                                                                      
,PROV.PROV_NAME as FD_HNT_PROV_PROV_NAME                                                            
,PROV.PROVIDER_TYPE as FD_HNT_PROV_PROVIDER_TYPE                                                                                              
,PROV.NPI as FD_HNT_PROV_NPI
,PROV.PROVIDER_SPECIALTY_1
,cs.PROJECT_ID as CLAIM_STATUS_PROJECT_ID
,P.PROVIDER_ID as PROV_PROVIDER_ID
from dmfeed01132.dbo.FD_HNT_CLM dc
inner join RACER01132.DBO.CLAIM c
on dc.claim_no = c.claim_no
inner join racer01132.dbo.claim_Status cs                                                                        
on c.claim_id = cs.claim_id
INNER JOIN RACER01132.DBO.CLAIM_LINE cl
ON cl.CLAIM_ID = c.CLAIM_ID 
inner join racer01132.dbo.case_data cd                                                                          
on cd.case_id = cs.case_id  
inner join Racer01132.dbo.STATUS_CODE sc                                                                         
on sc.status_code = cs.status_code
INNER JOIN RACER01132.DBO.PROVIDER P                                                                             
ON P.PROVIDER_ID = C.PROVIDER_ID
INNER JOIN DMFEED01132.DBO.FD_HNT_PROV PROV                                                                      
ON (P.PROVIDER_NO = PROV.PROVIDER_NO AND PROV.FEED_ID = C.FEED_ID)
CROSS APPLY (SELECT TOP 1 * FROM  DMFEED01132.DBO.FD_HNT_MEM  MEM (NOLOCK)
WHERE MEM.PAT_MEMBER_NO = DC.SUB_MEMBER_NO  
AND MEM.FEED_ID > 10 ) M
LEFT join Racer01132.dbo.REASON_CODE rc                                                                          
on CS.REASON_CODE = RC.REASON_CODE
WHERE  DATEDIFF(D,  dc.DATE_OF_SERVICE_BEG, GETDATE()) < 180
and dc.CLAIM_ID IS NOT NULL 
and cs.PROJECT_ID = 01132
and  M.LAST_NAME <> 'HN ASSOCIATE'
and c.CLAIM_ID IS NOT NULL
  and cl.CPT in ('99201',
  '99202',
  '99203',
  '99204',
  '99205' )
  ")

#saveRDS(data0, file="data0high.Rda")

DX_claim  <- sqlQuery(
  conn,
  " select
  DISTINCT CLM.CLAIM_ID,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM RACER01132.dbo.CLAIM CLM
  INNER JOIN RACER01132.dbo.ICD9 DX
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  where CLM.PROJECT_ID = 1132
  AND  DX.ORDER_IN_CLAIM <= 9
  order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc"
)


cl_id <- sqldf("select distinct CLAIM_CLAIM_ID from data0 ")


library(dplyr)

#library(tidyverse)

DX_claim <- inner_join(DX_claim, cl_id, by = c("CLAIM_ID" = "CLAIM_CLAIM_ID") )





DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")


elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")

CPT <- sqldf("select DISTINCT CLAIM_CLAIM_ID as CLAIM_ID,  CLAIM_LINE_CPT as CPT from data0")

library(dummies)

CPT <- cbind(CPT, dummy(CPT$CPT , sep= "_"))


# group by client id
CPT1 <- CPT %>% group_by(CLAIM_ID) %>% summarise_if(is.numeric, sum)

# temp make id character
CPT1$CLAIM_ID <- as.character(CPT1$CLAIM_ID)

# recode if > 0 then 1 else 0 instead of summing dummies
CPT2 <- CPT1 %>% mutate_if(is.numeric,
                           function(x) case_when(
                             x >= 1 ~ 1,
                             x == 0 ~ 0
                           )
)

CPT2 <- lapply(CPT2, factor) 
CPT2 <- as.data.frame(CPT2)
CPT2$CLAIM_ID <- as.numeric(as.character((CPT2$CLAIM_ID)))
CPT2$CPT <- NUL
names(CPT2)[1] <- 'CLAIM_IDx'

base1 <- sqldf("select distinct d.FD_HNT_PROV_PROVIDER_TYPE,
               d.PROVIDER_SPECIALTY_1,
               d.CLAIM_AMT_BILLED,
               e.*
               from data0 d,  elixhauser_scores e
               where  d.CLAIM_CLAIM_ID = e.CLAIM_ID")

base1$index <- NULL
base1$wscore_vw <- NULL
base1$windex_ahrq <- NULL
base1$windex_vw <- NULL
#base1$FD_HNT_PROV_PROVIDER_TYPE <- NULL


base1 <- sqldf("select distinct b.*,
               c.wscore as charlson
               from base1 b, charlson_scores c
               where b.CLAIM_ID = c.CLAIM_ID
               ")



base1 <- sqldf("select distinct b.*,
               c.*
               from base1 b, CPT2 c
               where b.CLAIM_ID = c.CLAIM_IDx
               ")



# base1$FD_HNT_PROV_PROVIDER_TYPE<- ifelse(base1$FD_HNT_PROV_PROVIDER_TYPE
#                                          %in% c('NA'),
#                                          "Missing", base1$FD_HNT_PROV_PROVIDER_TYPE)
# 




base2 <- base1
base2$CLAIM_ID <- NULL
base2$CLAIM_IDx <- NULL
learnname <- colnames(base2)
an1_h2o <- as.h2o(base2)

an1_h2o_dl <-
  h2o.deeplearning(
    x = learnname,
    training_frame = an1_h2o,
    autoencoder = TRUE,
    sparse = TRUE,
    hidden = c(10, 2, 10),
    epochs = 100,
    stopping_tolerance = 1e-4,
    activation = "Tanh",
    seed = 77,
    distribution = "AUTO",
    categorical_encoding = "AUTO"
  )
an1_h2o_dl2 = h2o.anomaly(an1_h2o_dl, an1_h2o)
an1_h2o_dl2 <- as.data.frame(an1_h2o_dl2)

names(an1_h2o_dl2)[1] <- "target"


base3<- cbind( an1_h2o_dl2, base1)

base3<- sqldf("select * from base3 order by target desc")

write.csv(base3, file = "high_dollar_example.csv")
#scp dless1@apsrd9425:/home/dless1/healthnet/high_dollar_example.csv /H/My_Doccuments

# hits are 99204 = 1 low and 0 acuity use outlier score to flag with these rules


