

# sOMBREREO testing


library(SOMbrero)
library(kohonen)

set.seed(77)


# make factors numeric
kohonen1 <- base_table8

# change factors to numeric
# 
kohonen1<-kohonen1 %>%
  mutate_if(is.factor, ~as.numeric(as.character(.)))

kohonen1$CLAIM_CLAIM_ID <- NULL
kohonen1$OVP <- NULL
som1 <- trainSOM(x.data = kohonen1, dimension = c(5,5), nb.save = 10, maxit = 2000, scaling = "none")

plot(som1, what = "energy")

plot(som1, what = "obs", type = "hitmap")

par(mfrow = c(1,2))
plot(som1, what = 'prototypes', type = "color", var = 1, main = "prototypes - x1")
plot(som1, what = 'prototypes', type = "color", var = 22, main = "prototypes - x2")


# means
plot(som1, what = 'obs', type = "color", var = 1, main = "obs mean values - x1")
plot(som1, what = 'obs', type = "color", var = 22, main = "obs mean values - x2")


som2 <- trainSOM(x.data = kohonen1, dimension = c(5,5), nb.save = 10, maxit = 200,
                 verbose = TRUE, scaling = "none")

table(som2$clustering)

# does anova for cluster membership - significance is put into relavant clusters
summary(som2)

plot(som2, what = "prototypes", type = "lines", print.title = TRUE)

plot(som2, what = "obs", type = "barplot", print.title = TRUE)


plot(som2, what = "obs", type = "radar", show.names = TRUE)

rownames(kohonen1)

plot(som2, what = "obs", type = "names",  show.names = TRUE)

plot(som2, what = "prototypes", type = "3d",  variable = 2, show.names = TRUE)

# distance between protptypes

plot(som2, what = "prototypes", type = "poly.dist",   show.names = TRUE)


plot(som2, what = "prototypes", type = "umatrix",   show.names = TRUE)


plot(som2, what = "prototypes", type = "smooth.dist")

plot(som2, what = "prototypes", type = "mds")


#################### kohonen



kohonen1 <- base_table8

# change factors to numeric
# 
kohonen1<-kohonen1 %>%
  mutate_if(is.factor, ~as.numeric(as.character(.)))

kohonen1$CLAIM_CLAIM_ID <- NULL
kohonen1$OVP <- NULL
kohonen1_matrix <- as.matrix(kohonen1)

som_grid <- somgrid(xdim = 15, ydim = 15 , topo = "hexagonal")

som_model <- som(kohonen1_matrix,
                grid = som_grid,
                rlen=500,
                alpha=c(0.05,0.01),
                keep.data = TRUE)

plot(som_model, type="change")

plot(som_model, type = "count", main="Node Counts")

# weight vecor
plot(som_model, type = "codes")

# heatmap

plot(som_model, type = "property", property = 
       getCodes(som_model)[,4], main=colnames(getCodes(som_model))[4],
     palette.name = rainbow)


# clustering codes
somcodes <- som_model$codes
wss <- (nrow(somcodes)-1 )* sum(apply(somcodes,2,var))
for (i in 2:15) {
    wss[i] <- sum(kmeans(somcodes, centers = i)$withinss)
        }
plot(wss)

som_cluster <- cutree(hclust(dist(som_model$codes)), 6)


som3 <- som(kohonen1_matrix, grid = somgrid(6,4,"rectangular"))


############################################################################################


# for number of cells in grid   abs( 3 * (sqrt(number of features)))

# hierarcial cluster example
library(rlang)
library(tidyverse)
library(magrittr)
library(RColorBrewer)
library(kohonen)

som_data1 <- base_table7
som_data1$CLAIM_CLAIM_ID<-NULL

numerics = summarise_all(som_data1, is.numeric) %>%
  as.logical

factors <- names(som_data1) %>%
  .[numerics]


numerics <- names(som_data1) %>%
  .[numerics]

data_list = list()
distances = vector()


for (fac in factors){
  data_list[[fac]] <- kohonen::classvec2classmat(som_data1[[fac]])
  distances <- c(distances, 'tanimoto')
}

data_list[['numerics']] <- scale(som_data1[,numerics])
distances <- c(distances, 'euclidean')

str(data_list)

map_dimension = abs( 3 * (sqrt(105)))
recalculate_map = T
n_iterations = 1000
recalculate_no_clusters = T

som_grid = kohonen::somgrid(xdim = map_dimension
                            , ydim = map_dimension
                            , topo = "hexagonal")

if(recalculate_map == F & file.exists('som.Rdata') == T){
  load('som.Rdata')
} else {
         m <- kohonen::supersom(data_list
                                , grid = som_grid
                                , rlen = n_iterations
                                , alpha = 0.05
                                , whatmap = c(factors, 'numerics')
                                , dist.fcts = distances)
         save(m, file = 'som.Rdata')
}
plot(m,type=changes)




plot(m,type="counts")

plot(m,type = "dist.neighbours")

plot(m. type = "codes")

plot(m, type="quality")











