


setwd("~/kaiser")


library(comorbidity)
library(RODBC)
library(sqldf)






conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=AIMDB10.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')

unkmem <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)",
  max=50)

str(unkmem,list.len = ncol(unkmem))


# rule_meta_data <-  sqlQuery(
#   conn,
#   "SELECT distinct p.PRIMACY_RULE_NUM , p.PRIMACY_RULE_DESC from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
#   where p.PRIMACY_RULE != 'NONE'
#   and p.SECONDARY_PAYER_NAME like'%Kaiser%'
#   and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
#   ",
#   max=50)
# 
# # exlude birthday rule and medicaid rule
# unkmem <- sqlQuery(
#   conn,
#   "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
#   where p.PRIMACY_RULE != 'NONE'
#   and p.SECONDARY_PAYER_NAME like'%Kaiser%'
#   and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
#   and p.PRIMACY_RULE != '2'
#   and p.PRIMACY_RULE ! = '9'
#   ",
#   max=50)

kieser_c2c <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
  where p.PRIMACY_RULE != 'NONE'
  and p.SECONDARY_PAYER_NAME like'%Kaiser%'
  and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
  and p.PRIMACY_RULE != '2'
  and p.PRIMACY_RULE ! = '9'
  ")




Kon = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=DBSWP0627.AIMHEALTH.COM;UID=COBUnixToSQL;PWD=Q438IerK@u9D')


# junk <- sqlQuery(
#   Kon,
#   "select CLAIM_NO from Racer01169.DBO.CLAIM", max=10)

#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01169.DBO.CLAIM where FEED_ID != 999")

tapestry_claim1 <- sqlQuery(
  Kon,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,
CLM.AMT_COB_PAID,
CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,

MEM.member_ID,MEM.MEMBER_NO, MEM.DATE_EFFECTIVE

FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID

where CLM.FEED_ID between 225 and 237")


tapestry_claim1 <- data.frame(r_index = row.names(tapestry_claim1), tapestry_claim1)
tapestry_claim1$r_index <- as.numeric(as.character(tapestry_claim1$r_index )) 

# targets
tapestry_dupes <- sqldf("select c.*, k.SECOND_CARRIER_MEMBER_NO from kieser_c2c k, tapestry_claim1 c
                        where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO")
  
# commercial project id

# commerical only had 7 hits
# probably legacy data --- exclude
#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01314.DBO.CLAIM where FEED_ID != 999")


base1 <- tapestry_claim1




mem_enroll_date <- sqldf("select MEMBER_NO, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE from base1

               group by MEMBER_NO")


base1 <- sqldf("select b.*, m.max_DATE_EFFECTIVE from base1 b left join mem_enroll_date m
               on b.MEMBER_NO = m.MEMBER_NO
               group by b.CLAIM_ID")



base1 <- sqldf(
  "select DISTINCT *
FROM base1
WHERE PATIENT_AGE <=64
and AMT_PAID >0
  ")


# convert to date format

base1$enroll_date <-as.POSIXct(base1$max_DATE_EFFECTIVE, origin="1970-01-01")
base1$admit_date <-as.POSIXct(base1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
base1$member_months <-(difftime(base1$admit_date , base1$enroll_date, units = "days"  ))/30.42
base1a <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base1
where member_months > 0
                             group by PATIENT_ID
                 ")


#rm(tapestry_claim1)
#rm(base1)


DX_claim_tapestry  <- sqlQuery(
  Kon,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
  INNER JOIN Racer01169.DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CLM.FEED_ID between 225 and 237
  AND  DX.ORDER_IN_CLAIM <= 5
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)


DX_claim <- sqldf("select d.* from DX_claim_tapestry d, base1 b
                  where d.CLAIM_ID = b.CLAIM_ID")
  
rm( DX_claim_tapestry)
DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")




# non dupes - - control group

charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL


base2 <- sqldf("select distinct b.*, c.wscore as charls_score from charlson_scores c,
               base1 b where 
               b.CLAIM_ID = c.CLAIM_ID", method = "name_class")


elixhauser_scores$CLAIM_IDx <- as.numeric(elixhauser_scores$CLAIM_ID)

base2 <- sqldf("select distinct b.*, c.* from elixhauser_scores c,
               base2 b where 
               b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")

base2$CLAIM_IDx <- NULL
base2$score <- NULL
base2$index <- NULL
base2$windex_ahrq <- NULL
base2$windex_vw <- NULL



# flag c2c hits for target


base3_0 <- sqldf("select distinct  c.*, k.SECOND_CARRIER_MEMBER_NO from base2 c , kieser_c2c k  
                       where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO")

base3_0 <- sqldf("select SECOND_CARRIER_MEMBER_NO , MEMBER_NO as indexy from tapestry_dupes")

library(dplyr)

base3 <- dplyr::left_join(base2, tapestry_dupes, by = c("MEMBER_NO" = "SECOND_CARRIER_MEMBER_NO"))



base3 <- dplyr::left_join(base2, base3_0, by = c("r_index" = "r_index"))


base3_0 <- sqldf("select distinct c.* from base2 c inner join tapestry_dupes k  
                       on c.r_index = k.r_index")

base3_0$c2c_hit<- 1

base3_id <- sqldf("select distinct r_index from base3_0")


base3 <- dplyr::anti_join(base2, base3_id, by = c("r_index" = "r_index"))

base3$c2c_hit<- 0

base4 <- rbind(base3_0,base3)

base4$CLAIM_ID..43 <- NULL


non_refund_members <- sqldf("select * from base4 where c2c_hit = 0")

non_refund_members0 <- sqldf("select PATIENT_ID, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE 
                             from base4 where c2c_hit = 0 group by PATIENT_ID")
non_refund_members1 <- sqldf("select n.*,m.max_DATE_EFFECTIVE from base4 m,  non_refund_members n
                             where m.PATIENT_ID= n.PATIENT_ID
                             and m.c2c_hit = 0")

# convert to date format
non_refund_members1$enroll_date <-as.POSIXct(non_refund_members1$max_DATE_EFFECTIVE, origin="1970-01-01")
non_refund_members1$admit_date <-as.POSIXct(non_refund_members1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
non_refund_members1$member_months <-(difftime(non_refund_members1$admit_date , non_refund_members1$enroll_date, units = "days"  ))/30.42
non_refund_members2 <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from non_refund_members1
                             group by PATIENT_ID")


refmem <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base4 where  c2c_hit = 1
                             group by PATIENT_ID")

refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as ref_cnt, 
avg(first_mm) as mean_mm from
refmem  group by INS_GROUP_ID order by ref_cnt desc" )



non_refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as non_ref_cnt, 
avg(first_mm) as non_mean_mm from
non_refund_members2  group by INS_GROUP_ID order by non_ref_cnt desc" )

groupid_ratio <- sqldf("select r.*, n.non_ref_cnt,n.non_mean_mm   from non_refund_members_cnt n, 
                       refund_members_cnt r where r.INS_GROUP_ID = n.INS_GROUP_ID")

groupid_ratio$groupid_refund_rate <- (groupid_ratio$ref_cnt / groupid_ratio$non_ref_cnt) *100000

# a positive number means that the refunds were newer members
groupid_ratio$member_month_delta <- as.numeric(groupid_ratio$non_mean_mm -  groupid_ratio$mean_mm)

base5 <- sqldf("select b.*, g.groupid_refund_rate, g.member_month_delta from base4 b , groupid_ratio g
               where b.INS_GROUP_ID = g.INS_GROUP_ID", method = "name_class")


base5$ratio_billed_to_paid<-(base5$AMT_BILLED + 1 )/(base5$AMT_PAID +1 )
base5$ratio_allowed_to_paid<-(base5$AMT_ALLOWED +1 ) /(base5$AMT_PAID +1)

base5$PLACE_OF_SERVICE<- ifelse(is.na(base5$PLACE_OF_SERVICE), 0, 
                                base5$PLACE_OF_SERVICE)

base5$BILL_TYPE<- ifelse(base5$BILL_TYPE == '', "0", base5$BILL_TYPE)

saveRDS(base4, file="base4.Rda")
saveRDS(base5, file="base5.Rda")

rm(base1)
rm(base1a)
rm(base2)
rm(base3)
rm(base3_0)
rm(non_refund_members1)
rm(charlson_scores)
rm(elixhauser_scores)
rm(tapestry_claim1)