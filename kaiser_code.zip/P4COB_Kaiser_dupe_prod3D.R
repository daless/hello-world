
# feeds appear to be daily or weekly so remove feeds
# for hx group id go bck 18 feeds for baseline


# feed  260-263
setwd("~/kaiser")


library(comorbidity)
library(RODBC)
library(sqldf)

#library(h2o)
#h2o.init(port=54333)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


# determine dup prevalance rate by groupi id


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=AIMDB10.aimhealth.com;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)

kieser_c2c <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
  where p.PRIMACY_RULE != 'NONE'
  and p.SECONDARY_PAYER_NAME like'%Kaiser%'
  and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
  and p.PRIMACY_RULE != '2'
  and p.PRIMACY_RULE ! = '9'
  and DATEDIFF(D,  p.OVERLAP_START_DATE, GETDATE()) < 720
  "
)




Kon = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=DBSWP0627.AIMHEALTH.COM;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)


#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01169.DBO.CLAIM where FEED_ID != 999")
# feedsll <- sqlQuery(Kon, "select distinct DATE_CREATED, FEED_ID from   Racer01169.DBO.CLAIM where FEED_ID > 240")

prevalnce1 <- sqlQuery(
  Kon,
  "select  distinct CLM.INS_GROUP_ID,MEM.MEMBER_NO
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where  CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720"
)


baseline_mem_counts_by_insur_id <-
  sqldf(
    "select INS_GROUP_ID, count(MEMBER_NO) as mem_cnt
                     from prevalnce1
                     where INS_GROUP_ID != 0
                     group by INS_GROUP_ID
                                         "
  )


tapestry_dupes0 <-
  sqldf(
    "select c.*, k.SECOND_CARRIER_MEMBER_NO from kieser_c2c k, prevalnce1 c
                        where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO"
  )

tapestry_dupes00 <-
  sqldf(
    "select INS_GROUP_ID, count(MEMBER_NO) as dupe_mem_cnt
from tapestry_dupes0
where INS_GROUP_ID != 0
                     group by INS_GROUP_ID"
  )


baseline_mem_counts_by_insur_id2 <-
  sqldf(
    "select b.*, t.dupe_mem_cnt
                                          from baseline_mem_counts_by_insur_id b left join tapestry_dupes00 t
                                          on b.INS_GROUP_ID = t.INS_GROUP_ID
                                          "
  )

baseline_mem_counts_by_insur_id2$dupe_mem_cnt <-
  ifelse(
    is.na(baseline_mem_counts_by_insur_id2$dupe_mem_cnt),
    0,
    baseline_mem_counts_by_insur_id2$dupe_mem_cnt
  )

baseline_mem_counts_by_insur_id2$groupid_refund_rate <-
  baseline_mem_counts_by_insur_id2$dupe_mem_cnt /
  baseline_mem_counts_by_insur_id2$mem_cnt

# remove those with more hits han in total group id
baseline_mem_counts_by_insur_id2 <-
  sqldf("select * from baseline_mem_counts_by_insur_id2 where groupid_refund_rate <=1")



# MMMMMMMMMMMMMMMMMMMMMMMMM

# member month calculations all members in study group


enrollment <- sqlQuery(
  Kon,
  "select  distinct MEM.MEMBER_NO,  MEM.DATE_EFFECTIVE, CLM.DATE_OF_SERVICE_BEG
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720"
)

enrollment2 <- sqldf("select MEMBER_NO, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE, 
                     max(DATE_OF_SERVICE_BEG) as max_DATE_OF_SERVICE_BEG
                     from enrollment
                     group by MEMBER_NO")


enrollment2$enroll_date <-as.POSIXct(enrollment2$max_DATE_EFFECTIVE, origin="1970-01-01")
enrollment2$admit_date <-as.POSIXct(enrollment2$max_DATE_OF_SERVICE_BEG, origin="1970-01-01")
enrollment2$member_months <-(difftime(enrollment2$admit_date ,enrollment2$enroll_date, units = "days"  ))/30.42
enrollment3 <- sqldf("select MEMBER_NO, min(member_months) as first_mm from enrollment2
where member_months > 0
                             group by MEMBER_NO
                 ")






# go back 1 year to get hx groupid and mem month data
# for model filter latest feed
# and c2c hit = 0

# junk <- sqlQuery(
#      Kon,
#     "select * from Racer01169.DBO.MEMBER MEM  with (nolock)", max=10)
#   



tapestry_claim1 <- sqlQuery(
  Kon,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,
CLM.AMT_COB_PAID,
CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,

MEM.member_ID,MEM.MEMBER_NO, MEM.DATE_EFFECTIVE, MEM.ZIP

FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID

where DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720")

# scp analytic_data2020_0_tab.txt dless1@apsrd9425:/home/dless1/kaiser
# scp FIPS_tab.txt dless1@apsrd9425:/home/dless1/kaiser
# scp USDA.txt dless1@apsrd9425:/home/dless1/kaiser





tapestry_claim1 <- data.frame(r_index = row.names(tapestry_claim1), tapestry_claim1)
tapestry_claim1$r_index <- as.numeric(as.character(tapestry_claim1$r_index )) 

# targets
tapestry_dupes <- sqldf("select c.*, k.SECOND_CARRIER_MEMBER_NO from kieser_c2c k, tapestry_claim1 c
                        where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO")

# commercial project id

# commerical only had 7 hits
# probably legacy data --- exclude
#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01314.DBO.CLAIM where FEED_ID != 999")


base1 <- tapestry_claim1


# 
# 
# mem_enroll_date <- sqldf("select MEMBER_NO, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE from base1
# 
#                group by MEMBER_NO")
# 
# 
# base1 <- sqldf("select b.*, m.max_DATE_EFFECTIVE from base1 b left join mem_enroll_date m
#                on b.MEMBER_NO = m.MEMBER_NO
#                group by b.CLAIM_ID")



base1 <- sqldf(
  "select DISTINCT *
FROM base1
WHERE PATIENT_AGE <=64
and AMT_PAID >0
  ")


# convert to date format

# base1$enroll_date <-as.POSIXct(base1$max_DATE_EFFECTIVE, origin="1970-01-01")
# base1$admit_date <-as.POSIXct(base1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
# base1$member_months <-(difftime(base1$admit_date , base1$enroll_date, units = "days"  ))/30.42
# base1a <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base1
# where member_months > 0
#                              group by PATIENT_ID
#                  ")



DX_claim_tapestry  <- sqlQuery(
  Kon,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
  INNER JOIN Racer01169.DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CLM.FEED_ID between 260 and 263
  AND  DX.ORDER_IN_CLAIM <= 5
   and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 180
   and CLM.PATIENT_AGE <=64
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)


DX_claim <- sqldf("select d.* from DX_claim_tapestry d, base1 b
                  where d.CLAIM_ID = b.CLAIM_ID")

#rm( DX_claim_tapestry)
DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

saveRDS(charlson_scores, file="charlson_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")







#rm(tapestry_claim1)
#rm(base1)


charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL
elixhauser_scores$CLAIM_IDx <- as.numeric(elixhauser_scores$CLAIM_ID)



base2 <- sqldf("select distinct b.*, c.wscore as charls_score from charlson_scores c,
               base1 b where 
               b.CLAIM_ID = c.CLAIM_ID", method = "name_class")




base2 <- sqldf("select distinct b.*, c.score as elix_score, c.wscore_ahrq from elixhauser_scores c,
               base2 b where 
               b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")


base2$ratio_billed_to_paid<-(base2$AMT_BILLED + 1 )/(base2$AMT_PAID +1 )
base2$ratio_allowed_to_paid<-(base2$AMT_ALLOWED +1 ) /(base2$AMT_PAID +1)

# find max values by member

base3 <- sqldf("select MEMBER_NO, INS_GROUP_ID, max(charls_score) as max_charls_score,
               max(elix_score) as max_elix_score,
               max(wscore_ahrq) as max_wscore_ahrq,
               max(ratio_billed_to_paid) as max_ratio_billed_to_paid,
               max(ratio_allowed_to_paid) as max_ratio_allowed_to_paid
               from base2 
               where ratio_billed_to_paid < 5
               and ratio_allowed_to_paid < 5
               group by MEMBER_NO
               ", method = "name_class")


base4 <- sqldf("select b.*, e.first_mm as member_months from  base3 b, enrollment3 e
               where e.MEMBER_NO = b.MEMBER_NO")


base4 <-  sqldf("select b.*, m.groupid_refund_rate, m.mem_cnt as number_members_in_group
from baseline_mem_counts_by_insur_id2 m,
                base4 b
                where b.INS_GROUP_ID = m.INS_GROUP_ID")


#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# add external data

ext_data1 <- sqlQuery(
  Kon,
  "select  distinct MEM.MEMBER_NO,  MEM.ZIP
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720
  and MEM.ZIP != ''")


# code to copy flat  files
# scp dless1@apsrd9425:/home/dless1/kaiser/analytic_data2020_0_tab.txt /H/My_Doccuments
# scp dless1@apsrd9425:/home/dless1/kaiser/FIPS_tab.txt /H/My_Doccuments
# scp dless1@apsrd9425:/home/dless1/kaiser/USDA.txt /H/My_Doccuments

county_hlth  <- read.csv("analytic_data2020_0_tab.txt", header=TRUE, sep="\t")
FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


ext_data2 <- sqldf("select v.*, f.COUNTY from FIPS f, ext_data1 v
                 where v.ZIP = f.zip")

ext_data2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from USDA f, ext_data2 v
                 where v.COUNTY = f.FIPS")

# #rename
names(county_hlth)[3] <- 'long_fips'
names(county_hlth)[140] <- 'physician_rate'
names(county_hlth)[152] <- 'MH_providers'
names(county_hlth)[8] <- 'premature_death'
names(county_hlth)[397] <- 'diabetes_preval'
names(county_hlth)[477] <- 'ratio_PCP_other'


county_hlth2 <- sqldf("select long_fips,
physician_rate,
                       premature_death,
                       MH_providers,
                      diabetes_preval,
                      ratio_PCP_other
                      from county_hlth
                      where long_fips !='0' ")

ext_data2 <- sqldf("select v.*, 
c.physician_rate,
                       c.premature_death,
                       c.MH_providers,
                      c.diabetes_preval,
                      c.ratio_PCP_other
                      from ext_data2 v, county_hlth2 c
                 where v.COUNTY = c.long_fips")


ext_data2$physician_rate <- as.numeric(as.character(ext_data2$physician_rate))
ext_data2$premature_death <- as.numeric(as.character(ext_data2$premature_death))
ext_data2$MH_providers <- as.numeric(as.character(ext_data2$MH_providers))
ext_data2$diabetes_preval <- as.numeric(as.character(ext_data2$diabetes_preval))
ext_data2$ratio_PCP_other <- as.numeric(as.character(ext_data2$ratio_PCP_other))

ext_data2$physician_rate <- ifelse(is.na(ext_data2$physician_rate), 0, ext_data2$physician_rate)
ext_data2$premature_death <- ifelse(is.na(ext_data2$premature_death), 0, ext_data2$premature_death)
ext_data2$MH_providers <- ifelse(is.na(ext_data2$MH_providers), 0, ext_data2$MH_providers)
ext_data2$diabetes_preval <- ifelse(is.na(ext_data2$diabetes_preval), 0, ext_data2$diabetes_preval)
ext_data2$ratio_PCP_other <- ifelse(is.na(ext_data2$ratio_PCP_other), 0, ext_data2$ratio_PCP_other)





# filter for most recent feed to score

base5 <- sqldf("select  b.*, e.USDA_urban_rural,
               e.physician_rate,
               e.premature_death,
               e.premature_death,
               e.MH_providers,
               e.diabetes_preval,
               e.ratio_PCP_other
               from base4 b, ext_data2 e
               where b.MEMBER_NO = e.MEMBER_NO
               group by b.MEMBER_NO")


saveRDS(base5, file="base5.Rda")


#base5 <- readRDS(file="base5.Rda")

# remove group ids with < 20 members

base_log <- sqldf("select * from base5 where number_members_in_group < 20
                  and member_months != 'NA' and max_ratio_billed_to_paid < 5
                  and max_ratio_allowed_to_paid < 5
                  ")

summary(base_log)


# filter on olny last 12 feeds


current_feed <- sqlQuery(
  Kon,
  "select  distinct CLM.INS_GROUP_ID,MEM.MEMBER_NO
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where  CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720"
)

cluster_inputs0 <- sqldf("select distinct b.* from base5 b, current_feed c
                         where c.INS_GROUP_ID = b.INS_GROUP_ID
                         and c.MEMBER_NO = b.MEMBER_NO")
# remove C2C hits


tapestry_dupes00 <-
  sqldf(
    "select distinct c.*, k.SECOND_CARRIER_MEMBER_NO from cluster_inputs0 c left join kieser_c2c k 
                        on c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO"
  )

tapestry_dupes00$SECOND_CARRIER_MEMBER_NO<- ifelse(is.na(tapestry_dupes00$SECOND_CARRIER_MEMBER_NO), '0', 
                                    tapestry_dupes00$SECOND_CARRIER_MEMBER_NO)

base_log2 <- sqldf("select * from tapestry_dupes00 where SECOND_CARRIER_MEMBER_NO  = '0' ")

c2chits <- sqldf("select * from tapestry_dupes00 where SECOND_CARRIER_MEMBER_NO  != '0' ")

f0 <- nrow(base_log)
f <- nrow(c2chits)

precent_c2c <- (f/f0) *100
print(f0)
print(f)
print(precent_c2c)

cluster_inputs <- base_log2

#cluster_inputs$PATIENT_AGE <- sqrt(cluster_inputs$PATIENT_AGE)
cluster_inputs$groupid_refund_rate <- sqrt(cluster_inputs$groupid_refund_rate)
cluster_inputs$max_ratio_billed_to_paid <- log10(cluster_inputs$max_ratio_billed_to_paid)
cluster_inputs$max_ratio_allowed_to_paid <- log10(cluster_inputs$max_ratio_allowed_to_paid)

cluster_inputs$max_charls_score <- (cluster_inputs$max_charls_score - mean(cluster_inputs$max_charls_score)) / sd(cluster_inputs$max_charls_score)

cluster_inputs$max_elix_score <- (cluster_inputs$max_elix_score  - mean(cluster_inputs$max_elix_score )) / sd(cluster_inputs$max_elix_score )

cluster_inputs$member_months <- log10(cluster_inputs$member_months)

cluster_inputs$physician_rate <- log10(cluster_inputs$physician_rate)
cluster_inputs$premature_death <- log10(cluster_inputs$premature_death)
cluster_inputs$MH_providers <- log10(cluster_inputs$MH_providers)
cluster_inputs$ratio_PCP_other <- log10(cluster_inputs$ratio_PCP_other)
cluster_inputs$USDA_urban_rural <- sqrt(cluster_inputs$USDA_urban_rural)
cluster_inputs$MEMBER_NO <- NULL
cluster_inputs$INS_GROUP_ID <- NULL
cluster_inputs$premature_death..14 <- NULL
cluster_inputs$number_members_in_group <- NULL
cluster_inputs$SECOND_CARRIER_MEMBER_NO  <- NULL

summary(cluster_inputs)

# move target to first column
library(dplyr)
cluster_inputs<- cluster_inputs %>% select (groupid_refund_rate, everything())

# library(plyr)
# library(xgboost)
# library(caret)
# library(caTools)
# library(tidyverse)
# 
# set.seed(77)

# # indexes <- createDataPartition(cluster_inputs$groupid_refund_rate , p = 0.7, list = FALSE)
# # 
# # train <- cluster_inputs[indexes, ]
# # test <- cluster_inputs[-indexes, ]
# # 
# # train_x <- data.matrix(train[, -7])
# # train_y <- train[, 7]
# # 
# # test_x <- data.matrix(test[, -7])
# # test_y <- test[, 7]
# # 
# # 
# # xgb_train <- xgb.DMatrix(data = train_x, label = train_y)
# # xgb_test <- xgb.DMatrix(data = test_x, label = test_y)
# # 
# # xgbc <- xgboost(data = xgb_train, max.depth = 2, nrounds = 50)
# # print(xgbc)
# # 
# # pred_y <- predict(xgbc, xgb_test)
# # 
# # 
# # mse <- mean((test_y - pred_y)^2)
# # mae <- caret::MAE(test_y , pred_y)
# # rmse <- caret::RMSE(test_y , pred_y)
# # 
# # cat("MSE: ", mse, "MAE:  ", mae, "RMSE:  , rmse")
# 
# 
# # training.samples <- cluster_inputs$groupid_refund_rate %>%
# #                         createDataPartition(p = 0.7, list = FALSE)
# # 
# # train.data <- cluster_inputs[training.samples]
# # test.data <- cluster_inputs[-training.samples]
# 
# 
# indexes <- createDataPartition(cluster_inputs$groupid_refund_rate , p = 0.7, list = FALSE)
# 
# train <- cluster_inputs[indexes, ]
# test <- cluster_inputs[-indexes, ]
# 
# model <- train(groupid_refund_rate ~., data = train, method = "xgbTree",
#                trControl = trainControl("cv", number = 10)
#   
# )  
# 
# model$bestTune
# 
# 
# predictions <- model %>% predict(test)
# 
# mean(predictions == test$groupid_refund_rate)
# 
# varImp(model)
# 
# 
# set.seed(77)
# sample_split <- sample.split(Y = cluster_inputs$groupid_refund_rate, SplitRatio = 0.7)
# train_set <- subset(x=cluster_inputs, sample_split = TRUE)
# test_set <- subset(x=cluster_inputs, sample_split = TRUE)
# 
# train_x <- data.matrix(train_set[, -7])
# train_y <- train_set[, 7]
# 
# test_x <- data.matrix(test_set[, -7])
# test_y <- test_set[, 7]
# 
# xgb_train <- xgb.DMatrix(data = as.matrix(train_x ), label = train_y)
# xgb_test <- xgb.DMatrix(data = as.matrix(test_x ), label = test_y)
# 
# xgb_params <- list(
#   booster = "gbtree",
#  
#   eta = 0.01,
#   max_depth = 8,
#   gama = 4,
#   subsample = 0.75,
#   colsample_bytree = 1,
#   eval_metric = "rmse"
#   )
# 
# 
# xgb_model <- xgb.train(
#   params = xgb_params,
#   data = xgb_train,
#   nrounds = 500,
#   verbose = 1
# )
# 
# xgb_model
# 
# xgb_preds <- predict(xgb_model, as.matrix(test_x), reshape = TRUE)
# xgb_preds <- as.data.frame(xgb_preds)
# 
# residuals <- test_y - xgb_preds
# RMSE <- sqrt(mean(residuals **2))
# y_test_mean <- mean(test_y)
# TSS <- sum((test_y -y_test_mean)**2 )
# RSS <- sum(residuals **2)
# R_squared = 1-(RSS/TSS)
# 
# xgb_preds$transofrmed <- exp(xgb_preds$xgb_preds) -1
# base_log2 <- cbind(xgb_preds,base_log )
# base_log2$residuals <- base_log2$transofrmed - base_log2$groupid_refund_rate
# RMSE <- sqrt(mean(base_log2$residuals **2))
# y_test_mean <- mean(base_log2$groupid_refund_rate)
# TSS <- sum((base_log2$transofrmed -y_test_mean)**2 )
# RSS <- sum(base_log2$residuals **2)
# R_squared = 1-(RSS/TSS)
# 
# mean(base_log2$transofrmed  == base_log2$groupid_refund_rate)

#HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
library(h2o)
h2o.init(port=54333)

# cluster_inputs_h2o <- as.h2o((cluster_inputs))
# 
# splits <- h2o.splitFrame(cluster_inputs_h2o, c(0.7), seed = 77)
# train <- h2o.assign(splits[[1]], "train.hex")
# test <- h2o.assign(splits[[2]], "test.hex")
# 
# y <- "groupid_refund_rate"
# x <- setdiff(names(train), y)
# 
# response <- "groupid_refund_rate"
# train[[response]] <- as.factor(train[[response]])
# predictors <- setdiff(colnames(train),response)

# 
# 
# #RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
# 
# 
# # Random Forest
# 
# nfolds = 10
# 
# rf <- h2o.randomForest( x = predictors,
#                         y = response,
#                         training_frame = train,
#                         ntrees = 20,
#                         nfolds = nfolds,
#                         fold_assignment = "Modulo",
#                         
#                         seed = 77)
# 
# 
# summary(rf)
# #keep_cross_validation_predictions = TRUE,
# 
# head(as.data.frame(h2o.varimp(rf)),n=10)
# 
# pred_rf <- h2o.performance(rf, newdata = test,  valid = TRUE)
# 
# summary(pred_rf)
# pred_rf@model$validation_metrics
# pred_rf
# 
# 
# 
# #glm GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG
# 
# 
# 
# nfolds = 10
# 
# glm1 <- h2o.glm( x = predictors,
#                  y = response,
#                  training_frame = train,
#                  family = "gaussian",
#                  lambda_search = TRUE,
# nfolds = nfolds,standardize = FALSE,
#                  
#                  
#                  seed = 77)
# 
# print(glm1)
# summary(glm1)
# 
# pred_glm1 <- h2o.performance(glm1, newdata = test,  valid = TRUE)
# 
# summary(pred_glm1)
# pred_glm1@model$coefficients
# pred_glm1@model$coefficients_table
# pred_glm1@model$standardized_coefficients_magnitudes
# pred_glm1



# nfolds <- 10
# xgboost <- h2o.xgboost(x=x,
#                        y = y,
#                        training_frame = train,
#                        validation_frame = test,
#                        ntrees = 200,
#                        nfolds = nfolds,
#                        fold_assignment = "Modulo",
#                        keep_cross_validation_predictions = TRUE,
#                        max_depth = 3,
#                        min_rows = 2,
#                        learn_rate =0.2,
#                        seed = 77)
# 
# summary(xgboost)
# 
# head(as.data.frame(h2o.varimp(xgboost)),n=10)
# h2o.saveModel(xgboost, path = "xgboost", force =TRUE)
#"/home/dless1/kaiser/xgboost/XGBoost_model_R_1614025114043_1"



# score new feed


data_to_score <- as.h2o(cluster_inputs)

rf_95<- h2o.loadModel("/home/dless1/kaiser/xgboost/XGBoost_model_R_1614025114043_1")

pred <- h2o.predict(object = rf_95, newdata = data_to_score)


pred_df <- as.data.frame(pred)

saveRDS(pred_df, file="pred_df_7_21.Rda")

#names(pred_df)[2] <- 'p0'
pred_df$predict <- as.numeric(as.character(pred_df$predict))

pred_df$predict<- ifelse(is.na(pred_df$predict), '0', 
                         pred_df$predict)

#my_threshold <- .5
#pred_df[,"predict"] <- pred_df[,"predict"] >= my_threshold

cl_ids <- base_log2 %>%
  select(MEMBER_NO) 


claim_probabilities <- cbind(cl_ids,pred_df )

claim_probabilities <- sqldf("select MEMBER_NO, predict as p1 from claim_probabilities where predict > 0")



current_feed <- sqlQuery(
  Kon,
  "select  distinct CLM.CLAIM_ID as CLAIM_CLAIM_ID,CLM.PATIENT_ID,
  CLM.CLAIM_NO as CLAIM_CLAIM_NO ,
  CLM.AMT_PAID,
  MEM.MEMBER_NO,
  MEM.MEMBER_ID,
  CLM.FEED_ID
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where CLM.PATIENT_AGE < 65
and CLM.FEED_ID between 260 and 263
  "
  
)



claims_to_investigate  <- sqldf("select distinct c.*, p1 as Model_Score
                               from claim_probabilities p, current_feed c
                               where p.MEMBER_NO = c.MEMBER_NO
                               and p.MEMBER_NO NOT IN ('110014745571NC', '110014745571NC','110012736628NC','110009290382NC',
                               '000004566694SC')
                               order by c.MEMBER_NO desc")

#kaiser239 <- readRDS(file="kaiser239.Rda")

# claims_to_investigate <- sqldf("select distinct c.*, k.MEMBER_NO as MEMBER_NOx from claims_to_investigate c left join kaiser239 k ON
#               c.MEMBER_NO = k.MEMBER_NO")
# 
# claims_to_investigate$MEMBER_NOx <- ifelse(is.na(claims_to_investigate$MEMBER_NOx),
#                                            0, claims_to_investigate$MEMBER_NOx)
# 
# claims_to_investigate <- sqldf("select  j.* from claims_to_investigate j where MEMBER_NOx != 0")
# claims_to_investigate$MEMBER_NOx <- NULL

# max feed 4/23 = 426
# buisness wants project id, MEMBEr_ID

# claims_to_investigate <- sqldf("select MEMBER_ID, max(p1) as Model_Score from claims_to_investigate
#               group by MEMBER_ID order by Model_Score desc")





claims_to_investigate$PROJECT_ID = 1169
write.csv(claims_to_investigate, file = "claims_to_investigate_kaiser260_263.csv")
#write.csv(member_cnt, file = "member_cnt_kaiser251_254.csv")
saveRDS(claims_to_investigate, file="kaiser260_263.Rda")

#junk <- readRDS(file="kaiser239.Rda")

#scp dless1@apsrd9425:/home/dless1/kaiser/claims_to_investigate_kaiser239.csv /H/My_Doccuments
#scp dless1@apsrd9425:/home/dless1/kaiser/member_cnt_kaiser239.csv /H/My_Doccuments


#claims_to_investigate <- readRDS(file="hipny198.Rda")
#claims_to_investigate$CLAIM_FEED_ID <- 238
# claims_to_investigate_claims<-sqldf("select CLAIM_CLAIM_ID,CLAIM_FEED_ID,
# AMT_PAID as CLAIM_AMT_PAID,p0 ,p1 
#                                     from claims_to_investigate group by 
#                                     CLAIM_CLAIM_ID,CLAIM_NO,CLAIM_FEED_ID,CLAIM_AMT_PAID,p0,p1")

# check connnection

conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
                         UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')



sqlSave(conn1,claims_to_investigate,tablename="dbo.kaiser260_263",rownames=FALSE)



raw_data_for_hits <- sqldf("select c.p1, b.* from base5 b, claim_probabilities c
                           where b.MEMBER_NO = c.MEMBER_NO")

write.csv(raw_data_for_hits, file = "raw_data_for_hits_kaiser260_263.csv")


h2o.shutdown(prompt  = FALSE)
































#base2$CLAIM_IDx <- NULL
#base2$score <- NULL
#base2$index <- NULL
#base2$windex_ahrq <- NULL
#base2$windex_vw <- NULL






# flag c2c hits for target


base3_0 <- sqldf("select distinct  c.*, k.SECOND_CARRIER_MEMBER_NO from base2 c , kieser_c2c k  
                       where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO")

base3_0 <- sqldf("select SECOND_CARRIER_MEMBER_NO , MEMBER_NO as indexy from tapestry_dupes")


library(dplyr)

base3 <- dplyr::left_join(base2, tapestry_dupes, by = c("MEMBER_NO" = "SECOND_CARRIER_MEMBER_NO"))



#base3 <- dplyr::left_join(base2, base3_0, by = c("r_index" = "r_index"))


base3_0 <- sqldf("select distinct c.* from base2 c inner join tapestry_dupes k  
                       on c.r_index = k.r_index")

base3_0$c2c_hit<- 1

base3_id <- sqldf("select distinct r_index from base3_0")


base3 <- dplyr::anti_join(base2, base3_id, by = c("r_index" = "r_index"))

base3$c2c_hit<- 0

base4 <- rbind(base3_0,base3)

base4$CLAIM_ID..43 <- NULL


non_refund_members <- sqldf("select distinct * from base4 where c2c_hit = 0")

non_refund_members0 <- sqldf("select PATIENT_ID, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE 
                             from base4 where c2c_hit = 0 group by PATIENT_ID")
non_refund_members1 <- sqldf("select distinct n.*,m.max_DATE_EFFECTIVE from non_refund_members0 m,  non_refund_members n
                             where m.PATIENT_ID= n.PATIENT_ID")

# convert to date format
non_refund_members1$enroll_date <-as.POSIXct(non_refund_members1$max_DATE_EFFECTIVE, origin="1970-01-01")
non_refund_members1$admit_date <-as.POSIXct(non_refund_members1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
non_refund_members1$member_months <-(difftime(non_refund_members1$admit_date , non_refund_members1$enroll_date, units = "days"  ))/30.42
non_refund_members2 <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from non_refund_members1
                             group by PATIENT_ID")


refmem <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base4 where  c2c_hit = 1
                             group by PATIENT_ID")

refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as ref_cnt, 
avg(first_mm) as mean_mm from
refmem  group by INS_GROUP_ID order by ref_cnt desc" )



non_refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as non_ref_cnt, 
avg(first_mm) as non_mean_mm from
non_refund_members2  group by INS_GROUP_ID order by non_ref_cnt desc" )

groupid_ratio <- sqldf("select r.*, n.non_ref_cnt,n.non_mean_mm   from non_refund_members_cnt n, 
                       refund_members_cnt r where r.INS_GROUP_ID = n.INS_GROUP_ID")

groupid_ratio$groupid_refund_rate <- (groupid_ratio$ref_cnt / groupid_ratio$non_ref_cnt) *1000

# a positive number means that the refunds were newer members
groupid_ratio$member_month_delta <- as.numeric(groupid_ratio$non_mean_mm -  groupid_ratio$mean_mm)

base5 <- sqldf("select b.*, g.groupid_refund_rate, g.member_month_delta from base4 b , groupid_ratio g
               where b.INS_GROUP_ID = g.INS_GROUP_ID", method = "name_class")


base5$ratio_billed_to_paid<-(base5$AMT_BILLED + 1 )/(base5$AMT_PAID +1 )
base5$ratio_allowed_to_paid<-(base5$AMT_ALLOWED +1 ) /(base5$AMT_PAID +1)

base5$PLACE_OF_SERVICE<- ifelse(is.na(base5$PLACE_OF_SERVICE), 0, 
                                base5$PLACE_OF_SERVICE)

base5$BILL_TYPE<- ifelse(base5$BILL_TYPE == '', "0", base5$BILL_TYPE)

saveRDS(base4, file="base4.Rda")
saveRDS(base5, file="base5.Rda")
#base5 <- readRDS(file="base5.Rda")
#base5 <- readRDS(file="base5_238.Rda")

rm(base1)
rm(base1a)
rm(base2)
rm(base3)
rm(base3_0)
rm(non_refund_members1)
rm(charlson_scores)
rm(elixhauser_scores)
rm(tapestry_claim1)



#LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

#str(base5,list.len = ncol(base5))
# log transofrmation

# remive feed 238 and use it for scorring for production


base_log <- sqldf("select * from base5 where FEED_ID != 238 and c2c_hit = 0
                  and member_month_delta != 'NA' and ratio_billed_to_paid < 5
                  and ratio_allowed_to_paid < 5
                  order by CLAIM_ID")

summary(base_log)







cluster_inputs <- base_log

cluster_inputs$PATIENT_AGE <- sqrt(cluster_inputs$PATIENT_AGE)
cluster_inputs$groupid_refund_rate <- log10(cluster_inputs$groupid_refund_rate)
cluster_inputs$ratio_billed_to_paid <- log10(cluster_inputs$ratio_billed_to_paid)
cluster_inputs$ratio_allowed_to_paid <- log10(cluster_inputs$ratio_allowed_to_paid)

cluster_inputs$charlson <- (cluster_inputs$charls_score - mean(cluster_inputs$charls_score)) / sd(cluster_inputs$charls_score)

cluster_inputs$elixhauser <- (cluster_inputs$wscore_vw  - mean(cluster_inputs$wscore_vw )) / sd(cluster_inputs$wscore_vw )
cluster_inputs$ahrq <- (cluster_inputs$wscore_ahrq  - mean(cluster_inputs$wscore_ahrq )) / sd(cluster_inputs$wscore_ahrq )

cluster_inputs$member_month_delta <- as.numeric(scale(cluster_inputs$member_month_delta))


cluster_inputs$charls_score <- NULL
cluster_inputs$wscore_vw <- NULL
cluster_inputs$r_index <- NULL
cluster_inputs$CLAIM_ID  <- NULL
cluster_inputs$CLAIM_NO <- NULL
cluster_inputs$FEED_ID <- NULL
cluster_inputs$PROJECT_ID <- NULL
cluster_inputs$PATIENT_ID  <- NULL
cluster_inputs$PATIENT_DOB <- NULL
cluster_inputs$DATE_OF_SERVICE_BEG  <- NULL
cluster_inputs$DATE_OF_SERVICE_END <- NULL
cluster_inputs$DATE_ADMITTED <- NULL
cluster_inputs$DATE_DISCHARGED  <- NULL
cluster_inputs$SUBSCRIBER_ID <- NULL
cluster_inputs$SUBSCRIBER_AGE  <- NULL
cluster_inputs$SUBSCRIBER_DOB <- NULL
cluster_inputs$AMT_BILLED <- NULL
cluster_inputs$AMT_ALLOWED  <- NULL
cluster_inputs$AMT_COPAY <- NULL
cluster_inputs$AMT_DEDUCTIBLE <- NULL
cluster_inputs$AMT_COINSURANCE <- NULL
cluster_inputs$AMT_COB_PAID <- NULL
cluster_inputs$AMT_PAID  <- NULL
cluster_inputs$DATE_PAID <- NULL
cluster_inputs$ADJ_CLAIM_FLAG <- NULL
cluster_inputs$Principal_Dx <- NULL
cluster_inputs$SUBSCRB_DOB <- NULL
cluster_inputs$INS_GROUP_ID  <- NULL
cluster_inputs$CLM_DATE_CREATED <- NULL
cluster_inputs$CLM_DATE_UPDATED  <- NULL
cluster_inputs$PROVIDER_ID <- NULL
cluster_inputs$member_ID <- NULL
cluster_inputs$MEMBER_NO <- NULL
cluster_inputs$DATE_EFFECTIVE <- NULL
cluster_inputs$max_DATE_EFFECTIVE <- NULL
cluster_inputs$enroll_date <- NULL
cluster_inputs$admit_date <- NULL
cluster_inputs$member_months <- NULL
cluster_inputs$wscore_ahrq <- NULL

cluster_inputs$c2c_hit <- NULL
# 
cluster_inputs$chf <-  as.factor(as.character(cluster_inputs$chf))
cluster_inputs$carit <-  as.factor(as.character(cluster_inputs$carit))
cluster_inputs$valv <-  as.factor(as.character(cluster_inputs$valv))
cluster_inputs$pcd <-  as.factor(as.character(cluster_inputs$pcd))
cluster_inputs$pvd <-  as.factor(as.character(cluster_inputs$pvd))
cluster_inputs$hypunc <-  as.factor(as.character(cluster_inputs$hypunc))
cluster_inputs$hypc <-  as.factor(as.character(cluster_inputs$hypc))
cluster_inputs$para <-  as.factor(as.character(cluster_inputs$para))
cluster_inputs$ond <-  as.factor(as.character(cluster_inputs$ond))
cluster_inputs$cpd <-  as.factor(as.character(cluster_inputs$cpd))
cluster_inputs$diabunc <-  as.factor(as.character(cluster_inputs$diabunc))
cluster_inputs$diabc <-  as.factor(as.character(cluster_inputs$diabc))
cluster_inputs$hypothy <-  as.factor(as.character(cluster_inputs$hypothy))
cluster_inputs$rf <-  as.factor(as.character(cluster_inputs$rf))
cluster_inputs$ld <-  as.factor(as.character(cluster_inputs$ld))
cluster_inputs$pud <-  as.factor(as.character(cluster_inputs$pud))
cluster_inputs$aids <-  as.factor(as.character(cluster_inputs$aids))
cluster_inputs$lymph <-  as.factor(as.character(cluster_inputs$lymph))
cluster_inputs$metacanc <-  as.factor(as.character(cluster_inputs$metacanc))
cluster_inputs$solidtum <-  as.factor(as.character(cluster_inputs$solidtum))
cluster_inputs$rheumd <-  as.factor(as.character(cluster_inputs$rheumd))
cluster_inputs$coag <-  as.factor(as.character(cluster_inputs$coag))
cluster_inputs$obes <-  as.factor(as.character(cluster_inputs$obes))
cluster_inputs$wloss <-  as.factor(as.character(cluster_inputs$wloss))
cluster_inputs$fed <-  as.factor(as.character(cluster_inputs$fed))
cluster_inputs$blane <-  as.factor(as.character(cluster_inputs$blane))
cluster_inputs$dane <-  as.factor(as.character(cluster_inputs$dane))
cluster_inputs$alcohol <-  as.factor(as.character(cluster_inputs$alcohol))
cluster_inputs$drug <-  as.factor(as.character(cluster_inputs$drug))
cluster_inputs$psycho <-  as.factor(as.character(cluster_inputs$psycho))
cluster_inputs$depre <-  as.factor(as.character(cluster_inputs$depre))


cluster_inputs$chf <-  NULL
cluster_inputs$carit <-  NULL
cluster_inputs$valv <-   NULL
cluster_inputs$pcd <-   NULL
cluster_inputs$pvd <-   NULL
cluster_inputs$hypunc <-   NULL
cluster_inputs$hypc <-   NULL
cluster_inputs$para <-   NULL
cluster_inputs$ond <-   NULL
cluster_inputs$cpd <-   NULL
cluster_inputs$diabunc <-   NULL
cluster_inputs$diabc <-   NULL
cluster_inputs$hypothy <-   NULL
cluster_inputs$rf <-   NULL
cluster_inputs$ld <-   NULL
cluster_inputs$pud <-   NULL
cluster_inputs$aids <-   NULL
cluster_inputs$lymph <-   NULL
cluster_inputs$metacanc <-   NULL
cluster_inputs$solidtum <-  NULL
cluster_inputs$rheumd <-   NULL
cluster_inputs$coag <-   NULL
cluster_inputs$obes <-   NULL
cluster_inputs$wloss <-   NULL
cluster_inputs$fed <-   NULL
cluster_inputs$blane <-   NULL
cluster_inputs$dane <-   NULL
cluster_inputs$alcohol <-   NULL
cluster_inputs$drug <-   NULL
cluster_inputs$psycho <-   NULL
cluster_inputs$depre <-   NULL


cluster_inputs$PATIENT_GENDER <-  as.factor(as.character(cluster_inputs$PATIENT_GENDER))
cluster_inputs$PLACE_OF_SERVICE <-  as.factor(as.character(cluster_inputs$PLACE_OF_SERVICE))
cluster_inputs$PRODUCT_LINE_ID <-  as.factor(as.character(cluster_inputs$PRODUCT_LINE_ID))

cluster_inputs$BILL_TYPE<- ifelse(is.na(cluster_inputs$BILL_TYPE), 0, 
                                  cluster_inputs$BILL_TYPE)


cluster_inputs$PATIENT_GENDER <- NULL
cluster_inputs$BILL_TYPE <- NULL
cluster_inputs$PLACE_OF_SERVICE <- NULL
cluster_inputs$PRODUCT_LINE_ID <- NULL

cluster_inputs$ZIP <- NULL
cluster_inputs$CLAIM_ID..44 <- NULL

attr(cluster_inputs, "label") <- NULL
#str(cluster_inputs,list.len = ncol(cluster_inputs))

summary(cluster_inputs)


cluster_inputs_h2o <- as.h2o((cluster_inputs))

splits <- h2o.splitFrame(cluster_inputs_h2o, c(0.7), seed = 77)
train <- h2o.assign(splits[[1]], "train.hex")
test <- h2o.assign(splits[[2]], "test.hex")

y <- "groupid_refund_rate"
x <- setdiff(names(train), y)

response <- "groupid_refund_rate"
train[[response]] <- as.factor(train[[response]])
predictors <- setdiff(colnames(train),response)



#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


# Random Forest

nfolds = 10

rf <- h2o.randomForest( x = predictors,
                        y = response,
                        training_frame = train,
                        ntrees = 20,
                        nfolds = nfolds,
                        fold_assignment = "Modulo",
                        
                        seed = 77)


summary(rf)
#keep_cross_validation_predictions = TRUE,

head(as.data.frame(h2o.varimp(rf)),n=10)

pred_rf <- h2o.performance(rf, newdata = test,  valid = TRUE)

summary(pred_rf)
pred_rf@model$validation_metrics
pred_rf



#glm GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG



nfolds = 10

glm1 <- h2o.glm( x = predictors,
                 y = response,
                 training_frame = train,
                 family = "gaussian",
                 
                 
                 
                 seed = 77)

print(glm1)
summary(glm1)
lambda_search = TRUE,
nfolds = nfolds,standardize = FALSE,
pred_glm1 <- h2o.performance(glm1, newdata = test,  valid = TRUE)

summary(pred_glm1)
pred_glm1@model$coefficients
pred_glm1@model$coefficients_table
pred_glm1@model$standardized_coefficients_magnitudes
pred_glm1

# repeat without log transofrmations and let H2O do standardize

base_log <- sqldf("select * from base5 where FEED_ID != 238 and c2c_hit = 0
                  and member_month_delta != 'NA' and ratio_billed_to_paid < 5
                  and ratio_allowed_to_paid < 5
                  order by CLAIM_ID")

summary(base_log)







cluster_inputs <- base_log
base_log <- sqldf("select * from base5 where FEED_ID != 238 and c2c_hit = 0
                  and member_month_delta != 'NA' and ratio_billed_to_paid < 5
                  and ratio_allowed_to_paid < 5
                  order by CLAIM_ID")

summary(base_log)







cluster_inputs <- base_log




cluster_inputs$r_index <- NULL
cluster_inputs$CLAIM_ID  <- NULL
cluster_inputs$CLAIM_NO <- NULL
cluster_inputs$FEED_ID <- NULL
cluster_inputs$PROJECT_ID <- NULL
cluster_inputs$PATIENT_ID  <- NULL
cluster_inputs$PATIENT_DOB <- NULL
cluster_inputs$DATE_OF_SERVICE_BEG  <- NULL
cluster_inputs$DATE_OF_SERVICE_END <- NULL
cluster_inputs$DATE_ADMITTED <- NULL
cluster_inputs$DATE_DISCHARGED  <- NULL
cluster_inputs$SUBSCRIBER_ID <- NULL
cluster_inputs$SUBSCRIBER_AGE  <- NULL
cluster_inputs$SUBSCRIBER_DOB <- NULL
cluster_inputs$AMT_BILLED <- NULL
cluster_inputs$AMT_ALLOWED  <- NULL
cluster_inputs$AMT_COPAY <- NULL
cluster_inputs$AMT_DEDUCTIBLE <- NULL
cluster_inputs$AMT_COINSURANCE <- NULL
cluster_inputs$AMT_COB_PAID <- NULL
cluster_inputs$AMT_PAID  <- NULL
cluster_inputs$DATE_PAID <- NULL
cluster_inputs$ADJ_CLAIM_FLAG <- NULL
cluster_inputs$Principal_Dx <- NULL
cluster_inputs$SUBSCRB_DOB <- NULL
cluster_inputs$INS_GROUP_ID  <- NULL
cluster_inputs$CLM_DATE_CREATED <- NULL
cluster_inputs$CLM_DATE_UPDATED  <- NULL
cluster_inputs$PROVIDER_ID <- NULL
cluster_inputs$member_ID <- NULL
cluster_inputs$MEMBER_NO <- NULL
cluster_inputs$DATE_EFFECTIVE <- NULL
cluster_inputs$max_DATE_EFFECTIVE <- NULL
cluster_inputs$enroll_date <- NULL
cluster_inputs$admit_date <- NULL
cluster_inputs$member_months <- NULL
cluster_inputs$wscore_ahrq <- NULL

cluster_inputs$c2c_hit <- NULL
# 
cluster_inputs$chf <-  as.factor(as.character(cluster_inputs$chf))
cluster_inputs$carit <-  as.factor(as.character(cluster_inputs$carit))
cluster_inputs$valv <-  as.factor(as.character(cluster_inputs$valv))
cluster_inputs$pcd <-  as.factor(as.character(cluster_inputs$pcd))
cluster_inputs$pvd <-  as.factor(as.character(cluster_inputs$pvd))
cluster_inputs$hypunc <-  as.factor(as.character(cluster_inputs$hypunc))
cluster_inputs$hypc <-  as.factor(as.character(cluster_inputs$hypc))
cluster_inputs$para <-  as.factor(as.character(cluster_inputs$para))
cluster_inputs$ond <-  as.factor(as.character(cluster_inputs$ond))
cluster_inputs$cpd <-  as.factor(as.character(cluster_inputs$cpd))
cluster_inputs$diabunc <-  as.factor(as.character(cluster_inputs$diabunc))
cluster_inputs$diabc <-  as.factor(as.character(cluster_inputs$diabc))
cluster_inputs$hypothy <-  as.factor(as.character(cluster_inputs$hypothy))
cluster_inputs$rf <-  as.factor(as.character(cluster_inputs$rf))
cluster_inputs$ld <-  as.factor(as.character(cluster_inputs$ld))
cluster_inputs$pud <-  as.factor(as.character(cluster_inputs$pud))
cluster_inputs$aids <-  as.factor(as.character(cluster_inputs$aids))
cluster_inputs$lymph <-  as.factor(as.character(cluster_inputs$lymph))
cluster_inputs$metacanc <-  as.factor(as.character(cluster_inputs$metacanc))
cluster_inputs$solidtum <-  as.factor(as.character(cluster_inputs$solidtum))
cluster_inputs$rheumd <-  as.factor(as.character(cluster_inputs$rheumd))
cluster_inputs$coag <-  as.factor(as.character(cluster_inputs$coag))
cluster_inputs$obes <-  as.factor(as.character(cluster_inputs$obes))
cluster_inputs$wloss <-  as.factor(as.character(cluster_inputs$wloss))
cluster_inputs$fed <-  as.factor(as.character(cluster_inputs$fed))
cluster_inputs$blane <-  as.factor(as.character(cluster_inputs$blane))
cluster_inputs$dane <-  as.factor(as.character(cluster_inputs$dane))
cluster_inputs$alcohol <-  as.factor(as.character(cluster_inputs$alcohol))
cluster_inputs$drug <-  as.factor(as.character(cluster_inputs$drug))
cluster_inputs$psycho <-  as.factor(as.character(cluster_inputs$psycho))
cluster_inputs$depre <-  as.factor(as.character(cluster_inputs$depre))


cluster_inputs$PATIENT_GENDER <-  as.factor(as.character(cluster_inputs$PATIENT_GENDER))
cluster_inputs$PLACE_OF_SERVICE <-  as.factor(as.character(cluster_inputs$PLACE_OF_SERVICE))
cluster_inputs$PRODUCT_LINE_ID <-  as.factor(as.character(cluster_inputs$PRODUCT_LINE_ID))


attr(cluster_inputs, "label") <- NULL


#glm GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG



nfolds = 10

glm2 <- h2o.glm( x = predictors,
                 y = response,
                 training_frame = train,
                 family = "gausian",
                 lambda_search = TRUE,
                 standardize = TRUE,
                 nfolds = nfolds,
                 seed = 77)

print(glm2)
summary(glm2)


pred_glm2 <- h2o.performance(glm2, newdata = test,  valid = TRUE)

summary(pred_glm2)
pred_glm2@model$coefficients
pred_glm2@model$coefficients_table
pred_glm2@model$standardized_coefficients_magnitudes
pred_glm2

# repeat without log transofrmations and let H2O do standardize












# score new feed

foo
data_to_score <- as.h2o(cluster_inputs)

rf_95<- h2o.loadModel("/home/dless1/BCBSMN/rf_2/DRF_model_R_1543339224218_3891")

pred <- h2o.predict(object = rf_95, newdata = data_to_score)


pred_df <- as.data.frame(pred)

my_threshold <- .5
pred_df[,"predict"] <- pred_df[,"p0"] >= my_threshold




cl_ids <- base_log %>%
  select(CLAIM_ID) 


#cl_ids <- sqldf("select CLAIM_ID, OVP from base_table8  ")


claim_probabilities <- cbind(cl_ids,pred_df )

claims_to_investigate <- sqldf("select distinct d.CLAIM_ID as CLAIM_CLAIM_ID, d.CLAIM_NO as CLAIM_CLAIM_NO ,
d.AMT_PAID,  c.*
                               from claim_probabilities c, base_log d
                               where d.CLAIM_ID = c.CLAIM_ID ")


claims_to_investigate <- sqldf("select * from claim_probabilities where predict = TRUE order by p1 asc")


write.csv(claims_to_investigate, file = "claims_to_investigate_kaiser263.csv")
saveRDS(claims_to_investigate, file="kaiser263.Rda")

#claims_to_investigate <- readRDS(file="hipny198.Rda")
claims_to_investigate$CLAIM_FEED_ID <- 263
claims_to_investigate_claims<-sqldf("select CLAIM_CLAIM_ID,CLAIM_FEED_ID,
AMT_PAID as CLAIM_AMT_PAID,p0 ,p1 
                                    from claims_to_investigate group by 
                                    CLAIM_CLAIM_ID,CLAIM_NO,CLAIM_FEED_ID,CLAIM_AMT_PAID,p0,p1")

# check connnection

conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
                         UID=COBUnixToSQL;PWD=Q438IerK@u9D')

sqlSave(conn1,claims_to_investigate_claims,tablename="dbo.hipny_COPDM_Feed263",rownames=FALSE)



































table(cluster_inputs$c2c_hit)
prop.table(table(cluster_inputs$c2c_hit))

#0          1 
#0.98385327 0.01614673


cluster_inputs_h2o <- as.h2o((cluster_inputs))

splits <- h2o.splitFrame(cluster_inputs_h2o, c(0.7), seed = 77)
train <- h2o.assign(splits[[1]], "train.hex")
test <- h2o.assign(splits[[2]], "test.hex")

y <- "c2c_hit"
x <- setdiff(names(train), y)

response <- "c2c_hit"
train[[response]] <- as.factor(train[[response]])
predictors <- setdiff(colnames(train),response)


gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10, seed = 77)
h2o.varimp(gbm)


summary(gbm)
# as dataframe - if works put st end of all models
head(as.data.frame(h2o.varimp(gbm)),n=20)
#h2o.varimp_plot(gbm)
# AUC if works add to all models
#h2o.auc(gbm,valid=TRUE)


gbm@model$validation_metrics
h2o.confusionMatrix(gbm,valid=TRUE)
h2o.hit_ratio_table(gbm,valid = T)[1,2]

pred_gbm <- h2o.performance(gbm, newdata = test)
pred_gbm


gbm_2a <- h2o.gbm(x= predictors, y=response, training_frame = train, validation_frame = test, nfolds = 10)

summary(gbm_2a)

head(as.data.frame(h2o.varimp(gbm_2a)),n=10)





# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 10
)

summary(gbm2)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
head(as.data.frame(h2o.varimp(gbm2)),n=10)



h2o.confusionMatrix(gbm2,valid=TRUE)




# GBM GRID
# gbm using hper parameter search
hyper_params = list(max_depth = seq(1,29,2))

grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = list(strategy = "Cartesian"),
  algorithm = "gbm",
  grid_id = "depth_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 200,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  stopping_rounds =5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10
)
grid
# sort grid models be creasing AUC
sortedGrid <- h2o.getGrid("depth_grid", sort_by="auc", decreasing = TRUE)
sortedGrid

# find the range of max_depth for the top 5 models
topDepths = sortedGrid@summary_table$max_depth[1:5]
minDepth = min(as.numeric(topDepths))
maxDepth = max(as.numeric(topDepths))
minDepth
maxDepth

#  includes balance classes = TRUE for low signal

hyper_params = list(
  max_depth = seq(minDepth, maxDepth, 1),
  sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate_per_tree = seq(0.2, 1, 0.01),
  col_sample_rate_change_per_level = seq(0.9, 1.1, 0.01),
  min_rows = 2^seq(0, log2(nrow(train)) - 1, 1),
  nbins = 2^seq(4, 10, 1),
  nbins_cats = 2^seq(4, 12, 1),
  min_split_improvement = c(0, 1e-8, 1e-6, 1e-4),
  balance_classes = c(TRUE, FALSE),
  histogram_type = c("UniformAdaptive", "QuantilesGlobal", "RoundRobin")
  
)

search_criteria = list(
  
  strategy = "RandomDiscrete",
  max_runtime_secs = 36000,
  max_models = 100,
  seed = 77,
  stopping_rounds = 5,
  stopping_metric = "AUC",
  stopping_tolerance = 1e-3
)

# if try different parametrs - change grid_id each time
grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = search_criteria,
  algorithm = "gbm",
  grid_id = "final_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  max_runtime_secs = 360,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10,
  seed = 77
)

##### from h2o tutorials in rclas h20 folder
# sort grid models by AUC
sortedGrid <- h2o.getGrid("final_grid", sort_by = "auc", decreasing = TRUE)
print(sortedGrid)

summary(grid)


#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


# Random Forest

nfolds = 10

rf <- h2o.randomForest( x = predictors,
                        y = response,
                        training_frame = train,
                        ntrees = 500,
                        nfolds = nfolds,
                        fold_assignment = "Modulo",
                        keep_cross_validation_predictions = TRUE,
                        seed = 77)


summary(rf)


head(as.data.frame(h2o.varimp(rf)),n=10)

pred_rf <- h2o.performance(rf, newdata = test,  valid = TRUE)

summary(pred_rf)
pred_rf@model$validation_metrics
pred_rf




rf_2 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         ntrees = 500,
                         nfolds = nfolds,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)
summary(rf_2)


#"/home/dless1/BCBSMN/rf_2/DRF_model_R_1543339224218_3891"



pred_rf_2 <- h2o.performance(rf_2, newdata = test,  valid = TRUE)
pred_rf_2
h2o.varimp(rf_2)

head(as.data.frame(h2o.varimp(pred_rf)),n=10)
#h2o.saveModel(rf_2, path = "rf_2", force =TRUE)
#"/home/dless1/kaiser/rf_2/DRF_model_R_1613561018570_620"




# xgboost

nfolds <- 10
xgboost <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 200,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost)

head(as.data.frame(h2o.varimp(xgboost)),n=10)
h2o.varimp_plot(xgboost)

#h2o.saveModel(xgboost, path = "xgboost", force =TRUE)




nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 200,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 200,
                            nfolds = nfolds,
                            sample_rate = 0.85,
                            fold_assignment = "Modulo",
                            stopping_tolerance = 1e-2,
                            stopping_rounds = 2,
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)

solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id))


#h2o.saveModel(ensemble, path = "ensemble", force =TRUE)

#"/home/dless1/BCBSMN/ensemble/ensemble_binomial"



perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_solo_dl))

ensemble_auc_test <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
pred_ensemble