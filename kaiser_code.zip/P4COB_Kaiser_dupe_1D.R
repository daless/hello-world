


setwd("~/kaiser")


library(comorbidity)
library(RODBC)
library(sqldf)

#library(h2o)
#h2o.init(port=54333)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)




conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=AIMDB10.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')

unkmem <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)",
  max=50)

str(unkmem,list.len = ncol(unkmem))


# rule_meta_data <-  sqlQuery(
#   conn,
#   "SELECT distinct p.PRIMACY_RULE_NUM , p.PRIMACY_RULE_DESC from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
#   where p.PRIMACY_RULE != 'NONE'
#   and p.SECONDARY_PAYER_NAME like'%Kaiser%'
#   and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
#   ",
#   max=50)
# 
# # exlude birthday rule and medicaid rule
# unkmem <- sqlQuery(
#   conn,
#   "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
#   where p.PRIMACY_RULE != 'NONE'
#   and p.SECONDARY_PAYER_NAME like'%Kaiser%'
#   and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
#   and p.PRIMACY_RULE != '2'
#   and p.PRIMACY_RULE ! = '9'
#   ",
#   max=50)

kieser_c2c <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
  where p.PRIMACY_RULE != 'NONE'
  and p.SECONDARY_PAYER_NAME like'%Kaiser%'
  and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
  and p.PRIMACY_RULE != '2'
  and p.PRIMACY_RULE ! = '9'
  ")




Kon = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=DBSWP0627.AIMHEALTH.COM;UID=COBUnixToSQL;PWD=Q438IerK@u9D')


# junk <- sqlQuery(
#   Kon,
#   "select CLAIM_NO from Racer01169.DBO.CLAIM", max=10)

#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01169.DBO.CLAIM where FEED_ID != 999")

tapestry_claim1 <- sqlQuery(
  Kon,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,
CLM.AMT_COB_PAID,
CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,

MEM.member_ID,MEM.MEMBER_NO, MEM.DATE_EFFECTIVE

FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID

where CLM.FEED_ID between 225 and 237")


tapestry_claim1 <- data.frame(r_index = row.names(tapestry_claim1), tapestry_claim1)
tapestry_claim1$r_index <- as.numeric(as.character(tapestry_claim1$r_index )) 

# targets
tapestry_dupes <- sqldf("select c.*, k.SECOND_CARRIER_MEMBER_NO from kieser_c2c k, tapestry_claim1 c
                        where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO")
  
# commercial project id

# commerical only had 7 hits
# probably legacy data --- exclude
#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01314.DBO.CLAIM where FEED_ID != 999")


base1 <- tapestry_claim1




mem_enroll_date <- sqldf("select MEMBER_NO, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE from base1

               group by MEMBER_NO")


base1 <- sqldf("select b.*, m.max_DATE_EFFECTIVE from base1 b left join mem_enroll_date m
               on b.MEMBER_NO = m.MEMBER_NO
               group by b.CLAIM_ID")



base1 <- sqldf(
  "select DISTINCT *
FROM base1
WHERE PATIENT_AGE <=64
and AMT_PAID >0
  ")


# convert to date format

base1$enroll_date <-as.POSIXct(base1$max_DATE_EFFECTIVE, origin="1970-01-01")
base1$admit_date <-as.POSIXct(base1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
base1$member_months <-(difftime(base1$admit_date , base1$enroll_date, units = "days"  ))/30.42
base1a <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base1
where member_months > 0
                             group by PATIENT_ID
                 ")


#rm(tapestry_claim1)
#rm(base1)


DX_claim_tapestry  <- sqlQuery(
  Kon,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
  INNER JOIN Racer01169.DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CLM.FEED_ID between 225 and 237
  AND  DX.ORDER_IN_CLAIM <= 5
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)


DX_claim <- sqldf("select d.* from DX_claim_tapestry d, base1 b
                  where d.CLAIM_ID = b.CLAIM_ID")
  
rm( DX_claim_tapestry)
DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")




# non dupes - - control group

charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL


base2 <- sqldf("select distinct b.*, c.wscore as charls_score from charlson_scores c,
               base1 b where 
               b.CLAIM_ID = c.CLAIM_ID", method = "name_class")


elixhauser_scores$CLAIM_IDx <- as.numeric(elixhauser_scores$CLAIM_ID)

base2 <- sqldf("select distinct b.*, c.* from elixhauser_scores c,
               base2 b where 
               b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")

base2$CLAIM_IDx <- NULL
base2$score <- NULL
base2$index <- NULL
base2$windex_ahrq <- NULL
base2$windex_vw <- NULL



# flag c2c hits for target


base3_0 <- sqldf("select distinct  c.*, k.SECOND_CARRIER_MEMBER_NO from base2 c , kieser_c2c k  
                       where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO")

base3_0 <- sqldf("select SECOND_CARRIER_MEMBER_NO , MEMBER_NO as indexy from tapestry_dupes")

library(dplyr)

base3 <- dplyr::left_join(base2, tapestry_dupes, by = c("MEMBER_NO" = "SECOND_CARRIER_MEMBER_NO"))



base3 <- dplyr::left_join(base2, base3_0, by = c("r_index" = "r_index"))


base3_0 <- sqldf("select distinct c.* from base2 c inner join tapestry_dupes k  
                       on c.r_index = k.r_index")

base3_0$c2c_hit<- 1

base3_id <- sqldf("select distinct r_index from base3_0")


base3 <- dplyr::anti_join(base2, base3_id, by = c("r_index" = "r_index"))

base3$c2c_hit<- 0

base4 <- rbind(base3_0,base3)

base4$CLAIM_ID..43 <- NULL


non_refund_members <- sqldf("select distinct * from base4 where c2c_hit = 0")

non_refund_members0 <- sqldf("select PATIENT_ID, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE 
                             from base4 where c2c_hit = 0 group by PATIENT_ID")
non_refund_members1 <- sqldf("select distinct n.*,m.max_DATE_EFFECTIVE from non_refund_members0 m,  non_refund_members n
                             where m.PATIENT_ID= n.PATIENT_ID")

# convert to date format
non_refund_members1$enroll_date <-as.POSIXct(non_refund_members1$max_DATE_EFFECTIVE, origin="1970-01-01")
non_refund_members1$admit_date <-as.POSIXct(non_refund_members1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
non_refund_members1$member_months <-(difftime(non_refund_members1$admit_date , non_refund_members1$enroll_date, units = "days"  ))/30.42
non_refund_members2 <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from non_refund_members1
                             group by PATIENT_ID")


refmem <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base4 where  c2c_hit = 1
                             group by PATIENT_ID")

refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as ref_cnt, 
avg(first_mm) as mean_mm from
refmem  group by INS_GROUP_ID order by ref_cnt desc" )



non_refund_members_cnt <- sqldf("select INS_GROUP_ID, count(INS_GROUP_ID) as non_ref_cnt, 
avg(first_mm) as non_mean_mm from
non_refund_members2  group by INS_GROUP_ID order by non_ref_cnt desc" )

groupid_ratio <- sqldf("select r.*, n.non_ref_cnt,n.non_mean_mm   from non_refund_members_cnt n, 
                       refund_members_cnt r where r.INS_GROUP_ID = n.INS_GROUP_ID")

groupid_ratio$groupid_refund_rate <- (groupid_ratio$ref_cnt / groupid_ratio$non_ref_cnt) *1000

# a positive number means that the refunds were newer members
groupid_ratio$member_month_delta <- as.numeric(groupid_ratio$non_mean_mm -  groupid_ratio$mean_mm)

base5 <- sqldf("select b.*, g.groupid_refund_rate, g.member_month_delta from base4 b , groupid_ratio g
               where b.INS_GROUP_ID = g.INS_GROUP_ID", method = "name_class")


base5$ratio_billed_to_paid<-(base5$AMT_BILLED + 1 )/(base5$AMT_PAID +1 )
base5$ratio_allowed_to_paid<-(base5$AMT_ALLOWED +1 ) /(base5$AMT_PAID +1)

base5$PLACE_OF_SERVICE<- ifelse(is.na(base5$PLACE_OF_SERVICE), 0, 
                                base5$PLACE_OF_SERVICE)

base5$BILL_TYPE<- ifelse(base5$BILL_TYPE == '', "0", base5$BILL_TYPE)

saveRDS(base4, file="base4.Rda")
saveRDS(base5, file="base5.Rda")
#base5 <- readRDS(file="base5.Rda")


rm(base1)
rm(base1a)
rm(base2)
rm(base3)
rm(base3_0)
rm(non_refund_members1)
rm(charlson_scores)
rm(elixhauser_scores)
rm(tapestry_claim1)



#LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

#str(base5,list.len = ncol(base5))
# log transofrmation



base_log <- base5


cluster_inputs <- base_log

cluster_inputs$PATIENT_AGE <- log10(cluster_inputs$PATIENT_AGE)
cluster_inputs$groupid_refund_rate <- log10(cluster_inputs$groupid_refund_rate)
cluster_inputs$ratio_billed_to_paid <- log10(cluster_inputs$ratio_billed_to_paid)
cluster_inputs$ratio_allowed_to_paid <- log10(cluster_inputs$ratio_allowed_to_paid)

cluster_inputs$charlson <- (cluster_inputs$charls_score - mean(cluster_inputs$charls_score)) / sd(cluster_inputs$charls_score)

cluster_inputs$elixhauser <- (cluster_inputs$wscore_vw  - mean(cluster_inputs$wscore_vw )) / sd(cluster_inputs$wscore_vw )
cluster_inputs$ahrq <- (cluster_inputs$wscore_ahrq  - mean(cluster_inputs$wscore_ahrq )) / sd(cluster_inputs$wscore_ahrq )

cluster_inputs$member_month_delta <- as.numeric(scale(cluster_inputs$member_month_delta))


cluster_inputs$charls_score <- NULL
cluster_inputs$wscore_vw <- NULL
cluster_inputs$r_index <- NULL
cluster_inputs$CLAIM_ID  <- NULL
cluster_inputs$CLAIM_NO <- NULL
cluster_inputs$FEED_ID <- NULL
cluster_inputs$PROJECT_ID <- NULL
cluster_inputs$PATIENT_ID  <- NULL
cluster_inputs$PATIENT_DOB <- NULL
cluster_inputs$DATE_OF_SERVICE_BEG  <- NULL
cluster_inputs$DATE_OF_SERVICE_END <- NULL
cluster_inputs$DATE_ADMITTED <- NULL
cluster_inputs$DATE_DISCHARGED  <- NULL
cluster_inputs$SUBSCRIBER_ID <- NULL
cluster_inputs$SUBSCRIBER_AGE  <- NULL
cluster_inputs$SUBSCRIBER_DOB <- NULL
cluster_inputs$AMT_BILLED <- NULL
cluster_inputs$AMT_ALLOWED  <- NULL
cluster_inputs$AMT_COPAY <- NULL
cluster_inputs$AMT_DEDUCTIBLE <- NULL
cluster_inputs$AMT_COINSURANCE <- NULL
cluster_inputs$AMT_COB_PAID <- NULL
cluster_inputs$AMT_PAID  <- NULL
cluster_inputs$DATE_PAID <- NULL
cluster_inputs$ADJ_CLAIM_FLAG <- NULL
cluster_inputs$Principal_Dx <- NULL
cluster_inputs$SUBSCRB_DOB <- NULL
cluster_inputs$INS_GROUP_ID  <- NULL
cluster_inputs$CLM_DATE_CREATED <- NULL
cluster_inputs$CLM_DATE_UPDATED  <- NULL
cluster_inputs$PROVIDER_ID <- NULL
cluster_inputs$member_ID <- NULL
cluster_inputs$MEMBER_NO <- NULL
cluster_inputs$DATE_EFFECTIVE <- NULL
cluster_inputs$max_DATE_EFFECTIVE <- NULL
cluster_inputs$enroll_date <- NULL
cluster_inputs$admit_date <- NULL
cluster_inputs$member_months <- NULL
cluster_inputs$wscore_ahrq <- NULL
cluster_inputs$chf <-  as.factor(as.character(cluster_inputs$chf))
cluster_inputs$carit <-  as.factor(as.character(cluster_inputs$carit))
cluster_inputs$valv <-  as.factor(as.character(cluster_inputs$valv))
cluster_inputs$pcd <-  as.factor(as.character(cluster_inputs$pcd))
cluster_inputs$pvd <-  as.factor(as.character(cluster_inputs$pvd))
cluster_inputs$hypunc <-  as.factor(as.character(cluster_inputs$hypunc))
cluster_inputs$hypc <-  as.factor(as.character(cluster_inputs$hypc))
cluster_inputs$para <-  as.factor(as.character(cluster_inputs$para))
cluster_inputs$ond <-  as.factor(as.character(cluster_inputs$ond))
cluster_inputs$cpd <-  as.factor(as.character(cluster_inputs$cpd))
cluster_inputs$diabunc <-  as.factor(as.character(cluster_inputs$diabunc))
cluster_inputs$diabc <-  as.factor(as.character(cluster_inputs$diabc))
cluster_inputs$hypothy <-  as.factor(as.character(cluster_inputs$hypothy))
cluster_inputs$rf <-  as.factor(as.character(cluster_inputs$rf))
cluster_inputs$ld <-  as.factor(as.character(cluster_inputs$ld))
cluster_inputs$pud <-  as.factor(as.character(cluster_inputs$pud))
cluster_inputs$aids <-  as.factor(as.character(cluster_inputs$aids))
cluster_inputs$lymph <-  as.factor(as.character(cluster_inputs$lymph))
cluster_inputs$metacanc <-  as.factor(as.character(cluster_inputs$metacanc))
cluster_inputs$solidtum <-  as.factor(as.character(cluster_inputs$solidtum))
cluster_inputs$rheumd <-  as.factor(as.character(cluster_inputs$rheumd))
cluster_inputs$coag <-  as.factor(as.character(cluster_inputs$coag))
cluster_inputs$obes <-  as.factor(as.character(cluster_inputs$obes))
cluster_inputs$wloss <-  as.factor(as.character(cluster_inputs$wloss))
cluster_inputs$fed <-  as.factor(as.character(cluster_inputs$fed))
cluster_inputs$blane <-  as.factor(as.character(cluster_inputs$blane))
cluster_inputs$dane <-  as.factor(as.character(cluster_inputs$dane))
cluster_inputs$alcohol <-  as.factor(as.character(cluster_inputs$alcohol))
cluster_inputs$drug <-  as.factor(as.character(cluster_inputs$drug))
cluster_inputs$psycho <-  as.factor(as.character(cluster_inputs$psycho))
cluster_inputs$depre <-  as.factor(as.character(cluster_inputs$depre))
cluster_inputs$PATIENT_GENDER <-  as.factor(as.character(cluster_inputs$PATIENT_GENDER))
cluster_inputs$PLACE_OF_SERVICE <-  as.factor(as.character(cluster_inputs$PLACE_OF_SERVICE))
cluster_inputs$PRODUCT_LINE_ID <-  as.factor(as.character(cluster_inputs$PRODUCT_LINE_ID))
attr(cluster_inputs, "label") <- NULL
#str(cluster_inputs,list.len = ncol(cluster_inputs))




table(cluster_inputs$c2c_hit)
prop.table(table(cluster_inputs$c2c_hit))

#0          1 
#0.98385327 0.01614673


cluster_inputs_h2o <- as.h2o((cluster_inputs))

splits <- h2o.splitFrame(cluster_inputs_h2o, c(0.7), seed = 77)
train <- h2o.assign(splits[[1]], "train.hex")
test <- h2o.assign(splits[[2]], "test.hex")

y <- "c2c_hit"
x <- setdiff(names(train), y)

response <- "c2c_hit"
train[[response]] <- as.factor(train[[response]])
predictors <- setdiff(colnames(train),response)


gbm <- h2o.gbm(x= predictors, y=response, training_frame = train, nfolds = 10, seed = 77)
h2o.varimp(gbm)


summary(gbm)
# as dataframe - if works put st end of all models
head(as.data.frame(h2o.varimp(gbm)),n=20)
#h2o.varimp_plot(gbm)
# AUC if works add to all models
#h2o.auc(gbm,valid=TRUE)


gbm@model$validation_metrics
h2o.confusionMatrix(gbm,valid=TRUE)
h2o.hit_ratio_table(gbm,valid = T)[1,2]

pred_gbm <- h2o.performance(gbm, newdata = test)
pred_gbm


gbm_2a <- h2o.gbm(x= predictors, y=response, training_frame = train, validation_frame = test, nfolds = 10)

summary(gbm_2a)

head(as.data.frame(h2o.varimp(gbm_2a)),n=10)





# gbm with stochastics to determine best parameters
gbm2 <- h2o.gbm(
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.01,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  balance_classes = TRUE,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  score_tree_interval = 10
)

summary(gbm2)
h2o.auc(h2o.performance(gbm2, valid = TRUE))
head(as.data.frame(h2o.varimp(gbm2)),n=10)



h2o.confusionMatrix(gbm2,valid=TRUE)




# GBM GRID
# gbm using hper parameter search
hyper_params = list(max_depth = seq(1,29,2))

grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = list(strategy = "Cartesian"),
  algorithm = "gbm",
  grid_id = "depth_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 200,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  sample_rate = 0.8,
  col_sample_rate = 0.8,
  seed = 77,
  stopping_rounds =5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10
)
grid
# sort grid models be creasing AUC
sortedGrid <- h2o.getGrid("depth_grid", sort_by="auc", decreasing = TRUE)
sortedGrid

# find the range of max_depth for the top 5 models
topDepths = sortedGrid@summary_table$max_depth[1:5]
minDepth = min(as.numeric(topDepths))
maxDepth = max(as.numeric(topDepths))
minDepth
maxDepth

#  includes balance classes = TRUE for low signal

hyper_params = list(
  max_depth = seq(minDepth, maxDepth, 1),
  sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate = seq(0.2, 1, 0.01),
  col_sample_rate_per_tree = seq(0.2, 1, 0.01),
  col_sample_rate_change_per_level = seq(0.9, 1.1, 0.01),
  min_rows = 2^seq(0, log2(nrow(train)) - 1, 1),
  nbins = 2^seq(4, 10, 1),
  nbins_cats = 2^seq(4, 12, 1),
  min_split_improvement = c(0, 1e-8, 1e-6, 1e-4),
  balance_classes = c(TRUE, FALSE),
  histogram_type = c("UniformAdaptive", "QuantilesGlobal", "RoundRobin")
  
)

search_criteria = list(
  
  strategy = "RandomDiscrete",
  max_runtime_secs = 36000,
  max_models = 100,
  seed = 77,
  stopping_rounds = 5,
  stopping_metric = "AUC",
  stopping_tolerance = 1e-3
)

# if try different parametrs - change grid_id each time
grid <- h2o.grid(
  hyper_params = hyper_params,
  search_criteria = search_criteria,
  algorithm = "gbm",
  grid_id = "final_grid",
  x = predictors,
  y = response,
  training_frame = train,
  validation_frame = test,
  ntrees = 100,
  learn_rate = 0.05,
  learn_rate_annealing = 0.99,
  max_runtime_secs = 360,
  stopping_rounds = 5,
  stopping_tolerance = 1e-4,
  stopping_metric = "AUC",
  score_tree_interval = 10,
  seed = 77
)

##### from h2o tutorials in rclas h20 folder
# sort grid models by AUC
sortedGrid <- h2o.getGrid("final_grid", sort_by = "auc", decreasing = TRUE)
print(sortedGrid)

summary(grid)


#RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR


# Random Forest

nfolds = 10

rf <- h2o.randomForest( x = predictors,
                        y = response,
                       training_frame = train,
                       ntrees = 500,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       seed = 77)


summary(rf)


head(as.data.frame(h2o.varimp(rf)),n=10)

pred_rf <- h2o.performance(rf, newdata = test,  valid = TRUE)

summary(pred_rf)
pred_rf@model$validation_metrics
pred_rf




rf_2 <- h2o.randomForest(x=x,
                         y = y,
                         training_frame = train,
                         ntrees = 500,
                         nfolds = nfolds,
                         sample_rate = 0.85,
                         fold_assignment = "Modulo",
                         stopping_tolerance = 1e-2,
                         stopping_rounds = 2,
                         keep_cross_validation_predictions = TRUE,
                         seed = 77)
summary(rf_2)


#"/home/dless1/BCBSMN/rf_2/DRF_model_R_1543339224218_3891"



pred_rf_2 <- h2o.performance(rf_2, newdata = test,  valid = TRUE)
pred_rf_2
h2o.varimp(rf_2)

head(as.data.frame(h2o.varimp(pred_rf)),n=10)
#h2o.saveModel(rf_2, path = "rf_2", force =TRUE)
#"/home/dless1/kaiser/rf_2/DRF_model_R_1613561018570_620"




# xgboost

nfolds <- 10
xgboost <- h2o.xgboost(x=x,
                       y = y,
                       training_frame = train,
                       validation_frame = test,
                       ntrees = 200,
                       nfolds = nfolds,
                       fold_assignment = "Modulo",
                       keep_cross_validation_predictions = TRUE,
                       max_depth = 3,
                       min_rows = 2,
                       learn_rate =0.2,
                       seed = 77)

summary(xgboost)

head(as.data.frame(h2o.varimp(xgboost)),n=10)
h2o.varimp_plot(xgboost)

#h2o.saveModel(xgboost, path = "xgboost", force =TRUE)




nfolds = 10

solo_gbm <- h2o.gbm(
  x = x,
  y = y,
  training_frame = train,
  distribution = "bernoulli",
  ntrees = 200,
  max_depth = 29,
  min_rows = 17,
  learn_rate = 0.2,
  nfolds = nfolds,
  fold_assignment = "Modulo",
  keep_cross_validation_predictions = TRUE,
  seed = 77
)

solo_rf <- h2o.randomForest(x=x,
                            y = y,
                            training_frame = train,
                            ntrees = 200,
                            nfolds = nfolds,
                            sample_rate = 0.85,
                            fold_assignment = "Modulo",
                            stopping_tolerance = 1e-2,
                            stopping_rounds = 2,
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)


# shallow
solo_xgboost1 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 3,
                             min_rows = 2,
                             learn_rate =0.2,
                             seed = 77)
# deepeer
solo_xgboost2 <- h2o.xgboost(x=x,
                             y = y,
                             training_frame = train,
                             ntrees = 200,
                             nfolds = nfolds,
                             fold_assignment = "Modulo",
                             keep_cross_validation_predictions = TRUE,
                             max_depth = 11,
                             min_rows = 1,
                             learn_rate =0.1,
                             sample_rate = 0.7,
                             col_sample_rate = 0.9,
                             seed = 77)

solo_dl <- h2o.deeplearning(x=x,
                            y = y,
                            training_frame = train,
                            l1 = 0.001,
                            l2 = 0.001,
                            hidden = c(200,100,200),
                            nfolds = nfolds,
                            fold_assignment = "Modulo",
                            keep_cross_validation_predictions = TRUE,
                            seed = 77)

ensemble <- h2o.stackedEnsemble(x=x,
                                y=y,
                                training_frame = train,
                                model_id = "ensemble_binomial",
                                base_models = list(solo_gbm@model_id, solo_rf@model_id,solo_xgboost1@model_id,
                                                   solo_xgboost1@model_id, solo_dl@model_id))


#h2o.saveModel(ensemble, path = "ensemble", force =TRUE)

#"/home/dless1/BCBSMN/ensemble/ensemble_binomial"



perf_gbm_test <-  h2o.performance(solo_gbm, newdata = test)
perf_rf_test <-  h2o.performance(solo_rf, newdata = test)
perf_solo_xgboost1_test <-  h2o.performance(solo_xgboost1, newdata = test)
perf_solo_xgboost2_test <-  h2o.performance(solo_xgboost2, newdata = test)
perf_solo_solo_dl <-  h2o.performance(solo_dl, newdata = test)
perf_ensemble <- h2o.performance(ensemble, newdata = test)


baselearner_best_auc_test <- max(h2o.auc(perf_gbm_test), h2o.auc(perf_rf_test),  h2o.auc(perf_solo_xgboost1_test),
                                 h2o.auc(perf_solo_xgboost2_test),h2o.auc(perf_solo_solo_dl))

ensemble_auc_test <- h2o.auc(perf_ensemble)
print(sprintf("Best Base-learner Test AUC: %s", baselearner_best_auc_test))
print(sprintf("Ensemble Test AUC:  %s", ensemble_auc_test))

pred_ensemble <- h2o.predict(ensemble, newdata = test)
pred_ensemble