



setwd("~/kaiser")


library(comorbidity)
library(RODBC)
library(sqldf)

#library(h2o)
#h2o.init(port=54333)
#library(h2oEnsemble)

#h2o.shutdown(prompt  = FALSE)


# determine dup prevalance rate by groupi id


conn = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=AIMDB10.aimhealth.com;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)

kieser_c2c <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
  where p.PRIMACY_RULE != 'NONE'
  and p.SECONDARY_PAYER_NAME like'%Kaiser%'
  and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
  and p.PRIMACY_RULE != '2'
  and p.PRIMACY_RULE ! = '9'
  and DATEDIFF(D,  p.OVERLAP_START_DATE, GETDATE()) < 720
  "
)




Kon = odbcDriverConnect(
  'DRIVER={ODBCSQLSvr};SERVER=DBSWP0627.AIMHEALTH.COM;UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3'
)


# feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01169.DBO.CLAIM where FEED_ID != 999")
# feedsll <- sqlQuery(Kon, "select distinct DATE_CREATED, FEED_ID from   Racer01169.DBO.CLAIM where FEED_ID > 263")

prevalnce1 <- sqlQuery(
  Kon,
  "select  distinct CLM.INS_GROUP_ID,MEM.MEMBER_NO
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where  CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720"
)


baseline_mem_counts_by_insur_id <-
  sqldf(
    "select INS_GROUP_ID, count(MEMBER_NO) as mem_cnt
                     from prevalnce1
                     where INS_GROUP_ID != 0
                     group by INS_GROUP_ID
                                         "
  )


tapestry_dupes0 <-
  sqldf(
    "select c.*, k.SECOND_CARRIER_MEMBER_NO from kieser_c2c k, prevalnce1 c
                        where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO"
  )

tapestry_dupes00 <-
  sqldf(
    "select INS_GROUP_ID, count(MEMBER_NO) as dupe_mem_cnt
from tapestry_dupes0
where INS_GROUP_ID != 0
                     group by INS_GROUP_ID"
  )


baseline_mem_counts_by_insur_id2 <-
  sqldf(
    "select b.*, t.dupe_mem_cnt
                                          from baseline_mem_counts_by_insur_id b left join tapestry_dupes00 t
                                          on b.INS_GROUP_ID = t.INS_GROUP_ID
                                          "
  )

baseline_mem_counts_by_insur_id2$dupe_mem_cnt <-
  ifelse(
    is.na(baseline_mem_counts_by_insur_id2$dupe_mem_cnt),
    0,
    baseline_mem_counts_by_insur_id2$dupe_mem_cnt
  )

baseline_mem_counts_by_insur_id2$groupid_refund_rate <-
  baseline_mem_counts_by_insur_id2$dupe_mem_cnt /
  baseline_mem_counts_by_insur_id2$mem_cnt

# remove those with more hits han in total group id
baseline_mem_counts_by_insur_id2 <-
  sqldf("select * from baseline_mem_counts_by_insur_id2 where groupid_refund_rate <=1")



# MMMMMMMMMMMMMMMMMMMMMMMMM

# member month calculations all members in study group


enrollment <- sqlQuery(
  Kon,
  "select  distinct MEM.MEMBER_NO,  MEM.DATE_EFFECTIVE, CLM.DATE_OF_SERVICE_BEG
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720"
)

enrollment2 <- sqldf("select MEMBER_NO, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE, 
                     max(DATE_OF_SERVICE_BEG) as max_DATE_OF_SERVICE_BEG
                     from enrollment
                     group by MEMBER_NO")


enrollment2$enroll_date <-as.POSIXct(enrollment2$max_DATE_EFFECTIVE, origin="1970-01-01")
enrollment2$admit_date <-as.POSIXct(enrollment2$max_DATE_OF_SERVICE_BEG, origin="1970-01-01")
enrollment2$member_months <-(difftime(enrollment2$admit_date ,enrollment2$enroll_date, units = "days"  ))/30.42
enrollment3 <- sqldf("select MEMBER_NO, min(member_months) as first_mm from enrollment2
where member_months > 0
                             group by MEMBER_NO
                 ")


# free up disk space
rm(enrollment)
rm(enrollment2)



# go back 1 year to get hx groupid and mem month data
# for model filter latest feed
# and c2c hit = 0



tapestry_claim1 <- sqlQuery(
  Kon,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,
CLM.AMT_COB_PAID,
CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,

MEM.member_ID,MEM.MEMBER_NO, MEM.DATE_EFFECTIVE, MEM.ZIP

FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID

where PATIENT_AGE <=64 
and AMT_PAID >0
 and  DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 620")



tapestry_claim1 <- data.frame(r_index = row.names(tapestry_claim1), tapestry_claim1)
tapestry_claim1$r_index <- as.numeric(as.character(tapestry_claim1$r_index )) 





DX_claim_tapestry  <- sqlQuery(
  Kon,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
  INNER JOIN Racer01169.DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
WHERE CLM.FEED_ID=292
  AND  DX.ORDER_IN_CLAIM <= 5
   and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 180
   and CLM.PATIENT_AGE <=64
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)


DX_claim <- sqldf("select d.* from DX_claim_tapestry d, tapestry_claim1 b
                  where d.CLAIM_ID = b.CLAIM_ID")

rm(DX_claim_tapestry)
DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

saveRDS(charlson_scores, file="charlson_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")

# charlson_scores <- readRDS(file="charlson_scores.Rda")
# elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")



charlson_scores$CLAIM_ID <- as.integer(charlson_scores$CLAIM_ID)
attr(charlson_scores, "label") <- NULL
elixhauser_scores$CLAIM_IDx <- as.numeric(elixhauser_scores$CLAIM_ID)



base2 <- sqldf("select distinct b.*, c.wscore as charls_score from charlson_scores c,
               tapestry_claim1 b where 
               b.CLAIM_ID = c.CLAIM_ID", method = "name_class")


rm(tapestry_claim1)

base2 <- sqldf("select distinct b.*, c.score as elix_score, c.wscore_ahrq from elixhauser_scores c,
               base2 b where 
               b.CLAIM_ID = c.CLAIM_IDx", method = "name_class")


base2$ratio_billed_to_paid<-(base2$AMT_BILLED + 1 )/(base2$AMT_PAID +1 )
base2$ratio_allowed_to_paid<-(base2$AMT_ALLOWED +1 ) /(base2$AMT_PAID +1)

# find max values by member

base3 <- sqldf("select MEMBER_NO, INS_GROUP_ID, max(charls_score) as max_charls_score,
               max(elix_score) as max_elix_score,
               max(wscore_ahrq) as max_wscore_ahrq,
               max(ratio_billed_to_paid) as max_ratio_billed_to_paid,
               max(ratio_allowed_to_paid) as max_ratio_allowed_to_paid
               from base2 
               where ratio_billed_to_paid < 5
               and ratio_allowed_to_paid < 5
               group by MEMBER_NO
               ", method = "name_class")


base4 <- sqldf("select b.*, e.first_mm as member_months from  base3 b, enrollment3 e
               where e.MEMBER_NO = b.MEMBER_NO")


base4 <-  sqldf("select b.*, m.groupid_refund_rate, m.mem_cnt as number_members_in_group
from baseline_mem_counts_by_insur_id2 m,
                base4 b
                where b.INS_GROUP_ID = m.INS_GROUP_ID")


#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
# add external data

ext_data1 <- sqlQuery(
  Kon,
  "select  distinct MEM.MEMBER_NO,  MEM.ZIP
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720
  and MEM.ZIP != ''")


# code to copy flat  files
# scp dless1@apsrd9425:/home/dless1/kaiser/analytic_data2020_0_tab.txt ~Desktop
# scp dless1@apsrd9425:/home/dless1/kaiser/FIPS_tab.txt ~Desktop
# scp dless1@apsrd9425:/home/dless1/kaiser/USDA.txt ~Desktop

county_hlth  <- read.csv("analytic_data2020_0_tab.txt", header=TRUE, sep="\t")
FIPS  <- read.csv("FIPS_tab.txt", header=TRUE, sep="\t")
USDA  <- read.csv("USDA.txt", header=TRUE, sep="\t")


ext_data2 <- sqldf("select v.*, f.COUNTY from FIPS f, ext_data1 v
                 where v.ZIP = f.zip")

ext_data2 <- sqldf("select v.*, f.RUCC_2013 as USDA_urban_rural from USDA f, ext_data2 v
                 where v.COUNTY = f.FIPS")

# #rename
names(county_hlth)[3] <- 'long_fips'
names(county_hlth)[140] <- 'physician_rate'
names(county_hlth)[152] <- 'MH_providers'
names(county_hlth)[8] <- 'premature_death'
names(county_hlth)[397] <- 'diabetes_preval'
names(county_hlth)[477] <- 'ratio_PCP_other'


county_hlth2 <- sqldf("select long_fips,
physician_rate,
                       premature_death,
                       MH_providers,
                      diabetes_preval,
                      ratio_PCP_other
                      from county_hlth
                      where long_fips !='0' ")

ext_data2 <- sqldf("select v.*, 
c.physician_rate,
                       c.premature_death,
                       c.MH_providers,
                      c.diabetes_preval,
                      c.ratio_PCP_other
                      from ext_data2 v, county_hlth2 c
                 where v.COUNTY = c.long_fips")


ext_data2$physician_rate <- as.numeric(as.character(ext_data2$physician_rate))
ext_data2$premature_death <- as.numeric(as.character(ext_data2$premature_death))
ext_data2$MH_providers <- as.numeric(as.character(ext_data2$MH_providers))
ext_data2$diabetes_preval <- as.numeric(as.character(ext_data2$diabetes_preval))
ext_data2$ratio_PCP_other <- as.numeric(as.character(ext_data2$ratio_PCP_other))

ext_data2$physician_rate <- ifelse(is.na(ext_data2$physician_rate), 0, ext_data2$physician_rate)
ext_data2$premature_death <- ifelse(is.na(ext_data2$premature_death), 0, ext_data2$premature_death)
ext_data2$MH_providers <- ifelse(is.na(ext_data2$MH_providers), 0, ext_data2$MH_providers)
ext_data2$diabetes_preval <- ifelse(is.na(ext_data2$diabetes_preval), 0, ext_data2$diabetes_preval)
ext_data2$ratio_PCP_other <- ifelse(is.na(ext_data2$ratio_PCP_other), 0, ext_data2$ratio_PCP_other)





# filter for most recent feed to score

base5 <- sqldf("select  b.*, e.USDA_urban_rural,
               e.physician_rate,
               e.premature_death,
               e.MH_providers,
               e.diabetes_preval,
               e.ratio_PCP_other
               from base4 b, ext_data2 e
               where b.MEMBER_NO = e.MEMBER_NO
               group by b.MEMBER_NO")


saveRDS(base5, file="base5.Rda")


#base5 <- readRDS(file="base5.Rda")

# remove group ids with < 20 members

base_log <- sqldf("select * from base5 where number_members_in_group < 20
                  and member_months != 'NA' and max_ratio_billed_to_paid < 5
                  and max_ratio_allowed_to_paid < 5
                  ")

summary(base_log)


# filter on olny last 12 feeds


current_feed <- sqlQuery(
  Kon,
  "select  distinct CLM.INS_GROUP_ID,MEM.MEMBER_NO
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where  CLM.PATIENT_AGE < 65
  and DATEDIFF(D,  CLM.DATE_PAID, GETDATE()) < 720"
)

cluster_inputs0 <- sqldf("select distinct b.* from base5 b, current_feed c
                         where c.INS_GROUP_ID = b.INS_GROUP_ID
                         and c.MEMBER_NO = b.MEMBER_NO")
# remove C2C hits


tapestry_dupes00 <-
  sqldf(
    "select distinct c.*, k.SECOND_CARRIER_MEMBER_NO from cluster_inputs0 c left join kieser_c2c k 
                        on c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO"
  )

tapestry_dupes00$SECOND_CARRIER_MEMBER_NO<- ifelse(is.na(tapestry_dupes00$SECOND_CARRIER_MEMBER_NO), '0', 
                                    tapestry_dupes00$SECOND_CARRIER_MEMBER_NO)

base_log2 <- sqldf("select * from tapestry_dupes00 where SECOND_CARRIER_MEMBER_NO  = '0' ")

c2chits <- sqldf("select * from tapestry_dupes00 where SECOND_CARRIER_MEMBER_NO  != '0' ")

f0 <- nrow(base_log)
f <- nrow(c2chits)

precent_c2c <- (f/f0) *100
print(f0)
print(f)
print(precent_c2c)

cluster_inputs <- base_log2

#cluster_inputs$PATIENT_AGE <- sqrt(cluster_inputs$PATIENT_AGE)
cluster_inputs$groupid_refund_rate <- sqrt(cluster_inputs$groupid_refund_rate)
cluster_inputs$max_ratio_billed_to_paid <- log10(cluster_inputs$max_ratio_billed_to_paid)
cluster_inputs$max_ratio_allowed_to_paid <- log10(cluster_inputs$max_ratio_allowed_to_paid)

cluster_inputs$max_charls_score <- (cluster_inputs$max_charls_score - mean(cluster_inputs$max_charls_score)) / sd(cluster_inputs$max_charls_score)

cluster_inputs$max_elix_score <- (cluster_inputs$max_elix_score  - mean(cluster_inputs$max_elix_score )) / sd(cluster_inputs$max_elix_score )

cluster_inputs$member_months <- log10(cluster_inputs$member_months)

cluster_inputs$physician_rate <- log10(cluster_inputs$physician_rate)
cluster_inputs$premature_death <- log10(cluster_inputs$premature_death)
cluster_inputs$MH_providers <- log10(cluster_inputs$MH_providers)
cluster_inputs$ratio_PCP_other <- log10(cluster_inputs$ratio_PCP_other)
cluster_inputs$USDA_urban_rural <- sqrt(cluster_inputs$USDA_urban_rural)
cluster_inputs$MEMBER_NO <- NULL
cluster_inputs$INS_GROUP_ID <- NULL
cluster_inputs$number_members_in_group <- NULL
cluster_inputs$SECOND_CARRIER_MEMBER_NO  <- NULL

summary(cluster_inputs)

# move target to first column
library(dplyr)
cluster_inputs<- cluster_inputs %>% select (groupid_refund_rate, everything())



saveRDS(cluster_inputs, file="cluster_inputs.Rda")


#HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
library(h2o)
h2o.init(port=54333)

#

# score new feed


data_to_score <- as.h2o(cluster_inputs)

# chnge to new subdirectory
rf_95<- h2o.loadModel("/home/dless1/kaiser/xgboost/XGBoost_model_R_1614025114043_1")

pred <- h2o.predict(object = rf_95, newdata = data_to_score)


pred_df <- as.data.frame(pred)

#saveRDS(pred_df, file="pred_df_8_26.Rda")


pred_df$predict <- as.numeric(as.character(pred_df$predict))

pred_df$predict<- ifelse(is.na(pred_df$predict), '0', 
                         pred_df$predict)



cl_ids <- base_log2 %>%
  select(MEMBER_NO) 


claim_probabilities <- cbind(cl_ids,pred_df )

claim_probabilities <- sqldf("select MEMBER_NO, predict as p1 from claim_probabilities where predict > 0")


current_feed <- sqlQuery(
  Kon,
  "select  distinct CLM.CLAIM_ID as CLAIM_CLAIM_ID,CLM.PATIENT_ID,
  CLM.CLAIM_NO as CLAIM_CLAIM_NO ,
  CLM.AMT_PAID,
  MEM.MEMBER_NO,
  MEM.MEMBER_ID,
  CLM.FEED_ID
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID
where CLM.PATIENT_AGE < 65
and CLM.FEED_ID between 283 and 292
  "
  
)



claims_to_investigate  <- sqldf("select distinct c.*, p1 as Model_Score
                               from claim_probabilities p, current_feed c
                               where p.MEMBER_NO = c.MEMBER_NO
                               and p.MEMBER_NO NOT IN ('110014745571NC', '110014745571NC','110012736628NC','110009290382NC',
                               '000004566694SC')
                               order by c.MEMBER_NO desc")



claims_to_investigate$PROJECT_ID = 1169
#write.csv(claims_to_investigate, file = "claims_to_investigate_kaiser268 and 271.csv")
#write.csv(member_cnt, file = "member_cnt_kaiser251_254.csv")
saveRDS(claims_to_investigate, file="kaiser292.Rda")


# check connnection




conn1 = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=dbswp0627.aimhealth.com;database=racerresearch;
                         UID=dsunixtosql;PWD=tzx@LB3id8UCwZ3')



sqlSave(conn1,claims_to_investigate,tablename="dbo.kaiser292",rownames=FALSE)


