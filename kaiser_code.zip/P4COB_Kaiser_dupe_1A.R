


setwd("~/kaiser")


library(comorbidity)
library(RODBC)
library(sqldf)






conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=AIMDB10.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')

unkmem <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)",
  max=50)

str(unkmem,list.len = ncol(unkmem))

unkmem <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
  where p.PRIMACY_RULE != 'NONE'
  and p.SECONDARY_PAYER_NAME ike'%Kaiser%'
  ",
  max=50)


•	Server – AIMDB10.aimhealth.com
•	Database – RacerResearch
•	Table - AAL_C2C_PRIMACY_RESULTS_ARCHIVE


selecttop10*from RacerResearch.dbo.aal_c2c_primacy_results_archive  (nolock)
whereprimacy_rule <> 'NONE'andsecondary_payer_namelike'%Kaiser%'

Server: DBSWP0627.AIMHEALTH.COM
Kaiser Tapestry: 1169
Kaiser Medicare: 1315
Kaiser Commercial: 1314
Kaiser Medicaid: 1316

Query to pull data from C2C

select * from RacerResearch.dbo.aal_c2c_primacy_results_archive  (nolock)
where primacy_rule <> 'NONE' 
and secondary_payer_name like '%Kaiser%'
