


setwd("~/kaiser")


library(comorbidity)
library(RODBC)
library(sqldf)






conn = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=AIMDB10.aimhealth.com;UID=COBUnixToSQL;PWD=Q438IerK@u9D')

unkmem <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)",
  max=50)

str(unkmem,list.len = ncol(unkmem))


# rule_meta_data <-  sqlQuery(
#   conn,
#   "SELECT distinct p.PRIMACY_RULE_NUM , p.PRIMACY_RULE_DESC from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
#   where p.PRIMACY_RULE != 'NONE'
#   and p.SECONDARY_PAYER_NAME like'%Kaiser%'
#   and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
#   ",
#   max=50)
# 
# # exlude birthday rule and medicaid rule
# unkmem <- sqlQuery(
#   conn,
#   "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
#   where p.PRIMACY_RULE != 'NONE'
#   and p.SECONDARY_PAYER_NAME like'%Kaiser%'
#   and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
#   and p.PRIMACY_RULE != '2'
#   and p.PRIMACY_RULE ! = '9'
#   ",
#   max=50)

kieser_c2c <- sqlQuery(
  conn,
  "SELECT  p.* from RacerResearch.DBO.AAL_C2C_PRIMACY_RESULTS_ARCHIVE p  with (nolock)
  where p.PRIMACY_RULE != 'NONE'
  and p.SECONDARY_PAYER_NAME like'%Kaiser%'
  and p.SECONDARY_PAYER_SOURCE_VALUE in(1169, 1315,1314,1316)
  and p.PRIMACY_RULE != '2'
  and p.PRIMACY_RULE ! = '9'
  ")




Kon = odbcDriverConnect('DRIVER={ODBCSQLSvr};SERVER=DBSWP0627.AIMHEALTH.COM;UID=COBUnixToSQL;PWD=Q438IerK@u9D')


# junk <- sqlQuery(
#   Kon,
#   "select CLAIM_NO from Racer01169.DBO.CLAIM", max=10)

#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01169.DBO.CLAIM where FEED_ID != 999")

tapestry_claim1 <- sqlQuery(
  Kon,
  "select DISTINCT CLM.CLAIM_ID,
CLM.CLAIM_NO,
CLM.FEED_ID,
CLM.PROJECT_ID,
CLM.PATIENT_ID,
CLM.PATIENT_AGE,
CLM.PATIENT_DOB,
CLM.PATIENT_GENDER,
CLM.DATE_OF_SERVICE_BEG,
CLM.DATE_OF_SERVICE_END,
CLM.DATE_ADMITTED,
CLM.DATE_DISCHARGED,
CLM.SUBSCRIBER_ID,
CLM.SUBSCRIBER_AGE,
CLM.SUBSCRIBER_DOB,
CLM.BILL_TYPE,
CLM.AMT_BILLED,
CLM.AMT_ALLOWED,
CLM.AMT_COPAY,
CLM.AMT_DEDUCTIBLE,
CLM.AMT_COINSURANCE,
CLM.AMT_COB_PAID,
CLM.AMT_PAID,
CLM.DATE_PAID,
CLM.ADJ_CLAIM_FLAG,
CLM.PRINCIPAL_DIAG as Principal_Dx,
CLM.PLACE_OF_SERVICE,
CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
CLM.INS_GROUP_ID,
CLM.PRODUCT_LINE_ID,
CLM.DATE_CREATED AS CLM_DATE_CREATED,
CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
CLM.PROVIDER_ID,

MEM.member_ID,MEM.MEMBER_NO, MEM.DATE_EFFECTIVE

FROM Racer01169.DBO.CLAIM CLM  with (nolock)
INNER JOIN Racer01169.DBO.MEMBER MEM  with (nolock)
ON CLM.PATIENT_ID = MEM.MEMBER_ID

where CLM.FEED_ID between 225 and 237")


tapestry_dupes <- sqldf("select c.*, k.SECOND_CARRIER_MEMBER_NO from kieser_c2c k, tapestry_claim1 c
                        where c.MEMBER_NO = k.SECOND_CARRIER_MEMBER_NO")
  
# commercial project id

# commerical only had 7 hits
# probably legacy data --- exclude
#feeds <- sqlQuery(Kon, "select max(FEED_ID) as mx from   Racer01314.DBO.CLAIM where FEED_ID != 999")
# 
# commercial_claim1 <- sqlQuery(
#   Kon,
#   "select DISTINCT CLM.CLAIM_ID,
# CLM.CLAIM_NO,
# CLM.FEED_ID,
# CLM.PROJECT_ID,
# CLM.PATIENT_ID,
# CLM.PATIENT_AGE,
# CLM.PATIENT_DOB,
# CLM.PATIENT_GENDER,
# CLM.DATE_OF_SERVICE_BEG,
# CLM.DATE_OF_SERVICE_END,
# CLM.DATE_ADMITTED,
# CLM.DATE_DISCHARGED,
# CLM.SUBSCRIBER_ID,
# CLM.SUBSCRIBER_AGE,
# CLM.SUBSCRIBER_DOB,
# CLM.BILL_TYPE,
# CLM.AMT_BILLED,
# CLM.AMT_ALLOWED,
# CLM.AMT_COPAY,
# CLM.AMT_DEDUCTIBLE,
# CLM.AMT_COINSURANCE,
# CLM.AMT_COB_PAID,
# CLM.AMT_PAID,
# CLM.DATE_PAID,
# CLM.ADJ_CLAIM_FLAG,
# CLM.PRINCIPAL_DIAG as Principal_Dx,
# CLM.PLACE_OF_SERVICE,
# CLM.SUBSCRIBER_DOB AS SUBSCRB_DOB,
# CLM.INS_GROUP_ID,
# CLM.PRODUCT_LINE_ID,
# CLM.DATE_CREATED AS CLM_DATE_CREATED,
# CLM.DATE_UPDATED AS CLM_DATE_UPDATED,
# CLM.PROVIDER_ID,
# 
# MEM.member_ID,MEM.MEMBER_NO, MEM.DATE_EFFECTIVE
# 
# FROM Racer01314.DBO.CLAIM CLM  with (nolock)
# INNER JOIN Racer01314.DBO.MEMBER MEM  with (nolock)
# ON CLM.PATIENT_ID = MEM.MEMBER_ID
# 
# where CLM.FEED_ID between 445 and 457")
# 
# # probably a legacy system
# commerical_dupes <- sqldf("select c.*, k.SECOND_CARRIER_MEMBER_NO from kieser_c2c k, commercial_claim1 c
#                         where c.member_ID = k.SECOND_CARRIER_MEMBER_NO")


base1 <- tapestry_claim1

base1 <- data.frame(r_index = row.names(base1), base1)


mem_enroll_date <- sqldf("select MEMBER_NO, max(DATE_EFFECTIVE) as max_DATE_EFFECTIVE from base1

               group by MEMBER_NO")


base1 <- sqldf("select b.*, m.max_DATE_EFFECTIVE from base1 b left join mem_enroll_date m
               on b.MEMBER_NO = m.MEMBER_NO
               group by b.CLAIM_ID")



base1 <- sqldf(
  "select DISTINCT *
FROM base1
WHERE PATIENT_AGE <=64
and AMT_PAID >0
  ")


# convert to date format

base1$enroll_date <-as.POSIXct(base1$max_DATE_EFFECTIVE, origin="1970-01-01")
base1$admit_date <-as.POSIXct(base1$DATE_OF_SERVICE_BEG, origin="1970-01-01")
base1$member_months <-(difftime(base1$admit_date , base1$enroll_date, units = "days"  ))/30.42
base1a <- sqldf("select INS_GROUP_ID, min(member_months) as first_mm from base1
where member_months > 0
                             group by PATIENT_ID
                 ")


rm(tapestry_claim1)
rm(base1)


DX_claim_tapestry  <- sqlQuery(
  Kon,
  " select
  DISTINCT CLM.CLAIM_ID,
  CLM.CLAIM_NO,
  DX.ICD9_CODE,
  DX.PROJECT_ID,
  DX.ICD9_TYPE,
  DX.ADMITTING_CODE,
  DX.PRINCIPAL_CODE,
  DX.ORDER_IN_CLAIM,
  DX.CLAIM_LINE_ID,
  DX.FEED_ID
  FROM Racer01169.DBO.CLAIM CLM  with (nolock)
  INNER JOIN Racer01169.DBO.ICD9 DX  with (nolock)
  ON CLM.CLAIM_ID = DX.CLAIM_ID
  WHERE CLM.FEED_ID between 225 and 237
  AND  DX.ORDER_IN_CLAIM <= 5
   order by CLM.CLAIM_ID asc, DX.ORDER_IN_CLAIM asc" 
)


DX_claim <- sqldf("select d.* from DX_claim_tapestry d, base1 b
                  where d.CLAIM_ID = b.CLAIM_ID")
  
rm( DX_claim_tapestry)
DX_claim$ICD9_CODE<-as.character(DX_claim$ICD9_CODE)
DX_claim$ICD10_CODE<-DX_claim$ICD9_CODE
DX_claim$ICD9_CODE<-gsub(".","",DX_claim$ICD9_CODE,fixed=TRUE)


#saveRDS(DX_claim, file="DX_claim.Rda")



#DX_claim <- readRDS(file="DX_claim.Rda")



DX_claimids_Diag <- sqldf("select distinct * from DX_claim where ICD9_TYPE='DIAG10'")

charlson_scores<- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "charlson")

#saveRDS(charlson_scores, file="charlson_scores.Rda")
#charlson_scores <- readRDS(file="charlson_scores.Rda")

elixhauser_scores <- comorbidity(x=DX_claimids_Diag , id = "CLAIM_ID",  code = "ICD9_CODE", icd = "icd10", score = "elixhauser")
#saveRDS(elixhauser_scores, file="elixhauser_scores.Rda")
#elixhauser_scores <- readRDS(file="elixhauser_scores.Rda")
